# Esquiva reactiva de Jill y Carlos

**09/10/2026 — Investigación y propuesta. Base funcional: 0.8.0, coop aceptado.**

La habilidad todavía no está implementada ni probada. Esta etapa consulta fuentes
oficiales, recursos locales y código original; no modifica la entrega instalada.

> Actualización posterior del 09/10/2026: el usuario cambió la entrada a **F**
> y autorizó implementar **0.8.1**. El texto de investigación que sigue conserva
> su propuesta original; la implementación actual está resumida al final.

## Petición y referencia RE3R

La petición es doble espacio, voltereta, desplazamiento corto hacia atrás e inmunidad
mínima de un segundo, únicamente ante daño inminente. Debe funcionar con ambos
personajes y con cooperativo.

El [manual oficial de Capcom](https://game.capcom.com/manual/re3/pt-br/ps4/page/2/2)
describe evasión rápida de Jill, menor eficacia al repetirla y evasión perfecta al
actuar justo antes del contacto. Después permite apuntar al punto débil. Carlos
utiliza embestida y contraataque con puñetazo, una acción diferente.

El doble espacio, rodar hacia atrás para ambos personajes y un segundo de inmunidad
son reglas propias del mashup. El manual no publica los frames exactos ni la duración
precisa de invulnerabilidad. No se ha inspeccionado el ejecutable RE3R para determinar
su lógica interna; las cifras propuestas abajo no son medidas oficiales.

## Recursos locales encontrados

El banco actual de cada personaje solo incorpora reposo, caminar y correr. Hay
que añadir pistas de evasión y comprobar su adaptación antes de utilizarlas.

La lectura acotada de listas base encontró **42 candidatos de Jill y 6 de Carlos**:

- Jill: `pl2000_es_0410_KFF_Escape_L0` y variantes L90/L180/R0/R90/R180;
  familias `Escape_Step_Alt01/02/03` y `Escape_Step_Short`.
- En el inventario de Jill también hay variantes de armas `Hold_Escape_B`.
- Carlos: `pl0000_es_0421_KFF_Escape_Step_01`, `0422..._02`,
  `0450_KFF_Escape_Step_Strength`, `0470_KFF_Escape_Jog_L`,
  `0471..._R` y `0500_KFF_Escape_Punch_L`.

Son candidatos por nombre: **no se ha confirmado visualmente cuál es la voltereta**.
Si Carlos no tiene una adecuada, habrá que adaptar la de Jill a su rig. No cambiar
la acción solicitada por un puñetazo sin acordarlo.

El inventario antiguo registra FPS 0/1 y el decodificador actual asume ticks a 60 Hz;
no calcular una duración definitiva dividiendo esos campos. Revisar inicio, evasión
y recuperación, incluidas posibles fases separadas. Eliminar el desplazamiento
de raíz duplicado cuando el controlador físico ya mueve al personaje.

Evidencia: `work/forest-re3-mashup/research-dodge/motion-candidates.json`,
`inspect_motion_candidates.py`, catálogo `work/jill/corrected/animation-inventory.json`
y manifiestos actuales `jill-motion-preview.json` / `carlos-motion-preview.json`.

## Puntos confirmados en The Forest

Lectura de IL/metadatos de la copia original de `Assembly-CSharp.dll`, sin ejecutar el juego:

| Punto | Hallazgo y utilidad |
|---|---|
| `FirstPersonCharacter.GetJumpInput()` | En modo normal consulta `Input.GetButtonDown("Jump")`. Entrada compartida con salto; VR tiene otra ruta. |
| `FirstPersonCharacter.rb`, `capsule`, `Grounded` | El controlador usa Rigidbody y cápsula nativos. Reutilizar su movimiento y colisiones. |
| `enemyWeaponMelee.OnTriggerEnter` | Hay rutas que fijan atacante y llaman/envían `hitFromEnemy` antes del daño. |
| `PlayerStats.hitFromEnemy(int)` | Procesa bloqueo, llama a `Hit`, envía reacciones y efectos de impacto. |
| `PlayerStats.Hit(int,bool,DamageType)` | Llama a `HitArmor`, modifica salud y reproduce dolor. Interceptar antes de sus efectos. |
| `BoltPlayerSetup.OnEvent(HitPlayer)` | Solo procesa para `entity.isOwner` y envía `hitFromEnemy`: también existe daño recibido por red. |
| `CoopPlayerCallbacks.OnEvent(PlayerHitByEnemey)` | En esta copia su cuerpo es solo `ret`; no sirve por su nombre como gancho universal. |

`DamageType` distingue Physical, Poison, Drowning, Fire y Frost. Physical no identifica
por sí solo combate: aterrizaje y otras rutas también llaman a `Hit`. Existen
`HealthChange`, trampas y efectos específicos cuya cobertura debe revisarse.

Curar después de recibir el golpe no basta: puede haberse consumido armadura,
disparado dolor, retroceso o muerte. Tampoco desactivar la cápsula, añadir otro
controlador ni usar modo dios global. La protección debe ser temporal y propia.

Evidencia: `work/forest-re3-mashup/research-dodge/player-damage-movement.txt`,
`input-hit-network.txt` y `damage-xrefs.txt`.

## Entrada y ventana de acierto

Valores **propuestos para el primer corte**, pendientes de ajuste:

| Concepto | Valor inicial |
|---|---|
| Intervalo máximo entre pulsaciones | 0.23 s |
| Ventana de acierto desde el segundo toque | 0.12 s, aproximadamente 7 frames a 60 FPS |
| Inmunidad tras acierto | **1.00 s** |
| Recorrido hacia atrás | Aproximadamente 0.4 alturas del jugador, limitado por obstáculos |
| Reutilización | No repetir antes de terminar inmunidad y recuperación; un uso por secuencia de ataque |

Usar tiempo/ticks de simulación, no frames renderizados: 30/60/144 FPS deben compartir
las mismas ventanas. La duración de animación se decide tras revisar los clips.

Secuencia:

1. Capturar dos pulsaciones nuevas con liberación entre ellas. Mantener espacio
   no cuenta. No acumular peticiones.
2. El doble toque arma una intención durante 0.12 s. **Por sí solo no mueve,
   anima ni concede inmunidad.**
3. Activar solo ante un ataque dirigido al jugador que realmente vaya a alcanzarlo.
   Cercanía o animación de ataque genérica no bastan: puede ir contra el compañero.
4. Primer enfoque recomendado: consumir la intención en el contacto de combate,
   antes de aplicar daño. La voltereta empieza en ese contacto; esto no equivale
   a predecir todos los golpes visualmente con antelación.
5. Para iniciarla unos instantes antes, añadir detección por familia de ataques:
   fase activa, objetivo, alcance y barrido de hitbox/proyectil contra cápsula.
   No existe todavía un detector universal confirmado.
6. Si no llega ataque o se falla el tiempo, expirar sin voltereta ni inmunidad.
   No esquivar retrospectivamente un golpe ya aplicado.
7. Al acertar, cancelar impacto y efectos correspondientes; comenzar pose,
   desplazamiento y protección juntos. No renovar inmunidad por spam o impactos.

### Conflicto con espacio/salto

Si la primera pulsación salta inmediatamente, la segunda normalmente llega en el
aire. No se pueden garantizar simultáneamente salto instantáneo, doble espacio y
esquiva solo apoyada sin decidir cómo comparten la entrada.

**Propuesta:** fuera de una amenaza, salto normal. Ante amenaza identificada,
retener la primera pulsación hasta la segunda o hasta 0.23 s; si solo hubo una,
entregar el salto cuando el estado aún lo permita. Esto introduce una demora de
salto contextual que deberá comprobarse. El detector contextual no concede por
sí mismo inmunidad ni éxito.

Si esa demora no resulta aceptable, las alternativas son interrumpir el inicio del
salto con una esquiva válida o cambiar de botón. Ninguna está acordada todavía.
No bloquear `CanJump` globalmente; restaurar cualquier estado temporal al salir.

## Movimiento, cámara y protección

- Fijar atrás según rumbo horizontal al iniciar; mirar al suelo no debe empujar
  hacia abajo ni girar la dirección física durante la acción.
- Mover la cápsula mediante el controlador existente, en su ruta física, usando
  barridos y colisiones. Limitar recorrido ante pared/techo, conservar gravedad
  y apoyo en pendientes; sin teletransporte ni atravesar árboles.
- Separar rotación de malla y cámara: el personaje rueda y la vista permanece
  en primera persona. Cabeza/ojos/pelo locales ocultos, cuerpo visible. Revisar
  cuello, brazos y objetos durante las poses extremas.
- Protección de un segundo con inicio/vencimiento propios; no ampliarla al recibir
  otro paquete, golpe o snapshot. Bloquear ataque durante la fase comprometida.
- Interpretación de la petición: inmunidad al daño entrante durante ese segundo;
  **solo combate activa** la esquiva. Caídas, hambre o veneno no la activan.
  Para protección total revisar sus rutas durante el intervalo y conservar curación.
- Agarres, proyectiles, explosiones y empujones necesitan revisar sus rutas: cancelar
  vida no garantiza cancelar inmovilización o fuerza de explosión. Su cobertura
  completa no se declara resuelta en esta investigación.
- Propuesta de exclusiones iniciales: avión/despertar, menús/chat/inventario,
  muerte/derribo, cuerda/escalada, natación e interacciones inmovilizadoras.
- Voz de esfuerzo mediante el canal existente, sin solapamiento, corte ni cola;
  el golpe cancelado no dispara además un quejido de daño.

## Cooperativo

La posición continúa por la replicación física nativa. Una pose nueva de RE3 no
aparece automáticamente en el Animator de The Forest: enviar un evento/estado
pequeño para que cada equipo reproduzca el clip desde sus propios archivos.

- Extender el protocolo actual con entidad, revisión de personaje, ID de acción,
  secuencia, dirección e inicio/vencimiento. No transmitir mallas o pistas de huesos.
- Inicio aceptado por canal fiable de control; no depender solo del canal de efectos
  no fiables para una acción de combate.
- Propietario procesa entrada y predice respuesta; host valida identidad, estado,
  secuencia, cadencia y duración y distribuye. Remotos reproducen pose, sin otro
  impulso físico ni cambios de vida sobre la copia del compañero.
- El daño revisado se resuelve en el propietario. Validar mensajes en el host
  **no convierte todo el daño en autoritativo del host**. Respetar el modelo nativo
  en el primer corte; si se exige probar allí cada amenaza, se necesita evidencia
  adicional del impacto y resolver resultados provisionales.
- Evaluar ventana localmente al contacto/entrada, sin esperar ida y vuelta al host.
  Correlacionar reloj de sesión y antigüedad. Paquetes tardíos no esquivan daño pasado.
- Resolver rechazo explícitamente; el vencimiento local siempre limita inmunidad,
  incluso si no llega confirmación. No esperar indefinidamente protegido.
- Remotos ajustan progreso al tiempo transcurrido. Snapshot solo incluye acciones
  aún activas y tiempo restante: nunca reinicia el segundo de protección.
- Deduplicar; limpiar al morir, reaparecer, desconectar, cambiar personaje o sesión.
  F8 no debe servir para cancelar recuperación y encadenar evasiones.
- Cambiar versión/capacidades del protocolo: ambos equipos necesitan la futura
  entrega. 0.8.0 actual no entiende mensajes de esquiva todavía.
- Mantener tiempo global normal en coop; no aplicar cámara lenta mediante
  `Time.timeScale` de un equipo. Cualquier efecto visual local sería independiente.

## Orden de implementación y aceptación futura

1. Revisar candidatos visualmente y preparar voltereta completa para ambos rigs.
2. Instrumentar entrada y daño, identificar contacto antes de sus efectos y
   diferencias de host/cliente.
3. Implementar doble toque, guard previo al daño, movimiento, protección y recuperación.
4. Integrar evento/estado remoto y voces existentes.
5. Preparar futura entrega y comprobar solo/host/cliente. No asignar ahora una versión
   como si la habilidad ya estuviera entregada.

Casos pendientes para esa comprobación, **no ejecutados en esta investigación**:

- Doble espacio sin ataque, ataque a otro, fuera de alcance o bloqueado: ninguna esquiva.
- Temprano/tarde recibe daño; acierto evita impacto, armadura, quejido y reacción asociados.
- Segundo golpe antes/después de 1 s; spam y snapshots no prolongan protección.
- Salto, paredes, pendientes, techo bajo, bordes/agua y restauración tras morir.
- Jill/Carlos con objetos: sin manos deformadas ni interior del cuerpo visible.
- Ambos roles y acciones simultáneas con latencia; duplicados, entrada tardía,
  reconexión y F8; sin doble desplazamiento ni inmunidad infinita.
- 30/60/144 FPS, pausa y pérdida de foco: duración consistente.

**Conclusión:** hay puntos concretos de integración y animaciones candidatas.
Las cuestiones principales son salto compartido, instante antes del daño y efectos
secundarios, selección de voltereta de Carlos y latencia. La 0.8.0 permanece aceptada;
esta investigación no certifica la habilidad.

## Implementación posterior: 0.8.1 — 09/10/2026

Se implementó la pulsación única F: ventana .12 s, roll completo .90 s, inmunidad
1 s y recuperación 1.15 s; sin activación al pulsar fuera de un ataque. El contacto
melee identifica el origen antes de hitFromEnemy; el daño se cancela antes de
vida/armadura/reacciones. La cápsula se aleja del atacante con barrido contra
obstáculos. No se activa una voltereta por hambre, caída ni daño de origen desconocido.

La revisión de poses decodificó las cuatro variantes L0/L180/R0/R180 de Jill y
los seis candidatos locales de Carlos. Ninguno de estos seis hace una voltereta:
se comparte el banco de Jill entre ambos, adaptándolo a la pose base de cada rig.
Revisión: research-dodge/dodge-candidate-poses.png. Quejidos cortos del evento
mov_s: dos de Jill y cuatro de Carlos, en el canal vocal existente sin cola.

F9 figura local, F10 congelación, F11 variante, Shift+F10 paso 1/60 s, Shift+F9
retirar; F6 solicita un caníbal creado por el host con spawner nativo; F8 personaje.
FR3C v2 envía inicio/variante/tiempo/dirección, voz por ID y acciones activas al
entrar tarde. El dueño resuelve daño nativo; el host valida mensajes y propiedad.
Ambos equipos requieren 0.8.1. Primera prueba visual y en coop pendiente.

Guía vigente: work/forest-re3-mashup/launcher/PRUEBA-ESQUIVA-0.8.1.txt.
