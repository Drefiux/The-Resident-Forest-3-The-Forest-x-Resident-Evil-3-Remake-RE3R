﻿# Cooperativo del mashup: investigación y ruta de integración

Fecha: **09/10/2026**  
Base aceptada: **0.7.7.1**, Jill y Carlos jugables; fase 0.7.x cerrada.  
Estado de este documento: **investigación de código y diseño; integración en red pendiente**.

## 1. Reestructuración acordada

| Versiones | Objetivo |
| --- | --- |
| 0.x y 1.x | Desarrollar el contenido principal del mashup y su cooperativo juntos. Cada sistema nuevo contempla host, clientes y entrada tardía. |
| 2.x | Publicación y solución de bugs graves encontrados por otros usuarios en sus equipos y partidas. |
| 3.x | Contenido extra, incluida tercera persona. |

Este acuerdo sustituye el plan anterior que reservaba 2.x para empezar el cooperativo. Las entradas anteriores del historial conservan lo acordado en su fecha. El cierre de 0.7.x sigue vigente; los números siguientes se asignarán al preparar una entrega.

## 2. Resultado de la investigación

**Sí existe una vía concreta para añadir datos propios a la red de esta instalación:** los canales de bytes de Bolt. Las funciones están presentes en los DLL originales del juego y The Forest ya las utiliza para su chat de voz.

La integración propuesta conserva la replicación nativa de movimiento, acciones y objetos. El mod sincroniza la identidad del personaje y los eventos propios que falten. Cada equipo utiliza sus modelos, texturas, animaciones y sonidos instalados.

La viabilidad de la API está confirmada por inspección del código. Todavía falta implementar el protocolo y comprobarlo entre equipos. Esta sesión no genera una versión jugable nueva ni cambia la instalación.

## 3. Qué usa realmente The Forest

### Transporte y autoridad

En la ruta de partida alojada por un jugador, `CoopSteamNGUI.Awake` selecciona `SteamPlatform`. `SteamSocket` utiliza `SteamNetworking.SendP2PPacket` y `ReadP2PPacket`, con canal Steam **0**. También contiene la variante `SteamGameServerNetworking`.

Sobre ese transporte funciona **Bolt con roles servidor/cliente**. Steam P2P describe cómo se transportan paquetes; por sí solo no significa que todos los clientes tengan la misma autoridad o que se comuniquen directamente entre sí. La ruta dedicada tiene diferencias: `CoopSteamClientStarter.InitBolt` selecciona `DotNetPlatform` cuando `CoopPeerStarter.Dedicated` está activo. Por eso conviene integrar el protocolo sobre Bolt y evaluar el dedicado por separado.

Tampoco debemos asumir que todas las animaciones nacen siempre en el host. El código distingue al **propietario de la entidad**:

- `BoltPlayerSetup.Attached` consulta `entity.isOwner` y escribe variación/otros datos desde el jugador local.
- `CoopMecanimReplicator.LateUpdate` separa `UpdateOwner`/`UpdateOwnerWithEvents` de la actualización remota.
- Las entidades exponen `networkId`, `source`, `controller` e `isOwner`. Estas referencias permiten relacionar un mensaje con el jugador que lo puede originar.

**Diseño propuesto:** el cliente comunica los cambios de su propio personaje al host; el host valida y distribuye el estado aceptado a los demás. Los sistemas futuros de enemigos, daño, inventarios compartidos y proyectiles necesitan una decisión de autoridad por sistema.

### Animaciones y objetos ya sincronizados

`IPlayerState` hereda de `IWorldCharacter`. El estado generado contiene:

- Transformación del jugador.
- Hashes de estados Mecanim, tiempos normalizados, pesos de capas y velocidad.
- Parámetros como velocidad, agachado, agua, escalada y orientación de cámara.
- Objeto de cada mano, objetos transportados, ropa y otros estados de juego.

`CoopMecanimReplicator` enlaza el Animator con el estado, lee estados actuales/destino en el propietario y reproduce el estado recibido en el remoto. Incluye una ruta basada en eventos y tratamiento de transiciones.

Esto respalda la idea de ejecutar las animaciones en cada PC a partir de información pequeña. La red sí transmite información sobre la animación; los clips y la deformación de la malla se resuelven localmente. Para Jill/Carlos, el Animator remoto nativo puede servir como fuente de pose para nuestra adaptación de huesos.

`CoopPlayerRemoteSetup` ya administra manos, objetos, troncos y el collider remoto. Nuestra capa visual debe conservar esas funciones y sus referencias.

## 4. Canal propio: API local y condiciones

Estas firmas existen en la versión instalada:

```csharp
BoltNetwork.CreateStreamChannel(string name, UdpKit.UdpChannelMode mode, int priority)
connection.StreamBytes(UdpKit.UdpChannelName channel, byte[] data)
Bolt.GlobalEventListener.StreamDataReceived(BoltConnection connection, UdpKit.UdpStreamData data)
```

`UdpStreamData` contiene `Channel` y `Data`. `UdpChannelMode` define `Unreliable = 0` y `Reliable = 1`. `Bolt.NetworkId.PackedValue` permite representar la entidad como un entero de 64 bits; `BoltNetwork.FindEntity` permite resolverla.

### Condición 1: registrar durante el inicio de Bolt

El DLL local lanza una excepción si se crean canales después de la ventana de `BoltStartBegin`. En `BoltCore.BeginStart`, el callback ocurre después de crear el socket y antes de iniciarlo. La documentación oficial también establece esa restricción. [Photon: Bolt Stream System](https://doc.photonengine.com/bolt/current/in-depth/streaming-bytes).

El cargador actual del mashup espera a que exista un jugador para cargar recursos. Eso resolvió los bloqueos del menú y debe conservarse. La parte de red necesita un registro temprano y ligero, independiente de cargar modelos, bancos de audio o buscar esqueletos.

### Condición 2: mismo orden de registro

En este UdpKit, `StreamChannelCreate` asigna el ID incrementando `channelIdCounter`. **El nombre por sí solo no garantiza que el ID coincida entre equipos.** Todos deben registrar los mismos canales, con el mismo orden y configuración.

Punto propuesto para el primer prototipo: ampliar mediante ModAPI `CoopPlayerCallbacks.BoltStartBegin`, ejecutar primero el método nativo que registra `Voice` y luego registrar nuestros canales, siempre en orden fijo y una sola vez por inicio de Bolt. La coexistencia con otros mods que registren canales debe comprobarse; no se asume resuelta por el nombre.

Nombres propuestos, todavía sin registrar:

1. `ForestRE3.Control.v1`: fiable; compatibilidad, selección y estado del reparto.
2. `ForestRE3.Effects.v1`: no fiable; eventos breves de voz/efectos con caducidad.

### Condición 3: filtrar el receptor nativo de voz

**Hallazgo importante de esta compilación:** `CoopPlayerCallbacks.StreamDataReceived` lee los primeros ocho bytes como `NetworkId` y entrega el resto a `CoopVoice`, sin consultar `data.Channel`.

Además, `GlobalEventListenerBase.StreamDataReceivedInvoke` entrega cada bloque a todos los listeners; un listener propio no consume el mensaje ni impide que lo lea el nativo.

Antes de transmitir datos propios hay que proteger ese método mediante ModAPI para que la ruta nativa de audio procese exclusivamente `CoopVoice.VoiceChannel`. El receptor del mashup procesa únicamente sus canales y valida formato/tamaño. De lo contrario, nuestros bytes podrían interpretarse como un paquete de voz y producir errores, aunque usemos un canal con otro nombre.

No se ha aplicado este parche todavía. La técnica de ampliar métodos nativos ya se utiliza en los parches de audio del proyecto; este punto concreto requiere implementación y comprobación en cooperativo.

### Condición 4: respetar el presupuesto compartido

The Forest establece `SetStreamBandwidth(40000)` por conexión en `CoopPlayerCallbacks.Connected`. Ese presupuesto pertenece al streaming de la conexión, incluida la voz de micrófono. El protocolo del mashup debe enviar mensajes pequeños por cambio/evento y aprovechar los estados nativos, sin modificar ese límite a ciegas.

## 5. Opciones comparadas

| Ruta | Evaluación para el mashup |
| --- | --- |
| Canales propios de Bolt | **Ruta preferida.** API y uso nativo confirmados. Requiere registro temprano, orden idéntico y filtro del receptor de voz. |
| Ampliar `IPlayerState` o crear eventos Bolt generados | Posible trabajo de ingeniería adicional, pero implica fábricas, IDs, metadatos y serializadores compatibles en todos los equipos. Añadir un campo C# no actualiza automáticamente el esquema de red. |
| Usar `PlayerVariation`, ropa, chat o voz como datos del mod | Esos campos/canales tienen funciones activas. Mezclar significados puede disparar cambios de ropa, mensajes o decodificación de audio. No es necesario para la ruta propuesta. |
| Canal Steam P2P separado | Alternativa de transporte para investigar si Bolt resulta insuficiente. Exige administrar lectura, sesiones, IDs y reenvío, y adaptar la ruta dedicada. Que el juego use el canal 0 no demuestra que otro número esté libre frente a todos los mods. |

La propuesta usa el cargador existente y los DLL de esta instalación. La documentación moderna de Photon tiene diferencias de namespaces y funciones; los ejemplos deben adaptarse a las firmas locales, sin reemplazar las bibliotecas del juego.

## 6. Datos que enviaría el mashup

Diseño inicial, todavía sin formato binario definitivo:

| Mensaje | Contenido | Momento |
| --- | --- | --- |
| `Hello` / aceptación | Versión del protocolo y catálogo de recursos, capacidades | Al conectar |
| Selección propia | ID de entidad, Jill/Carlos, revisión | Al aparecer o cambiar con F8 |
| Estado aceptado | Entidad, personaje, revisión y sesión | Host → clientes después de validar |
| Instantánea del reparto | Lista actual de jugadores/personajes | Entrada tardía, resincronización |
| Evento de voz | Entidad, personaje/revisión, categoría, ID del clip, secuencia y caducidad | Cuando empieza una voz aceptada |

El catálogo usa IDs estables para personajes y clips. Todos instalan una versión compatible del paquete. No hay que enviar FBX, texturas, clips de animación, WAV ni rotaciones de cada dedo. Las posiciones y acciones nativas siguen su sincronización habitual.

Cada mensaje necesita cabecera identificable, versión, límite de tamaño y validación de valores. El host acepta cambios de identidad únicamente de la conexión correspondiente al jugador; los clientes aceptan el reparto distribuido por el host. Los datos de red seleccionan recursos del catálogo instalado.

Flujo previsto:

```mermaid
flowchart LR
    A[Jugador cambia a Carlos] --> B[Host valida entidad y revisión]
    B --> C[Distribuye ID Carlos]
    C --> D[Cada PC muestra su modelo local]
    E[Estado y Animator remoto de The Forest] --> D
```

### Entrada tardía y reconexiones

Un cambio puntual de skin no sirve como única fuente de estado: quien llega después necesita conocer el reparto actual. El host conserva una tabla por `NetworkId` y envía una instantánea cuando el cliente está preparado. Si llega antes la identidad que la entidad, se guarda de forma acotada hasta `EntityAttached`.

Al desconectarse/detacharse una entidad se limpian modelos y entradas. Al reiniciar Bolt se registra de nuevo el canal y se cambia la sesión del protocolo para descartar datos viejos. Las revisiones evitan que un cambio anterior sobrescriba uno reciente; las instantáneas deben aplicar la misma regla.

Como referencia de diseño, Photon advierte que los eventos de entidad pueden llegar antes de existir la entidad y que no se garantiza el orden relativo entre eventos y estado. Por eso aquí se propone estado recuperable y manejo explícito de la llegada de la entidad. [Photon: Events](https://doc.photonengine.com/bolt/current/gameplay/events).

La primera integración se dirige a partidas privadas donde todos tienen el mashup compatible. La convivencia con clientes sin el mod sigue sin comprobarse; no debe anunciarse como compatible. El saludo verifica protocolo/recursos, pero no sustituye resolver previamente el registro de canales.

## 7. Adaptar el código actual a jugadores remotos

El trabajo principal pendiente está en la separación de contextos del avatar:

- `JillPlayerAvatar` toma controlador, cámara y Animator de `LocalPlayer`.
- `JillMotionPreview` admite una fuente para cinemáticas, pero varias decisiones siguen consultando `LocalPlayer`, su velocidad, cámara y acciones.
- `JillVoice` mantiene una instancia local, audio 2D y supresión de voces por proximidad. También silencia un bus de respiración compartido.

Copiar esos componentes sobre cada jugador remoto haría que varios personajes siguieran al jugador local o interfirieran con su audio. Se necesita un contexto por actor: entidad, raíz, Animator, estado, perfil y modalidad local/remota.

### Presentación de los remotos

1. Detectar entidades de jugador en `EntityAttached` y revisar también las ya existentes al terminar de cargar recursos.
2. Mantener Animator, esqueleto fuente, colliders, daño y objetos nativos activos. Ocultar selectivamente las mallas del personaje original.
3. Instanciar Jill/Carlos como representación visual asociada a esa entidad, con cabeza, ojos y cabello completos. Las reglas de primera persona se aplican únicamente al propio jugador.
4. Adaptar la pose desde el Animator remoto después de su actualización nativa. Reutilizar la corrección de hombros/manos con calibración para el rig remoto.
5. Resolver agarres, escala y equipos usando el actor remoto. Mantener la animación del avión local siempre como Jill, según el requisito existente; sincronizar la identidad de gameplay al finalizar esa etapa.

La coincidencia exacta de rigs, capas y todas las transiciones remotas todavía requiere comprobación. El movimiento no debe inferirse exclusivamente de diferencias de posición: agachado, golpes cargados, caída, natación y escalada necesitan sus estados y fases.

### Voces remotas

- Un canal de voz por actor, con posición y atenuación 3D para los demás jugadores; el local conserva su mezcla actual.
- Enviar el ID del clip elegido cuando realmente comienza a sonar. Si el actor ya está hablando, descartar el nuevo intento sin transmitirlo ni encolarlo.
- Al recibir, descartar duplicados, eventos caducados y eventos incompatibles con la revisión del personaje. Si ese actor sigue hablando, descartar el nuevo evento.
- Saltar normalmente continúa en silencio. El esfuerzo corresponde a la liberación del golpe pesado o al golpe hacia abajo.
- Separar las voces nativas por actor/emisor. El filtro local por distancia y el bus compartido deben adaptarse para que un compañero cercano no active la voz del jugador local ni se silencien voces ajenas por accidente.
- Conservar sonidos de herramientas, impactos, entorno y voz de micrófono. Los eventos propios deben tener una única fuente para evitar duplicar el mismo golpe desde observación de animación y desde mensaje.

## 8. Orden recomendado de implementación

1. **Infraestructura:** registro determinista, filtro de voz nativo, recepción validada y saludo de compatibilidad. Mantener ligero el menú y la carga diferida de recursos.
2. **Reparto Jill/Carlos:** selección al aparecer, F8, distribución desde host, instantánea para entradas tardías y limpieza al salir.
3. **Modelo remoto:** cuerpo completo, escala, manos/hombros y objetos nativos. Conservar la experiencia local aceptada.
4. **Acciones y voces:** revisar todas las fases de golpes, agachado, salto, natación, escalada y reacciones; añadir eventos de voz con descarte cuando esté ocupado.
5. **Contenido siguiente:** integrar cada arma, curativo, baúl y enemigo con su autoridad y estado persistente definidos desde el comienzo.

Para dar por funcional el primer corte hará falta observar host y cliente en equipos distintos, cambios de personaje en ambos sentidos, entrada tardía, reconexión, voz de micrófono y las acciones anteriores. La ruta dedicada y la convivencia con otros mods son comprobaciones adicionales. **Nada de eso se ejecutó durante esta investigación.**

El cañón del rifle de Carlos al golpear el suelo sigue registrado como corrección pendiente. La pequeña penetración del cuerpo al atacar y mirar a la derecha conserva la prioridad baja aceptada por el usuario.

## 9. Evidencia y reproducción de la investigación

Se inspeccionaron los respaldos originales de `work/forest-re3-mashup/modapi-workspace/gamefiles/original/TheForest/TheForest_data/Managed`, correspondientes a la instalación local de The Forest 1.11b / Unity 5.6.5p4. Versiones de ensamblado: Bolt **0.4.3.4**, UdpKit **0.5.0.0**; no confundirlas con números del SDK actual de Photon.

La carpeta [research-coop](../../work/forest-re3-mashup/research-coop) conserva el lector `InspectCoop.cs`, su ejecutable y los informes de metadatos/IL. El lector usa Mono.Cecil; no carga ni ejecuta código del juego.

| Evidencia local | Qué documenta |
| --- | --- |
| `bolt-api.txt`, `bolt-lifecycle.txt` | Firmas de canales, conexiones, IDs y restricción de registro |
| `udp-stream-types.txt`, `udp-channel-registration.txt` | Datos recibidos, modos e IDs por contador |
| `game-network-flow.txt` | Registro de voz, receptor sin filtro, entidades y manos remotas |
| `listeners-bolt.dll.txt`, `stream-dispatch.txt` | Distribución a todos los listeners y orden de arranque |
| `steam-voice-setup.txt`, `steam-animation-flow.txt` | SteamPlatform, canal de transporte 0 y formato de voz nativa |
| `state-inheritance.txt`, `player-state-events.txt`, `generated-state-lifecycle.txt` | Estado del jugador, herencia y esquema generado |
| `mecanim-replication.txt`, `ownership-animation.txt` | Propietario/remoto, capas, tiempos y transiciones |
| `game-network-xrefs.txt`, `animation-transport-xrefs.txt` | Referencias de uso en el código nativo |

SHA-256 de los ensamblados examinados:

```text
Assembly-CSharp.dll  3FCB3958D5C6A04C16B010A056BC0798EC4E1A4705CDC1E974D70BA2FB5C1C59
bolt.dll             D2B93E9FC2E2C48F159B736EAC62CF51453E4CD28866536A55EA0FEABA0B42EC
bolt.user.dll        628C6F87C3DE09F59AE0FA116F33B76E13C98B98D49F598828713604EFAD70B3
udpkit.dll           23DFD810213E48BA4E6742EAD15E1CC01D32CD93E822224905A5D6F72B36D994
```

Fuentes externas primarias consultadas el 09/10/2026: [Bolt Stream System](https://doc.photonengine.com/bolt/current/in-depth/streaming-bytes) y [Bolt Events](https://doc.photonengine.com/bolt/current/gameplay/events). La recomendación se apoya principalmente en los DLL locales; los detalles de integración propuestos aún no son resultados comprobados en partida.


## 10. Implementación posterior del mismo día: 0.8.0

Después de esta investigación, el usuario pidió implementar el coop de inmediato.
Se preparó 0.8.0 (ModAPI 0.8.0.0) con `CoopSync.cs` y `CoopRemoteAvatar.cs`.
La arquitectura propuesta se concreta en protocolo FR3C v1, dos streams propios,
identidad/revisión, saludo de catálogo, validación por host y snapshot al entrar
más reparación cada 10 segundos. Los ganchos protegen el receptor Voice original.

El componente de sincronización hereda MonoBehaviour; su listener Bolt es una
clase anidada. Así ModAPI conserva un componente nuevo y no convierte la herencia
de GlobalEventListener en una inyección para todos los listeners. Los tres métodos
invocados desde Assembly-CSharp son públicos, porque cruzan el límite de ensamblado.

Cada remoto usa su Animator/estado IPlayerState, sin controles ni física adicionales.
Reutiliza los correctivos y el mapeo anatómico de las cadenas completas de dedos,
incluidos metacarpianos de anular/meñique. `coopAnimatorVis.skinRenderer` apunta
al renderer del nuevo modelo mientras está conectado y se restaura al retirarlo:
el renderer original oculto ya no puede congelar la animación del reemplazo visible.
La velocidad `overallSpeed` es normalizada por `maxSpeed` en el código original;
la selección de locomoción remota usa esa referencia, no metros por segundo.

Voces: clips locales compartidos, AudioSource 3D por actor, ID/secuencia/edad/revisión
por red, sin cola. Los filtros de voces genéricas se separan por actor y en coop
no se silencia el bus FMOD compartido. Las excepciones restauran la apariencia
original y el adaptador visual tiene reintentos limitados.

La compilación, el empaquetado y la preparación aislada del runtime se conservan
en `research-coop/coop-0.8.0-build.json`. El paquete central incluye PRUEBA-COOP.txt
para dos PCs. **La inspección estática no confirma aún la ejecución multijugador**;
las observaciones pendientes de la sección 8 siguen siendo criterios de aceptación.
