﻿using System;
using System.Collections.Generic;
using UnityEngine;
using TheForest.Utils;

namespace ForestRE3JillVisualProbe
{
    // Change only the rendered view. Restore before native input, locomotion
    // and eye-height alignment run again, avoiding a camera/body feedback loop.
    [DefaultExecutionOrder(-30000)]
    public sealed class DodgeFirstPersonCamera : MonoBehaviour
    {
        private sealed class SavedView
        {
            internal Camera camera;
            internal Transform anchor;
            internal Vector3 position;
            internal Quaternion rotation;
            internal int frame;
            internal bool weapon;
        }
        private static DodgeFirstPersonCamera instance;
        private readonly List<SavedView> views=new List<SavedView>();
        private uint reported;
        private bool subscribed, failed;

        internal void Initialize()
        {
            instance=this;
            // Register before the avatar's clipping callback so its _FPEye
            // shader coordinate sees the animated camera, including child views.
            Camera.onPreCull+=BeforeCamera;
            Camera.onPostRender+=AfterCamera;
            subscribed=true;
        }
        private void BeforeCamera(Camera camera)
        {
            if ((!DodgeRuntime.Active && !G19Runtime.Equipped) || !JillPlayerAvatar.IsOwnCamera(camera)) return;
            // Motion-blur history must see the same view that was rendered.
            if(views.Count>0 && views[0].weapon && views[0].frame==Time.frameCount)return;
            var avatar=JillPlayerAvatar.Current;
            Camera main=LocalPlayer.MainCam;
            Transform anchor=LocalPlayer.MainCamTr;
            if (main==null || avatar==null) return;
            if (anchor==null) anchor=main.transform;
            Vector3 eyes;
            Quaternion head;
            DodgeAction action=null;Vector3 position;Quaternion rotation;
            if(DodgeRuntime.Active)
            {
                if(!avatar.TryDodgeEyes(out eyes,out head))return;
                action=DodgeRuntime.Pose(null);if(action==null)return;
                float weight=DodgeRuntime.AnimationWeight(action.Age);
                position=Vector3.Lerp(main.transform.position,eyes,weight);
                rotation=Quaternion.Slerp(main.transform.rotation,head,weight);
            }
            else if(!TryWeaponView(out position,out rotation))return;
            position=ProtectView(main.transform.position,position);
            views.Add(new SavedView { camera=camera,anchor=anchor,position=anchor.localPosition,
                rotation=anchor.localRotation,frame=Time.frameCount,weapon=action==null });
            try
            {
                // MainCamTr can be a parent of the actual camera. Preserve its
                // child offsets while placing the main view at the posed eyes.
                Quaternion delta=rotation*Quaternion.Inverse(main.transform.rotation);
                anchor.rotation=delta*anchor.rotation;
                anchor.position+=position-main.transform.position;
                if (action!=null && reported!=action.sequence)
                {
                    reported=action.sequence;
                    ModAPI.Log.Write("[ForestRE3] DODGE_CAMERA sequence="+reported+"; eyeFollow=true; headRotate=true; renderOnly=true");
                }
            }
            catch (Exception error)
            {
                RestoreAll();
                if (!failed) ModAPI.Log.Write("[ForestRE3] DODGE_CAMERA_FAILED "+error);
                failed=true;
            }
        }
        internal static bool TryWeaponView(out Vector3 position,out Quaternion rotation)
        {
            position=Vector3.zero;rotation=Quaternion.identity;
            var avatar=JillPlayerAvatar.Current;Camera main=LocalPlayer.MainCam;
            if(!G19Runtime.Equipped || DodgeRuntime.Active || avatar==null || main==null || !avatar.TryWeaponEyes(out position,out rotation))return false;
            position=ProtectView(main.transform.position,position);return true;
        }
        private static Vector3 ProtectView(Vector3 origin,Vector3 target)
        {
            var fp=LocalPlayer.FpCharacter;
            if (fp==null || fp.capsule==null) return target;
            float radius=Mathf.Max(.04f,fp.capsule.bounds.size.y*.02f);
            target.y=Mathf.Max(target.y,fp.capsule.bounds.min.y+radius);
            Vector3 offset=target-origin;
            float distance=offset.magnitude;
            if (distance<.001f) return target;
            Vector3 direction=offset/distance;
            float allowed=distance;
            int mask=fp.CollisionLayers.value; if (mask==0) mask=~0;
            foreach (RaycastHit hit in Physics.SphereCastAll(origin,radius,direction,distance,mask,QueryTriggerInteraction.Ignore))
            {
                if (hit.collider==null || hit.collider.transform.root==fp.transform.root) continue;
                // Ignore an initial overlap that the native view already had;
                // prevent moving farther through a surface in the roll itself.
                if (hit.distance<=.001f || Vector3.Dot(hit.normal,direction)>=0f) continue;
                allowed=Mathf.Min(allowed,Mathf.Max(0f,hit.distance-.02f));
            }
            return origin+direction*allowed;
        }
        private void AfterCamera(Camera camera)
        {
            for (int i=views.Count-1;i>=0;i--)
                if (views[i].camera==camera) { if(!views[i].weapon)RestoreFrom(i); break; }
        }
        private void RestoreFrom(int index)
        {
            for (int i=views.Count-1;i>=index;i--)
            {
                SavedView view=views[i];
                if (view.anchor!=null)
                { view.anchor.localPosition=view.position; view.anchor.localRotation=view.rotation; }
                views.RemoveAt(i);
            }
        }
        internal static void RestoreAll() { if (instance!=null) instance.RestoreFrom(0); }
        private void Update()
        { if (views.Count>0 && views[0].frame!=Time.frameCount) RestoreFrom(0); }
        private void FixedUpdate()
        { if(views.Count>0)RestoreFrom(0); }
        private void OnDisable()
        {
            RestoreFrom(0);
            if (subscribed) { Camera.onPreCull-=BeforeCamera; Camera.onPostRender-=AfterCamera; subscribed=false; }
        }
        private void OnDestroy() { OnDisable(); if (instance==this) instance=null; }
    }
}
