﻿using System;
using System.Collections.Generic;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class JillMotionPreview
    {
        private readonly Dictionary<string,List<Binding>> handgunTracks=new Dictionary<string,List<Binding>>();
        private GameObject handgun;
        private byte handgunId;private float weaponAimWeight;
        private Vector3 weaponEyePosition,weaponBasePosition;private Quaternion weaponEyeRotation,weaponBaseRotation;private bool weaponViewReady;private int weaponViewFrame;
        internal bool TryWeaponEyes(out Vector3 position,out Quaternion rotation)
        {
            position=weaponEyePosition;rotation=weaponEyeRotation;
            // A click is processed before this frame's LateUpdate. Preserve
            // the eye-animation offset while using the latest mouse direction.
            Camera camera=LocalPlayer.MainCam;
            if(camera!=null && weaponViewFrame!=Time.frameCount)
            {Quaternion delta=camera.transform.rotation*Quaternion.Inverse(weaponBaseRotation);position=camera.transform.position+delta*(position-weaponBasePosition);rotation=delta*rotation;}
            return weaponViewReady && Time.frameCount-weaponViewFrame<=2;
        }
        private Light muzzle;
        // The RE weapon socket uses +X along the barrel and +Z up. The
        // imported pistol mesh uses +Z along the barrel and +Y up.
        private static readonly Quaternion handgunSocketBasis=Quaternion.LookRotation(Vector3.right,Vector3.forward);
        private bool handgunReported;
        private void ApplyG19(bool dodging)
        {
            G19Pose pose=playerAttached && sourceOverride==null ? G19Runtime.Pose(remoteEntity):null;
            weaponViewReady=false;
            if(dodging || pose==null || (actions!=null && G19Runtime.NativeHandAction(actions.Action)) || G19Runtime.WeaponPrefab(pose.weapon)==null)
            {if(handgun!=null)handgun.SetActive(false);weaponForwardWeight=weaponAimWeight=0f;return;}
            // Authored upper-body clips are layered over the native legs. Reload
            // contains only 58/59 tracks and must retain the handgun base pose.
            string prefix=character.BodyId+(pose.weapon==28 ? "_rocket_":pose.weapon==3 ? "_m3_":"_");
            ResetWeaponArms(prefix+"hold");
            HandgunLayer(prefix+"hold",Time.time*60f,true,false);
            HandgunLayer(prefix+"grip",0f,false,true);
            Rest socket;
            if(!rest.TryGetValue("r_weapon",out socket))throw new InvalidOperationException("Missing weapon socket.");
            if(pose.weapon==3)CaptureM3Contacts(socket);
            float pumpReference=pose.weapon==3 ? PumpGrip():0f;
            bool raised=!pose.Reloading && (pose.aim || Time.time-pose.raiseAt<.4f || Time.time-pose.shotAt<(pose.weapon==28 ? 2f:pose.weapon==3 ? 87f/60f:.4f));
            if(raised)HandgunLayer(prefix+"aim",Time.time*60f,true,false);
            Quaternion referenceRotation=socket.bone.rotation*handgunSocketBasis;Vector3 referencePosition=socket.bone.position;
            float shot=Time.time-pose.shotAt,load=Time.time-pose.reloadAt,readyAge=Time.time-pose.equipAt;
            if(pose.Reloading)HandgunLayer(prefix+(pose.weapon==3 && load>190f/60f ? "reloadend":"reload"),(pose.weapon==3 && load>190f/60f ? load*60f-190f:load*60f),false,false);
            else if(shot<(pose.weapon==28 ? 2f:pose.weapon==3 ? 87f/60f:50f/60f))HandgunLayer(prefix+(pose.aim ? "aimshoot":"shoot"),shot*60f,false,false);
            else if(readyAge<20f/60f)HandgunLayer(prefix+"ready",readyAge*60f,false,false);
            m3PumpOffset=pose.weapon==3 ? Mathf.Clamp(PumpGrip()-pumpReference,-.14f,.02f):0f;
            // Keep the authored CLOSED M3 fingers after all absolute/additive
            // upper-body clips; reload still owns its opening/insertion gesture.
            if(pose.weapon==3 && !pose.Reloading)HandgunLayer(prefix+"grip",0f,false,true);
            PlaceWeapon(pose,socket,referenceRotation,referencePosition);
            if(handgun!=null && handgunId!=pose.weapon){UnityEngine.Object.Destroy(handgun);handgun=null;}
            if(handgun==null)
            {
                handgunId=pose.weapon;
                handgun=UnityEngine.Object.Instantiate(G19Runtime.WeaponPrefab(pose.weapon));
                handgun.name="ForestRE3_"+Re3Weapon.Name(pose.weapon);handgun.transform.SetParent(transform,false);
                foreach(var renderer in handgun.GetComponentsInChildren<Renderer>())
                {renderer.enabled=true;renderer.gameObject.layer=JillPlayerAvatar.VisibleLayer(0);renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.On;}
                var flash=new GameObject("G19_Muzzle");flash.transform.SetParent(handgun.transform,false);flash.transform.localPosition=new Vector3(0,.073f,pose.weapon==3 ? .72f:.15f);
                muzzle=flash.AddComponent<Light>();muzzle.type=LightType.Point;muzzle.color=new Color(1f,.7f,.25f);muzzle.range=4f;muzzle.intensity=1.1f;muzzle.enabled=false;
            }
            handgun.SetActive(true);
            handgun.transform.rotation=socket.bone.rotation*handgunSocketBasis;
            handgun.transform.position=socket.bone.position;
            handgun.transform.localScale=Vector3.one;
            if(!handgunReported)
            {handgunReported=true;ModAPI.Log.Write("[ForestRE3] G19_SOCKET_ATTACHED character="+character.Name+"; socket=r_weapon; rotations=absolute_RE; scale="+handgun.transform.lossyScale+"; firstPerson="+firstPersonRig);}
            muzzle.enabled=shot>=0 && shot<.05f && !pose.Reloading;
            foreach(Transform part in handgun.transform)
            {
                if(part.name.StartsWith("Magazine_",StringComparison.Ordinal))
                    part.localPosition=pose.Reloading && load>.3f && load<1.1f ? new Vector3(0,-.16f,0):Vector3.zero;
                else if(pose.weapon==3 && part.name=="M3_2")
                    // The original fore-end follows the original left-hand
                    // cycle, measured relative to the right-hand weapon socket.
                    part.localPosition=new Vector3(0,0,m3PumpOffset);
            }
        }
        private float PumpGrip()
        {
            Rest right,left;if(!rest.TryGetValue("r_weapon",out right) || !rest.TryGetValue("l_weapon",out left))return 0f;
            return Matrix4x4.TRS(right.bone.position,right.bone.rotation*handgunSocketBasis,transform.lossyScale).inverse.MultiplyPoint3x4(left.bone.position).z;
        }
        private void HandgunLayer(string key,float frame,bool loop,bool fingers)
        {
            MotionClip clip;if(!G19Runtime.Clips.TryGetValue(key,out clip))return;
            // Hold_Shoot is recoil DELTA over Hold_Idle. Focus_Shoot, reload,
            // ready and hold/focus are authored absolute poses. Applying the
            // near-identity recoil as a full pose straightens both arms away.
            bool additive=key.EndsWith("_shoot",StringComparison.Ordinal) || key.EndsWith("_m3_aimshoot",StringComparison.Ordinal) || key.EndsWith("_rocket_aimshoot",StringComparison.Ordinal);
            frame=loop ? frame%Mathf.Max(1,clip.frames):Mathf.Clamp(frame,0,clip.frames);
            List<Binding> mapped;
            string mapKey=key+(fingers ? "/fingers":"/upper-body");
            if(!handgunTracks.TryGetValue(mapKey,out mapped))
            {
                mapped=new List<Binding>();
                foreach(var track in clip.tracks)
                {
                    Rest target;MotionBone source=FindMotionBone(clip,track.bone);
                    if(source==null || !rest.TryGetValue(track.bone,out target))continue;
                    // First person retains the accepted native torso, neck and
                    // eye-height pose. Weapon animations drive the arms only.
                    if(firstPersonRig && (track.bone.StartsWith("spine_") || track.bone=="neck_0" || track.bone=="head"))continue;
                    bool hand=track.bone.Contains("_hand_");
                    if(fingers ? !hand : !(hand || armPoseBones.Contains(target) || track.bone=="r_weapon" || track.bone=="l_weapon" || track.bone.StartsWith("spine_") || track.bone=="neck_0" || track.bone=="head" || track.bone.Contains("pec") || track.bone.Contains("delt") || track.bone.Contains("scapula")))continue;
                    // RE offsets have the correct proportions already; only the
                    // matching arm hierarchy is animated, never hips/root/feet.
                    mapped.Add(new Binding{track=track,target=target,source=source});
                }
                handgunTracks[mapKey]=mapped;
            }
            foreach(var binding in mapped)
            {
                float[] v=binding.track.values;bool rotation=binding.track.kind=="rotation";int stride=rotation ? 5:4,count=v.Length/stride;
                if(count==0)continue;int low=0,high=count-1;
                while(low<high){int mid=(low+high+1)/2;if(v[mid*stride]<=frame)low=mid;else high=mid-1;}
                int next=Math.Min(low+1,count-1),a=low*stride+1,b=next*stride+1;float duration=v[next*stride]-v[low*stride];
                float blend=duration>0 ? Mathf.Clamp01((frame-v[low*stride])/duration):0;
                // These original RE tracks contain absolute local rotations.
                // Their mot skeleton reference is already posed, not the FBX
                // bind pose. Subtracting it rotates the hands behind the camera.
                if(rotation)
                {
                    Quaternion value=Quaternion.Slerp(ConvertRotation(v,a),ConvertRotation(v,b),blend);
                    binding.target.bone.localRotation=additive ? binding.target.bone.localRotation*value:value;
                }
                else if(binding.track.kind=="position")
                {
                    Vector3 value=Vector3.Lerp(ConvertPosition(v,a),ConvertPosition(v,b),blend);
                    string name=binding.track.bone;
                    // Main arm lengths and finger spacing belong to the target
                    // character. The socket and deformation helpers, however,
                    // contain ABSOLUTE RE local coordinates. A mot skeleton can
                    // have a different posed reference (notably the SG socket);
                    // subtracting that reference displaces the gun from its grip.
                    if(name.Contains("_hand_") || name.EndsWith("_arm_clavicle") || name.EndsWith("_arm_humerus") || name.EndsWith("_arm_radius") || name.EndsWith("_arm_wrist"))continue;
                    binding.target.bone.localPosition=additive ? binding.target.bone.localPosition+value*motionPositionRatio:value*motionPositionRatio;
                }
            }
        }
        private void ResetWeaponArms(string key)
        {
            // Partial weapon clips must never inherit the native axe's finger,
            // shoulder or stretched twist-bone pose from the preceding layer.
            foreach(Rest item in rest.Values)
            {
                string name=item.bone.name;
                if(!(name.Contains("_hand_") || armPoseBones.Contains(item) || name=="r_weapon" || name=="l_weapon" || name.Contains("pec") || name.Contains("delt") || name.Contains("scapula")))continue;
                item.bone.localPosition=item.position;item.bone.localRotation=item.rotation;item.bone.localScale=item.scale;
            }
            // Evaluate the authored grip in the SOURCE arm geometry first.
            // Carlos uses Jill's M3 clips: evaluating those with Carlos's longer
            // arms changes the left hand's contact with the fore-end. The final
            // IK restores target lengths after both source grips are captured.
            MotionClip clip;
            if(G19Runtime.Clips.TryGetValue(key,out clip))foreach(ArmSupport arm in armSupports)
                foreach(Rest feature in arm.features)
                {
                    MotionBone source=FindMotionBone(clip,feature.bone.name);
                    if(source!=null)feature.bone.localPosition=ConvertPosition(source.restPosition,0)*motionPositionRatio;
                }
        }
    }
}
