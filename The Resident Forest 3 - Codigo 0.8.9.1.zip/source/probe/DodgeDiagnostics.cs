﻿using System;
using System.Collections.Generic;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;

namespace ForestRE3JillVisualProbe
{
    [DefaultExecutionOrder(12000)]
    public sealed class DodgeDiagnostics : MonoBehaviour
    {
        private static DodgeDiagnostics current;
        private readonly List<Material> materials=new List<Material>();
        private readonly List<spawnMutants> spawns=new List<spawnMutants>();
        private GameObject figure;
        private JillMotionPreview pose;
        private CharacterProfile character;
        private FirstPersonCharacter sessionOwner;
        private Vector3 origin,bottom,direction;
        private float scale,age,spawnAt,requestAt;
        private byte variant;
        private bool frozen,poseDirty=true;
        private string message="";
        private static bool WorldReady
        {
            get { return LocalPlayer.FpCharacter!=null && LocalPlayer.FpCharacter.gameObject.activeInHierarchy
                && LocalPlayer.Stats!=null && !LocalPlayer.Stats.Dead && LocalPlayer.Inventory!=null
                && LocalPlayer.Inventory.CurrentView==TheForest.Items.Inventory.PlayerInventory.PlayerViews.World
                && !JillPlaneAvatar.CharacterLocked && Time.timeScale>0f && !Cursor.visible; }
        }
        private void Awake() { current=this; }
        private void Update()
        {
            if (sessionOwner!=LocalPlayer.FpCharacter)
            { RemoveFigure(); spawns.Clear(); spawnAt=requestAt=0; sessionOwner=LocalPlayer.FpCharacter; }
            if(!Re3DeveloperTools.Enabled){RemoveFigure();return;}
            if (!WorldReady) { if (figure!=null) figure.SetActive(false); return; }
            if (figure!=null) figure.SetActive(true);
            try
            {
                if (UnityEngine.Input.GetKeyDown(KeyCode.F9))
                {
                    if (Shift()) RemoveFigure(); else CreateFigure();
                }
                if (figure!=null)
                {
                    if (UnityEngine.Input.GetKeyDown(KeyCode.F10))
                    { if (Shift()) { frozen=true; age=Mathf.Min(DodgeRuntime.AnimationSeconds-.001f,age+1f/60f); poseDirty=true; } else frozen=!frozen; }
                    if (UnityEngine.Input.GetKeyDown(KeyCode.F11)) { variant=(byte)((variant+1)%4); age=0; poseDirty=true; }
                    if (JillPlayerAvatar.Current!=null && character!=JillPlayerAvatar.Current.NetworkCharacter) CreateFigure();
                    if (!frozen)
                    { age+=Time.deltaTime; if (age>=DodgeRuntime.AnimationSeconds+.6f) { age=0; variant=(byte)((variant+1)%4); } }
                }
                if (UnityEngine.Input.GetKeyDown(KeyCode.F6) && Time.realtimeSinceStartup>=requestAt)
                {
                    requestAt=Time.realtimeSinceStartup+5f;
                    if (LocalPlayer.AnimControl!=null && (LocalPlayer.AnimControl.swimming || LocalPlayer.AnimControl.onRope || LocalPlayer.AnimControl.cliffClimb))
                        message="Canibal: colocate en suelo firme";
                    else { message="Canibal solicitado (el host lo genera; puede tardar unos segundos)"; CoopSync.RequestCannibal(); }
                }
            }
            catch (Exception error) { message="Error de laboratorio: consulta el registro"; ModAPI.Log.Write("[ForestRE3] DODGE_DIAGNOSTIC_ERROR "+error); RemoveFigure(); }
        }
        private static bool Shift() { return UnityEngine.Input.GetKey(KeyCode.LeftShift) || UnityEngine.Input.GetKey(KeyCode.RightShift); }
        private static bool Ground(Vector3 desired,Transform exclude,out Vector3 point)
        {
            point=desired; float best=float.PositiveInfinity;
            foreach (RaycastHit hit in Physics.RaycastAll(desired+Vector3.up*8f,Vector3.down,24f,~0,QueryTriggerInteraction.Ignore))
            {
                if (hit.collider==null || hit.collider.transform.root==exclude.root || hit.normal.y<.65f || hit.distance>=best) continue;
                if (hit.collider.GetComponentInParent<BoltEntity>()!=null || hit.collider.GetComponentInParent<enemyWeaponMelee>()!=null) continue;
                best=hit.distance; point=hit.point;
            }
            return best<float.PositiveInfinity;
        }
        private void CreateFigure()
        {
            RemoveFigure();
            var player=JillPlayerAvatar.Current; if (player==null || !player.NetworkReady || DodgeRuntime.Clips==null) return;
            character=player.NetworkCharacter;
            Vector3 forward=Vector3.ProjectOnPlane(LocalPlayer.MainCam.transform.forward,Vector3.up).normalized;
            if (forward.sqrMagnitude<.01f) forward=LocalPlayer.Transform.forward;
            float height=LocalPlayer.FpCharacter.originalHeight*Mathf.Abs(LocalPlayer.FpCharacter.capsule.transform.lossyScale.y);
            if (!Ground(LocalPlayer.FpCharacter.capsule.bounds.center+forward*height*1.6f,LocalPlayer.Transform,out origin))
            { message="Figura: no encontre un suelo cerca"; return; }
            direction=forward;
            figure=UnityEngine.Object.Instantiate(character.Prefab); figure.name="ForestRE3_Dodge_Inspection_"+character.Name;
            figure.transform.position=Vector3.zero; figure.transform.rotation=Quaternion.identity; figure.transform.localScale=Vector3.one;
            JillPlayerAvatar.MakeVisualOnly(figure); AvatarGeometry.AdjustEyes(figure,materials);
            Bounds bounds=AvatarGeometry.MeasureGeometry(figure);
            scale=height*character.HeightRatio/bounds.size.y; bottom=new Vector3(bounds.center.x,bounds.min.y,bounds.center.z);
            pose=figure.AddComponent<JillMotionPreview>(); pose.Initialize(character); pose.enabled=false;
            frozen=false; age=0; poseDirty=true;
            message="Figura local de "+character.Name+" | sin fisica | Shift+F9: quitar | Shift+F10: avanzar un frame";
        }
        private void LateUpdate()
        {
            if (figure==null || pose==null || !WorldReady) return;
            if (frozen && !poseDirty) return;
            try
            {
                var action=new DodgeAction { clip=variant,direction=direction,localStart=Time.time-Mathf.Min(age,DodgeRuntime.AnimationSeconds-.0001f) };
                Quaternion heading=DodgeRuntime.Heading(action);
                figure.transform.rotation=heading; figure.transform.localScale=Vector3.one*scale;
                figure.transform.position=origin+direction*(DodgeRuntime.Travel(variant,age)*pose.DodgeMotionScale)-heading*(bottom*scale);
                pose.SetGroundReference(origin.y); pose.InspectDodge(action); pose.StepPlayerPose();
                poseDirty=false;
                if (!pose.PoseAvailable) throw new InvalidOperationException("Inspection pose unavailable");
            }
            catch (Exception error) { ModAPI.Log.Write("[ForestRE3] DODGE_INSPECTION_FAILED "+error); RemoveFigure(); message="Fallo la figura; consulta el registro"; }
        }
        internal static void SpawnCannibal(Transform player)
        {
            if (!Re3DeveloperTools.Enabled || current==null || player==null || !WorldReady || (BoltNetwork.isRunning && !BoltNetwork.IsSinglePlayer && !BoltNetwork.isServer)) return;
            if (Time.realtimeSinceStartup<current.spawnAt) return;
            current.spawns.RemoveAll(delegate(spawnMutants item) { return item==null; });
            if (current.spawns.Count>=4) { current.message="Limite: cuatro canibales de prueba por partida"; return; }
            Vector3 forward=Vector3.ProjectOnPlane(player.forward,Vector3.up).normalized,point;
            if (!Ground(player.position+forward*10f,player,out point)) { current.message="No encontre suelo para el canibal"; return; }
            GameObject prefab=Resources.Load<GameObject>("instantMutantSpawner");
            if (prefab==null) { current.message="Spawner nativo no disponible"; return; }
            GameObject instance=UnityEngine.Object.Instantiate(prefab,point+Vector3.up,Quaternion.identity);
            spawnMutants spawner=instance.GetComponent<spawnMutants>();
            if (spawner==null) { UnityEngine.Object.Destroy(instance); return; }
            spawner.amount_male_skinny=spawner.amount_female_skinny=spawner.amount_skinny_pale=0;
            spawner.amount_female=spawner.amount_fireman=spawner.amount_pale=spawner.amount_armsy=spawner.amount_vags=0;
            spawner.amount_baby=spawner.amount_fat=spawner.amount_girl=0; spawner.amount_male=1;
            spawner.instantSpawn=true; spawner.range=1f; spawner.daysTillSpawn=0; spawner.daysTillActiveDuringDay=0;
            spawner.sleepingSpawn=false; spawner.eatingOnSpawn=false; spawner.wakeUpOnSpawn=true;
            current.spawns.Add(spawner); current.spawnAt=Time.realtimeSinceStartup+5f;
            current.message="Canibal creado mediante el spawner nativo (espera hasta 4 s)";
            ModAPI.Log.Write("[ForestRE3] DODGE_TEST_CANNIBAL nativeSpawner=true; host="+BoltNetwork.isServer+"; position="+point);
        }
        private void RemoveFigure()
        {
            if (figure!=null) UnityEngine.Object.Destroy(figure); figure=null; pose=null;
            foreach (Material material in materials) if (material!=null) UnityEngine.Object.Destroy(material); materials.Clear();
        }
        private void OnGUI()
        {
            if (!Re3DeveloperTools.Enabled || LocalPlayer.FpCharacter==null || JillPlayerAvatar.Current==null || !JillPlayerAvatar.Current.NetworkReady) return;
            GUI.Label(new Rect(12,36,1500,24),"F: esquiva al recibir un golpe (.12 s) | F6: canibal | F8: personaje | F9: figura | F10: congelar | F11: variante");
            GUI.Label(new Rect(12,60,1500,24),figure!=null ? message+" | voltereta "+(variant+1)+"/4 | "+(frozen ? "CONGELADA":"reproduciendo")+" | "+Mathf.Min(age,.9f).ToString("F3")+" s" : message);
        }
        private void OnDestroy() { RemoveFigure(); if (current==this) current=null; }
    }
}
