﻿using System;
using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    // Host-authoritative RE3 impacts use Forest's owner-routed damage event.
    // No custom message accepts a client-provided target or damage amount.
    internal static class Re3FriendlyFire
    {
        internal static BoltEntity Player(Collider collider)
        {
            if(collider==null || !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer)return null;
            var entity=collider.GetComponentInParent<BoltEntity>();
            if(entity==null || !entity.isAttached || !entity.StateIs<IPlayerState>())return null;
            if(collider.isTrigger && !collider.CompareTag("PlayerNet") && !collider.CompareTag("Player") && !collider.CompareTag("playerHitDetect"))return null;
            return entity;
        }
        internal static void Hit(BoltEntity target,BoltEntity attacker,int damage)
        {
            if(!BoltNetwork.isRunning || !BoltNetwork.isServer || !Re3CoopOptions.FriendlyFire || target==null || !target.isAttached
                || !target.StateIs<IPlayerState>() || target==attacker || damage<=0)return;
            int nativeDamage=PlayerPreferences.RealisticPlayerDamage ? damage:5;
            var hit=HitPlayer.Create(target,Bolt.EntityTargets.OnlyOwner);hit.damage=nativeDamage;hit.Send();
            ModAPI.Log.Write("[ForestRE3] RE_WEAPON_PLAYER_HIT victim="+target.networkId.PackedValue+"; damage="+nativeDamage+"; fullPvp="+PlayerPreferences.RealisticPlayerDamage+"; authority=host");
        }
    }
    public class Re3FriendlyFireStatsPatch : global::PlayerStats
    {
        public new virtual void Explosion(float distance,bool player)
        {if(Re3Dynamite.AllowPlayerExplosion(this))base.Explosion(distance,player);GC.KeepAlive(this);}
    }
}
