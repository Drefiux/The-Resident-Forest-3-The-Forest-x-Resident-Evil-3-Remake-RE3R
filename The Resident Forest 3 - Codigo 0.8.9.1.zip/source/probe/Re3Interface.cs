﻿using System;
using System.IO;
using System.Reflection;
using System.Collections;
using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    internal static class Re3Interface
    {
        internal static Font TextFont,AmmoFont;
        internal static Texture2D Inventory,Gradients,Ammo,Reticle;
        private static bool loading,failed;
        internal static IEnumerator Load()
        {
            if(TextFont!=null || failed)yield break;
            if(loading){while(loading)yield return null;yield break;}
            loading=true;byte[] bytes=null;
            try
            {
                using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.re3-interface"))
                {
                    if(s==null || s.Length>8*1024*1024)throw new InvalidDataException("RE3 interface resource");
                    bytes=new byte[(int)s.Length];int at=0;
                    while(at<bytes.Length){int n=s.Read(bytes,at,bytes.Length-at);if(n<=0)throw new EndOfStreamException();at+=n;}
                }
            }
            catch(Exception e){failed=true;ModAPI.Log.Write("[ForestRE3] RE3_INTERFACE_ERROR "+e);}
            if(bytes!=null)
            {
                var request=AssetBundle.LoadFromMemoryAsync(bytes);yield return request;
                var bundle=request.assetBundle;
                if(bundle!=null)
                {
                    const string p="Assets/LocalAssets/Re3Interface/";
                    TextFont=bundle.LoadAsset<Font>(p+"RE3Interface.otf");AmmoFont=bundle.LoadAsset<Font>(p+"RE3Ammo.otf");
                    Inventory=bundle.LoadAsset<Texture2D>(p+"inventory-atlas.png");Gradients=bundle.LoadAsset<Texture2D>(p+"inventory-gradients.png");Ammo=bundle.LoadAsset<Texture2D>(p+"ammo-atlas.png");
                    Reticle=bundle.LoadAsset<Texture2D>(p+"reticle-atlas.png");bundle.Unload(false);
                }
                if(TextFont==null || AmmoFont==null || Inventory==null || Gradients==null || Ammo==null || Reticle==null)
                {failed=true;ModAPI.Log.Write("[ForestRE3] RE3_INTERFACE_ERROR missing original font/atlas");}
                else ModAPI.Log.Write("[ForestRE3] RE3_INTERFACE_LOADED originalFonts=Helvetica+OCR originalAtlases=ui3000+ui3003+ui2012+ui2000");
            }
            loading=false;
        }
        internal static void Image(Rect target,Texture2D atlas,Rect pixels)
        {
            if(atlas==null)return;
            GUI.DrawTextureWithTexCoords(target,atlas,new Rect(pixels.x/atlas.width,1f-pixels.yMax/atlas.height,pixels.width/atlas.width,pixels.height/atlas.height),true);
        }
        internal static void Rule(Rect target)
        {Image(target,Gradients,new Rect(0,0,512,32));}
    }
}
