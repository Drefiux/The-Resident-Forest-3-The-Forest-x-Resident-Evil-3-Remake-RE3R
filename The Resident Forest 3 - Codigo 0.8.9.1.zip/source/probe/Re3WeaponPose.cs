﻿using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class JillMotionPreview
    {
        private float weaponForwardWeight;
        private int weaponWeightFrame=-1;
        private readonly Vector3[] weaponGripOffsets=new Vector3[2];
        private readonly Quaternion[] weaponGripRotations=new Quaternion[2];
        private readonly Vector3[] m3ContactCorrection=new Vector3[2];
        private readonly Quaternion[] m3GripFrames=new Quaternion[2];
        private float m3PumpOffset;
        private bool m3ContactReported;private float m3ContactLogAt;
        private static Vector3 M3Contact(bool left)
        {return left ? new Vector3(0f,.003f,.390f):new Vector3(.032f,-.065f,-.100f);}
        private Vector3 M3PalmCenter(out Vector3 normal)
        {
            Vector3 p=rest["l_hand_middle_0"].bone.position;
            Vector3 a=rest["l_hand_middle_1"].bone.position-p;
            Vector3 b=rest["l_hand_middle_2"].bone.position-p;
            Vector3 cross=Vector3.Cross(a,b);float square=cross.sqrMagnitude;
            if(square<.0000000001f)
            {normal=rest["l_arm_wrist"].bone.forward;return p+b*.5f;}
            normal=cross.normalized;
            // The finger bones lie ON the curved grip, not at its axis. Fit
            // their circumcircle and align its center to the fore-end axis.
            // Anchoring a single knuckle to its outside edge left the whole
            // closed hand cupped beside the shotgun despite zero IK error.
            return p+(a.sqrMagnitude*Vector3.Cross(b,cross)+b.sqrMagnitude*Vector3.Cross(cross,a))/(2f*square);
        }
        private void CaptureM3Contacts(Rest socket)
        {
            Quaternion inverse=Quaternion.Inverse(socket.bone.rotation*handgunSocketBasis);
            float scale=Mathf.Max(.001f,Mathf.Abs(transform.lossyScale.y));
            for(int i=0;i<armSupports.Count;i++)
            {
                bool left=armSupports[i].wrist.bone.name.StartsWith("l_");
                Rest knuckle=rest[left ? "l_hand_middle_0":"r_hand_middle_0"];
                Vector3 normal=Vector3.forward;
                Vector3 point=left ? M3PalmCenter(out normal):knuckle.bone.position;
                Vector3 authored=inverse*(point-socket.bone.position)/scale;
                // M3 mesh coordinates: rear grip spans z=-.16..-.10;
                // fore-end spans z=.245.. .567, radius approximately .032.
                // Use the support hand's grip axis and the rear hand's
                // knuckle contact. Keep authored reload-release offsets.
                Vector3 contact=M3Contact(left);
                m3ContactCorrection[i]=contact-authored;
                m3GripFrames[i]=inverse*armSupports[i].wrist.bone.rotation;
                if(left)
                {
                    normal=inverse*normal;
                    if(Vector3.Dot(normal,Vector3.forward)<0f)normal=-normal;
                    m3GripFrames[i]=Quaternion.FromToRotation(normal,Vector3.forward)*m3GripFrames[i];
                }
            }
        }
        private void ConstrainM3Grip(int index,G19Pose pose,Quaternion weaponRotation,float scale)
        {
            ArmSupport arm=armSupports[index];
            bool left=arm.wrist.bone.name.StartsWith("l_");
            Rest knuckle=rest[left ? "l_hand_middle_0":"r_hand_middle_0"];
            // Measure the FINAL finger pose in wrist axes, after action layers.
            // A base-pose translation cannot enforce contact when recoil turns
            // the wrist or an absolute aiming layer changes the finger pose.
            Vector3 palmNormal;
            Vector3 point=left ? M3PalmCenter(out palmNormal):knuckle.bone.position;
            Vector3 gripFromWrist=Quaternion.Inverse(arm.wrist.bone.rotation)*(point-arm.wrist.bone.position);
            Quaternion rotation=weaponRotation*m3GripFrames[index];
            if(pose.Reloading && !left)rotation=weaponGripRotations[index];
            Vector3 contact=M3Contact(left);
            if(left)contact.z+=m3PumpOffset;
            Vector3 offset=weaponRotation*(contact*scale)-rotation*gripFromWrist;
            float attached=1f;
            if(left && pose.Reloading)
            {
                float age=Time.time-pose.reloadAt;
                float release=Mathf.SmoothStep(0f,1f,Mathf.Clamp01(age/.18f));
                float regrip=Mathf.SmoothStep(0f,1f,Mathf.Clamp01((age-(pose.ReloadSeconds-.35f))/.35f));
                attached=1f-release*(1f-regrip);
            }
            // Free the support hand for shell insertion, then blend it back to
            // the fore-end. Every other state shares one rigid gun/hand frame.
            weaponGripOffsets[index]=Vector3.Lerp(weaponGripOffsets[index],offset,attached);
            weaponGripRotations[index]=Quaternion.Slerp(weaponGripRotations[index],rotation,attached);
        }
        private void PlaceWeapon(G19Pose pose,Rest socket,Quaternion referenceRotation,Vector3 referencePosition)
        {
            bool firing=Time.time-pose.raiseAt<.4f || Time.time-pose.shotAt<(pose.weapon==28 ? 2f:pose.weapon==3 ? 87f/60f:.4f);
            if(weaponWeightFrame!=Time.frameCount)
            {
                weaponWeightFrame=Time.frameCount;
                weaponAimWeight=Mathf.MoveTowards(weaponAimWeight,pose.aim && !pose.Reloading ? 1f:0f,Time.deltaTime*9f);
                weaponForwardWeight=Mathf.MoveTowards(weaponForwardWeight,!pose.Reloading && (pose.aim || firing) ? 1f:0f,Time.deltaTime*12f);
            }
            Camera camera=TheForest.Utils.LocalPlayer.MainCam;
            if(firstPersonRig && camera==null)return;
            Vector3 eye;Quaternion head;if(!TryDodgeEyes(out eye,out head))return;
            Quaternion view=firstPersonRig ? camera.transform.rotation:Quaternion.LookRotation(pose.lookDirection,Vector3.up);
            Vector3 origin=firstPersonRig ? camera.transform.position:eye;
            float scale=Mathf.Abs(transform.lossyScale.y);
            Quaternion authoredRotation=socket.bone.rotation*handgunSocketBasis;
            Vector3 authoredPosition=socket.bone.position;
            Quaternion recoil=Quaternion.Inverse(referenceRotation)*authoredRotation;
            Vector3 kick=Quaternion.Inverse(referenceRotation)*(authoredPosition-referencePosition)/Mathf.Max(scale,.001f);
            // Reload keeps its authored gesture; shots keep the small original
            // recoil. Neither uses the large third-person head rotation.
            recoil=Quaternion.RotateTowards(Quaternion.identity,recoil,pose.Reloading ? 65f:10f);
            kick=Vector3.ClampMagnitude(kick,pose.Reloading ? .16f:.035f);
            Vector3 restOffset=pose.weapon==28 ? new Vector3(.15f,-.16f,.18f):pose.weapon==3 ? new Vector3(.12f,-.15f,.12f):new Vector3(.16f,-.24f,.30f);
            Vector3 fireOffset=pose.weapon==28 ? new Vector3(.12f,-.10f,.19f):pose.weapon==3 ? new Vector3(.065f,-.11f,.14f):new Vector3(.10f,-.14f,.35f);
            Vector3 aimOffset=pose.weapon==28 ? new Vector3(.11f,-.07f,.19f):new Vector3(0f,-.073f,pose.weapon==3 ? .14f:.36f);
            Vector3 offset=Vector3.Lerp(Vector3.Lerp(restOffset,fireOffset,weaponForwardWeight),aimOffset,weaponAimWeight);
            Quaternion restTilt=Quaternion.Euler(pose.weapon==28 ? 8f:pose.weapon==3 ? 5f:28f,-6f,pose.weapon==3 ? 0f:-5f);
            Quaternion desiredRotation=view*Quaternion.Slerp(restTilt,Quaternion.identity,weaponForwardWeight)*recoil;
            Vector3 desiredPosition=origin+view*((offset+kick)*scale);
            Quaternion delta=desiredRotation*Quaternion.Inverse(authoredRotation);
            // Capture BOTH grips before moving either arm. One common rigid
            // transform preserves the original hand-to-weapon contact.
            for(int i=0;i<armSupports.Count;i++)
            {
                ArmSupport arm=armSupports[i];
                weaponGripOffsets[i]=delta*(arm.wrist.bone.position-authoredPosition);
                if(pose.weapon==3)weaponGripOffsets[i]+=desiredRotation*(m3ContactCorrection[i]*scale);
                weaponGripRotations[i]=delta*arm.wrist.bone.rotation;
                if(pose.weapon==3)ConstrainM3Grip(i,pose,desiredRotation,scale);
            }
            foreach(ArmSupport arm in armSupports)
            {
                foreach(Rest feature in arm.features)feature.bone.localPosition=feature.position;
                for(int i=0;i<8;i++)arm.helpers[i].bone.localPosition=arm.helpers[i].position;
            }
            // Project the shared weapon target into both arms' reach without
            // stretching bones. During reload the left hand is free to release.
            for(int pass=0;pass<8;pass++)for(int i=0;i<armSupports.Count;i++)
            {
                ArmSupport arm=armSupports[i];
                if(pose.Reloading && arm.humerus.bone.name.StartsWith("l_"))continue;
                float reach=(arm.radius.position.magnitude+arm.wrist.position.magnitude)*scale*.995f;
                Vector3 center=arm.humerus.bone.position-weaponGripOffsets[i];
                desiredPosition=center+Vector3.ClampMagnitude(desiredPosition-center,reach);
            }
            for(int i=0;i<armSupports.Count;i++)
                SolveWeaponArm(armSupports[i],desiredPosition+weaponGripOffsets[i],weaponGripRotations[i],view);
            // The mesh follows the same frame used for both hand targets.
            socket.bone.rotation=desiredRotation*Quaternion.Inverse(handgunSocketBasis);
            socket.bone.position=desiredPosition;
            if(pose.weapon==3 && !pose.Reloading && Time.time>=m3ContactLogAt)
            {
                float error=0f;
                foreach(ArmSupport arm in armSupports)
                {
                    bool left=arm.wrist.bone.name.StartsWith("l_");
                    Vector3 contact=M3Contact(left);if(left)contact.z+=m3PumpOffset;
                    Vector3 target=desiredPosition+desiredRotation*(contact*scale);
                    Vector3 normal;
                    Vector3 point=left ? M3PalmCenter(out normal):rest["r_hand_middle_0"].bone.position;
                    error=Mathf.Max(error,Vector3.Distance(point,target));
                }
                m3ContactLogAt=Time.time+5f;
                if(!m3ContactReported || error>.01f)
                {m3ContactReported=true;ModAPI.Log.Write("[ForestRE3] M3_FINAL_CONTACT character="+character.Name+"; reference=palm_arc_axis; maxErrorMeters="+error.ToString("F4")+"; sharedPump="+m3PumpOffset.ToString("F4"));}
            }
            if(firstPersonRig)
            {
                weaponEyePosition=origin+Vector3.ClampMagnitude(eye-origin,.025f*scale)*weaponAimWeight;
                weaponEyeRotation=view*Quaternion.Slerp(Quaternion.identity,recoil,weaponAimWeight*.15f);
                weaponBasePosition=origin;weaponBaseRotation=view;weaponViewFrame=Time.frameCount;
                weaponViewReady=weaponAimWeight>0f;
            }
        }
        private void SolveWeaponArm(ArmSupport arm,Vector3 grip,Quaternion wristRotation,Quaternion view)
        {
            arm.humerus.bone.localPosition=arm.humerus.position;
            arm.radius.bone.localPosition=arm.radius.position;arm.wrist.bone.localPosition=arm.wrist.position;
            float upper=(arm.radius.bone.position-arm.humerus.bone.position).magnitude;
            float lower=(arm.wrist.bone.position-arm.radius.bone.position).magnitude;
            Vector3 shoulder=arm.humerus.bone.position,reach=grip-shoulder;
            float distance=Mathf.Clamp(reach.magnitude,Mathf.Abs(upper-lower)+.0001f,upper+lower-.0001f);
            Vector3 axis=reach.sqrMagnitude>.000001f ? reach.normalized:view*Vector3.forward;
            float side=arm.humerus.bone.name.StartsWith("l_") ? -1f:1f;
            Vector3 bend=Vector3.ProjectOnPlane(view*new Vector3(side*.35f,-.65f,-.05f),axis);
            if(bend.sqrMagnitude<.00001f)bend=Vector3.ProjectOnPlane(view*Vector3.right,axis);
            bend.Normalize();
            float along=(upper*upper-lower*lower+distance*distance)/(2f*distance);
            Vector3 elbow=shoulder+axis*along+bend*Mathf.Sqrt(Mathf.Max(0f,upper*upper-along*along));
            Vector3 endpoint=shoulder+axis*distance;
            Quaternion radiusBefore=arm.radius.bone.localRotation,wristBefore=arm.wrist.bone.localRotation;
            // Swing the ACTUAL child axes, keeping the authored axial roll.
            // Reconstructing roll from a nearly straight reference elbow can
            // flip 180 degrees and fold the deformation helpers through skin.
            arm.humerus.bone.rotation=Normalize(Quaternion.FromToRotation(arm.radius.bone.position-shoulder,elbow-shoulder)*arm.humerus.bone.rotation);
            arm.radius.bone.rotation=Normalize(Quaternion.FromToRotation(arm.wrist.bone.position-arm.radius.bone.position,endpoint-arm.radius.bone.position)*arm.radius.bone.rotation);
            arm.wrist.bone.rotation=wristRotation;
            // Add only the twist introduced by IK to the original RE helpers.
            // Use the shortest quaternion arc, never a persistent accumulated
            // roll carried over from an axe pose or an earlier weapon state.
            AdjustWeaponTwist(arm,0,arm.radius.position,arm.radius.bone.localRotation*Quaternion.Inverse(radiusBefore));
            AdjustWeaponTwist(arm,4,arm.wrist.position,arm.wrist.bone.localRotation*Quaternion.Inverse(wristBefore));
        }
        private static void AdjustWeaponTwist(ArmSupport arm,int start,Vector3 segment,Quaternion delta)
        {
            if(segment.sqrMagnitude<.000001f)return;
            if(delta.w<0f)delta=new Quaternion(-delta.x,-delta.y,-delta.z,-delta.w);
            Vector3 axis=segment.normalized;
            float sine=Vector3.Dot(new Vector3(delta.x,delta.y,delta.z),axis);
            if(sine*sine+delta.w*delta.w<.000001f)return;
            float degrees=Mathf.Atan2(sine,delta.w)*2f*Mathf.Rad2Deg;
            for(int i=0;i<4;i++)
            {
                Rest helper=arm.helpers[start+i];
                float fraction=Mathf.Clamp01(Vector3.Dot(helper.position,axis)/segment.magnitude);
                helper.bone.localRotation=Normalize(Quaternion.AngleAxis(degrees*fraction,axis)*helper.bone.localRotation);
            }
        }
    }
}
