﻿using System;
using System.Collections;
using System.IO;
using System.Reflection;
using UnityEngine;
using LocalPlayer = TheForest.Utils.LocalPlayer;
using Scene = TheForest.Utils.Scene;

namespace ForestRE3JillVisualProbe
{
    public static class EntryPoints
    {
        private static JillRuntimeBootstrap bootstrap;
        private static bool newWorldPending=true;

        [ModAPI.Attributes.ExecuteOnApplicationStart]
        public static void OnApplicationStart() { Re3DeveloperTools.Reload();EnsureBootstrap();newWorldPending=true; }

        [ModAPI.Attributes.ExecuteOnGameStart]
        public static void OnGameStart()
        {
            EnsureBootstrap();
            if(newWorldPending){newWorldPending=false;Re3InventoryRuntime.BeginWorld();}
        }

        private static void EnsureBootstrap()
        {
            if (bootstrap != null) return;
            GameObject host = new GameObject("ForestRE3JillVisualProbe");
            UnityEngine.Object.DontDestroyOnLoad(host);
            bootstrap = host.AddComponent<JillRuntimeBootstrap>();
            CoopSync.Ensure(host);
            ModAPI.Log.Write("[ForestRE3] BOOTSTRAP_WAIT version=0.8.9.1; menuResources=false; pollSeconds=0.25");
        }
    }

    // The application callback also runs in the main menu. Keep it lightweight:
    // no avatar assets, voices, render callbacks or player scans until gameplay.
    public sealed class JillRuntimeBootstrap : MonoBehaviour
    {
        private bool loading, loaded, failed;
        private float pollAt;
        private string phase = "";
        private AssetBundle bundle;

        private static bool HasGameActor()
        {
            return (LocalPlayer.FpCharacter != null && LocalPlayer.FpCharacter.gameObject.activeInHierarchy)
                || (Scene.TriggerCutScene != null && Scene.TriggerCutScene.gameObject.activeInHierarchy);
        }

        private void Update()
        {
            if (loading || loaded || failed || Time.realtimeSinceStartup < pollAt) return;
            pollAt = Time.realtimeSinceStartup+.25f;
            if (!HasGameActor()) return;
            loading=true;
            StartCoroutine(Prepare());
        }

        private IEnumerator Prepare()
        {
            IEnumerator steps = LoadSteps();
            while (true)
            {
                bool more;
                try { more=steps.MoveNext(); }
                catch (Exception error)
                {
                    failed=true; loading=false; phase="Error al preparar personajes; consulta el registro.";
                    if (bundle != null) { bundle.Unload(false); bundle=null; }
                    ModAPI.Log.Write("[ForestRE3] BOOTSTRAP_FAILED autoRetry=false; "+error);
                    break;
                }
                if (!more) break;
                yield return steps.Current;
            }
            IDisposable disposable=steps as IDisposable;
            if (disposable != null) disposable.Dispose();
            loading=false;
        }

        private void SetPhase(string value)
        {
            phase=value;
            ModAPI.Log.Write("[ForestRE3] BOOTSTRAP_PHASE "+value);
        }

        private IEnumerator LoadSteps()
        {
                SetPhase("Cargando superficie de primera persona...");
                string colorSpace = QualitySettings.activeColorSpace == ColorSpace.Linear ? "linear" : "gamma";
                byte[] surfaceBytes;
                using (Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.jill-first-person-surface-"+colorSpace))
                {
                    if (stream==null || stream.Length>4*1024*1024) throw new InvalidOperationException("Missing or oversized first-person surface.");
                    surfaceBytes=new byte[(int)stream.Length];
                    int at=0;
                    while (at<surfaceBytes.Length)
                    {
                        int read=stream.Read(surfaceBytes,at,surfaceBytes.Length-at);
                        if (read<=0) throw new EndOfStreamException("First-person surface resource.");
                        at+=read;
                    }
                }
                AssetBundleCreateRequest surfaceBundle=AssetBundle.LoadFromMemoryAsync(surfaceBytes);
                yield return surfaceBundle;
                bundle=surfaceBundle.assetBundle; surfaceBytes=null;
                if (bundle==null) throw new InvalidOperationException("First-person surface bundle load failed.");
                AssetBundleRequest surfaceRequest=bundle.LoadAssetAsync("Assets/Shaders/JillFirstPerson.shader",typeof(Shader));
                yield return surfaceRequest;
                JillFirstPersonView.Surface=surfaceRequest.asset as Shader;
                if (JillFirstPersonView.Surface==null || !JillFirstPersonView.Surface.isSupported) throw new InvalidOperationException("Unsupported first-person surface.");
                bundle.Unload(false); bundle=null;
                foreach (CharacterProfile character in CharacterProfile.All)
                {
                    SetPhase("Cargando recursos de "+character.Name+"...");
                    byte[] bytes;
                    using (Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.forest-re3-"+character.Id+"-"+colorSpace))
                    {
                        if (stream==null || stream.Length>int.MaxValue) throw new InvalidOperationException("Missing character bundle: "+character.Name);
                        bytes=new byte[(int)stream.Length]; int offset=0;
                        while (offset<bytes.Length)
                        {
                            int count=stream.Read(bytes,offset,Math.Min(4*1024*1024,bytes.Length-offset));
                            if (count<=0) throw new EndOfStreamException(character.Name+" bundle.");
                            offset+=count; yield return null;
                        }
                    }
                    SetPhase("Preparando materiales de "+character.Name+"...");
                    AssetBundleCreateRequest request=AssetBundle.LoadFromMemoryAsync(bytes);
                    yield return request; bundle=request.assetBundle; bytes=null;
                    if (bundle==null) throw new InvalidOperationException("Character bundle failed: "+character.Name);
                    AssetBundleRequest asset=bundle.LoadAssetAsync(character.Name+"AvatarPreview",typeof(GameObject));
                    yield return asset; character.Prefab=asset.asset as GameObject;
                    if (character.Prefab==null) throw new InvalidOperationException("Missing prefab: "+character.Name);
                    foreach (string part in new[] { "Body_"+character.BodyId, "Head_"+character.HeadId, "Hair_"+character.HairId })
                    {
                        Transform node=character.Prefab.transform.Find(part);
                        if (node==null || node.GetComponentsInChildren<Renderer>(true).Length==0) throw new InvalidOperationException("Missing character part: "+part);
                    }
                    Transform skeleton=character.Prefab.transform.Find(character.Skeleton);
                    if (skeleton==null || character.Prefab.GetComponentsInChildren<Light>(true).Length!=0) throw new InvalidOperationException("Invalid rig: "+character.Name);
                    foreach (SkinnedMeshRenderer renderer in character.Prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                    {
                        if (renderer.rootBone!=skeleton) throw new InvalidOperationException("Separate skeleton: "+renderer.name);
                        foreach (Transform bone in renderer.bones)
                            if (bone==null || !bone.IsChildOf(skeleton)) throw new InvalidOperationException("Unmerged bone: "+renderer.name);
                        foreach (Material material in renderer.sharedMaterials)
                            if (material==null || material.shader==null || !material.shader.isSupported) throw new InvalidOperationException("Unsupported material: "+renderer.name);
                        yield return null;
                    }
                    bundle.Unload(false); bundle=null;
                    // Jill can already cover the opening while Carlos loads.
                    if (character==CharacterProfile.Jill) gameObject.AddComponent<JillPlaneAvatar>().Initialize(character.Prefab);
                }
                while (!HasGameActor()) yield return new WaitForSeconds(.25f);
                gameObject.AddComponent<DodgeRuntime>().Initialize();
                gameObject.AddComponent<DodgeFirstPersonCamera>().Initialize();
                gameObject.AddComponent<JillPlayerAvatar>().Initialize(CharacterProfile.Jill.Prefab);
                gameObject.AddComponent<DodgeDiagnostics>();
                gameObject.AddComponent<G19Runtime>();
                gameObject.AddComponent<Re3InventoryRuntime>();
                loaded=true; phase="";
                ModAPI.Log.Write("[ForestRE3] ROSTER_READY version=0.8.9.1; characters=Jill,Carlos; random=50/50; opening=Jill; F8=change_character; externalFigureControls=false");
        }

        private void OnGUI()
        {
            if ((loading || failed) && HasGameActor()) GUI.Label(new Rect(12,84,1200,24), phase);
        }
    }

    internal static class AvatarGeometry
    {
        internal static Bounds MeasureGeometry(GameObject figure)
        {
            Bounds result = new Bounds();
            bool initialized = false;
            foreach (SkinnedMeshRenderer renderer in figure.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                // Measure the skinned vertices directly in world space. This avoids
                // version-specific BakeMesh treatment of renderer/parent scale.
                Mesh mesh = renderer.sharedMesh;
                if (mesh == null) continue;
                Vector3[] vertices = mesh.vertices;
                BoneWeight[] weights = mesh.boneWeights;
                Matrix4x4[] bindposes = mesh.bindposes;
                Transform[] bones = renderer.bones;
                Matrix4x4[] skin = new Matrix4x4[bones.Length];
                if (bindposes.Length != bones.Length || weights.Length != vertices.Length)
                    throw new InvalidOperationException("Invalid geometry measurement data on " + renderer.name);
                for (int index = 0; index < bones.Length; index++)
                {
                    if (bones[index] == null) throw new InvalidOperationException("Missing measurement bone on " + renderer.name);
                    skin[index] = bones[index].localToWorldMatrix * bindposes[index];
                }
                for (int index = 0; index < vertices.Length; index++)
                {
                    BoneWeight weight = weights[index];
                    Vector3 vertex = vertices[index];
                    Vector3 point = Vector3.zero;
                    if (weight.weight0 > 0f) point += skin[weight.boneIndex0].MultiplyPoint3x4(vertex) * weight.weight0;
                    if (weight.weight1 > 0f) point += skin[weight.boneIndex1].MultiplyPoint3x4(vertex) * weight.weight1;
                    if (weight.weight2 > 0f) point += skin[weight.boneIndex2].MultiplyPoint3x4(vertex) * weight.weight2;
                    if (weight.weight3 > 0f) point += skin[weight.boneIndex3].MultiplyPoint3x4(vertex) * weight.weight3;
                    if (weight.weight0 + weight.weight1 + weight.weight2 + weight.weight3 <= 0f)
                        point = renderer.transform.TransformPoint(vertex);
                    if (!initialized) { result = new Bounds(point, Vector3.zero); initialized = true; }
                    else result.Encapsulate(point);
                }
            }
            if (!initialized) throw new InvalidOperationException("Could not measure Jill's skinned geometry.");
            return result;
        }

        internal static void AdjustEyes(GameObject instance, System.Collections.Generic.List<Material> eyeMaterials)
        {
            string headId = instance.transform.Find("Head_pl0001") != null ? "pl0001" : "pl2001";
            int hiddenCorneas = 0, innerEyes = 0, tearLines = 0;
            foreach (Renderer renderer in instance.GetComponentsInChildren<Renderer>(true))
            {
                Material[] materials = renderer.sharedMaterials;
                bool changed = false;
                bool outerOnly = materials.Length > 0;
                foreach (Material source in materials)
                    if (!MatchesEyeMaterial(renderer, materials.Length, source, headId+"_Eyes_Out_Mat")) outerOnly = false;
                if (outerOnly)
                {
                    // The RE Engine cornea currently approximated as Standard glass
                    // reflects the outdoor sky indoors. Keep the iris/eyeball and hide
                    // only this overlay until a dedicated cornea shader is bundled.
                    renderer.enabled = false;
                    hiddenCorneas++;
                    ModAPI.Log.Write("[ForestRE3] EYE_CORNEA_HIDDEN renderer=" + renderer.name + "; material=" + materials[0].name);
                    continue;
                }
                for (int slot = 0; slot < materials.Length; slot++)
                {
                    Material original = materials[slot];
                    if (original == null) continue;
                    bool inner = MatchesEyeMaterial(renderer, materials.Length, original, headId+"_Eyes_In_Mat");
                    inner |= MatchesEyeMaterial(renderer, materials.Length, original, headId+"_Eye_In_Mat");
                    bool tear = MatchesEyeMaterial(renderer, materials.Length, original, headId+"_Tearline_Mat");
                    if (!inner && !tear) continue;
                    Material material = new Material(original);
                    material.name = original.name + "_RuntimeEye042";
                    eyeMaterials.Add(material);
                    // Only change existing uniforms: new shader keywords could request
                    // a variant stripped from the already-built 0.4 AssetBundle.
                    material.SetFloat("_GlossMapScale", inner ? 0.3f : 0.15f);
                    material.SetFloat("_Glossiness", inner ? 0.3f : 0.15f);
                    if (inner) innerEyes++;
                    if (tear) tearLines++;
                    ModAPI.Log.Write("[ForestRE3] EYE_MATERIAL_ADJUSTED renderer=" + renderer.name + "; sourceMaterial=" + original.name
                        + "; glossMapScale=" + material.GetFloat("_GlossMapScale") + "; glossiness=" + material.GetFloat("_Glossiness"));
                    materials[slot] = material;
                    changed = true;
                }
                if (changed) renderer.sharedMaterials = materials;
            }
            if (hiddenCorneas == 0 || innerEyes == 0 || tearLines == 0)
                ModAPI.Log.Write("[ForestRE3] EYE_PATCH_INCOMPLETE 0.4.2: corneasHidden=" + hiddenCorneas + "; innerEyes=" + innerEyes + "; tearLines=" + tearLines + ". Eye adjustment is not confirmed.");
            else
                ModAPI.Log.Write("[ForestRE3] EYE_PATCH_APPLIED 0.4.2: corneasHidden=" + hiddenCorneas + "; innerEyes=" + innerEyes + "; tearLines=" + tearLines + "; iris retained; dedicated cornea shader pending.");
        }

        private static bool MatchesEyeMaterial(Renderer renderer, int slotCount, Material material, string sourceName)
        {
            if (material == null) return false;
            string name = material.name.Replace(" (Instance)", "").Trim();
            // Unity restores NativeFormat .mat names from filenames, including the
            // part prefix. The FBX renderer also preserves its exact MDF identity.
            return name.Equals(sourceName, StringComparison.Ordinal)
                || name.EndsWith("_" + sourceName, StringComparison.Ordinal)
                || (slotCount == 1 && renderer.name.EndsWith("__" + sourceName, StringComparison.Ordinal));
        }

    }
}
