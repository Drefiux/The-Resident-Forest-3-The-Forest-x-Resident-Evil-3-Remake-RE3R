﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class G19Runtime
    {
        internal static GameObject RocketPrefab,RocketProjectilePrefab;
        internal static Texture2D RocketIcon;
        private float rocketSpeed,rocketGravity,rocketRange,rocketRadius;
        private readonly Dictionary<string,Re3RocketFlight> rockets=new Dictionary<string,Re3RocketFlight>();
        private readonly Dictionary<string,float> rocketFinished=new Dictionary<string,float>();
        private static string RocketKey(ulong actor,uint seq){return actor+"/"+seq;}
        private IEnumerator LoadRocket()
        {
            byte[] bytes=null;
            try
            {
                using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.rocket-"+(QualitySettings.activeColorSpace==ColorSpace.Linear ? "linear":"gamma")))
                {if(s==null || s.Length>32*1024*1024)throw new InvalidDataException("Rocket bundle size");bytes=new byte[(int)s.Length];int at=0;while(at<bytes.Length){int n=s.Read(bytes,at,bytes.Length-at);if(n<=0)throw new EndOfStreamException();at+=n;}}
                using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.rocket-ballistics.bin"))
                using(var r=new BinaryReader(s))
                {
                    if(r.ReadUInt32()!=0x31475052)throw new InvalidDataException("Rocket ballistics");
                    rocketSpeed=r.ReadSingle();rocketGravity=r.ReadSingle();rocketRange=r.ReadSingle();rocketRadius=r.ReadSingle();
                    if(!Finite(rocketSpeed)||rocketSpeed<=0||rocketSpeed>1000||rocketGravity!=0||rocketRange<=0||rocketRange>1000||rocketRadius<=0||rocketRadius>1)throw new InvalidDataException("Rocket source values");
                    // 0.8.9: double source speed, triple the original flight
                    // time. Range must grow sixfold to avoid early despawn.
                    rocketSpeed*=2f;rocketRange*=6f;
                }
            }
            catch(Exception e){ModAPI.Log.Write("[ForestRE3] ROCKET_ASSET_ERROR "+e);}
            if(bytes==null)yield break;
            var request=AssetBundle.LoadFromMemoryAsync(bytes);yield return request;var bundle=request.assetBundle;if(bundle==null)yield break;
            var p=bundle.LoadAssetAsync("Assets/Generated/Rocket/Rocket.prefab",typeof(GameObject));yield return p;RocketPrefab=p.asset as GameObject;
            p=bundle.LoadAssetAsync("Assets/Generated/RocketProjectile/RocketProjectile.prefab",typeof(GameObject));yield return p;RocketProjectilePrefab=p.asset as GameObject;
            RocketIcon=bundle.LoadAsset<Texture2D>("Assets/LocalAssets/Re3Rocket/rocket-icon.png");bundle.Unload(false);
            ModAPI.Log.Write("[ForestRE3] ROCKET_READY model=wp4600; speed="+rocketSpeed+"; gravity="+rocketGravity+"; range="+rocketRange+"; lifetime="+(rocketRange/rocketSpeed)+"; visualScale=1.25,1.25,1.60; radius="+rocketRadius+"; damage=330; authority=host");
        }
        private bool RocketReady {get{return RocketPrefab!=null && RocketProjectilePrefab!=null && rocketSpeed>0 && Re3Dynamite.ExplosionPrefab()!=null;}}
        private void LaunchRocket(ulong actor,uint seq,Vector3 origin,Vector3 direction,BoltEntity shooter,bool authoritative)
        {
            string key=RocketKey(actor,seq);
            if(rocketFinished.ContainsKey(key) || rockets.ContainsKey(key) || RocketProjectilePrefab==null || rocketSpeed<=0 || rockets.Count>=128)return;
            var obj=Instantiate(RocketProjectilePrefab);obj.name="ForestRE3_Rocket_"+key;obj.transform.position=origin;obj.transform.rotation=Quaternion.LookRotation(direction,Vector3.up);
            obj.transform.localScale=Vector3.Scale(obj.transform.localScale,new Vector3(1.25f,1.25f,1.60f));
            var flight=obj.AddComponent<Re3RocketFlight>();flight.Begin(this,key,actor,seq,origin,direction,rocketSpeed,rocketRange,rocketRadius,shooter,authoritative);rockets.Add(key,flight);
        }
        internal void RocketEnded(string key,ulong actor,uint seq,Vector3 position,Vector3 normal,bool impact,bool authoritative)
        {
            BoltEntity attacker=null;Re3RocketFlight flight;if(rockets.TryGetValue(key,out flight)){rockets.Remove(key);if(flight!=null){attacker=flight.shooter;flight.gameObject.SetActive(false);Destroy(flight.gameObject);}}
            if(rocketFinished.ContainsKey(key))return;rocketFinished[key]=Time.time+30f;
            if(impact)Re3Dynamite.Spawn(position+normal*.05f,attacker,actor);
            if(authoritative && BoltNetwork.isRunning && BoltNetwork.isServer)
                CoopSync.RocketState(null,delegate(BinaryWriter w){w.Write((byte)(impact ? 1:2));w.Write(actor);w.Write(seq);WriteVector(w,position);WriteVector(w,normal);});
        }
        internal static void ReceiveRocket(BinaryReader r)
        {
            byte op=r.ReadByte();ulong actor=r.ReadUInt64();uint seq=r.ReadUInt32();Vector3 position=ReadVector(r),direction=ReadVector(r);
            if(op>2||seq==0||!Finite(position)||!Finite(direction)||r.BaseStream.Position!=r.BaseStream.Length || (op==0&&(direction.sqrMagnitude<.9f||direction.sqrMagnitude>1.1f)))throw new InvalidDataException("Rocket state");
            if(Instance==null)return;
            if(op==0)Instance.LaunchRocket(actor,seq,position,direction,null,false);
            else Instance.RocketEnded(RocketKey(actor,seq),actor,seq,position,direction,op==1,false);
        }
        private void ClearRockets()
        {foreach(var f in rockets.Values)if(f!=null)Destroy(f.gameObject);rockets.Clear();rocketFinished.Clear();}
        private void TickRockets()
        {
            if(rocketFinished.Count==0)return;var expired=new List<string>();foreach(var p in rocketFinished)if(p.Value<Time.time)expired.Add(p.Key);foreach(var k in expired)rocketFinished.Remove(k);
        }
        internal static void RocketSnapshot(BoltConnection connection)
        {
            if(Instance==null)return;
            foreach(var f in Instance.rockets.Values)if(f!=null && f.authoritative)
                CoopSync.RocketState(connection,delegate(BinaryWriter w){w.Write((byte)0);w.Write(f.actor);w.Write(f.sequence);WriteVector(w,f.transform.position);WriteVector(w,f.direction);});
        }
    }
    public sealed class Re3RocketFlight : MonoBehaviour
    {
        private G19Runtime runtime;private string key;internal ulong actor;internal uint sequence;internal Vector3 direction;internal bool authoritative;
        private float speed,remaining,radius;internal BoltEntity shooter;private float expires;private bool done;
        internal void Begin(G19Runtime owner,string token,ulong id,uint seq,Vector3 origin,Vector3 forward,float velocity,float range,float size,BoltEntity entity,bool authority)
        {runtime=owner;key=token;actor=id;sequence=seq;direction=forward.normalized;speed=velocity;remaining=range;radius=size;shooter=entity;authoritative=authority;expires=Time.time+range/velocity+15f;}
        private void Update()
        {
            if(done||runtime==null)return;
            // Clients animate the source projectile, then wait for the reliable
            // host impact. They never decide collisions or apply enemy damage.
            float distance=Mathf.Min(speed*Time.deltaTime,remaining);
            if(authoritative && distance>0)
            {
                var hits=Physics.SphereCastAll(transform.position,radius,direction,distance,~0,QueryTriggerInteraction.Collide);
                Array.Sort(hits,delegate(RaycastHit a,RaycastHit b){return a.distance.CompareTo(b.distance);});
                foreach(var hit in hits)if(Solid(hit.collider))
                {done=true;runtime.RocketEnded(key,actor,sequence,hit.point,hit.normal,true,true);return;}
                // SphereCast does not report an overlap at its starting point.
                foreach(var c in Physics.OverlapSphere(transform.position,radius,~0,QueryTriggerInteraction.Collide))if(Solid(c))
                {done=true;runtime.RocketEnded(key,actor,sequence,transform.position,-direction,true,true);return;}
            }
            transform.position+=direction*distance;remaining-=distance;
            if(authoritative && remaining<=0 || Time.time>expires)
            {done=true;runtime.RocketEnded(key,actor,sequence,transform.position,Vector3.zero,false,authoritative);}
        }
        private bool Solid(Collider c)
        {
            if(c==null || (shooter!=null && c.transform.IsChildOf(shooter.transform)) || (actor==0 && LocalPlayer.Transform!=null && c.transform.IsChildOf(LocalPlayer.Transform)) || c.GetComponentInParent<Re3RocketFlight>()!=null || c.GetComponentInParent<JillMotionPreview>()!=null)return false;
            bool enemy=c.GetComponentInParent<EnemyHealth>()!=null || c.GetComponentInParent<mutantHitReceiver>()!=null;
            bool player=Re3FriendlyFire.Player(c)!=null;
            if(c.isTrigger && !enemy && !player)return false;
            // Native small plants are pass-through. Trunks, logs, constructed
            // walls and terrain remain solid regardless of their object name.
            for(Transform t=c.transform;t!=null;t=t.parent)
            {
                string tag=t.tag;
                if(tag=="SmallTree" || tag=="Bush" || tag=="Grass" || tag=="Leaves" || tag=="Water")return false;
                foreach(var component in t.GetComponents<Component>())if(component!=null)
                {string type=component.GetType().Name;if(type=="BushDamage" || type=="bushDamage" || type=="CutBush" || type=="Grass" || type=="PickUpGrowable" || type=="BerryBush")return false;}
                if(t.GetComponent<EnemyHealth>()!=null || tag=="Tree" || tag=="structure" || tag=="TerrainMain" || t.GetComponent<TerrainCollider>()!=null)break;
            }
            return true;
        }
    }
    // This marker survives the native Bomb's detachment of its explosion.
    public sealed class Re3DynamiteTag : MonoBehaviour {internal BoltEntity attacker;internal bool rocket;internal ulong actor;}
    public static class Re3Dynamite
    {
        private static GameObject explosionPrefab;
        public static GameObject ExplosionPrefab()
        {
            if(explosionPrefab!=null)return explosionPrefab;
            try
            {
                var native=Bolt.PrefabDatabase.Find(BoltPrefabs.Dynamite);
                var bomb=native!=null ? native.GetComponentInChildren<Bomb>(true):null;
                if(bomb!=null && bomb.Explosion!=null)explosionPrefab=bomb.Explosion;
                if(explosionPrefab==null)foreach(var b in Resources.FindObjectsOfTypeAll<Bomb>())if(b!=null && b.Explosion!=null && IsDynamite(b)){explosionPrefab=b.Explosion;break;}
            }
            catch(Exception e){ModAPI.Log.Write("[ForestRE3] DYNAMITE_PREFAB_ERROR "+e.Message);}
            return explosionPrefab;
        }
        private static bool IsDynamite(Bomb b)
        {for(Transform t=b.transform;t!=null;t=t.parent)if(t.name.IndexOf("dynamite",StringComparison.OrdinalIgnoreCase)>=0)return true;return false;}
        public static void Mark(Bomb bomb)
        {if(bomb!=null && bomb.Explosion!=null && IsDynamite(bomb) && bomb.Explosion.GetComponent<Re3DynamiteTag>()==null)bomb.Explosion.AddComponent<Re3DynamiteTag>();}
        internal static void Spawn(Vector3 position,BoltEntity attacker,ulong actor)
        {
            var prefab=ExplosionPrefab();if(prefab==null){ModAPI.Log.Write("[ForestRE3] ROCKET_EXPLOSION_MISSING");return;}
            var obj=UnityEngine.Object.Instantiate(prefab,position,Quaternion.identity);obj.name="ForestRE3_DynamiteExplosion";
            var tag=obj.GetComponent<Re3DynamiteTag>() ?? obj.AddComponent<Re3DynamiteTag>();tag.attacker=attacker;tag.rocket=true;tag.actor=actor;
            foreach(var e in obj.GetComponentsInChildren<Explode>(true))e.damage=330f;
            obj.SetActive(true);UnityEngine.Object.Destroy(obj,8f);
        }
        private sealed class Scope : IDisposable
        {
            internal Scope previous;internal BoltEntity attacker;internal bool rocket;internal ulong actor;internal readonly HashSet<EnemyHealth> hit=new HashSet<EnemyHealth>();
            public void Dispose(){current=previous;}
        }
        private static Scope current;
        public static IDisposable Begin(Explode explode)
        {
            var tag=explode.GetComponentInParent<Re3DynamiteTag>();bool dynamite=tag!=null || explode.name.IndexOf("dynamite",StringComparison.OrdinalIgnoreCase)>=0;
            var scope=new Scope{previous=current,attacker=tag!=null ? tag.attacker:null,rocket=tag!=null && tag.rocket,actor=tag!=null ? tag.actor:0};current=dynamite ? scope:null;
            if(dynamite)explode.damage=330f;return scope;
        }
        // Called only while the original explosion dispatches its player hit.
        // A regular dynamite/bomb has no rocket flag and retains native damage.
        public static bool AllowPlayerExplosion(PlayerStats stats)
        {
            if(current==null || !current.rocket || Re3CoopOptions.FriendlyFire || !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer)return true;
            if(stats!=LocalPlayer.Stats)return true;
            // The launch actor is carried in the trusted host impact message,
            // including on peers where the shooter entity is temporarily absent.
            return LocalPlayer.Entity!=null && LocalPlayer.Entity.isAttached && LocalPlayer.Entity.networkId.PackedValue==current.actor;
        }
        public static bool Hit(EnemyHealth health,float distance)
        {
            if(current==null)return false;
            if(BoltNetwork.isRunning && !BoltNetwork.isServer || health==null || health.Health<=0 || !current.hit.Add(health))return true;
            var ai=health.GetComponent<mutantAI>();
            if(ai!=null && ai.creepy_boss && !ai.girlFullyTransformed)return true;
            Re3EnemyBalance.Apply(health);health.hitBlock=false;health.getAttackDirection(5);
            if(current.attacker!=null)EnemyHealth.CurrentAttacker=current.attacker;
            bool mutant=ai!=null && (ai.creepy || ai.creepy_male || ai.creepy_fat || ai.creepy_baby || ai.creepy_boss);
            var animator=health.GetComponentInChildren<Animator>();
            // Sleeping cannibals have a hardcoded 100 HP melee override. A
            // blast wakes them and supplies its actual damage. Native downed
            // damage multiplier is compensated so one blast stays at 330.
            if(!mutant && animator!=null && animator.GetBool("sleepBOOL"))animator.SetBool("sleepBOOL",false);
            int amount=!mutant && animator!=null && animator.GetBool("deathBOOL") ? 165:330;
            health.HitReal(amount);
            ModAPI.Log.Write("[ForestRE3] DYNAMITE_DAMAGE damage=330; enemy="+health.name+"; remaining="+health.Health+"; authority=host");return true;
        }
    }
    public class Re3DynamiteBombPatch : global::Bomb
    {public new virtual void Start(){Re3Dynamite.Mark(this);base.Start();GC.KeepAlive(this);}}
    public class Re3DynamiteBlastPatch : global::Explode
    {public new virtual void RunExplode(){using(Re3Dynamite.Begin(this))base.RunExplode();GC.KeepAlive(this);}}
}
