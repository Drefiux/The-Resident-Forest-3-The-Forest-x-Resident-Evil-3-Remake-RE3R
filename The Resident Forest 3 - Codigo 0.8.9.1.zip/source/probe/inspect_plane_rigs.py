﻿"""Read local Unity scene hierarchy for the opening's player rigs."""
import json
import struct
from pathlib import Path
from inspect_native_controller import Reader, GAME, ROOT


def pointer(r):
    return [r.number('i'), r.number('q')]


def inspect(path):
    with path.open('rb') as f:
        header = f.read(20)
        size, _, version, offset = struct.unpack('>4I', header[:16])
        if version != 17: return []
        r = Reader(f.read(size)); r.cstring(); r.number('i'); tree = r.number('B')
        types = []
        for _ in range(r.number('i')):
            cls = r.number('i'); r.number('B'); r.number('h')
            if cls == 114: r.at += 16
            r.at += 16
            if tree:
                nodes, strings = r.number('i'), r.number('i'); r.at += nodes*24+strings
            types.append(cls)
        entries = []
        for _ in range(r.number('i')):
            r.align(); ident = r.number('q')
            start, count, typ = r.number('I'), r.number('I'), r.number('i')
            if types[typ] in (1, 4): entries.append((ident, start+offset, count, types[typ]))
        gos, transforms = {}, {}
        for ident, start, count, cls in entries:
            f.seek(start); q = Reader(f.read(count))
            if cls == 1:
                components = [pointer(q) for _ in range(q.number('i'))]
                layer = q.number('i'); length = q.number('i')
                name = q.value[q.at:q.at+length].decode('utf-8')
                q.at += length; q.align(); tag = q.number('H'); active = bool(q.number('B'))
                gos[ident] = dict(name=name, components=components, layer=layer, active=active)
            else:
                go = pointer(q); rotation = [q.number('f') for _ in range(4)]
                position = [q.number('f') for _ in range(3)]; scale = [q.number('f') for _ in range(3)]
                children = [pointer(q) for _ in range(q.number('i'))]; parent = pointer(q)
                transforms[ident] = dict(go=go, children=children, parent=parent,
                                         position=position, rotation=rotation, scale=scale)
        def hierarchy(ident, depth=0):
            t = transforms.get(ident)
            if t is None or depth > 50: return []
            go = gos.get(t['go'][1], {})
            line = dict(depth=depth, name=go.get('name', '?'), id=ident,
                        position=t['position'], rotation=t['rotation'], scale=t['scale'],
                        layer=go.get('layer'), active=go.get('active'))
            result = [line]
            for file_id, child in t['children']:
                if file_id == 0: result.extend(hierarchy(child, depth+1))
            return result
        found = []
        for ident, t in transforms.items():
            name = gos.get(t['go'][1], {}).get('name', '')
            if 'player' in name.lower() or 'crawl' in name.lower():
                h = hierarchy(ident)
                if any('Hips' in item['name'] or 'Pelvis' in item['name'] for item in h):
                    found.append(dict(file=path.name, name=name, hierarchy=h))
        return found


if __name__ == '__main__':
    report = []
    for path in list(GAME.glob('level[0-9]*'))+list(GAME.glob('*.assets')):
        if path.suffix == '.resS': continue
        report.extend(inspect(path))
    output = ROOT/'work/forest-re3-mashup/plane-rig-hierarchy.json'
    output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    for rig in report:
        names = [b['name'] for b in rig['hierarchy']]
        print(rig['file'], rig['name'], 'bones='+str(len(names)), 'hips='+str([n for n in names if 'Hips' in n]),
              'hands='+str([n for n in names if 'Hand' in n and 'Middle' in n]))
