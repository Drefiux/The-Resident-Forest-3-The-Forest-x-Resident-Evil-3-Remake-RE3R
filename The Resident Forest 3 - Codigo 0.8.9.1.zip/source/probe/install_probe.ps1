﻿$ErrorActionPreference = 'Stop'
$workspace = (Get-Location).Path
$probeDirectory = Join-Path $workspace 'work\forest-re3-mashup\probe'
$packageWorkspace = Join-Path $workspace 'work\forest-re3-mashup\modapi-workspace'
$game = 'C:\Program Files (x86)\Steam\steamapps\common\The Forest'
$managed = Join-Path $game 'TheForest_Data\Managed'
$mods = Join-Path $game 'Mods'
$preflight = Join-Path $workspace 'outputs\forest-re3-mashup\design\preflight-report.json'
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$helperSource = Join-Path $probeDirectory 'InstallProbe.cs'
$helperExe = Join-Path $packageWorkspace 'InstallProbe.exe'

$gate = Get-Content -LiteralPath $preflight -Raw | ConvertFrom-Json
if (-not $gate.buildAllowed -or $gate.buildMilestone -ne 'MODAPI_LOADER_PROBE') {
    throw "Preflight no autoriza este hito: $($gate.result) / $($gate.buildMilestone)"
}
if (-not (Test-Path -LiteralPath $game)) { throw 'No se encontró The Forest.' }
if (Test-Path -LiteralPath $mods) { throw 'La carpeta Mods ya existe; no se va a sobrescribir.' }
if (-not (Test-Path -LiteralPath (Join-Path $workspace 'work\universal-modder-data\backups\theforest-managed-pristine\20261005-165233.zip'))) {
    throw 'No se encontró el respaldo prístino de ensamblados requerido antes de instalar.'
}

function Get-InstallSnapshot {
    $files = @{}
    foreach ($file in Get-ChildItem -LiteralPath $managed -File) {
        $files['Managed/' + $file.Name] = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash
    }
    foreach ($file in Get-ChildItem -LiteralPath $game -File) {
        $files['Root/' + $file.Name] = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash
    }
    if (Test-Path -LiteralPath $mods) {
        foreach ($file in Get-ChildItem -LiteralPath $mods -File -Recurse) {
            $relative = $file.FullName.Substring($mods.Length).TrimStart('\').Replace('\', '/')
            $files['Mods/' + $relative] = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash
        }
    }
    return $files
}

$before = Get-InstallSnapshot
$manifestPath = Join-Path $probeDirectory 'install-diff.json'
$previousDirectory = Get-Location
try {
    & $compiler /nologo /target:exe /optimize+ "/out:$helperExe" "/reference:$(Join-Path $packageWorkspace 'ModAPI.exe')" "/reference:$(Join-Path $packageWorkspace 'ModAPI_Shared.dll')" $helperSource
    if ($LASTEXITCODE -ne 0) { throw "No se pudo compilar el instalador ModAPI con código $LASTEXITCODE." }

    Set-Location -LiteralPath $packageWorkspace
    & $helperExe 2>&1 | Tee-Object -FilePath (Join-Path $probeDirectory 'install-probe.log')
    if ($LASTEXITCODE -ne 0) { throw "ModAPI no pudo aplicar el paquete diagnóstico: código $LASTEXITCODE." }
}
finally {
    Set-Location -LiteralPath $previousDirectory
}

$after = Get-InstallSnapshot
$added = @($after.Keys | Where-Object { -not $before.ContainsKey($_) } | Sort-Object)
$removed = @($before.Keys | Where-Object { -not $after.ContainsKey($_) } | Sort-Object)
$changed = @($after.Keys | Where-Object { $before.ContainsKey($_) -and $before[$_] -ne $after[$_] } | Sort-Object)
$diff = [ordered]@{
    snapshotType = 'The Forest root files, Managed files and Mods files only'
    timestamp = (Get-Date).ToString('o')
    added = $added
    changed = $changed
    removed = $removed
    restoredFromPristineBackupAvailable = $true
    saveFilesTouched = $false
}
$diff | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifestPath -Encoding utf8
Get-Content -LiteralPath $manifestPath
