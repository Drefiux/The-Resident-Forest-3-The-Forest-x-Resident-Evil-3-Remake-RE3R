﻿using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class Re3InventoryRuntime
    {
        private GUIStyle title,label,small,button;private Texture2D pixel;
        private int catalogIndex;
        private int dragged=-1;private bool draggedChest,dragMoving;
        private uint dragRevision;private Vector2 dragStart,dragOffset;
        private Rect playerGrid,chestGrid;private float playerCell,chestCell;
        private readonly Color ink=new Color(.025f,.03f,.035f,.42f),panel=new Color(.06f,.07f,.08f,.96f),line=new Color(.4f,.45f,.47f);
        private void Styles()
        {
            if(pixel!=null)return;
            pixel=new Texture2D(1,1);pixel.SetPixel(0,0,Color.white);pixel.Apply();
            title=new GUIStyle(GUI.skin.label){fontSize=26,fontStyle=FontStyle.Normal};title.normal.textColor=Color.white;
            label=new GUIStyle(GUI.skin.label){fontSize=16,wordWrap=true};small=new GUIStyle(label){fontSize=13};
            button=new GUIStyle(GUI.skin.button){fontSize=15,wordWrap=true};
        }
        private void Fill(Rect rect,Color color){Color before=GUI.color;GUI.color=color;GUI.DrawTexture(rect,pixel);GUI.color=before;}
        private void Outline(Rect r,Color c){Fill(new Rect(r.x,r.y,r.width,1),c);Fill(new Rect(r.x,r.yMax-1,r.width,1),c);Fill(new Rect(r.x,r.y,1,r.height),c);Fill(new Rect(r.xMax-1,r.y,1,r.height),c);}
        private void Atlas(Rect target,Rect source)
        {
            Texture2D atlas=Re3Interface.Inventory ?? G19Runtime.InventoryAtlas;
            if(atlas==null){Outline(target,line);return;}
            Re3Interface.Image(target,atlas,source);
        }
        private void OnGUI()
        {
            if(!ActiveWorld)return;Styles();
            if(Re3Interface.TextFont!=null){title.font=Re3Interface.TextFont;label.font=Re3Interface.TextFont;small.font=Re3Interface.TextFont;}
            if(!menu)
            {
                if(aimed>=0)GUI.Box(new Rect(Screen.width*.5f-55,Screen.height*.65f,110,30),"[E] Baúl");
                if(Time.realtimeSinceStartup<noticeUntil)GUI.Label(new Rect(12,150,1000,42),feedback);
                return;
            }
            Matrix4x4 matrix=GUI.matrix;Color color=GUI.color;
            float scale=Mathf.Min(Screen.width/1120f,Screen.height/820f)*(debug ? 1f:.72f);
            float left=(Screen.width/scale-1100)*.5f,top=(Screen.height/scale-780)*.5f;
            GUI.matrix=Matrix4x4.TRS(new Vector3(left*scale,top*scale,0),Quaternion.identity,Vector3.one*scale);
            if(debug)Fill(new Rect(0,0,1100,780),new Color(.025f,.03f,.035f,.95f));
            if(debug)
            {
                GUI.Label(new Rect(28,19,950,38),"Laboratorio",title);
                Re3CoopOptions.DrawToggle(new Rect(35,65,1000,28),GUI.skin.toggle);
                if(GUI.Button(new Rect(1000,17,76,36),"Cerrar",button))Close();
                DrawDebug();
                GUI.Label(new Rect(35,720,1030,44),pending ? "Esperando al host…":feedback,small);
            }
            else
            {
                // The original ui3000 frames, ui3003 rules/gradients and RE
                // Helvetica replace the generic framed window. Keep the
                // expanded 4x5 bag and the requested clean two-panel locker.
                float x=opened>=0 ? 105:650;
                InventoryPanel(new Rect(x-17,70,418,590),"Inventario");
                Grid(player,x,142,96,false);
                if(opened>=0){InventoryPanel(new Rect(658,70,294,590),"Baúl");Grid(boxes[opened],675,142,120,true);}
                InventoryDrag();
            }
            GUI.matrix=matrix;GUI.color=color;
            if(Event.current.type==EventType.MouseDown || Event.current.type==EventType.MouseUp || Event.current.type==EventType.ScrollWheel)Event.current.Use();
        }
        private void InventoryPanel(Rect rect,string heading)
        {
            Fill(rect,ink);
            Color before=GUI.color;GUI.color=new Color(.7f,.76f,.78f,.13f);
            Re3Interface.Image(rect,Re3Interface.Gradients,new Rect(0,64,512,32));
            GUI.color=Color.white;GUI.Label(new Rect(rect.x+17,rect.y+12,rect.width-34,38),heading,title);
            GUI.color=new Color(.85f,.9f,.92f,.55f);Re3Interface.Rule(new Rect(rect.x+17,rect.y+56,rect.width-34,1));GUI.color=before;
        }
        private void Grid(Re3Bag bag,float x,float y,float size,bool chest)
        {
            var bounds=new Rect(x,y,bag.columns*size,(bag.slots.Length/bag.columns)*size);
            if(chest){chestGrid=bounds;chestCell=size;}else{playerGrid=bounds;playerCell=size;}
            for(int i=0;i<bag.slots.Length;i++)
            {
                var slot=bag.slots[i];if(slot.id==Re3Bag.Continued)continue;
                var item=Re3Catalog.Find(slot.id);int span=item==null ? 1:item.width;
                var rect=new Rect(x+(i%bag.columns)*size,y+(i/bag.columns)*size,size*span-5,size-5);
                bool hover=rect.Contains(Event.current.mousePosition);
                // Exact regions from ui3000.uvs.7: base #1, focus #47.
                Atlas(rect,new Rect(112,0,112,112));
                if(hover)Atlas(rect,new Rect(320,212,112,112));
                if(dragMoving && hover)Outline(rect,new Color(.9f,.95f,1f,.9f));
                if(item==null)continue;
                Rect inner=new Rect(rect.x+8,rect.y+8,rect.width-16,rect.height-16);
                if(Re3Weapon.Valid(item.id) && G19Runtime.WeaponIcon(item.id)!=null)GUI.DrawTexture(inner,G19Runtime.WeaponIcon(item.id),ScaleMode.ScaleToFit,true);
                else
                {
                    // The original UI's equip/selection glyph identifies the
                    // storage-only catalogue until those items gain models.
                    Color before=GUI.color;GUI.color=item.color;
                    Atlas(new Rect(rect.center.x-17,rect.center.y-17,34,34),new Rect(135,297,39,36));GUI.color=before;
                }
                if(Re3Weapon.Valid(item.id) && !chest && G19Runtime.EquippedId==item.id)
                    Atlas(new Rect(rect.x+6,rect.y+6,24,24),new Rect(48,112,48,48));
            }
        }
        private bool DragCell(Vector2 mouse,out bool chest,out int cell)
        {
            chest=opened>=0 && chestGrid.Contains(mouse);Rect bounds=chest ? chestGrid:playerGrid;
            cell=-1;if(!bounds.Contains(mouse))return false;
            Re3Bag bag=chest ? boxes[opened]:player;float size=chest ? chestCell:playerCell;
            cell=(int)((mouse.y-bounds.y)/size)*bag.columns+(int)((mouse.x-bounds.x)/size);
            return cell>=0 && cell<bag.slots.Length;
        }
        private void InventoryDrag()
        {
            Event e=Event.current;bool chest;int cell;
            if(!networkReady || pending || lifeQueue.Count>0){dragged=-1;return;}
            if(dragged>=0)
            {
                Re3Bag source=draggedChest && opened>=0 ? boxes[opened]:player;
                if(source.revision!=dragRevision){dragged=-1;return;}
            }
            if(e.type==EventType.MouseDown && e.button==0 && DragCell(e.mousePosition,out chest,out cell))
            {
                Re3Bag bag=chest ? boxes[opened]:player;int root=bag.Root(cell);
                if(Re3Catalog.Find(bag.slots[root].id)==null)return;
                dragged=root;draggedChest=chest;dragRevision=bag.revision;dragMoving=false;dragStart=e.mousePosition;
                Rect bounds=chest ? chestGrid:playerGrid;float size=chest ? chestCell:playerCell;
                dragOffset=e.mousePosition-new Vector2(bounds.x+(root%bag.columns)*size,bounds.y+(root/bag.columns)*size);e.Use();
            }
            if(dragged<0)return;
            if(e.type==EventType.MouseDrag){if((e.mousePosition-dragStart).sqrMagnitude>36f)dragMoving=true;e.Use();}
            if(e.type==EventType.MouseUp && e.button==0)
            {
                int source=dragged;bool fromChest=draggedChest,moved=dragMoving;dragged=-1;dragMoving=false;
                Re3Bag bag=fromChest ? boxes[opened]:player;var item=bag.slots[source];
                if(moved)
                {
                    if(DragCell(e.mousePosition,out chest,out cell))
                        SendRequest(7,opened>=0 ? opened:0,source,cell,(fromChest ? 1:0)|(chest ? 2:0),Vector3.zero);
                }
                else if(opened>=0)SendRequest((byte)(fromChest ? 2:1),opened,source,0,e.control ? 1:item.count,Vector3.zero);
                else if(Re3Weapon.Valid(item.id)){G19Runtime.ToggleEquip((byte)item.id);Close();}
                e.Use();return;
            }
            if(dragMoving && e.type==EventType.Repaint)
            {
                var item=Re3Catalog.Find((draggedChest ? boxes[opened]:player).slots[dragged].id);
                float size=draggedChest ? chestCell:playerCell;
                var rect=new Rect(e.mousePosition.x-dragOffset.x,e.mousePosition.y-dragOffset.y,size*item.width-5,size-5);
                Fill(rect,new Color(.04f,.05f,.06f,.8f));Outline(rect,new Color(.85f,.9f,.95f));
                Texture2D icon=Re3Weapon.Valid(item.id) ? G19Runtime.WeaponIcon(item.id):null;
                if(icon!=null)GUI.DrawTexture(new Rect(rect.x+8,rect.y+8,rect.width-16,rect.height-16),icon,ScaleMode.ScaleToFit,true);
                else{Color previous=GUI.color;GUI.color=item.color;Atlas(new Rect(rect.center.x-17,rect.center.y-17,34,34),new Rect(135,297,39,36));GUI.color=previous;}
            }
        }
        private void DrawDebug()
        {
            if(!Re3DeveloperTools.Enabled)return;
            Fill(new Rect(24,105,1052,582),panel);
            GUI.Label(new Rect(43,122,1020,30),"CINCO BAÚLES INDEPENDIENTES · 4 ESPACIOS CADA UNO",label);
            for(int i=0;i<5;i++)
            {
                int id=i; float y=170+i*69;
                GUI.Label(new Rect(43,y+7,420,38),(i+1)+". "+Re3ChestLocation.All[i].name,label);
                GUI.enabled=!teleporting;
                if(GUI.Button(new Rect(465,y,230,44),"Teletransportarme",button)) StartCoroutine(Teleport(id));
                GUI.enabled=networkReady && !pending;
                if(GUI.Button(new Rect(711,y,341,44),"Colocar copia delante de mí",button)) PlaceTest(id);
                GUI.enabled=true;
            }
            GUI.Label(new Rect(43,518,1008,48),"La copia usa los mismos 4 slots de ese baúl. G19: yate. M3: cueva de la katana.",small);
            GUI.Label(new Rect(43,570,1008,30),"OBJETOS DE PRUEBA PARA COMPROBAR LAS TRANSFERENCIAS",label);
            if(GUI.Button(new Rect(43,610,42,38),"<",button)) catalogIndex=(catalogIndex+Re3Catalog.Items.Length-1)%Re3Catalog.Items.Length;
            if(GUI.Button(new Rect(465,610,42,38),">",button)) catalogIndex=(catalogIndex+1)%Re3Catalog.Items.Length;
            Re3Item item=Re3Catalog.Items[catalogIndex]; GUI.Label(new Rect(100,615,350,45),item.name,label);
            GUI.enabled=networkReady && !pending;
            if(GUI.Button(new Rect(530,610,220,38),"Añadir 1 al inventario",button)) SendRequest(3,0,0,item.id,1,Vector3.zero);
            if(GUI.Button(new Rect(768,610,284,38),"Añadir pila ("+item.stack+")",button)) SendRequest(3,0,0,item.id,item.stack,Vector3.zero);
            GUI.enabled=true;
            GUI.Label(new Rect(43,660,1008,24),"G19 y M3: clic para equipar, botón derecho para apuntar, izquierdo para disparar, R para recargar.",small);
        }
    }
}
