﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using TheForest.Utils;

namespace ForestRE3JillVisualProbe
{
    // The opening has two authored actors, distinct from LocalPlayer.Animator:
    // TriggerCutScene.playerSeatGo and TriggerCutScene.crawl. Read their final
    // native poses; retain all cinematic cameras, props, timing and scripts.
    [DefaultExecutionOrder(10010)]
    public sealed class JillPlaneAvatar : MonoBehaviour
    {
        private sealed class Rig
        {
            public Animator source;
            public AnimatorCullingMode culling;
            public GameObject model;
            public JillMotionPreview pose;
            public bool ready;
            public float viewHeight;
            public readonly Dictionary<Renderer, bool> native = new Dictionary<Renderer, bool>();
            public readonly List<Renderer> world = new List<Renderer>(), fp = new List<Renderer>();
            public readonly List<Mesh> meshes = new List<Mesh>();
            public readonly List<Material> materials = new List<Material>();
        }
        private static JillPlaneAvatar current;
        private readonly List<Rig> rigs = new List<Rig>();
        private readonly HashSet<Animator> failedSources = new HashSet<Animator>();
        private GameObject prefab;
        private float scanAt;
        internal static bool CharacterLocked
        {
            get { return IsActive || (LocalPlayer.AnimControl!=null && LocalPlayer.AnimControl.introCutScene); }
        }
        public static bool IsActive
        {
            get
            {
                if (current == null) return false;
                foreach (Rig rig in current.rigs) if (Active(rig)) return true;
                return false;
            }
        }
        private static bool Active(Rig rig)
        {
            return rig.ready && rig.source != null && rig.source.enabled && rig.source.gameObject.activeInHierarchy;
        }
        public void Initialize(GameObject avatar)
        {
            prefab = avatar; current = this;
            Camera.onPreCull+=BeforeCamera;
        }
        private void Update()
        {
            for (int i = rigs.Count-1; i >= 0; i--)
                if (rigs[i].source == null) { Release(rigs[i]); rigs.RemoveAt(i); }
            if (Time.realtimeSinceStartup < scanAt) return;
            scanAt = Time.realtimeSinceStartup+.25f;
            TriggerCutScene scene = Scene.TriggerCutScene;
            if (scene == null) return;
            if (scene.playerSeatGo != null) Add(scene.playerSeatGo.GetComponent<Animator>(), "avion_sentada");
            // The cutscene's crawl cache is private; resolve the same actor
            // from its explicit PlaneReal root, including the inactive rig.
            if (scene.PlaneReal != null)
            {
                setupPlayerCrawl crawl = scene.PlaneReal.GetComponentInChildren<setupPlayerCrawl>(true);
                if (crawl != null) Add(crawl.GetComponent<Animator>(), "despertar_suelo");
            }
        }
        private void Add(Animator source, string phase)
        {
            if (source == null || source == LocalPlayer.Animator || failedSources.Contains(source)
                || !source.gameObject.activeInHierarchy || !source.isInitialized) return;
            foreach (Rig prior in rigs) if (prior.source == source) return;
            var rig = new Rig { source=source, culling=source.cullingMode };
            try
            {
                // Only skins weighted to this cinematic human skeleton. Its
                // book, pillow, Timmy and other actors retain their renderers.
                foreach (Renderer skin in source.GetComponentsInChildren<Renderer>(true))
                {
                    if (JillPlayerAvatar.IsNativeSkinRenderer(skin)) rig.native.Add(skin, skin.enabled);
                }
                if (rig.native.Count == 0) throw new InvalidOperationException("Missing opening human skins: "+source.name);
                rig.model = UnityEngine.Object.Instantiate(prefab) as GameObject;
                rig.model.name = "Jill_Opening_0771_"+phase;
                JillPlayerAvatar.MakeVisualOnly(rig.model);
                rig.model.transform.position = source.transform.position;
                rig.model.transform.rotation = source.transform.rotation;
                rig.model.transform.localScale = Vector3.one;
                AvatarGeometry.AdjustEyes(rig.model, rig.materials);
                rig.world.AddRange(rig.model.GetComponentsInChildren<Renderer>(true));
                JillPlayerAvatar.BuildFirstPersonGeometry(rig.model, false, rig.meshes, rig.fp);
                int lowerParts = rig.fp.Count;
                JillPlayerAvatar.BuildFirstPersonGeometry(rig.model, true, rig.meshes, rig.fp);
                if (lowerParts == 0 || rig.fp.Count == lowerParts) throw new InvalidOperationException("Missing opening first-person geometry.");
                JillFirstPersonView.Configure(rig.fp,rig.materials);
                rig.pose = rig.model.AddComponent<JillMotionPreview>();
                rig.pose.AttachToCinematic(source); rig.pose.Initialize();
                if (!rig.pose.PoseAvailable || rig.pose.NativeToJillRatio <= .001f)
                    throw new InvalidOperationException("Incomplete opening body/palm mapping: "+source.name);
                source.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                rig.ready = true; rigs.Add(rig); Step(rig);
                ModAPI.Log.Write("[ForestRE3] OPENING_JILL_ATTACHED phase="+phase+"; source="+source.name
                    +"; nativeSkins="+rig.native.Count+"; fpParts="+rig.fp.Count+"; nativePose=true; firstPersonHeadVisible=false; cameraUnmodified=true");
            }
            catch (Exception error)
            {
                failedSources.Add(source);
                rigs.Remove(rig); Release(rig); scanAt = Time.realtimeSinceStartup+4f;
                ModAPI.Log.Write("[ForestRE3] OPENING_JILL_ATTACH_FAILED phase="+phase+"; "+error);
            }
        }
        private static void Hide(Rig rig)
        {
            foreach (Renderer skin in rig.native.Keys) if (skin != null) skin.enabled = false;
        }
        private static void Step(Rig rig)
        {
            bool active = Active(rig);
            if (rig.model.activeSelf != active) rig.model.SetActive(active);
            if (!active) return;
            Hide(rig);
            Transform native = rig.source.transform;
            Vector3 forward = Vector3.ProjectOnPlane(native.forward, Vector3.up);
            if (forward.sqrMagnitude < .00001f) forward = Vector3.forward;
            rig.model.transform.rotation = Quaternion.LookRotation(forward.normalized, Vector3.up);
            rig.model.transform.position = native.position;
            // Bind-space ratio, independent of the player's standing capsule:
            // these actors are seated/prone and have their own scene scale.
            float scale = Mathf.Abs(native.lossyScale.y)*(1.72f/1.78f)/rig.pose.NativeToJillRatio;
            rig.model.transform.localScale = Vector3.one*scale;
            rig.viewHeight=1.72f*scale;
            rig.pose.StepPlayerPose();
            // Persistent visibility before skinning/culling, just like the
            // normal player. Only head/eyes/hair are absent from the FP copy.
            foreach (Renderer skin in rig.world) if (skin != null) skin.shadowCastingMode=ShadowCastingMode.ShadowsOnly;
            foreach (Renderer skin in rig.fp) if (skin != null) skin.enabled=true;
            if (!rig.pose.PoseAvailable) throw new InvalidOperationException("Opening pose stopped: "+native.name);
        }
        private void LateUpdate()
        {
            for (int i = rigs.Count-1; i >= 0; i--)
            {
                Rig rig = rigs[i];
                if (rig.source == null) continue;
                try { Step(rig); }
                catch (Exception error)
                {
                    failedSources.Add(rig.source);
                    Release(rig); rigs.RemoveAt(i); scanAt = Time.realtimeSinceStartup+4f;
                    ModAPI.Log.Write("[ForestRE3] OPENING_JILL_POSE_FAILED "+error);
                }
            }
        }
        private static void Release(Rig rig)
        {
            foreach (var saved in rig.native) if (saved.Key != null) saved.Key.enabled = saved.Value;
            if (rig.ready && rig.source != null) rig.source.cullingMode = rig.culling;
            if (rig.model != null) UnityEngine.Object.Destroy(rig.model);
            foreach (Mesh mesh in rig.meshes) if (mesh != null) UnityEngine.Object.Destroy(mesh);
            foreach (Material material in rig.materials) if (material != null) UnityEngine.Object.Destroy(material);
            rig.ready = false;
        }
        private void OnDestroy()
        {
            Camera.onPreCull-=BeforeCamera;
            foreach (Rig rig in rigs) Release(rig); rigs.Clear(); failedSources.Clear();
            if (current == this) current = null;
        }
        private void BeforeCamera(Camera camera)
        {
            if (camera==null) return;
            foreach (Rig rig in rigs) if (Active(rig)) JillFirstPersonView.BeforeCamera(camera,rig.materials,rig.viewHeight);
        }
    }
}
