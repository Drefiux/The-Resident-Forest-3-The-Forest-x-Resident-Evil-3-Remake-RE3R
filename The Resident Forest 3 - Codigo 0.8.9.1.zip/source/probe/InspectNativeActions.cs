﻿using System;
using System.Collections.Generic;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

internal static class InspectNativeActions
{
    static IEnumerable<TypeDefinition> Types(TypeDefinition type)
    {
        yield return type;
        foreach (var child in type.NestedTypes)
            foreach (var nested in Types(child)) yield return nested;
    }
    public static void Main(string[] args)
    {
        using (var module = ModuleDefinition.ReadModule(args[0]))
        foreach (var type in module.Types.SelectMany(Types))
        {
            string name = type.FullName.ToLowerInvariant();
            bool relevant = name.Contains("playeranimatorcontrol") || name.Contains("firstpersoncharacter")
                || name.Contains("playerhitreact") || name.Contains("playerclimb") || name.Contains("playerwater")
                || name.Contains("playerswim") || name.Contains("playerstats") || name.Contains("playerinventory")
                || name.Contains("playerspecialactions") || name.Contains("playeranimsetup");
            if (!relevant) continue;
            Console.WriteLine("TYPE " + type.FullName);
            foreach (var f in type.Fields) Console.WriteLine("FIELD " + f.FullName + " " + f.Attributes);
            foreach (var p in type.Properties) Console.WriteLine("PROPERTY " + p.FullName);
            foreach (var method in type.Methods.Where(m => m.HasBody))
            {
                bool full = args.Length > 1 && args[1] == "--il";
                Console.WriteLine("METHOD " + method.FullName);
                foreach (var instruction in method.Body.Instructions)
                    if (full || instruction.OpCode.Code == Code.Ldstr) Console.WriteLine(instruction);
            }
        }
    }
}
