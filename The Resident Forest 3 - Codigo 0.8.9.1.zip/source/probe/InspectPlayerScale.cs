﻿using System;
using System.Linq;
using Mono.Cecil;

internal static class InspectPlayerScale
{
    public static void Main(string[] args)
    {
        using (var module = ModuleDefinition.ReadModule(args[0]))
        {
            if (args.Length > 1 && args[1] == "--combat")
            {
                foreach (var type in module.Types.Where(t => t.Name == "playerAnimatorControl" || t.Name == "PlayerInventory" || t.Name == "FirstPersonCharacter"))
                {
                    foreach (var field in type.Fields.Where(f => f.Name.ToLowerInvariant().Contains("attack") || f.Name.ToLowerInvariant().Contains("charge")))
                        Console.WriteLine("FIELD " + type.FullName + "." + field.Name + " " + field.FieldType + " " + field.Attributes);
                    foreach (var method in type.Methods.Where(m => m.Name.Contains("WeaponChargeStartTime"))) Console.WriteLine("ACCESS " + method.FullName + " " + method.Attributes);
                    foreach (var method in type.Methods.Where(m => m.HasBody && (m.Name == "PlayerIsAttacking" || m.Name.ToLowerInvariant().Contains("charge"))))
                    {
                        Console.WriteLine("METHOD " + method.FullName);
                        foreach (var instruction in method.Body.Instructions) Console.WriteLine(instruction);
                    }
                    foreach (var method in type.Methods.Where(m => m.HasBody))
                        foreach (var instruction in method.Body.Instructions)
                            if (instruction.OpCode.Code == Mono.Cecil.Cil.Code.Ldstr)
                            {
                                string value = instruction.Operand as string;
                                if (value != null && (value.ToLowerInvariant().Contains("attack") || value.ToLowerInvariant().Contains("charge") || value.ToLowerInvariant().Contains("swing")))
                                    Console.WriteLine("STRING " + type.FullName + "." + method.Name + " " + value);
                            }
                }
                var animatorType = module.Types.First(t => t.Name == "playerAnimatorControl");
                foreach (var nested in animatorType.NestedTypes.Where(t => t.Name.Contains("checkChargeConditions")))
                    foreach (var method in nested.Methods.Where(m => m.Name == "MoveNext"))
                    {
                        Console.WriteLine("CHARGE_ITERATOR " + method.FullName);
                        foreach (var instruction in method.Body.Instructions) Console.WriteLine(instruction);
                    }
                return;
            }
            if (args.Length > 1 && args[1] == "--motion-metadata")
            {
                foreach (var resource in module.Resources.OfType<EmbeddedResource>().Where(r => r.Name.Contains("motion-preview")))
                {
                    byte[] bytes = resource.GetResourceData();
                    string hash = BitConverter.ToString(System.Security.Cryptography.SHA256.Create().ComputeHash(bytes)).Replace("-", "");
                    Console.WriteLine("RESOURCE " + resource.Name + " bytes=" + bytes.Length + " SHA256=" + hash);
                }
                foreach (var parent in module.Types.Where(t => t.Name.Contains("JillMotionPreview")))
                    foreach (var type in parent.NestedTypes.Where(t => t.Name.Contains("Motion")))
                    {
                        Console.WriteLine("TYPE " + type.FullName + " attributes=" + type.Attributes);
                        foreach (var field in type.Fields) Console.WriteLine("FIELD " + field.Name + " attributes=" + field.Attributes);
                    }
                return;
            }
            if (args.Length > 1 && args[1] == "--action-signatures")
            {
                foreach (var type in module.Types.Where(t => t.Name == "playerAnimatorControl" || t.Name == "FirstPersonCharacter"))
                {
                    foreach (var method in type.Methods.Where(m => m.Name == "PlayerIsAttacking")) Console.WriteLine(method.FullName + " " + method.Attributes);
                    foreach (var field in type.Fields.Where(f => f.Name == "crouching" || f.Name == "running")) Console.WriteLine(field.FullName + " " + field.Attributes);
                }
                return;
            }
            if (args.Length > 1 && args[1] == "--rig-strings")
            {
                foreach (var type in module.Types)
                    foreach (var method in type.Methods.Where(m => m.HasBody))
                        foreach (var instruction in method.Body.Instructions)
                        {
                            string value = instruction.Operand as string;
                            if (instruction.OpCode.Code != Mono.Cecil.Cil.Code.Ldstr || value == null) continue;
                            string low = value.ToLowerInvariant();
                            if (low.Contains("joint") || low.Contains("bip01") || low.Contains("spine") || low.Contains("mixamorig") || type.Name == "playerScriptSetup")
                                Console.WriteLine(type.FullName + "." + method.Name + " = " + value);
                        }
                return;
            }
            if (args.Length > 1 && args[1] == "--bindings")
            {
                string[] required = { "TheForest.Utils.LocalPlayer|MainCam", "TheForest.Utils.LocalPlayer|FpCharacter", "FirstPersonCharacter|capsule", "FirstPersonCharacter|originalHeight" };
                foreach (string item in required)
                {
                    string[] parts = item.Split('|');
                    var type = module.Types.First(t => t.FullName == parts[0]);
                    var field = type.Fields.First(f => f.Name == parts[1]);
                    if (!field.IsPublic) throw new InvalidOperationException("Inaccessible native field " + item);
                    Console.WriteLine("BINDING_OK " + type.FullName + "." + field.Name + " " + field.FieldType.FullName + " " + field.Attributes);
                }
                return;
            }
            foreach (var type in module.Types.Where(t => t.FullName == "FirstPersonCharacter" || t.FullName == "TheForest.Utils.LocalPlayer"))
            {
                Console.WriteLine("TYPE " + type.FullName);
                foreach (var field in type.Fields.Where(f => type.Name == "LocalPlayer" || f.Name == "originalHeight" || f.Name == "capsule" || f.Name == "crouching"))
                    Console.WriteLine("FIELD " + field.Attributes + " " + field.FieldType.FullName + " " + field.Name);
                if (type.Name != "FirstPersonCharacter") continue;
                foreach (var method in type.Methods.Where(m => m.Name == "Start" || m.Name == "Awake" || m.Name == "ResetCapsule" || m.Name == "ScaleCapsuleForCrouching"))
                {
                    Console.WriteLine("METHOD " + method.Name);
                    if (method.HasBody) foreach (var instruction in method.Body.Instructions) Console.WriteLine(instruction);
                }
            }
        }
    }
}
