﻿using System;
using UnityEngine;
using TheForest.Utils;
namespace ForestRE3JillVisualProbe
{
    // One small state per pooled enemy. Native health initialization is async;
    // reconcile its max-HP writes, never refill health on every update.
    public sealed class Re3EnemyBalanceState : MonoBehaviour
    {
        internal mutantAI ai;
        internal int target;
        internal string kind;
        internal void ResetSpawn(){target=0;kind=null;}
    }
    public static class Re3EnemyBalance
    {
        public static void Spawned(EnemyHealth health)
        {
            if(health==null || (BoltNetwork.isRunning && !BoltNetwork.isServer))return;
            State(health).ResetSpawn();
        }
        private static Re3EnemyBalanceState State(EnemyHealth health)
        {
            var state=health.GetComponent<Re3EnemyBalanceState>();
            if(state==null)state=health.gameObject.AddComponent<Re3EnemyBalanceState>();
            if(state.ai==null)state.ai=health.GetComponent<mutantAI>();
            if(state.ai==null)state.ai=health.GetComponentInParent<mutantAI>();
            return state;
        }
        public static void Apply(EnemyHealth health)
        {
            if(health==null || health.Health<=0 || health.maxHealth<=0 || (BoltNetwork.isRunning && !BoltNetwork.isServer))return;
            var state=State(health);var ai=state.ai;if(ai==null)return;
            int difficulty=GameSetup.IsHardSurvivalMode ? 2:GameSetup.IsHardMode ? 1:0;
            string kind;int target=Target(ai,difficulty,out kind);if(target==0)return;
            if(state.target==target && state.kind==kind && health.maxHealth==target)
            {health.maxHealthFloat=target;return;}
            int previous=health.maxHealth;
            health.Health=Mathf.Clamp(Mathf.RoundToInt((float)health.Health/previous*target),1,target);
            health.recoverValue=Mathf.Clamp(Mathf.RoundToInt((float)health.recoverValue/previous*target),0,target);
            health.maxHealth=target;health.maxHealthFloat=target;
            state.target=target;state.kind=kind;
            ModAPI.Log.Write("[ForestRE3] ENEMY_BALANCE kind="+kind+"; difficulty="+difficulty+"; nativeMax="+previous+"; max="+target+"; current="+health.Health+"; authority=host");
        }
        private static int Target(mutantAI ai,int difficulty,out string kind)
        {
            int normal,hard,survival;
            if(ai.creepy_boss){kind="Megan";normal=4500;hard=6500;survival=9000;}
            else if(ai.creepy_baby){kind=null;return 0;}
            else if(ai.creepy_male){kind="Armsy";normal=850;hard=1300;survival=1800;}
            else if(ai.creepy_fat){kind="Cowman";normal=1000;hard=1500;survival=2000;}
            else if(ai.creepy){kind="Virginia";normal=750;hard=1150;survival=1600;}
            else if(ai.skinned){kind=null;return 0;}
            else if(ai.pale)
            {
                if(ai.maleSkinny || ai.femaleSkinny){kind="PaleCave";normal=160;hard=240;survival=320;}
                else {kind="PaleBlueStrong";normal=220;hard=330;survival=440;}
            }
            else if(ai.leader || ai.fireman){kind="LeaderTorch";normal=120;hard=180;survival=240;}
            else if(ai.maleSkinny || ai.femaleSkinny){kind="Skinny";normal=60;hard=90;survival=120;}
            else {kind=null;return 0;}
            return difficulty==2 ? survival:difficulty==1 ? hard:normal;
        }
    }
    public class Re3EnemyHealthPatch : global::EnemyHealth
    {
        public new virtual void OnEnable(){base.OnEnable();Re3EnemyBalance.Spawned(this);GC.KeepAlive(this);}
        public new virtual void Update(){Re3EnemyBalance.Apply(this);base.Update();GC.KeepAlive(this);}
        public new virtual void Explosion(float distance){if(!Re3Dynamite.Hit(this,distance))base.Explosion(distance);GC.KeepAlive(this);}
        public new virtual void Hit(int damage){Re3EnemyBalance.Apply(this);base.Hit(damage);GC.KeepAlive(this);}
        public new virtual void HitReal(int damage){Re3EnemyBalance.Apply(this);base.HitReal(damage);GC.KeepAlive(this);}
    }
}
