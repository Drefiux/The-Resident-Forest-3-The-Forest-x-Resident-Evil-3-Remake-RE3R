﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace ForestRE3JillVisualProbe
{
    // External animation laboratory: reads the player's skeleton, never writes it.
    public sealed partial class JillMotionPreview : MonoBehaviour
    {
        private sealed class Rest { public Transform bone; public Vector3 position, scale, figurePosition, previousPosition; public Quaternion rotation, figureRotation, previousRotation; }
        private sealed class Binding { public MotionTrack track; public Rest target; public MotionBone source; }
        private sealed class NativeRest { public Vector3 position; public Quaternion rotation; }
        private sealed class LegSupport { public Rest thigh, knee, ankle; }
        private sealed class NativeBinding { public Transform source; public Rest target; public NativeRest rest; public Quaternion alignedTargetRest; public ArmSupport arm; public HandSupport hand; public bool upperArm, shoulderAnchor; }
        private sealed class FingerBinding { public Transform source, child; public Rest target; public Quaternion sourceLocalRest, parentAxes; public Vector3 targetSegmentDirection, tipLocalDirection; }
        private sealed class HandSupport
        {
            public Transform wrist, index, middle, little;
            public Rest targetWrist, targetIndex, targetMiddle, targetLittle;
            public Quaternion targetPalmRest, desired, sourcePalmRest, currentPalm;
            public Vector3 sampledForward, sampledNormal;
            public readonly List<FingerBinding> fingers = new List<FingerBinding>();
        }
        private sealed class ShoulderSample { public Quaternion[] features = new Quaternion[4], rotations = new Quaternion[12]; public Vector3[] positions = new Vector3[12]; }
        private sealed class ArmSupport
        {
            public Rest clavicle, humerus, radius, wrist;
            public Rest[] helpers, features;
            public Transform sourceShoulder, sourceElbow, sourceWrist;
            public Quaternion upperReferenceFrame, foreReferenceFrame, upperDesired, foreDesired;
            public Vector3 previousPlane;
            public ShoulderSample[] samples;
            public int[] nearest = new int[4];
            public float[] errors = new float[4], weights = new float[4];
            public float matchError;
            public bool rollReady;
            public float wristRoll;
        }
        private sealed class SoleMesh { public Transform[] bones; public Matrix4x4[] bindposes, matrices; public Vector3[] vertices; public BoneWeight[] weights; public int[] indices, bodyIndices; }
        private MotionData data;
        private readonly Dictionary<int,List<Binding>> dodgeTracks=new Dictionary<int,List<Binding>>();
        private DodgeAction inspectionDodge;
        internal void InspectDodge(DodgeAction value) { inspectionDodge=value; }
        private CharacterProfile character = CharacterProfile.Jill;
        private float[][][] shoulderData;
        private static readonly string[] SelectionModes = { "", "idle", "walk", "run", "forest" };
        private readonly Dictionary<string, Rest> rest = new Dictionary<string, Rest>(StringComparer.Ordinal);
        private readonly Dictionary<string, List<Binding>> tracks = new Dictionary<string, List<Binding>>(StringComparer.Ordinal);
        private readonly List<NativeBinding> native = new List<NativeBinding>();
        private readonly List<ArmSupport> armSupports = new List<ArmSupport>();
        private readonly List<HandSupport> hands = new List<HandSupport>();
        private readonly List<LegSupport> groundedLegs = new List<LegSupport>();
        private readonly HashSet<Rest> armPoseBones = new HashSet<Rest>();
        private readonly List<SoleMesh> soles = new List<SoleMesh>();
        private readonly List<SoleMesh> bodyContacts = new List<SoleMesh>();
        private readonly Dictionary<Rest, Quaternion> legRotations = new Dictionary<Rest, Quaternion>();
        private readonly Dictionary<Rest, Vector3> legPositions = new Dictionary<Rest, Vector3>();
        private Rest eyeLeft, eyeRight;
        private float nextEyeHeightLog;
        private float playerMeshBottom;
        private JillNativeActions actions;
        private Transform sourceRoot;
        private Animator sourceAnimator, sourceOverride;
        private Animator remoteSource;
        private BoltEntity remoteEntity;
        private IPlayerState remoteState;
        private Animator ExpectedSource { get { return remoteEntity!=null ? remoteSource : (sourceOverride!=null ? sourceOverride : TheForest.Utils.LocalPlayer.Animator); } }
        private Quaternion nativeBasis = Quaternion.identity;
        private Quaternion nativePoseBasis = Quaternion.identity, sourceHeading = Quaternion.identity;
        private float nativePositionRatio, motionPositionRatio = 1f, xSign = -1f;
        private int selection;
        private bool paused, ready, failed;
        private bool playerAttached, firstPersonRig;
        private bool AnatomicalFingerChains { get { return firstPersonRig || remoteEntity!=null; } }
        private string currentMode = "", nativeIssue = "";
        private float elapsed, nextNativeRetry;
        private float floorY, standingLocalHeight, groundedPlayerY;
        private bool floorReady;
        private bool rootReferenceReady, impactTracking;
        private Vector3 neutralRootOffset, impactOrigin, previewWorldOffset;
        private Quaternion impactHeading = Quaternion.identity;
        public string Status { get { return (paused ? "PAUSA | " : "") + (selection == 0 ? "automatico | " : "manual | ") + currentMode
            + (currentMode == "forest" && actions != null ? " | " + actions.Action + " | " + actions.Phase : "")
            + (currentMode != "forest" && HeldHandOverlay ? " | agarre nativo" : "") + nativeIssue; } }
        private bool HeldHandOverlay { get { return selection == 0 && actions != null && (actions.HeldPose
            || (remoteState!=null && (remoteState.itemInLeftHand>0 || remoteState.itemInRightHand>0))); } }

        public void Initialize() { Initialize(CharacterProfile.Jill); }

        internal void Initialize(CharacterProfile profile)
        {
            character=profile; data=profile.Motion; shoulderData=profile.Shoulders;
            if (data == null)
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(character.Resource("-motion-preview.bin")))
                {
                    if (stream == null) throw new InvalidOperationException("Missing Jill motion resource.");
                    data = JillMotionDataReader.Read(stream); character.Motion=data;
                    ModAPI.Log.Write("[ForestRE3] MOTION_BINARY_READ_OK character="+character.Name+"; format=JRM1; clips=" + data.clips.Length);
                }
            if (data == null || data.clips == null || data.clips.Length != 3) throw new InvalidOperationException("Invalid Jill motion manifest.");
            Transform skeleton = transform.Find(character.Skeleton);
            if (skeleton == null) throw new InvalidOperationException("Missing animation skeleton.");
            foreach (Transform bone in skeleton.GetComponentsInChildren<Transform>(true))
                rest.Add(bone.name, new Rest { bone = bone, position = bone.localPosition, rotation = bone.localRotation, scale = bone.localScale,
                    figurePosition = transform.InverseTransformPoint(bone.position), figureRotation = Quaternion.Inverse(transform.rotation) * bone.rotation });
            rest.TryGetValue("EyeCorner_L",out eyeLeft); rest.TryGetValue("EyeCorner_R",out eyeRight);
            if (firstPersonRig && (eyeLeft==null || eyeRight==null)) throw new InvalidOperationException("Missing Jill anatomical eye height reference.");
            if (firstPersonRig && sourceOverride==null)
                foreach (string side in new[] { "l", "r" })
                    groundedLegs.Add(new LegSupport { thigh=rest[side+"_leg_femur"], knee=rest[side+"_leg_tibia"], ankle=rest[side+"_leg_ankle"] });
            MotionBone sourceCog = FindMotionBone(data.clips[0], "COG");
            Rest cog, femur;
            if (!rest.TryGetValue("COG", out cog) || sourceCog == null || Mathf.Abs(sourceCog.restPosition[1]) < 0.01f)
                throw new InvalidOperationException("Missing motion translation reference.");
            motionPositionRatio = cog.position.y / sourceCog.restPosition[1];
            MotionBone sourceFemur = FindMotionBone(data.clips[0], "l_leg_femur");
            if (sourceFemur != null && rest.TryGetValue("l_leg_femur", out femur))
                xSign = Mathf.Sign(femur.position.x * sourceFemur.restPosition[0]);
            if (shoulderData == null)
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(character.Resource("-shoulder-correctives.bin")))
                {
                    if (stream == null) throw new InvalidOperationException("Missing authored shoulder correctives.");
                    shoulderData = JillShoulderDataReader.Read(stream); character.Shoulders=shoulderData;
                }
            foreach (MotionClip clip in data.clips)
            {
                var mapped = new List<Binding>();
                var absent = new HashSet<string>(StringComparer.Ordinal);
                foreach (MotionTrack track in clip.tracks)
                {
                    Rest target;
                    MotionBone source = FindMotionBone(clip, track.bone);
                    if (track.bone == "root" || track.bone == "Null_Offset") continue;
                    if (source == null) throw new InvalidOperationException("Missing RE motion rest bone " + track.bone);
                    if (!rest.TryGetValue(track.bone, out target))
                    {
                        // These source-only equipment helpers do not exist in the
                        // exported model and have no skin weights to drive.
                        if (track.bone != "setProp_D_00" && track.bone != "r_holster_muscle")
                            throw new InvalidOperationException("Unmapped RE motion bone " + track.bone);
                        absent.Add(track.bone);
                        continue;
                    }
                    mapped.Add(new Binding { track = track, target = target, source = source });
                }
                tracks.Add(clip.mode, mapped);
                ModAPI.Log.Write("[ForestRE3] MOTION_BOUND character="+character.Name+"; mode=" + clip.mode + "; source=" + clip.name + "; frames=" + clip.frames
                    + "; fps=" + clip.fps + "; tracks=" + mapped.Count + "; translationRatio=" + motionPositionRatio + "; xSign=" + xSign);
                foreach (string name in absent) ModAPI.Log.Write("[ForestRE3] MOTION_SOURCE_ONLY_HELPER mode=" + clip.mode + "; bone=" + name);
            }
            ready = true;
            BindArmSupports();
            // Ground contact belongs to the native capsule for a player rig.
            // The dedicated first-person rig may contain no enabled feet.
            if (!playerAttached) CacheSoles();
            BindNative();
            ModAPI.Log.Write("[ForestRE3] CHARACTER_POSE_READY character="+character.Name+"; RE3 idle/walk/run; all other weighted native actions and transitions; swimming/jump/climb/impact supported; nativePlayerReadOnly=true");
        }

        public void RestoreRestForPlacement()
        {
            foreach (Rest item in rest.Values)
            {
                item.bone.localPosition = item.position;
                item.bone.localRotation = item.rotation;
                item.bone.localScale = item.scale;
            }
        }

        // The playable adapter owns placement and calls the pose after native
        // animation. It never applies the inspection figure's root displacement
        // or fixed ground plane a second time to the moving player.
        public void AttachToPlayer(bool firstPerson)
        {
            playerAttached = true; firstPersonRig = firstPerson; paused = false;
            selection = 0; enabled = false;
        }

        public void AttachToCinematic(Animator source)
        {
            sourceOverride = source;
            AttachToPlayer(true);
        }

        internal void AttachToRemote(BoltEntity entity, Animator source)
        {
            remoteEntity=entity; remoteSource=source; remoteState=entity.GetState<IPlayerState>();
            AttachToPlayer(false);
        }

        public float NativeToJillRatio { get { return nativePositionRatio; } }
        internal float DodgeMotionScale { get { return Mathf.Abs(motionPositionRatio*transform.lossyScale.y); } }
        internal bool TryDodgeEyes(out Vector3 position,out Quaternion rotation)
        {
            position=Vector3.zero; rotation=Quaternion.identity;
            Rest head;
            if (!ready || failed || eyeLeft==null || eyeRight==null || !rest.TryGetValue("head",out head)) return false;
            position=(eyeLeft.bone.position+eyeRight.bone.position)*.5f;
            // Convert the head's authored bone axes into the figure's forward/up
            // axes. This retains every animated pitch/roll, including inversion.
            rotation=head.bone.rotation*Quaternion.Inverse(head.figureRotation);
            return true;
        }
        public void SetPlayerMeshBottom(float bottom) { playerMeshBottom=bottom; }
        public Quaternion SourceHeading { get { return sourceHeading; } }

        private void AlignCinematicRoot()
        {
            foreach (NativeBinding binding in native)
                if (binding.target.bone.name == "COG")
                { binding.target.bone.position = binding.source.position; return; }
        }

        public bool PoseAvailable { get { return ready && !failed && native.Count >= 16 && hands.Count == 2; } }
        public void StepPlayerPose() { LateUpdate(); }

        public void SetGroundReference(float worldY)
        {
            floorY = worldY; floorReady = true;
            rootReferenceReady = impactTracking = false; previewWorldOffset = Vector3.zero;
        }

        private void CacheSoles()
        {
            float minY = float.PositiveInfinity, maxY = float.NegativeInfinity;
            var candidates = new List<SoleMesh>();
            foreach (SkinnedMeshRenderer renderer in GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (!renderer.enabled || renderer.sharedMesh == null) continue;
                Mesh mesh = renderer.sharedMesh;
                var item = new SoleMesh { bones = renderer.bones, bindposes = mesh.bindposes, vertices = mesh.vertices, weights = mesh.boneWeights };
                if (item.bones.Length != item.bindposes.Length || item.vertices.Length != item.weights.Length) continue;
                item.matrices = new Matrix4x4[item.bones.Length];
                UpdateSkinMatrices(item);
                for (int i = 0; i < item.vertices.Length; i++)
                {
                    float y = SkinPoint(item, i).y;
                    minY = Mathf.Min(minY, y); maxY = Mathf.Max(maxY, y);
                }
                candidates.Add(item);
            }
            float band = (maxY-minY)*0.012f;
            standingLocalHeight = (maxY-minY)/Mathf.Abs(transform.lossyScale.y);
            int probes = 0;
            foreach (SoleMesh item in candidates)
            {
                var indices = new List<int>();
                for (int i = 0; i < item.vertices.Length; i++) if (SkinPoint(item, i).y <= minY+band) indices.Add(i);
                // Whole-body contact samples are used for prone/knockdown
                // poses, where feet alone cannot describe the ground contact.
                var bodyIndices = new List<int>(indices);
                int stride = Math.Max(1, item.vertices.Length/256);
                for (int i = 0; i < item.vertices.Length; i += stride) bodyIndices.Add(i);
                item.bodyIndices = bodyIndices.ToArray(); bodyContacts.Add(item);
                if (indices.Count > 0) { item.indices = indices.ToArray(); probes += item.indices.Length; soles.Add(item); }
            }
            if (soles.Count == 0) throw new InvalidOperationException("No sole geometry for ground correction.");
            floorY = minY; floorReady = true;
            ModAPI.Log.Write("[ForestRE3] SOLE_GROUND_READY probes=" + probes + "; referenceY=" + floorY + "; soleBand=" + band);
        }
        private static void UpdateSkinMatrices(SoleMesh item)
        {
            for (int b = 0; b < item.bones.Length; b++) item.matrices[b] = item.bones[b].localToWorldMatrix * item.bindposes[b];
        }
        private static Vector3 SkinPoint(SoleMesh item, int index)
        {
            Vector3 vertex = item.vertices[index]; BoneWeight weight = item.weights[index];
            Vector3 point = Vector3.zero;
            if (weight.weight0 > 0f) point += item.matrices[weight.boneIndex0].MultiplyPoint3x4(vertex)*weight.weight0;
            if (weight.weight1 > 0f) point += item.matrices[weight.boneIndex1].MultiplyPoint3x4(vertex)*weight.weight1;
            if (weight.weight2 > 0f) point += item.matrices[weight.boneIndex2].MultiplyPoint3x4(vertex)*weight.weight2;
            if (weight.weight3 > 0f) point += item.matrices[weight.boneIndex3].MultiplyPoint3x4(vertex)*weight.weight3;
            return point;
        }
        private void CorrectGroundPenetration()
        {
            if (!floorReady) return;
            JillNativeActions.GroundSupport support = currentMode == "forest" && actions != null
                ? actions.Support : JillNativeActions.GroundSupport.Feet;
            if (support == JillNativeActions.GroundSupport.Free) return;
            float lowest = float.PositiveInfinity;
            foreach (SoleMesh item in support == JillNativeActions.GroundSupport.Body ? bodyContacts : soles)
            {
                UpdateSkinMatrices(item);
                foreach (int index in support == JillNativeActions.GroundSupport.Body ? item.bodyIndices : item.indices)
                    lowest = Mathf.Min(lowest, SkinPoint(item, index).y);
            }
            float correction = floorY-lowest;
            if (correction > 0.00001f) rest["COG"].bone.position += Vector3.up*correction;
        }

        public void DisableAfterInitializationError(Exception exception)
        {
            ready = false; failed = true;
            RestoreRestForPlacement();
            currentMode = "animaciones no disponibles: " + exception.GetType().Name;
            ModAPI.Log.Write("[ForestRE3] MOTION_INITIALIZATION_FAILED_FIGURE_RETAINED " + exception);
        }

        private static MotionBone FindMotionBone(MotionClip clip, string name)
        {
            foreach (MotionBone bone in clip.bones) if (bone.name == name) return bone;
            return null;
        }

        private void LateUpdate()
        {
            if (!ready || failed || paused) return;
            try
            {
                string mode = SelectMode();
                if (mode != currentMode)
                {
                    currentMode = mode; elapsed = 0f;
                    foreach (ArmSupport arm in armSupports) arm.rollReady = false;
                    ModAPI.Log.Write("[ForestRE3] MOTION_MODE " + mode + "; selection=" + selection);
                }
                elapsed += Time.deltaTime;
                if (mode == "forest") ApplyNative(false);
                else
                {
                    ApplyRE(mode);
                    if (firstPersonRig)
                    {
                        // Retain RE locomotion in the legs, but use one native
                        // torso/arm pose for the camera and original item grips.
                        legRotations.Clear(); legPositions.Clear();
                        foreach (Rest item in rest.Values) if (IsLeg(item.bone))
                        { legRotations[item]=item.bone.localRotation; legPositions[item]=item.bone.localPosition; }
                        ApplyNative(false);
                        foreach (var saved in legRotations) saved.Key.bone.localRotation=saved.Value;
                        foreach (var saved in legPositions) saved.Key.bone.localPosition=saved.Value;
                    }
                    else if (HeldHandOverlay) ApplyNative(true);
                }
                if (sourceOverride != null || (remoteEntity==null && playerAttached && TheForest.Utils.LocalPlayer.AnimControl != null
                    && TheForest.Utils.LocalPlayer.AnimControl.introCutScene)) AlignCinematicRoot();
                if (firstPersonRig) { AlignFirstPersonBody(); AlignGroundedLegs(); AlignPlayerArms(); ApplyAnatomicalFingers(); }
                else if (remoteEntity!=null && (mode=="forest" || HeldHandOverlay)) { AlignPlayerArms(); ApplyAnatomicalFingers(); }
                DodgeAction dodge=inspectionDodge ?? (playerAttached && sourceOverride==null ? DodgeRuntime.Pose(remoteEntity):null);
                ApplyG19(dodge!=null && dodge.Playing);
                if (dodge!=null && dodge.Playing) ApplyDodge(dodge);
                else if (!playerAttached) CorrectGroundPenetration();
            }
            catch (Exception exception)
            {
                failed = true;
                RestoreRestForPlacement();
                currentMode = "ERROR: " + exception.GetType().Name;
                ModAPI.Log.Write("[ForestRE3] MOTION_PREVIEW_FAILED " + exception);
            }
        }

        private string SelectMode()
        {
            Animator expected = ExpectedSource;
            if (sourceAnimator == null || expected != sourceAnimator)
            {
                if (Time.realtimeSinceStartup > nextNativeRetry) { nextNativeRetry = Time.realtimeSinceStartup+1f; BindNative(); }
            }
            if (actions != null) actions.Read();
            UpdateNativeRootFrame();
            if (sourceOverride != null) return "forest";
            if (remoteEntity!=null)
            {
                if (actions!=null && actions.Native) return "forest";
                float speed=remoteState!=null ? Mathf.Abs(remoteState.overallSpeed) : 0f;
                return speed>.65f ? "run" : (speed>.03f ? "walk" : "idle");
            }
            if (selection > 0) return SelectionModes[selection];
            FirstPersonCharacter controller = remoteEntity==null ? TheForest.Utils.LocalPlayer.FpCharacter : null;
            if (controller == null) return "idle";
            if (actions != null && actions.Native) return "forest";
            if (controller.running) return "run";
            Rigidbody body = TheForest.Utils.LocalPlayer.Rigidbody;
            return body != null && Vector3.ProjectOnPlane(body.velocity, Vector3.up).sqrMagnitude > 0.25f ? "walk" : "idle";
        }

        private void UpdateNativeRootFrame()
        {
            FirstPersonCharacter controller = TheForest.Utils.LocalPlayer.FpCharacter;
            if (sourceRoot == null || actions == null) return;
            Vector3 flatForward = Vector3.ProjectOnPlane(sourceRoot.forward, Vector3.up);
            if (flatForward.sqrMagnitude > .00001f) sourceHeading = Quaternion.LookRotation(flatForward, Vector3.up);
            // Remove heading, retaining the native model's pitch/roll. Removing
            // the whole Animator rotation flattened swimming/knockdown poses.
            nativePoseBasis = nativeBasis * Quaternion.Inverse(sourceHeading) * sourceRoot.rotation;
            if (playerAttached) { previewWorldOffset = Vector3.zero; return; }
            if (controller == null) return;
            Vector3 playerPosition = controller.transform.position;
            Vector3 rootOffset = controller.transform.InverseTransformPoint(sourceRoot.position);
            if (!rootReferenceReady)
            {
                groundedPlayerY = playerPosition.y; neutralRootOffset = rootOffset;
                rootReferenceReady = true;
            }
            if (controller.Grounded && !actions.Impact && actions.Action != "escalar" && actions.Action != "nadar")
            {
                groundedPlayerY = playerPosition.y;
                if (!actions.Native) neutralRootOffset = rootOffset;
            }
            if (actions.Action == "escalar" || actions.Action == "nadar") groundedPlayerY = playerPosition.y;
            CapsuleCollider capsule = controller.capsule;
            float nativeHeight = capsule != null ? controller.originalHeight * capsule.transform.TransformVector(Vector3.up).magnitude : 0f;
            float ratio = nativeHeight > .01f ? standingLocalHeight * Mathf.Abs(transform.lossyScale.y)/nativeHeight : 1f;
            Vector3 desiredOffset = Vector3.zero;
            if (actions.Native)
            {
                Vector3 modelOffset = controller.transform.TransformVector(rootOffset-neutralRootOffset);
                desiredOffset = transform.rotation * (nativeBasis * Quaternion.Inverse(sourceHeading) * modelOffset) * ratio;
                if (actions.Airborne && actions.Action == "salto")
                    desiredOffset += Vector3.up * Mathf.Max(0f, playerPosition.y-groundedPlayerY) * ratio;
                if (actions.Impact)
                {
                    if (!impactTracking) { impactOrigin = playerPosition; impactHeading = sourceHeading; impactTracking = true; }
                    Vector3 displacement = playerPosition-impactOrigin;
                    desiredOffset += transform.rotation * (nativeBasis * Quaternion.Inverse(impactHeading) * displacement) * ratio;
                }
                else impactTracking = false;
            }
            else impactTracking = false;
            previewWorldOffset = Vector3.Lerp(previewWorldOffset, desiredOffset, 1f-Mathf.Exp(-16f*Time.deltaTime));
        }

        private void ApplyDodge(DodgeAction action)
        {
            MotionClip clip=DodgeRuntime.Clips[action.clip];
            List<Binding> mapped;
            if (!dodgeTracks.TryGetValue(action.clip,out mapped))
            {
                mapped=new List<Binding>();
                foreach (MotionTrack track in clip.tracks)
                {
                    Rest target; MotionBone source=FindMotionBone(clip,track.bone);
                    if (source!=null && track.bone!="root" && track.bone!="Null_Offset" && rest.TryGetValue(track.bone,out target))
                        mapped.Add(new Binding { track=track,target=target,source=source });
                }
                dodgeTracks.Add(action.clip,mapped);
            }
            float age=action.Age, frame=Mathf.Clamp01(age/DodgeRuntime.AnimationSeconds)*clip.frames;
            float weight=Mathf.Min(Mathf.Clamp01(age/.06f),Mathf.Clamp01((DodgeRuntime.AnimationSeconds-age)/.12f));
            foreach (Rest bone in rest.Values)
            {
                bone.previousRotation=bone.bone.localRotation; bone.previousPosition=bone.bone.localPosition;
                bone.bone.localRotation=bone.rotation; bone.bone.localPosition=bone.position; bone.bone.localScale=bone.scale;
            }
            foreach (Binding binding in mapped)
            {
                float[] values=binding.track.values; int stride=binding.track.kind=="rotation" ? 5:4;
                int count=values.Length/stride,low=0,high=count-1;
                if (count==0) continue;
                while (low<high) { int mid=(low+high+1)/2; if (values[mid*stride]<=frame) low=mid; else high=mid-1; }
                int next=Math.Min(low+1,count-1),a=low*stride+1,b=next*stride+1;
                float duration=values[next*stride]-values[low*stride];
                float blend=duration>0f ? Mathf.Clamp01((frame-values[low*stride])/duration):0f;
                if (binding.track.kind=="rotation")
                {
                    Quaternion sample=Quaternion.Slerp(ConvertRotation(values,a),ConvertRotation(values,b),blend);
                    binding.target.bone.localRotation=binding.target.rotation*Quaternion.Inverse(ConvertRotation(binding.source.restRotation,0))*sample;
                }
                else if (binding.track.kind=="position")
                {
                    Vector3 reference=ConvertPosition(binding.source.restPosition,0);
                    float ratio=reference.magnitude>.001f && binding.track.bone!="COG" ? binding.target.position.magnitude/reference.magnitude:motionPositionRatio;
                    Vector3 delta=(Vector3.Lerp(ConvertPosition(values,a),ConvertPosition(values,b),blend)-reference)*ratio;
                    if (binding.track.bone=="COG") { delta.x=0f; delta.z=0f; }
                    binding.target.bone.localPosition=binding.target.position+delta;
                }
            }
            foreach (Rest bone in rest.Values)
            {
                bone.bone.localRotation=Quaternion.Slerp(bone.previousRotation,bone.bone.localRotation,weight);
                bone.bone.localPosition=Vector3.Lerp(bone.previousPosition,bone.bone.localPosition,weight);
            }
            // Full-body contact rather than standing feet during an authored roll.
            if (!playerAttached && floorReady)
            {
                float lowest=float.PositiveInfinity;
                foreach (SoleMesh item in bodyContacts)
                { UpdateSkinMatrices(item); foreach (int index in item.bodyIndices) lowest=Mathf.Min(lowest,SkinPoint(item,index).y); }
                if (floorY>lowest) rest["COG"].bone.position+=Vector3.up*(floorY-lowest);
            }
        }

        private Vector3 ConvertPosition(float[] values, int offset)
        {
            return new Vector3(values[offset] * xSign, values[offset+1], values[offset+2]);
        }
        private Quaternion ConvertRotation(float[] values, int offset)
        {
            Quaternion q = xSign < 0f ? new Quaternion(values[offset], -values[offset+1], -values[offset+2], values[offset+3])
                : new Quaternion(values[offset], values[offset+1], values[offset+2], values[offset+3]);
            return Normalize(q);
        }
        private static Quaternion Normalize(Quaternion q)
        {
            float length = Mathf.Sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
            if (length < 0.00001f) throw new InvalidOperationException("Invalid motion quaternion.");
            return new Quaternion(q.x/length, q.y/length, q.z/length, q.w/length);
        }

        private void ApplyRE(string mode)
        {
            MotionClip clip = null;
            foreach (MotionClip item in data.clips) if (item.mode == mode) clip = item;
            if (clip == null) throw new InvalidOperationException("Missing selected motion " + mode);
            float frame = (elapsed * clip.fps) % Mathf.Max(1f, clip.frames);
            // Restore only bones without tracks too, so native-to-RE transitions
            // do not retain an unmatched neck or auxiliary bone pose.
            foreach (Rest item in rest.Values) { item.previousRotation = item.bone.localRotation; item.previousPosition = item.bone.localPosition; }
            if (!HeldHandOverlay) RestoreRestForPlacement();
            else foreach (Rest item in rest.Values)
                if (!armPoseBones.Contains(item)) { item.bone.localPosition = item.position; item.bone.localRotation = item.rotation; item.bone.localScale = item.scale; }
            foreach (Binding binding in tracks[mode])
            {
                if (HeldHandOverlay && armPoseBones.Contains(binding.target)) continue;
                float[] values = binding.track.values;
                int stride = binding.track.kind == "rotation" ? 5 : 4;
                int count = values.Length / stride;
                if (count == 0) throw new InvalidOperationException("Empty motion track.");
                int low = 0, high = count-1;
                while (low < high) { int mid = (low+high+1)/2; if (values[mid*stride] <= frame) low = mid; else high = mid-1; }
                int next = Math.Min(low+1, count-1);
                float duration = values[next*stride] - values[low*stride];
                float blend = duration > 0f ? Mathf.Clamp01((frame-values[low*stride])/duration) : 0f;
                int a = low*stride+1, b = next*stride+1;
                if (binding.track.kind == "rotation")
                    binding.target.bone.localRotation = Quaternion.Slerp(ConvertRotation(values, a), ConvertRotation(values, b), blend);
                else if (binding.track.kind == "position")
                {
                    Vector3 position = Vector3.Lerp(ConvertPosition(values, a), ConvertPosition(values, b), blend);
                    Vector3 delta = (position - ConvertPosition(binding.source.restPosition, 0)) * motionPositionRatio;
                    if (binding.track.bone == "COG") { delta.x = 0f; delta.z = 0f; }
                    binding.target.bone.localPosition = binding.target.position + delta;
                }
                else
                {
                    Vector3 scale = Vector3.Lerp(new Vector3(values[a], values[a+1], values[a+2]), new Vector3(values[b], values[b+1], values[b+2]), blend);
                    if (scale.x < 0.05f || scale.y < 0.05f || scale.z < 0.05f || scale.x > 4f || scale.y > 4f || scale.z > 4f)
                        throw new InvalidOperationException("Unexpected scale key on " + binding.track.bone);
                    binding.target.bone.localScale = Vector3.Scale(binding.target.scale, scale);
                }
            }
            float smoothing = Mathf.Clamp01(Time.deltaTime*16f);
            foreach (Rest item in rest.Values)
            {
                if (HeldHandOverlay && armPoseBones.Contains(item)) continue;
                item.bone.localRotation = Quaternion.Slerp(item.previousRotation, item.bone.localRotation, smoothing);
                item.bone.localPosition = Vector3.Lerp(item.previousPosition, item.bone.localPosition, smoothing);
            }
            nativeIssue = "";
        }

        private void BindNative()
        {
            native.Clear();
            sourceAnimator = ExpectedSource;
            actions = null; rootReferenceReady = false; impactTracking = false;
            if (sourceAnimator == null) { nativeIssue = " | falta Animator nativo"; return; }
            sourceRoot = sourceAnimator.transform;
            actions = new JillNativeActions(sourceAnimator, remoteEntity==null, remoteState);
            var names = new Dictionary<string, Transform>(StringComparer.Ordinal);
            foreach (Transform bone in sourceRoot.GetComponentsInChildren<Transform>(true)) if (!names.ContainsKey(bone.name)) names.Add(bone.name, bone);
            var bind = new Dictionary<Transform, NativeRest>();
            Transform meshRoot=remoteEntity!=null ? remoteEntity.transform : sourceRoot;
            foreach (SkinnedMeshRenderer renderer in meshRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (renderer.sharedMesh == null) continue;
                Transform[] bones = renderer.bones;
                Matrix4x4[] poses = renderer.sharedMesh.bindposes;
                if (bones.Length != poses.Length) continue;
                for (int i = 0; i < bones.Length; i++)
                {
                    if (bones[i] == null || bind.ContainsKey(bones[i])) continue;
                    Matrix4x4 matrix = sourceRoot.worldToLocalMatrix * renderer.transform.localToWorldMatrix * poses[i].inverse;
                    bind.Add(bones[i], new NativeRest { position = matrix.GetColumn(3), rotation = Quaternion.LookRotation(matrix.GetColumn(2), matrix.GetColumn(1)) });
                }
            }
            string[,] pairs = {
                { "char_Hips", "COG", "char_Spine", "spine_0" },
                { "char_Spine", "spine_0", "char_Spine1", "spine_1" },
                { "char_Spine1", "spine_1", "char_Spine2", "spine_2" },
                { "char_Spine2", "spine_2", "char_Neck", "neck_0" },
                { "char_Neck", "neck_0", "char_Head1", "head" },
                { "char_Head1", "head", "", "" },
                { "char_LeftShoulder", "l_arm_clavicle", "char_LeftArm", "l_arm_humerus" },
                { "char_LeftArm", "l_arm_humerus", "char_LeftForeArm", "l_arm_radius" },
                { "char_LeftForeArm", "l_arm_radius", "char_LeftHand", "l_arm_wrist" },
                { "char_LeftHand", "l_arm_wrist", "", "" },
                { "char_RightShoulder", "r_arm_clavicle", "char_RightArm", "r_arm_humerus" },
                { "char_RightArm", "r_arm_humerus", "char_RightForeArm", "r_arm_radius" },
                { "char_RightForeArm", "r_arm_radius", "char_RightHand", "r_arm_wrist" },
                { "char_RightHand", "r_arm_wrist", "", "" },
                { "char_LeftUpLeg", "l_leg_femur", "char_LeftLeg", "l_leg_tibia" },
                { "char_LeftLeg", "l_leg_tibia", "char_LeftFoot", "l_leg_ankle" },
                { "char_LeftFoot", "l_leg_ankle", "char_LeftToeBase", "l_leg_ball" },
                { "char_LeftToeBase", "l_leg_ball", "", "" },
                { "char_RightUpLeg", "r_leg_femur", "char_RightLeg", "r_leg_tibia" },
                { "char_RightLeg", "r_leg_tibia", "char_RightFoot", "r_leg_ankle" },
                { "char_RightFoot", "r_leg_ankle", "char_RightToeBase", "r_leg_ball" },
                { "char_RightToeBase", "r_leg_ball", "", "" }
            };
            Transform left, right;
            if (names.TryGetValue("char_LeftUpLeg", out left) && names.TryGetValue("char_RightUpLeg", out right)
                && bind.ContainsKey(left) && bind.ContainsKey(right))
            {
                Vector3 sourceAcross = Vector3.ProjectOnPlane(bind[left].position-bind[right].position, Vector3.up);
                Vector3 targetAcross = Vector3.ProjectOnPlane(rest["l_leg_femur"].figurePosition-rest["r_leg_femur"].figurePosition, Vector3.up);
                nativeBasis = Quaternion.FromToRotation(sourceAcross, targetAcross);
            }
            for (int i = 0; i < pairs.GetLength(0); i++)
            {
                Transform source, child;
                Rest target, targetChild;
                if (!names.TryGetValue(pairs[i,0], out source) || !rest.TryGetValue(pairs[i,1], out target) || !bind.ContainsKey(source)) continue;
                Quaternion aligned = target.figureRotation;
                if (names.TryGetValue(pairs[i,2], out child) && rest.TryGetValue(pairs[i,3], out targetChild) && bind.ContainsKey(child))
                {
                    Vector3 sourceDirection = nativeBasis * (bind[child].position-bind[source].position);
                    Vector3 targetDirection = targetChild.figurePosition-target.figurePosition;
                    if (sourceDirection.sqrMagnitude > 0.0001f && targetDirection.sqrMagnitude > 0.0001f)
                        aligned = Quaternion.FromToRotation(targetDirection, sourceDirection) * aligned;
                }
                var binding = new NativeBinding { source = source, target = target, rest = bind[source], alignedTargetRest = aligned };
                // Native first-person clavicle protraction displaced Jill's
                // shoulder socket about 7 cm forward even with the 35-degree
                // limit in 0.5.3/0.5.4. Keep this joint's RE bind orientation
                // relative to her chest. Upper/lower arms still receive the
                // complete native pose; RE locomotion keeps authored clavicles.
                if (target.bone.name.EndsWith("_arm_clavicle", StringComparison.Ordinal))
                    binding.shoulderAnchor = true;
                native.Add(binding);
            }
            foreach (ArmSupport arm in armSupports)
                foreach (NativeBinding binding in native)
                {
                    if (binding.target == arm.humerus) { arm.sourceShoulder = binding.source; binding.arm = arm; binding.upperArm = true; }
                    if (binding.target == arm.radius) { arm.sourceElbow = binding.source; binding.arm = arm; }
                    if (binding.target == arm.wrist) arm.sourceWrist = binding.source;
                }
            bool haveHips = native.Count > 0 && native[0].target.bone.name == "COG";
            if (native.Count < 16 || !haveHips)
            {
                nativeIssue = " | mapeo Forest incompleto (" + native.Count + "/22)";
                ModAPI.Log.Write("[ForestRE3] NATIVE_MOTION_MAP_INCOMPLETE bones=" + native.Count + "; root=" + sourceRoot.name + "; transforms=" + names.Count + "; bindBones=" + bind.Count);
                native.Clear();
                return;
            }
            float nativeHipHeight = Mathf.Abs(native[0].rest.position.y);
            nativePositionRatio = nativeHipHeight > 0.01f ? Mathf.Abs(rest["COG"].figurePosition.y) / nativeHipHeight : 0.37f;
            int fingers = BindNativeHands(names, bind);
            nativeIssue = "";
            ModAPI.Log.Write("[ForestRE3] NATIVE_MOTION_MAP_READY mapped=" + native.Count + "; animator=" + sourceAnimator.name + "; humanoid="
                + sourceAnimator.isHuman + "; fingers=" + fingers + (AnatomicalFingerChains ? "/34":"/30") + "; palms=" + hands.Count + "/2; positionRatio=" + nativePositionRatio + "; basis=" + nativeBasis + "; player poses are read only.");
        }

        private static Quaternion PalmFrame(Vector3 wrist, Vector3 index, Vector3 middle, Vector3 little)
        {
            Vector3 forward = middle-wrist;
            Vector3 normal = Vector3.Cross(forward, index-little);
            if (forward.sqrMagnitude < .000001f || normal.sqrMagnitude < .00000001f)
                throw new InvalidOperationException("Degenerate anatomical palm reference.");
            // The same index-to-little convention on both rigs preserves
            // chirality without an arbitrary 90/180 degree wrist correction.
            return Quaternion.LookRotation(forward, normal);
        }

        private int BindNativeHands(Dictionary<string, Transform> names, Dictionary<Transform, NativeRest> bind)
        {
            hands.Clear();
            int mapped = 0;
            string[] sourceDigits = { "Thumb", "Index", "Middle", "Ring", "Pinky" };
            string[] targetDigits = { "thumb", "index", "middle", "ring", "little" };
            for (int side = 0; side < 2; side++)
            {
                string sourceSide = side == 0 ? "Left" : "Right", targetSide = side == 0 ? "l" : "r";
                Transform wrist, index, middle, little;
                if (!names.TryGetValue("char_"+sourceSide+"Hand", out wrist)
                    || !names.TryGetValue("char_"+sourceSide+"HandIndex1", out index)
                    || !names.TryGetValue("char_"+sourceSide+"HandMiddle1", out middle)
                    || !names.TryGetValue("char_"+sourceSide+"HandPinky1", out little)
                    || !bind.ContainsKey(wrist) || !bind.ContainsKey(index) || !bind.ContainsKey(middle) || !bind.ContainsKey(little))
                {
                    ModAPI.Log.Write("[ForestRE3] NATIVE_PALM_REFERENCE_MISSING side=" + sourceSide);
                    continue;
                }
                var hand = new HandSupport { wrist = wrist, index = index, middle = middle, little = little,
                    targetWrist = rest[targetSide+"_arm_wrist"], targetIndex = rest[targetSide+"_hand_index_0"],
                    targetMiddle = rest[targetSide+"_hand_middle_0"], targetLittle = rest[targetSide+"_hand_little_0"] };
                Quaternion sourcePalmRest = PalmFrame(bind[wrist].position, bind[index].position, bind[middle].position, bind[little].position);
                hand.sourcePalmRest=sourcePalmRest;
                hand.targetPalmRest = PalmFrame(hand.targetWrist.figurePosition, hand.targetIndex.figurePosition,
                    hand.targetMiddle.figurePosition, hand.targetLittle.figurePosition);
                Quaternion anatomicalAxes = hand.targetPalmRest * Quaternion.Inverse(sourcePalmRest);
                foreach (Transform child in hand.targetWrist.bone.GetComponentsInChildren<Transform>(true))
                {
                    Rest childRest;
                    if (rest.TryGetValue(child.name, out childRest)) armPoseBones.Add(childRest);
                }
                foreach (NativeBinding binding in native) if (binding.target == hand.targetWrist) binding.hand = hand;
                for (int digit = 0; digit < 5; digit++)
                    for (int segment = 0; segment < (AnatomicalFingerChains && digit>=3 ? 4:3); segment++)
                    {
                        // Jill's ring/little _0 are metacarpals, followed by
                        // three phalanges _1/_2/_3. Forest has separate Palm1
                        // references and phalanges 1/2/3 (4 is a tip marker).
                        // The accepted external laboratory keeps its old map.
                        bool extraPalm=AnatomicalFingerChains && digit>=3;
                        string sourcePrefix="char_"+sourceSide+"Hand"+sourceDigits[digit];
                        int sourceSegment=segment+(extraPalm ? 0:1);
                        string sourceName=sourcePrefix+(extraPalm && segment==0 ? "Palm1":sourceSegment.ToString());
                        string targetName = targetSide + "_hand_" + targetDigits[digit] + "_" + segment;
                        Transform source; Rest target;
                        if (!names.TryGetValue(sourceName, out source) || !bind.ContainsKey(source) || source.parent == null
                            || !bind.ContainsKey(source.parent) || !rest.TryGetValue(targetName, out target))
                        {
                            ModAPI.Log.Write("[ForestRE3] NATIVE_OPTIONAL_FINGER_MISSING source=" + sourceName + "; target=" + targetName);
                            // A rig without a skinned Palm1 keeps the authored
                            // metacarpal at rest. Never shift its three phalanges
                            // back onto the wrong joint to fill the optional gap.
                            continue;
                        }
                        Rest parent = rest[target.bone.parent.name];
                        // Transfer the finger's LOCAL bind-relative motion in
                        // anatomical parent axes. World deltas used by 0.6.0
                        // contradicted the newly retargeted wrist/forearm roll.
                        Transform next;
                        names.TryGetValue(sourcePrefix+(sourceSegment+1), out next);
                        Vector3 direction = next != null && bind.ContainsKey(next) ? bind[next].position-bind[source].position
                            : bind[source].position-bind[source.parent].position;
                        if (direction.sqrMagnitude < .0000001f) throw new InvalidOperationException("Missing finger direction "+sourceName);
                        Rest targetNext;
                        Vector3 targetDirection;
                        if (rest.TryGetValue(targetSide+"_hand_"+targetDigits[digit]+"_"+(segment+1),out targetNext))
                            targetDirection=targetNext.figurePosition-target.figurePosition;
                        else
                        {
                            // Distal tips have no child joint. Continue the same
                            // authored local segment axis (mirrored on the left).
                            Vector3 parentDirection=target.figurePosition-parent.figurePosition;
                            targetDirection=target.figureRotation*Quaternion.Inverse(parent.figureRotation)*parentDirection;
                        }
                        if (targetDirection.sqrMagnitude < .0000001f) throw new InvalidOperationException("Missing Jill finger axis "+targetName);
                        hand.fingers.Add(new FingerBinding { source = source, child=next, target = target,
                            targetSegmentDirection=targetDirection.normalized,
                            tipLocalDirection=Quaternion.Inverse(next!=null && bind.ContainsKey(next) ? bind[source].rotation:bind[source.parent].rotation)*direction.normalized,
                            sourceLocalRest = Quaternion.Inverse(bind[source.parent].rotation)*bind[source].rotation,
                            parentAxes = Quaternion.Inverse(parent.figureRotation)*anatomicalAxes*bind[source.parent].rotation });
                        armPoseBones.Add(target);
                        mapped++;
                        if (extraPalm) ModAPI.Log.Write("[ForestRE3] FINGER_CHAIN_BIND source="+sourceName+"; target="+targetName
                            +"; role="+(segment==0 ? "metacarpal":"phalanx")+"; nextSource="+(next!=null ? next.name:"inferred_tip"));
                    }
                hands.Add(hand);
                ModAPI.Log.Write("[ForestRE3] PALM_RETARGET_READY side="+sourceSide+"; fingers="+hand.fingers.Count
                    +"; wrist=anatomical_knuckle_frame; fingerMotion="+(AnatomicalFingerChains ? "anatomical_chains_with_metacarpals":"local_bind_delta")+"; forearmRoll=continuous_distribution");
            }
            return mapped;
        }

        private void ApplyNative(bool upperOnly)
        {
            if (native.Count == 0 || sourceAnimator == null)
            {
                if (Time.realtimeSinceStartup > nextNativeRetry) { nextNativeRetry = Time.realtimeSinceStartup+5f; BindNative(); }
                return;
            }
            foreach (Rest item in rest.Values)
            {
                if (upperOnly && !armPoseBones.Contains(item)) continue;
                item.previousRotation = item.bone.localRotation;
                item.previousPosition = item.bone.localPosition;
            }
            // Build a complete desired pose before blending. Every joint keeps
            // Jill's own segment length; RE translation tracks cannot leak into
            // the Forest pose. Blending world rotations parent by parent would
            // apply the parent's motion twice to children during fast swings.
            if (!upperOnly) RestoreRestForPlacement();
            else foreach (Rest item in armPoseBones)
                { item.bone.localPosition = item.position; item.bone.localRotation = item.rotation; item.bone.localScale = item.scale; }
            foreach (ArmSupport arm in armSupports) CalculateArmFrames(arm);
            foreach (HandSupport hand in hands)
            {
                Quaternion palm = PalmFrame(sourceRoot.InverseTransformPoint(hand.wrist.position), sourceRoot.InverseTransformPoint(hand.index.position),
                    sourceRoot.InverseTransformPoint(hand.middle.position), sourceRoot.InverseTransformPoint(hand.little.position));
                Quaternion figurePalm = nativePoseBasis*palm;
                hand.currentPalm=sourceRoot.rotation*palm;
                hand.sampledForward = figurePalm*Vector3.forward; hand.sampledNormal = figurePalm*Vector3.up;
                hand.desired = transform.rotation*figurePalm*Quaternion.Inverse(hand.targetPalmRest)*hand.targetWrist.figureRotation;
            }
            foreach (NativeBinding binding in native)
            {
                if (upperOnly && !armPoseBones.Contains(binding.target)) continue;
                Quaternion sourceCurrent = nativePoseBasis * Quaternion.Inverse(sourceRoot.rotation) * binding.source.rotation;
                Quaternion sourceRest = nativeBasis * binding.rest.rotation;
                Quaternion desired = transform.rotation * sourceCurrent * Quaternion.Inverse(sourceRest) * binding.alignedTargetRest;
                if (binding.arm != null) desired = binding.upperArm ? binding.arm.upperDesired : binding.arm.foreDesired;
                if (binding.hand != null) desired = binding.hand.desired;
                if (binding.shoulderAnchor) binding.target.bone.localRotation = binding.target.rotation;
                else binding.target.bone.rotation = Normalize(desired);
                if (binding.target.bone.name == "COG")
                {
                    Vector3 delta = (nativePoseBasis * sourceRoot.InverseTransformPoint(binding.source.position)
                        - nativeBasis * binding.rest.position) * nativePositionRatio;
                    Vector3 desiredPosition = transform.TransformPoint(binding.target.figurePosition+delta) + previewWorldOffset;
                    binding.target.bone.position = desiredPosition;
                }
            }
            foreach (HandSupport hand in hands)
                foreach (FingerBinding finger in hand.fingers)
                {
                    Quaternion sourceLocal = Quaternion.Inverse(finger.source.parent.rotation)*finger.source.rotation;
                    Quaternion delta = sourceLocal*Quaternion.Inverse(finger.sourceLocalRest);
                    finger.target.bone.localRotation = Normalize(finger.parentAxes*delta*Quaternion.Inverse(finger.parentAxes)*finger.target.rotation);
                }
            ApplyArmSupports();
            DistributeForearmRoll();
            float smoothing = firstPersonRig ? 1f : 1f-Mathf.Exp(-16f*Time.deltaTime);
            foreach (Rest item in rest.Values)
            {
                if (upperOnly && !armPoseBones.Contains(item)) continue;
                item.bone.localRotation = Quaternion.Slerp(item.previousRotation, item.bone.localRotation, smoothing);
                item.bone.localPosition = Vector3.Lerp(item.previousPosition, item.bone.localPosition, smoothing);
            }
            foreach (NativeBinding binding in native)
                if (binding.target.bone.name != "COG" && (!upperOnly || armPoseBones.Contains(binding.target)))
                    binding.target.bone.localPosition = binding.target.position;
        }

        private Rest RequireRest(string name)
        {
            Rest result;
            if (!rest.TryGetValue(name, out result)) throw new InvalidOperationException("Missing shoulder support " + name);
            return result;
        }

        private void BindArmSupports()
        {
            int sideIndex = 0;
            foreach (string side in new[] { "l", "r" })
            {
                var arm = new ArmSupport { clavicle = RequireRest(side+"_arm_clavicle"), humerus = RequireRest(side+"_arm_humerus"),
                    radius = RequireRest(side+"_arm_radius"), wrist = RequireRest(side+"_arm_wrist"), helpers = new Rest[12] };
                arm.features = new[] { arm.clavicle, arm.humerus, arm.radius, arm.wrist };
                for (int i = 0; i < 4; i++)
                {
                    arm.helpers[i] = RequireRest(side+"_arm_humerus_twist_"+i+"_H");
                    arm.helpers[4+i] = RequireRest(side+"_arm_radius_twist_"+i+"_H");
                }
                string[] muscleNames = { "deltFront_muscle", "deltUp_muscle", "deltBack_muscle", "pecA_muscle" };
                for (int i = 0; i < 4; i++) arm.helpers[8+i] = RequireRest(side+"_"+muscleNames[i]);
                Vector3 upper = arm.radius.figurePosition-arm.humerus.figurePosition;
                Vector3 lower = arm.wrist.figurePosition-arm.radius.figurePosition;
                Vector3 plane = Vector3.Cross(upper, lower).normalized;
                if (plane.sqrMagnitude < .5f) throw new InvalidOperationException("Degenerate RE elbow reference.");
                arm.upperReferenceFrame = Quaternion.LookRotation(upper, plane);
                arm.foreReferenceFrame = Quaternion.LookRotation(lower, plane);
                arm.previousPlane = plane;
                arm.samples = new ShoulderSample[shoulderData[sideIndex].Length];
                for (int s = 0; s < arm.samples.Length; s++)
                {
                    var sample = new ShoulderSample(); float[] values = shoulderData[sideIndex][s];
                    for (int i = 0; i < 4; i++) sample.features[i] = ConvertRotation(values, i*4);
                    for (int i = 0; i < 12; i++)
                    {
                        sample.positions[i] = ConvertPosition(values, 16+i*7)*motionPositionRatio;
                        sample.rotations[i] = ConvertRotation(values, 19+i*7);
                    }
                    arm.samples[s] = sample;
                }
                armSupports.Add(arm);
                foreach (Rest feature in arm.features) armPoseBones.Add(feature);
                foreach (Rest helper in arm.helpers) armPoseBones.Add(helper);
                sideIndex++;
            }
            ModAPI.Log.Write("[ForestRE3] SHOULDER_SUPPORT_READY version=0.7.1; arms=2; samples=" + armSupports[0].samples.Length + "/" + armSupports[1].samples.Length
                + "; armRoll=elbow_plane; helpers=authored_RE; clavicles=RE_socket_anchor; segmentLengths=RE_rest; poseBlend=local");
        }

        private void CalculateArmFrames(ArmSupport arm)
        {
            if (arm.sourceShoulder == null || arm.sourceElbow == null || arm.sourceWrist == null)
                throw new InvalidOperationException("Missing native arm landmarks.");
            Vector3 shoulder = sourceRoot.InverseTransformPoint(arm.sourceShoulder.position);
            Vector3 elbow = sourceRoot.InverseTransformPoint(arm.sourceElbow.position);
            Vector3 wrist = sourceRoot.InverseTransformPoint(arm.sourceWrist.position);
            Vector3 upper = nativePoseBasis*(elbow-shoulder).normalized;
            Vector3 lower = nativePoseBasis*(wrist-elbow).normalized;
            if (upper.sqrMagnitude < .5f || lower.sqrMagnitude < .5f) throw new InvalidOperationException("Degenerate native arm segment.");
            Vector3 plane = Vector3.Cross(upper, lower);
            // A nearly straight elbow does not define roll. Preserve the last
            // bend plane projected to the new arm direction until it bends again.
            if (plane.sqrMagnitude < .0025f) plane = Vector3.ProjectOnPlane(arm.previousPlane, upper);
            if (plane.sqrMagnitude < .00001f) plane = Vector3.Cross(upper, Mathf.Abs(upper.y) < .9f ? Vector3.up : Vector3.forward);
            plane.Normalize(); arm.previousPlane = plane;
            arm.upperDesired = transform.rotation * Quaternion.LookRotation(upper, plane) * Quaternion.Inverse(arm.upperReferenceFrame) * arm.humerus.figureRotation;
            arm.foreDesired = transform.rotation * Quaternion.LookRotation(lower, plane) * Quaternion.Inverse(arm.foreReferenceFrame) * arm.radius.figureRotation;
        }

        private void ApplyArmSupports()
        {
            foreach (ArmSupport arm in armSupports)
            {
                for (int i = 0; i < 4; i++) { arm.nearest[i] = -1; arm.errors[i] = float.PositiveInfinity; }
                for (int s = 0; s < arm.samples.Length; s++)
                {
                    float error = 0f;
                    for (int i = 0; i < 4; i++)
                    {
                        float similarity = Mathf.Clamp01(Mathf.Abs(Quaternion.Dot(arm.features[i].bone.localRotation, arm.samples[s].features[i])));
                        error += (1f-similarity) * (i == 1 ? 4f : (i == 3 ? .5f : 1f));
                    }
                    for (int i = 0; i < 4; i++)
                        if (error < arm.errors[i])
                        {
                            for (int j = 3; j > i; j--) { arm.nearest[j] = arm.nearest[j-1]; arm.errors[j] = arm.errors[j-1]; }
                            arm.nearest[i] = s; arm.errors[i] = error; break;
                        }
                }
                arm.matchError = arm.errors[0];
                float total = 0f;
                for (int i = 0; i < 4; i++)
                {
                    float distance = .015f+arm.errors[i];
                    arm.weights[i] = 1f/(distance*distance); total += arm.weights[i];
                }
                for (int helper = 0; helper < 12; helper++)
                {
                    Vector3 position = Vector3.zero;
                    Quaternion anchor = arm.samples[arm.nearest[0]].rotations[helper];
                    Quaternion rotation = new Quaternion(0f,0f,0f,0f);
                    for (int i = 0; i < 4; i++)
                    {
                        ShoulderSample sample = arm.samples[arm.nearest[i]];
                        float weight = arm.weights[i]/total;
                        position += sample.positions[helper]*weight;
                        Quaternion q = sample.rotations[helper];
                        if (Quaternion.Dot(anchor, q) < 0f) q = new Quaternion(-q.x,-q.y,-q.z,-q.w);
                        rotation.x += q.x*weight; rotation.y += q.y*weight; rotation.z += q.z*weight; rotation.w += q.w*weight;
                    }
                    arm.helpers[helper].bone.localPosition = arm.helpers[helper].position+position;
                    arm.helpers[helper].bone.localRotation = Normalize(rotation);
                }
            }
        }

        private void DistributeForearmRoll()
        {
            foreach (ArmSupport arm in armSupports)
            {
                Vector3 axis = arm.wrist.position.normalized;
                Quaternion delta = arm.wrist.bone.localRotation*Quaternion.Inverse(arm.wrist.rotation);
                Vector3 projected = Vector3.Project(new Vector3(delta.x, delta.y, delta.z), axis);
                float length = Mathf.Sqrt(projected.sqrMagnitude+delta.w*delta.w);
                if (length < .00001f) continue; // pure 180-degree swing has no defined axial twist
                float sine = Vector3.Dot(projected, axis)/length, cosine = delta.w/length;
                float angle = Mathf.Atan2(sine, cosine)*2f*Mathf.Rad2Deg;
                if (!arm.rollReady) { arm.wristRoll = Mathf.DeltaAngle(0f, angle); arm.rollReady = true; }
                else arm.wristRoll += Mathf.DeltaAngle(arm.wristRoll, angle);
                for (int i = 0; i < 4; i++)
                {
                    Rest helper = arm.helpers[4+i];
                    float fraction = Mathf.Clamp01(Vector3.Dot(helper.position, axis)/arm.wrist.position.magnitude);
                    helper.bone.localRotation = Quaternion.AngleAxis(arm.wristRoll*fraction, axis)*helper.rotation;
                    helper.bone.localPosition = helper.position;
                }
            }
        }

        private void AlignPlayerArms()
        {
            // Keep the shoulder socket attached to Jill's chest. Solve elbow
            // and wrist from segment lengths; never copy the male shoulder's
            // animated position into Jill's humerus.
            foreach (ArmSupport arm in armSupports)
            {
                arm.humerus.bone.localPosition=arm.humerus.position;
                Vector3 shoulder=arm.humerus.bone.position, grip=arm.sourceWrist.position;
                float scale=Mathf.Abs(transform.lossyScale.y);
                float upper=(arm.radius.figurePosition-arm.humerus.figurePosition).magnitude*scale;
                float lower=(arm.wrist.figurePosition-arm.radius.figurePosition).magnitude*scale;
                Vector3 reach=grip-shoulder;
                float stretch=Mathf.Clamp(reach.magnitude/(upper+lower)*1.001f,1f,1.18f);
                upper*=stretch; lower*=stretch;
                float distance=Mathf.Clamp(reach.magnitude,Mathf.Abs(upper-lower)+.0001f,upper+lower-.0001f);
                Vector3 axis=reach.sqrMagnitude > .000001f ? reach.normalized : transform.forward;
                // The native first-person elbow belongs to a camera-relative
                // rig. Its absolute position is not Jill's anatomical elbow.
                Vector3 bend=Vector3.ProjectOnPlane(arm.radius.bone.position-shoulder,axis);
                Camera view=TheForest.Utils.LocalPlayer.MainCam;
                if (remoteEntity==null && sourceOverride==null && actions!=null && (!actions.Native || actions.Action=="agacharse")
                    && view!=null && Vector3.Dot(view.transform.forward,Vector3.down)>.25f)
                {
                    float side=arm.humerus.bone.name.StartsWith("l_",StringComparison.Ordinal) ? -1f:1f;
                    Vector3 lowered=Vector3.ProjectOnPlane(transform.TransformDirection(new Vector3(side*.45f,-1f,.25f)),axis);
                    if (lowered.sqrMagnitude>.00001f)
                        bend=Vector3.Slerp(bend.normalized,lowered.normalized,.8f);
                }
                if (bend.sqrMagnitude < .00001f) bend=Vector3.Cross(transform.rotation*arm.previousPlane,axis);
                if (bend.sqrMagnitude < .00001f) bend=Vector3.ProjectOnPlane(transform.up,axis);
                bend.Normalize();
                float along=(upper*upper-lower*lower+distance*distance)/(2f*distance);
                Vector3 elbow=shoulder+axis*along+bend*Mathf.Sqrt(Mathf.Max(0f,upper*upper-along*along));
                Vector3 solvedGrip=shoulder+axis*distance;
                Vector3 upperDir=(elbow-shoulder).normalized, lowerDir=(solvedGrip-elbow).normalized;
                Vector3 plane=Vector3.Cross(upperDir,lowerDir);
                if (plane.sqrMagnitude < .00001f) plane=Vector3.Cross(axis,bend);
                plane.Normalize();
                arm.radius.bone.localPosition=arm.radius.position*stretch;
                arm.wrist.bone.localPosition=arm.wrist.position*stretch;
                arm.humerus.bone.rotation=Normalize(Quaternion.LookRotation(upperDir,plane)*Quaternion.Inverse(arm.upperReferenceFrame)*arm.humerus.figureRotation);
                arm.radius.bone.rotation=Normalize(Quaternion.LookRotation(lowerDir,plane)*Quaternion.Inverse(arm.foreReferenceFrame)*arm.radius.figureRotation);
                foreach (HandSupport hand in hands) if (hand.targetWrist==arm.wrist) arm.wrist.bone.rotation=hand.desired;
            }
            ApplyArmSupports(); DistributeForearmRoll();
            foreach (ArmSupport arm in armSupports)
            {
                float upperRatio=arm.radius.bone.localPosition.magnitude/arm.radius.position.magnitude;
                float lowerRatio=arm.wrist.bone.localPosition.magnitude/arm.wrist.position.magnitude;
                for (int i=0;i<4;i++) { arm.helpers[i].bone.localPosition*=upperRatio; arm.helpers[4+i].bone.localPosition*=lowerRatio; }
            }
        }

        private static bool IsLeg(Transform bone)
        {
            for (Transform at=bone; at!=null; at=at.parent)
                if (at.name.StartsWith("l_leg_",StringComparison.Ordinal) || at.name.StartsWith("r_leg_",StringComparison.Ordinal)) return true;
            return false;
        }

        private void AlignFirstPersonBody()
        {
            Camera camera=TheForest.Utils.LocalPlayer.MainCam;
            Rest neck, cog;
            if (camera==null || !rest.TryGetValue("neck_0",out neck) || !rest.TryGetValue("COG",out cog)) return;
            // Keep the accepted horizontal neck placement. Vertically align
            // the actual animated eye corners, rather than retaining the
            // capsule/bind-space estimate that left the whole torso too low.
            float height=Mathf.Max(.1f,rest["head"].figurePosition.y)*Mathf.Abs(transform.lossyScale.y);
            Vector3 wanted=camera.transform.position-transform.forward*height*.085f;
            Vector3 correction=Vector3.ProjectOnPlane(wanted-neck.bone.position,Vector3.up);
            cog.bone.position+=Vector3.ClampMagnitude(correction,height*.24f);
            Vector3 eye=(eyeLeft.bone.position+eyeRight.bone.position)*.5f;
            float vertical=camera.transform.position.y-eye.y;
            // Reject a stale camera from a different actor, without hiding the
            // attached model or changing the real camera/capsule.
            if (Mathf.Abs(vertical)<height*2f) cog.bone.position+=Vector3.up*vertical;
            if (Time.realtimeSinceStartup>=nextEyeHeightLog)
            {
                nextEyeHeightLog=Time.realtimeSinceStartup+10f;
                Vector3 aligned=(eyeLeft.bone.position+eyeRight.bone.position)*.5f;
                ModAPI.Log.Write("[ForestRE3] FP_EYE_HEIGHT_ALIGNMENT actor="+(sourceAnimator!=null ? sourceAnimator.name:"unbound")+"; mode="+currentMode
                    +"; cameraY="+camera.transform.position.y+"; beforeEyeY="+eye.y+"; correctionY="+vertical
                    +"; residualY="+(camera.transform.position.y-aligned.y)+"; cameraWrites=false");
            }
        }

        private void AlignGroundedLegs()
        {
            FirstPersonCharacter controller=TheForest.Utils.LocalPlayer.FpCharacter;
            var control=TheForest.Utils.LocalPlayer.AnimControl;
            if (sourceOverride!=null || controller==null || controller.capsule==null || !controller.Grounded
                || actions==null || actions.Support!=JillNativeActions.GroundSupport.Feet || actions.Airborne || actions.Impact
                || (control!=null && (control.introCutScene || control.sitting))) return;
            Rest left=rest["l_leg_ankle"],right=rest["r_leg_ankle"];
            float minimum=Mathf.Min(left.bone.position.y,right.bone.position.y);
            CapsuleCollider capsule=controller.capsule;
            Vector3 axis=capsule.direction==0 ? Vector3.right:capsule.direction==2 ? Vector3.forward:Vector3.up;
            Vector3 worldAxis=capsule.transform.TransformVector(axis);
            float floor=(capsule.transform.TransformPoint(capsule.center)-worldAxis*capsule.height*.5f).y;
            float scale=Mathf.Abs(transform.lossyScale.y);
            foreach (LegSupport leg in groundedLegs)
            {
                Rest thigh=leg.thigh,knee=leg.knee,ankle=leg.ankle;
                Vector3 hip=thigh.bone.position, goal=ankle.bone.position;
                // Preserve the RE gait's relative foot lift. The lower foot
                // follows the native capsule's floor; there is no new collider.
                goal.y=floor+(ankle.figurePosition.y-playerMeshBottom)*scale+Mathf.Max(0f,goal.y-minimum);
                float upper=knee.position.magnitude*scale, lower=ankle.position.magnitude*scale;
                Vector3 reach=goal-hip;
                float stretch=Mathf.Clamp(reach.magnitude/(upper+lower)*1.001f,1f,1.12f);
                upper*=stretch; lower*=stretch;
                float distance=Mathf.Clamp(reach.magnitude,Mathf.Abs(upper-lower)+.0001f,upper+lower-.0001f);
                Vector3 direction=reach.sqrMagnitude>.000001f ? reach.normalized:Vector3.down;
                Vector3 bend=Vector3.ProjectOnPlane(knee.bone.position-hip,direction);
                if (bend.sqrMagnitude<.00001f) bend=Vector3.ProjectOnPlane(transform.forward,direction);
                if (bend.sqrMagnitude<.00001f) continue;
                float along=(upper*upper-lower*lower+distance*distance)/(2f*distance);
                Vector3 solvedKnee=hip+direction*along+bend.normalized*Mathf.Sqrt(Mathf.Max(0f,upper*upper-along*along));
                Vector3 solvedAnkle=hip+direction*distance;
                Quaternion footRotation=ankle.bone.rotation;
                knee.bone.localPosition=knee.position*stretch; ankle.bone.localPosition=ankle.position*stretch;
                thigh.bone.rotation=Quaternion.FromToRotation(knee.bone.position-thigh.bone.position,solvedKnee-hip)*thigh.bone.rotation;
                knee.bone.rotation=Quaternion.FromToRotation(ankle.bone.position-knee.bone.position,solvedAnkle-solvedKnee)*knee.bone.rotation;
                ankle.bone.rotation=footRotation;
            }
        }

        private void ApplyAnatomicalFingers()
        {
            foreach (HandSupport hand in hands)
            {
                Quaternion palm=hand.targetWrist.bone.rotation*Quaternion.Inverse(hand.targetWrist.figureRotation)*hand.targetPalmRest;
                Quaternion figureToPalm=palm*Quaternion.Inverse(hand.targetPalmRest);
                foreach (FingerBinding finger in hand.fingers)
                {
                    Vector3 direction=finger.child!=null ? finger.child.position-finger.source.position
                        : finger.source.rotation*finger.tipLocalDirection;
                    if (direction.sqrMagnitude < .0000001f) continue;
                    Vector3 current=Quaternion.Inverse(hand.currentPalm)*direction.normalized;
                    Vector3 wanted=palm*current;
                    // Align the actual Jill child axis to the sampled native
                    // segment, not a delta from the other rig's bind direction.
                    // Proximal-to-distal world assignment preserves joint length
                    // and drops incompatible axial roll on each phalanx.
                    Quaternion align=Quaternion.FromToRotation(figureToPalm*finger.targetSegmentDirection,wanted);
                    finger.target.bone.rotation=Normalize(align*figureToPalm*finger.target.figureRotation);
                    finger.target.bone.localPosition=finger.target.position;
                }
            }
        }

        private void LogPausedPose()
        {
            if (actions != null) actions.LogPose();
            ModAPI.Log.Write("[ForestRE3] PAUSED_ROOT_FRAME basis=" + nativePoseBasis + "; worldOffset=" + previewWorldOffset);
            if (currentMode == "forest" || HeldHandOverlay) foreach (HandSupport hand in hands)
            {
                Quaternion actual = Quaternion.Inverse(transform.rotation)*PalmFrame(hand.targetWrist.bone.position,
                    hand.targetIndex.bone.position, hand.targetMiddle.bone.position, hand.targetLittle.bone.position);
                ModAPI.Log.Write("[ForestRE3] PAUSED_PALM_ALIGNMENT hand="+hand.targetWrist.bone.name+"; forwardDot="
                    +Vector3.Dot(actual*Vector3.forward, hand.sampledForward)+"; normalDot="+Vector3.Dot(actual*Vector3.up, hand.sampledNormal)
                    +"; fingers="+hand.fingers.Count+"; heldOverlay="+HeldHandOverlay);
                foreach (FingerBinding finger in hand.fingers)
                {
                    Quaternion q = finger.target.bone.localRotation;
                    ModAPI.Log.Write("[ForestRE3] PAUSED_FINGER bone="+finger.target.bone.name+"; localQ="+q.x+","+q.y+","+q.z+","+q.w);
                }
            }
            foreach (ArmSupport arm in armSupports)
            {
                ModAPI.Log.Write("[ForestRE3] PAUSED_SHOULDER_POSE mode="+currentMode+"; side="+arm.humerus.bone.name+"; correctiveError="+arm.matchError);
                if (sourceRoot != null && arm.sourceShoulder != null && arm.sourceElbow != null && arm.sourceWrist != null)
                    ModAPI.Log.Write("[ForestRE3] POSE_NATIVE_LANDMARKS side="+arm.humerus.bone.name
                        +"; shoulder="+sourceRoot.InverseTransformPoint(arm.sourceShoulder.position)
                        +"; elbow="+sourceRoot.InverseTransformPoint(arm.sourceElbow.position)
                        +"; wrist="+sourceRoot.InverseTransformPoint(arm.sourceWrist.position));
                foreach (Rest feature in arm.features)
                {
                    Quaternion q = feature.bone.localRotation;
                    ModAPI.Log.Write("[ForestRE3] POSE_JOINT bone="+feature.bone.name+"; localQ="+q.x+","+q.y+","+q.z+","+q.w+"; localP="+feature.bone.localPosition);
                    Quaternion figureQ = Quaternion.Inverse(transform.rotation)*feature.bone.rotation;
                    ModAPI.Log.Write("[ForestRE3] POSE_FIGURE bone="+feature.bone.name+"; figureQ="+figureQ.x+","+figureQ.y+","+figureQ.z+","+figureQ.w
                        +"; figureP="+transform.InverseTransformPoint(feature.bone.position));
                }
                Vector3 socketRest = arm.clavicle.rotation*arm.humerus.position;
                Vector3 socketActual = arm.clavicle.bone.localRotation*arm.humerus.bone.localPosition;
                Vector3 socketDelta = socketActual-socketRest;
                ModAPI.Log.Write("[ForestRE3] POSE_SOCKET_DELTA side="+arm.humerus.bone.name+"; chestLocalDelta="+socketDelta.x+","+socketDelta.y+","+socketDelta.z);
                foreach (Rest helper in arm.helpers)
                {
                    Quaternion q = helper.bone.localRotation;
                    ModAPI.Log.Write("[ForestRE3] POSE_HELPER bone="+helper.bone.name+"; localQ="+q.x+","+q.y+","+q.z+","+q.w+"; localP="+helper.bone.localPosition);
                }
            }
        }
    }
}
