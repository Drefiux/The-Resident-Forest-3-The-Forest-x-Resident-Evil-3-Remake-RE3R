﻿using System;
using System.IO;
using System.Reflection;

internal static class InspectFmodStrings
{
    private static string managed;
    private static void Require(FMOD.RESULT result)
    { if (result != FMOD.RESULT.OK) throw new InvalidOperationException(result.ToString()); }
    private static void Inventory(string bankPath)
    {
        FMOD.Studio.System studio;
        Require(FMOD.Studio.System.create(out studio));
        try
        {
            FMOD.System low;
            Require(studio.getLowLevelSystem(out low));
            Require(low.setOutput(FMOD.OUTPUTTYPE.NOSOUND));
            Require(studio.initialize(64, FMOD.Studio.INITFLAGS.NORMAL, FMOD.INITFLAGS.NORMAL, IntPtr.Zero));
            FMOD.Studio.Bank bank;
            Require(studio.loadBankFile(bankPath, FMOD.Studio.LOAD_BANK_FLAGS.NORMAL, out bank));
            int count; Require(bank.getStringCount(out count));
            for (int i=0; i<count; i++)
            {
                Guid id; string path;
                Require(bank.getStringInfo(i,out id,out path));
                Console.WriteLine(path);
            }
            Require(bank.unload());
        }
        finally { studio.release(); }
    }
    public static void Main(string[] args)
    {
        managed=Path.GetFullPath(args[0]);
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs request)
        {
            string path=Path.Combine(managed,new AssemblyName(request.Name).Name+".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        Environment.SetEnvironmentVariable("PATH",Path.GetFullPath(args[1])+";"+Environment.GetEnvironmentVariable("PATH"));
        Inventory(args[2]);
    }
}
