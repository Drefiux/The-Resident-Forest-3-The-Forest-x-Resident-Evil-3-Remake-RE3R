﻿using System;
using System.IO;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.SceneManagement;
using LocalPlayer=TheForest.Utils.LocalPlayer;
using GameSetup=TheForest.Utils.GameSetup;
using NativeInput=TheForest.Utils.Input;
using InputState=TheForest.Utils.InputState;
using SaveSlotUtils=TheForest.Utils.SaveSlotUtils;

namespace ForestRE3JillVisualProbe
{
    [DefaultExecutionOrder(-500)]
    public sealed partial class Re3InventoryRuntime : MonoBehaviour
    {
        internal static Re3InventoryRuntime Instance;
        internal readonly Dictionary<string,Re3Bag> bags=new Dictionary<string,Re3Bag>();
        internal Re3Bag player=new Re3Bag(20,4);
        internal Re3Bag[] boxes=new Re3Bag[5];
        internal readonly Vector3[] anchors=new Vector3[5],testPoints=new Vector3[5];
        internal readonly bool[] hasTest=new bool[5];
        private readonly GameObject[] chests=new GameObject[5],testChests=new GameObject[5];
        private GameObject prefab;
        private FirstPersonCharacter owner,lockedOwner;
        private bool ready,loading,assetsFailed,menu,debug,teleporting,wasMovementLocked,wasMouseLocked,outdoorResolved,saveBlocked;
        internal readonly Dictionary<string,Re3Storage> storage=new Dictionary<string,Re3Storage>();
        private bool worldInitialized;
        private bool oldMenu,oldWorld; private CursorLockMode oldCursor; private bool oldVisible;
        private int opened=-1,aimed=-1; private string feedback=""; private float tickAt,requestAt,noticeUntil,releaseAt;
        private static string pendingLoadPath;
        private static readonly string SaveName="ForestRE3-Inventarios-v1.dat";
        internal static bool Client { get { return BoltNetwork.isRunning && !BoltNetwork.IsSinglePlayer && BoltNetwork.isClient; } }
        public static bool BlockControls { get { return Instance!=null && (Instance.menu || Instance.teleporting || Instance.lifeQueue.Count>0 || Time.realtimeSinceStartup<Instance.releaseAt); } }
        internal bool ActiveWorld
        { get { return LocalPlayer.FpCharacter!=null && LocalPlayer.FpCharacter.gameObject.activeInHierarchy && LocalPlayer.Inventory!=null
            && LocalPlayer.Stats!=null && !LocalPlayer.Stats.Dead && !JillPlaneAvatar.CharacterLocked; } }
        private bool CanOpen
        { get { return ActiveWorld && lifeQueue.Count==0 && LocalPlayer.Inventory.CurrentView==TheForest.Items.Inventory.PlayerInventory.PlayerViews.World
            && !LocalPlayer.IsInPauseMenu && !DodgeRuntime.Busy && Time.timeScale>0f && Application.isFocused
            && LocalPlayer.AnimControl!=null && !LocalPlayer.AnimControl.endGameCutScene && !LocalPlayer.AnimControl.onRope && !LocalPlayer.AnimControl.cliffClimb; } }
        private void Awake() { Instance=this; ResetData(); }
        private void ResetData()
        {
            bags.Clear(); storage.Clear(); player=new Re3Bag(20,4); bags.Add("host",player);
            var host=new Re3Storage();storage.Add("host",host);boxes=host.boxes;
            outdoorResolved=false; saveBlocked=false;G19Runtime.ResetWorld();ResetLifecycle();
            for(int i=0;i<5;i++) { anchors[i]=Re3ChestLocation.All[i].position; hasTest[i]=false; }
            networkReady=!Client;
        }
        private Re3Storage Storage(string key)
        {
            Re3Storage value;
            if(!storage.TryGetValue(key,out value)){value=new Re3Storage();storage.Add(key,value);}
            return value;
        }
        private static bool Holds(Re3Bag bag,Re3Storage store,int item)
        {
            if(G19Runtime.HasWeapon(bag,item))return true;
            foreach(var box in store.boxes)if(G19Runtime.HasWeapon(box,item))return true;
            foreach(var recovery in store.recovery.Values)if(G19Runtime.HasWeapon(recovery.bag,item))return true;
            return false;
        }
        private void SeedStorage(string key)
        {
            if(Client || saveBlocked)return;
            Re3Bag bag;if(!bags.TryGetValue(key,out bag))return;var store=Storage(key);
            if(!store.g19Seeded && (Holds(bag,store,1) || store.boxes[2].Add(1,1)))store.g19Seeded=true;
            if(!store.m3Seeded && (Holds(bag,store,3) || store.boxes[0].Add(3,1)))store.m3Seeded=true;
            foreach(int id in (GameSetup.IsHardSurvivalMode ? new[]{0}:new[]{3,4}))
            {
                int bit=1<<id;if((store.rocketSeeded&bit)!=0)continue;
                // Existing carried/deposited launchers count during migration;
                // newly created storage still receives each original location.
                if(G19Runtime.HasWeapon(store.boxes[id],28) || store.boxes[id].Add(28,1))store.rocketSeeded|=(byte)bit;
            }
        }
        private void SeedG19(){foreach(string key in new List<string>(bags.Keys))SeedStorage(key);}
        private void SeedM3(){}
        private void SeedRocket(){}
        private void Update()
        {
            TickLifecycle();
            if(owner!=LocalPlayer.FpCharacter)
            {
                Close(); DestroyWorld(); owner=LocalPlayer.FpCharacter;
                if(owner!=null && owner.gameObject.activeInHierarchy)
                {
                    if(!worldInitialized)
                    {
                        string path=pendingLoadPath; pendingLoadPath=null;
                        if(!Client && (path!=null || GameSetup.IsSavedGame)) LoadData(path ?? SlotPath());
                        worldInitialized=true;
                    }
                    // Respawn replaces only this actor. All host-authoritative
                    // peer bags, chest contents and ammunition stay alive.
                    G19Runtime.PlayerRecreated();SeedG19();ready=true;
                }
            }
            if(!ActiveWorld) { if(menu) Close(); return; }
            if(menu && debug && !Re3DeveloperTools.Enabled)Close();
            if(!ready) {SeedG19();SeedM3();SeedRocket();ready=true;}
            if(prefab==null && !loading && !assetsFailed) { loading=true; StartCoroutine(LoadAssets()); }
            if(menu)
            {
                if(!CanOpen || !Application.isFocused) { Close(); return; }
                NativeInput.UnLockMouse(); Cursor.visible=true; Cursor.lockState=CursorLockMode.None;
                if(UnityEngine.Input.GetKeyDown(KeyCode.Escape) || UnityEngine.Input.GetKeyDown(KeyCode.Tab) || UnityEngine.Input.GetKeyDown(KeyCode.F5)) Close();
                if(opened>=0 && !Near(opened,LocalPlayer.Transform.position,14f)) Close();
            }
            else if(CanOpen && !Cursor.visible && !teleporting)
            {
                if(UnityEngine.Input.GetKeyDown(KeyCode.Tab)) Open(-1,false);
                else if(Re3DeveloperTools.Enabled && UnityEngine.Input.GetKeyDown(KeyCode.F5)) Open(-1,true);
                else if(aimed>=0 && UnityEngine.Input.GetKeyDown(KeyCode.E)) Open(aimed,false);
                else QuickEquipSlot();
            }
            if(Time.realtimeSinceStartup>=tickAt)
            {
                tickAt=Time.realtimeSinceStartup+.25f;
                if(prefab!=null) RefreshWorld();
                SeedG19();SeedM3();SeedRocket();Aim();
            }
            if(Client && lifeQueue.Count==0 && Time.realtimeSinceStartup>=requestAt && CoopSync.CanStartDodge)
            { requestAt=Time.realtimeSinceStartup+(menu ? 1f:3f); SendRequest(0,0,0,0,0,Vector3.zero); }
            if(pending && Time.realtimeSinceStartup-pendingAt>5f)
            { pending=false; Notice("La operación no fue confirmada; sincronizando. No se repite automáticamente."); requestAt=0; }
        }
        private void QuickEquipSlot()
        {
            // Called only from active world input, never from a menu/cutscene.
            if(!networkReady || pending || BlockControls)return;
            int slot=-1;
            if(UnityEngine.Input.GetKeyDown(KeyCode.Alpha5) || UnityEngine.Input.GetKeyDown(KeyCode.Keypad5))slot=0;
            else if(UnityEngine.Input.GetKeyDown(KeyCode.Alpha6) || UnityEngine.Input.GetKeyDown(KeyCode.Keypad6))slot=1;
            else if(UnityEngine.Input.GetKeyDown(KeyCode.Alpha7) || UnityEngine.Input.GetKeyDown(KeyCode.Keypad7))slot=2;
            else if(UnityEngine.Input.GetKeyDown(KeyCode.Alpha8) || UnityEngine.Input.GetKeyDown(KeyCode.Keypad8))slot=3;
            if(slot<0 || slot>=player.slots.Length)return;
            int index=player.Root(slot);
            if(index<0 || index>=player.slots.Length)return;
            Re3Slot item=player.slots[index];
            if(item.count>0 && Re3Weapon.Valid(item.id))G19Runtime.Equip((byte)item.id);
        }
        private IEnumerator LoadAssets()
        {
            yield return StartCoroutine(Re3Interface.Load());
            string suffix=QualitySettings.activeColorSpace==ColorSpace.Linear ? "linear":"gamma";
            byte[] bytes=null;
            try
            {
                using(Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.inventory-"+suffix))
                {
                    if(stream==null || stream.Length>16*1024*1024) throw new InvalidDataException("Inventory resource");
                    bytes=new byte[(int)stream.Length]; int at=0;
                    while(at<bytes.Length) { int read=stream.Read(bytes,at,bytes.Length-at); if(read<=0) throw new EndOfStreamException(); at+=read; }
                }
            }
            catch(Exception e) { AssetError(e); }
            if(bytes!=null)
            {
                var request=AssetBundle.LoadFromMemoryAsync(bytes); yield return request; bytes=null;
                var bundle=request.assetBundle;
                if(bundle!=null)
                {
                    var asset=bundle.LoadAssetAsync("Assets/Generated/Inventory/Re3ItemBox.prefab",typeof(GameObject)); yield return asset;
                    prefab=asset.asset as GameObject; bundle.Unload(false);
                }
                if(prefab==null) AssetError(new InvalidDataException("Locker prefab"));
            }
            loading=false;
        }
        private void AssetError(Exception e) { assetsFailed=true; Notice("No se pudo cargar el baúl RE3R; consulta el registro."); ModAPI.Log.Write("[ForestRE3] INVENTORY_ASSET_ERROR "+e); }
        internal void Notice(string value) { feedback=value; noticeUntil=Time.realtimeSinceStartup+6f; }
        private void Open(int chest,bool diagnostics)
        {
            if(menu || !CanOpen || diagnostics && !Re3DeveloperTools.Enabled) return;
            dragged=-1;dragMoving=false;
            opened=chest; debug=diagnostics; menu=true;
            lockedOwner=LocalPlayer.FpCharacter; wasMovementLocked=lockedOwner.MovementLocked; lockedOwner.MovementLocked=true;
            oldMenu=NativeInput.GetState(InputState.Menu); oldWorld=NativeInput.GetState(InputState.World);
            wasMouseLocked=NativeInput.IsMouseLocked; oldCursor=Cursor.lockState; oldVisible=Cursor.visible;
            NativeInput.SetState(InputState.Menu,true); NativeInput.SetState(InputState.World,false); NativeInput.UnLockMouse();
            Cursor.visible=true; Cursor.lockState=CursorLockMode.None; requestAt=0;
        }
        private void Close()
        {
            if(menu)
            {
                bool stillWorld=LocalPlayer.Inventory!=null && LocalPlayer.Inventory.CurrentView==TheForest.Items.Inventory.PlayerInventory.PlayerViews.World
                    && !LocalPlayer.IsInPauseMenu && LocalPlayer.Stats!=null && !LocalPlayer.Stats.Dead;
                if(lockedOwner!=null && (stillWorld || lockedOwner!=LocalPlayer.FpCharacter)) lockedOwner.MovementLocked=wasMovementLocked;
                if(stillWorld && NativeInput.States!=null)
                { NativeInput.SetState(InputState.Menu,oldMenu); NativeInput.SetState(InputState.World,oldWorld); }
                if(stillWorld)
                { if(wasMouseLocked) NativeInput.LockMouse(); else NativeInput.UnLockMouse(); Cursor.lockState=oldCursor; Cursor.visible=oldVisible; }
                releaseAt=Time.realtimeSinceStartup+.18f;
            }
            menu=false; opened=-1; lockedOwner=null; aimed=-1;
        }
        private void OnDisable() { Close(); }
        private void OnDestroy() { Close(); DestroyWorld(); if(pixel!=null) Destroy(pixel); if(Instance==this) Instance=null; }
        private void DestroyWorld()
        { for(int i=0;i<5;i++) { if(chests[i]!=null) Destroy(chests[i]); if(testChests[i]!=null) Destroy(testChests[i]); chests[i]=testChests[i]=null; } }
        internal static bool Ground(Vector3 desired,float above,float below,out Vector3 floor)
        {
            floor=desired; float closest=float.PositiveInfinity;
            foreach(var hit in Physics.RaycastAll(desired+Vector3.up*above,Vector3.down,above+below,~0,QueryTriggerInteraction.Ignore))
            {
                if(hit.collider==null || hit.normal.y<.65f || hit.collider.GetComponentInParent<Re3Chest>()!=null
                    || hit.collider.GetComponentInParent<BoltEntity>()!=null
                    || (LocalPlayer.Transform!=null && hit.collider.transform.IsChildOf(LocalPlayer.Transform))) continue;
                // Prefer the floor at this altitude, never a cave ceiling far above it.
                float difference=Mathf.Abs(hit.point.y-desired.y);
                if(difference<closest) { closest=difference; floor=hit.point; }
            }
            return closest<float.PositiveInfinity;
        }
        private void RefreshWorld()
        {
            ResolveCoast();
            for(int i=0;i<5;i++)
            {
                var loc=Re3ChestLocation.All[i];
                bool nearby=(LocalPlayer.Transform.position-anchors[i]).sqrMagnitude<250f*250f;
                bool visible=loc.endgame ? SceneManager.GetSceneByName("endgame_streaming").isLoaded:(i==1 || (loc.cave ? LocalPlayer.IsInCaves:!LocalPlayer.IsInCaves));
                if(nearby && visible && chests[i]==null)
                {
                    Vector3 wanted=anchors[i];
                    if(!loc.cave && !loc.endgame && Terrain.activeTerrain!=null) wanted.y=Terrain.activeTerrain.SampleHeight(wanted)+Terrain.activeTerrain.transform.position.y;
                    Vector3 floor=wanted; if(i==4 ? outdoorResolved && ShoreFloor(wanted,out floor):Ground(wanted,8f,10f,out floor))
                    { anchors[i]=floor; chests[i]=CreateChest(i,floor,loc.yaw,false); }
                }
                if(chests[i]!=null){chests[i].transform.position=anchors[i];chests[i].SetActive(visible);}
                if(hasTest[i] && testChests[i]==null) testChests[i]=CreateChest(i,testPoints[i],0,true);
                if(!hasTest[i] && testChests[i]!=null) { Destroy(testChests[i]); testChests[i]=null; }
                if(testChests[i]!=null) testChests[i].transform.position=testPoints[i];
            }
        }
        private float coastRetry;
        private static bool ShoreFloor(Vector3 point,out Vector3 floor)
        {
            floor=point;RaycastHit top=new RaycastHit();float distance=float.PositiveInfinity;
            // Start above the mountain, so a low terrain layer underneath a
            // rock cannot be mistaken for exposed coastline.
            foreach(var hit in Physics.RaycastAll(new Vector3(point.x,900f,point.z),Vector3.down,1000f,~0,QueryTriggerInteraction.Ignore))
                if(hit.collider.GetComponentInParent<Re3Chest>()==null && hit.collider.GetComponentInParent<BoltEntity>()==null
                    && (LocalPlayer.Transform==null || !hit.collider.transform.IsChildOf(LocalPlayer.Transform)) && hit.distance<distance){top=hit;distance=hit.distance;}
            if(distance==float.PositiveInfinity)return false;
            if(top.normal.y<.92f || top.point.y<42f || top.point.y>58f || top.collider.GetComponentInParent<BoltEntity>()!=null)return false;
            floor=top.point;
            foreach(var overlap in Physics.OverlapBox(floor+Vector3.up*2.6f,new Vector3(2f,2.4f,2f),Quaternion.identity,~0,QueryTriggerInteraction.Ignore))
                if(overlap.GetComponentInParent<Re3Chest>()==null && overlap.GetComponentInParent<BoltEntity>()==null
                    && (LocalPlayer.Transform==null || !overlap.transform.IsChildOf(LocalPlayer.Transform)))return false;
            foreach(var offset in new[]{Vector3.forward*5f,Vector3.back*5f,Vector3.right*5f,Vector3.left*5f})
            {
                RaycastHit near;
                if(!Physics.Raycast(floor+offset+Vector3.up*8f,Vector3.down,out near,12f,~0,QueryTriggerInteraction.Ignore) || near.normal.y<.8f || Mathf.Abs(near.point.y-floor.y)>1.8f)return false;
            }
            return true;
        }
        private void ResolveCoast()
        {
            Terrain terrain=Terrain.activeTerrain;if(terrain==null || outdoorResolved || (Client && networkReady) || Time.realtimeSinceStartup<coastRetry)return;
            coastRetry=Time.realtimeSinceStartup+3f;
            float score=float.PositiveInfinity;Vector3 chosen=anchors[4];bool found=false;
            for(float x=950;x<=1750;x+=25f)for(float z=-1750;z<=-900;z+=25f)
            {
                Vector3 point=new Vector3(x,0,z);float y=terrain.SampleHeight(point)+terrain.transform.position.y;
                if(y<42f || y>58f)continue;
                float sea1=terrain.SampleHeight(point+Vector3.right*40f)+terrain.transform.position.y;
                float sea2=terrain.SampleHeight(point+Vector3.back*40f)+terrain.transform.position.y;
                if(sea1>42f && sea2>42f)continue;
                Vector3 floor;if(!ShoreFloor(point,out floor))continue;
                float candidate=(x-1700)*(x-1700)+(z+1750)*(z+1750);
                if(candidate<score){score=candidate;chosen=floor;found=true;}
            }
            if(found){anchors[4]=chosen;outdoorResolved=true;ModAPI.Log.Write("[ForestRE3] CHEST_NW_ACCESSIBLE "+chosen+"; topSurface+clearance+fourApproaches=true");}
        }
        private GameObject CreateChest(int id,Vector3 floor,float yaw,bool copy)
        {
            var obj=UnityEngine.Object.Instantiate(prefab); obj.name="ForestRE3_Baul_"+id+(copy ? "_Prueba":"");
            obj.transform.position=Vector3.zero; obj.transform.rotation=Quaternion.identity; obj.transform.localScale=Vector3.one;
            Bounds bounds=new Bounds(); bool first=true;
            foreach(var renderer in obj.GetComponentsInChildren<Renderer>())
            { if(first) { bounds=renderer.bounds; first=false; } else bounds.Encapsulate(renderer.bounds); }
            float scale=3.2f/Mathf.Max(.01f,bounds.size.x);
            var model=new GameObject("RE3R_original"); model.transform.SetParent(obj.transform,false);
            var children=new List<Transform>(); foreach(Transform child in obj.transform) if(child!=model.transform) children.Add(child);
            foreach(var child in children) child.SetParent(model.transform,true);
            model.transform.localPosition=-new Vector3(bounds.center.x,bounds.min.y,bounds.center.z)*scale;
            model.transform.localScale=Vector3.one*scale;
            var collider=obj.AddComponent<BoxCollider>(); collider.center=new Vector3(0,bounds.size.y*scale*.5f,0); collider.size=bounds.size*scale;
            obj.AddComponent<Re3Chest>().id=id;
            obj.transform.position=floor; obj.transform.rotation=Quaternion.Euler(0,yaw,0);
            return obj;
        }
        private void Aim()
        {
            aimed=-1; if(menu || !CanOpen || LocalPlayer.MainCam==null) return;
            RaycastHit hit;
            if(Physics.Raycast(LocalPlayer.MainCam.transform.position,LocalPlayer.MainCam.transform.forward,out hit,10f,~0,QueryTriggerInteraction.Ignore))
            { var box=hit.collider.GetComponentInParent<Re3Chest>(); if(box!=null) aimed=box.id; }
        }
        internal bool Near(int id,Vector3 pos,float distance)
        { return id>=0 && id<5 && ((anchors[id]-pos).sqrMagnitude<distance*distance || (hasTest[id] && (testPoints[id]-pos).sqrMagnitude<distance*distance)); }
        private void PlaceTest(int id)
        {
            if(!Re3DeveloperTools.Enabled)return;
            Vector3 f=Vector3.ProjectOnPlane(LocalPlayer.MainCam.transform.forward,Vector3.up).normalized;
            if(f.sqrMagnitude<.01f) f=LocalPlayer.Transform.forward;
            Vector3 floor;
            if(!Ground(LocalPlayer.Transform.position+f*8f,6f,12f,out floor)) { Notice("No encontré suelo delante del jugador."); return; }
            SendRequest(4,id,0,0,0,floor); Close();
        }
        private IEnumerator Teleport(int id)
        {
            if(!Re3DeveloperTools.Enabled)yield break;
            ResolveCoast();
            Vector3 saved=LocalPlayer.Transform.position; bool cave=LocalPlayer.IsInCaves; var fp=LocalPlayer.FpCharacter;
            float pivotAboveFeet=fp.transform.position.y-fp.capsule.bounds.min.y;
            bool previous=menu && lockedOwner==fp ? wasMovementLocked:fp.MovementLocked,kinematic=fp.rb.isKinematic;
            Close(); teleporting=true; fp.MovementLocked=true; fp.rb.velocity=Vector3.zero; fp.rb.isKinematic=true;
            var loc=Re3ChestLocation.All[id]; bool success=false;
            try
            {
                Notice("Cargando zona: "+loc.name);
                if(loc.endgame && !SceneManager.GetSceneByName("endgame_streaming").isLoaded)
                {
                    bool requested=false;
                    foreach(var trigger in UnityEngine.Object.FindObjectsOfType<TheForest.World.SceneLoadTrigger>())
                        if(trigger._sceneName=="endgame_streaming") { trigger.SetCanLoad(true); trigger.ForceLoad(); requested=true; break; }
                    if(!requested) SceneManager.LoadSceneAsync("endgame_streaming",LoadSceneMode.Additive);
                }
                if(loc.cave!=LocalPlayer.IsInCaves) LocalPlayer.GameObject.SendMessage(loc.cave ? "InACave":"NotInACave",SendMessageOptions.DontRequireReceiver);
                // Move while frozen so native area triggers stream the destination.
                Vector3 wanted=anchors[id];
                if(!loc.cave && !loc.endgame && Terrain.activeTerrain!=null) wanted.y=Terrain.activeTerrain.SampleHeight(wanted)+Terrain.activeTerrain.transform.position.y;
                fp.transform.position=wanted+Vector3.up*(id==4 ? 150f:4f);
                foreach(var area in UnityEngine.Object.FindObjectsOfType<TheForest.World.Areas.Area>())
                { var collider=area.GetComponent<Collider>(); if(collider!=null && collider.bounds.Contains(wanted)) { area.OnEnter(null); break; } }
                float until=Time.realtimeSinceStartup+15f;
                while(Time.realtimeSinceStartup<until && fp==LocalPlayer.FpCharacter)
                {
                    if(id==4 && !Client){outdoorResolved=false;coastRetry=0;ResolveCoast();wanted=anchors[4];}
                    Vector3 floor=wanted;
                    if((!loc.endgame || SceneManager.GetSceneByName("endgame_streaming").isLoaded) && (id==4 ? outdoorResolved && ShoreFloor(wanted,out floor):Ground(wanted,8f,12f,out floor)))
                    {
                        // Validate a landing next to the box; preserve the native capsule pivot.
                        Vector3 landing=floor+Quaternion.Euler(0,loc.yaw,0)*Vector3.forward*5f; Vector3 landingFloor;
                        if(Ground(landing,7f,10f,out landingFloor))
                        {
                            anchors[id]=floor;
                            fp.transform.position=landingFloor+Vector3.up*(.15f+pivotAboveFeet);
                            fp.transform.rotation=Quaternion.LookRotation(Vector3.ProjectOnPlane(floor-landingFloor,Vector3.up));
                            success=true; RefreshWorld(); Notice("Zona lista: "+loc.name); break;
                        }
                    }
                    yield return new WaitForSeconds(.25f);
                }
            }
            finally
            {
                if(fp!=null)
                {
                    if(!success && fp==LocalPlayer.FpCharacter)
                    { fp.transform.position=saved; LocalPlayer.GameObject.SendMessage(cave ? "InACave":"NotInACave",SendMessageOptions.DontRequireReceiver); Notice("La zona no terminó de cargar; regresaste al punto de salida."); }
                    fp.rb.isKinematic=kinematic; fp.rb.velocity=Vector3.zero; fp.MovementLocked=previous;
                }
                teleporting=false; releaseAt=Time.realtimeSinceStartup+.2f;
            }
        }
        private static string SlotPath() { return Path.Combine(SaveSlotUtils.GetLocalSlotPath(),SaveName); }
        public static void NativeLoaded()
        {
            if(Client) return;
            string path=SlotPath(); pendingLoadPath=path;
            if(Instance!=null && Instance.ready) { Instance.Close(); Instance.ResetData(); Instance.LoadData(path);Instance.worldInitialized=true; pendingLoadPath=null; }
        }
        public static void NativeSaved()
        {
            if(Instance==null || !Instance.ready || Client) return;
            try { Instance.SaveData(SlotPath()); Instance.Notice("Inventario RE3R y cinco baúles guardados con la partida."); }
            catch(Exception e) { Instance.Notice("No se pudo guardar el inventario RE3R; consulta el registro."); ModAPI.Log.Write("[ForestRE3] INVENTORY_SAVE_ERROR "+e); }
        }
        private void SaveData(string path)
        {
            if(saveBlocked) throw new InvalidDataException("Existing RE3 save could not be loaded; preserving it.");
            byte[] bytes;
            using(var stream=new MemoryStream())
            {
                using(var w=new BinaryWriter(stream))
                {
                    w.Write(0x31495246u); w.Write((ushort)5); w.Write(bags.Count);
                    foreach(var pair in bags)
                    {
                        w.Write(pair.Key); pair.Value.Write(w);w.Write((byte)G19Runtime.SavedAmmo(pair.Key,1));w.Write((byte)G19Runtime.SavedAmmo(pair.Key,3));
                        Storage(pair.Key).Write(w);
                    }
                    w.Flush(); bytes=stream.ToArray();
                }
            }
            byte[] hash; using(var sha=SHA256.Create()) hash=sha.ComputeHash(bytes);
            Directory.CreateDirectory(Path.GetDirectoryName(path)); string temp=path+".tmp";
            using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)) { f.Write(bytes,0,bytes.Length); f.Write(hash,0,hash.Length); f.Flush(); }
            if(File.Exists(path)) File.Replace(temp,path,path+".bak"); else File.Move(temp,path);
            ModAPI.Log.Write("[ForestRE3] INVENTORY_SAVED path="+path+"; players="+bags.Count+"; chests=5x4");
        }
        private void LoadData(string path)
        {
            if(!File.Exists(path)) return;
            try
            {
                var bytes=File.ReadAllBytes(path); if(bytes.Length<100 || bytes.Length>1024*1024) throw new InvalidDataException("Save size");
                byte[] hash; using(var sha=SHA256.Create()) hash=sha.ComputeHash(bytes,0,bytes.Length-32);
                for(int i=0;i<32;i++) if(hash[i]!=bytes[bytes.Length-32+i]) throw new InvalidDataException("Save checksum");
                var loaded=new Dictionary<string,Re3Bag>();var loadedStorage=new Dictionary<string,Re3Storage>();
                using(var r=new BinaryReader(new MemoryStream(bytes,0,bytes.Length-32,false)))
                {
                    if(r.ReadUInt32()!=0x31495246u) throw new InvalidDataException("Save schema");
                    ushort schema=r.ReadUInt16();if(schema<1 || schema>5)throw new InvalidDataException("Save schema");
                    int count=r.ReadInt32(); if(count<1 || count>64) throw new InvalidDataException("Player count");
                    for(int i=0;i<count;i++)
                    {
                        string key=r.ReadString(); if(key.Length>100) throw new InvalidDataException("Player key"); loaded.Add(key,Re3Bag.Read(r,20,4));
                        if(schema>=2){int ammo=r.ReadByte();if(ammo>15)throw new InvalidDataException("G19 ammo");G19Runtime.RestoreAmmo(key,1,ammo);}
                        if(schema>=3){int ammo=r.ReadByte();if(ammo>4)throw new InvalidDataException("M3 ammo");G19Runtime.RestoreAmmo(key,3,ammo);}
                        loadedStorage.Add(key,schema>=5 ? Re3Storage.Read(r):new Re3Storage());
                    }
                    if(schema<5)
                    {
                        var host=loadedStorage["host"];
                        for(int i=0;i<5;i++)host.boxes[i]=Re3Bag.Read(r,4,2);
                        if(schema>=2)r.ReadBoolean();if(schema>=3)r.ReadBoolean();
                        if(schema>=4 && (r.ReadByte()&~25)!=0)throw new InvalidDataException("Rocket seed flags");
                        // Legacy chest deposits had no owner metadata. Preserve
                        // those stacks once for the host, never clone deposits.
                        // Each peer receives its own newly seeded weapon boxes.
                        foreach(var pair in loaded)
                        {
                            var store=loadedStorage[pair.Key];
                            store.g19Seeded=Holds(pair.Value,store,1);store.m3Seeded=Holds(pair.Value,store,3);
                            if(Holds(pair.Value,store,28))store.rocketSeeded=25;
                        }
                        ModAPI.Log.Write("[ForestRE3] INVENTORY_MIGRATED personalChests=true; legacyDeposits=host; duplicateDeposits=false");
                    }
                    if(r.BaseStream.Position!=r.BaseStream.Length || !loaded.ContainsKey("host")) throw new InvalidDataException("Save trailing data");
                }
                bags.Clear();storage.Clear(); foreach(var pair in loaded)bags.Add(pair.Key,pair.Value);foreach(var pair in loadedStorage)storage.Add(pair.Key,pair.Value);
                player=bags["host"];boxes=storage["host"].boxes;
                ModAPI.Log.Write("[ForestRE3] INVENTORY_LOADED path="+path);
            }
            catch(Exception e) { saveBlocked=true; Notice("Archivo RE3R inválido: se conserva el archivo. Guardado RE3R bloqueado para protegerlo."); ModAPI.Log.Write("[ForestRE3] INVENTORY_LOAD_ERROR "+e); }
        }
    }
    public sealed class Re3Chest : MonoBehaviour { internal int id; }

    public class Re3InventorySavePatch : TheForest.Items.Inventory.PlayerInventory
    {
        public new virtual IEnumerator OnSerializing()
        { IEnumerator value=Re3SaveObserver.Observe(base.OnSerializing(),this,false); return value; }
        public new virtual IEnumerator OnDeserialized()
        { IEnumerator value=Re3SaveObserver.Observe(base.OnDeserialized(),this,true); return value; }
    }
    public static class Re3SaveObserver
    {
        public static IEnumerator Observe(IEnumerator original,TheForest.Items.Inventory.PlayerInventory inventory,bool load)
        {
            while(original.MoveNext()) yield return original.Current;
            if(inventory==LocalPlayer.Inventory)
            { if(load) Re3InventoryRuntime.NativeLoaded(); else Re3InventoryRuntime.NativeSaved(); }
        }
    }
}
