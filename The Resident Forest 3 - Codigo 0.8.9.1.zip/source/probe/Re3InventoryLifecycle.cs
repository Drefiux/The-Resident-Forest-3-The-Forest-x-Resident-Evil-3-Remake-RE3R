﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
using NativeInput=TheForest.Utils.Input;

namespace ForestRE3JillVisualProbe
{
    internal sealed class Re3Recovery
    {
        internal uint token;internal Vector3 position;internal Re3Bag bag=new Re3Bag(20,4);internal bool collecting;
    }
    internal sealed class Re3Storage
    {
        internal Re3Bag[] boxes=new Re3Bag[5];internal bool g19Seeded,m3Seeded;internal byte rocketSeeded;
        internal readonly Dictionary<uint,Re3Recovery> recovery=new Dictionary<uint,Re3Recovery>();
        internal Re3Storage(){for(int i=0;i<5;i++)boxes[i]=new Re3Bag(4,2);}
        internal void Write(BinaryWriter w)
        {
            foreach(var box in boxes)box.Write(w);w.Write(g19Seeded);w.Write(m3Seeded);w.Write(rocketSeeded);w.Write(recovery.Count);
            foreach(var item in recovery.Values){w.Write(item.token);w.Write(item.position.x);w.Write(item.position.y);w.Write(item.position.z);w.Write(item.collecting);item.bag.Write(w);}
        }
        internal static Re3Storage Read(BinaryReader r)
        {
            var value=new Re3Storage();for(int i=0;i<5;i++)value.boxes[i]=Re3Bag.Read(r,4,2);
            value.g19Seeded=r.ReadBoolean();value.m3Seeded=r.ReadBoolean();value.rocketSeeded=r.ReadByte();if((value.rocketSeeded&~25)!=0)throw new InvalidDataException("Rocket seed flags");
            int n=r.ReadInt32();if(n<0 || n>64)throw new InvalidDataException("Backpack count");
            for(int i=0;i<n;i++)
            {
                var item=new Re3Recovery{token=r.ReadUInt32(),position=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()),collecting=r.ReadBoolean(),bag=Re3Bag.Read(r,20,4)};
                if(item.token==0 || !Re3InventoryRuntime.ValidPosition(item.position))throw new InvalidDataException("Backpack record");value.recovery.Add(item.token,item);
            }
            return value;
        }
    }
    public sealed partial class Re3InventoryRuntime
    {
        private sealed class DeathEvidence{internal Vector3 position;internal ulong actor;internal float at;}
        private readonly Dictionary<string,List<DeathEvidence>> deathEvidence=new Dictionary<string,List<DeathEvidence>>();
        private bool lifeAcknowledged;
        internal static void ActorDetached(BoltEntity entity)
        {
            if(Instance==null || Client || entity==null || !entity.StateIs<IPlayerState>())return;
            string key=PeerKey(entity.source);
            List<DeathEvidence> history;
            if(!Instance.deathEvidence.TryGetValue(key,out history)){history=new List<DeathEvidence>();Instance.deathEvidence.Add(key,history);}
            if(history.Count>=64)history.RemoveAt(0);
            history.Add(new DeathEvidence{position=entity.transform.position,actor=entity.networkId.PackedValue,at=Time.realtimeSinceStartup});
        }
        public static void BeginWorld()
        {
            if(Instance==null)return;Instance.Close();Instance.DestroyWorld();Instance.ResetData();Instance.worldInitialized=false;Instance.ready=false;Instance.owner=null;
        }
        private sealed class LifeRequest{internal byte operation;internal uint token;internal Vector3 position;internal float next;}
        private readonly Queue<LifeRequest> lifeQueue=new Queue<LifeRequest>();
        private readonly Dictionary<uint,Re3RecoveryMarker> recoveryMarkers=new Dictionary<uint,Re3RecoveryMarker>();
        private readonly Dictionary<uint,Vector3> visibleRecoveries=new Dictionary<uint,Vector3>();
        internal static bool ValidPosition(Vector3 p){return Finite(p) && Mathf.Abs(p.x)<100000f && Mathf.Abs(p.y)<100000f && Mathf.Abs(p.z)<100000f;}
        private void ResetLifecycle()
        {
            lifeQueue.Clear();visibleRecoveries.Clear();deathEvidence.Clear();foreach(var marker in recoveryMarkers.Values)if(marker!=null && marker.fallback)Destroy(marker.gameObject);recoveryMarkers.Clear();
        }
        public static uint BeforeRespawn(GameObject corpse)
        {
            if(Instance==null || !Instance.ready || corpse==null || LocalPlayer.Stats==null || !LocalPlayer.Stats.Dead)return 0;
            uint token=BitConverter.ToUInt32(Guid.NewGuid().ToByteArray(),0);if(token==0)token=1;
            Instance.Close();G19Runtime.PlayerRecreated();Instance.QueueLife(5,token,corpse.transform.position);
            // Keep local prediction hidden until the host acknowledges the
            // authoritative move. The client's bag never supplies item data.
            if(Client){Instance.player=new Re3Bag(20,4);Instance.networkReady=false;}
            ModAPI.Log.Write("[ForestRE3] INVENTORY_DEATH_CAPTURE token="+token+"; onlyLocalPlayer=true");return token;
        }
        public static void AfterRespawn(GameObject corpse,uint token,Vector3 position)
        {
            if(Instance==null || token==0)return;
            if(corpse!=null)
            {
                var marker=corpse.GetComponent<Re3RecoveryMarker>() ?? corpse.AddComponent<Re3RecoveryMarker>();marker.token=token;marker.position=position;marker.fallback=false;
                Instance.recoveryMarkers[token]=marker;
            }
            Instance.visibleRecoveries[token]=position;
        }
        public static void NativeBackpackCollected(Re3RecoveryMarker marker)
        {
            if(Instance!=null && marker!=null)Instance.QueueLife(6,marker.token,marker.position);
        }
        private void QueueLife(byte operation,uint token,Vector3 position)
        {
            if(token==0 || !ValidPosition(position))return;
            foreach(var item in lifeQueue)if(item.operation==operation && item.token==token)return;
            lifeQueue.Enqueue(new LifeRequest{operation=operation,token=token,position=position});pending=false;
        }
        private void TickLifecycle()
        {
            if(lifeQueue.Count>0 && ready && (!Client || CoopSync.CanStartDodge))
            {
                var item=lifeQueue.Peek();
                if(Time.realtimeSinceStartup>=item.next && (!BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer || LocalPlayer.Entity!=null && LocalPlayer.Entity.isAttached))
                {
                    item.next=Time.realtimeSinceStartup+1f;
                    SendRequest(item.operation,0,0,0,0,item.position,item.token);
                }
            }
            if(!Client)
            {
                foreach(var pair in storage)
                {
                    Re3Bag bag;if(!bags.TryGetValue(pair.Key,out bag))continue;
                    foreach(var recovery in pair.Value.recovery.Values)if(recovery.collecting && recovery.bag.Used>0)MergeRecovery(bag,recovery);
                }
                visibleRecoveries.Clear();Re3Storage host;
                if(storage.TryGetValue("host",out host))foreach(var item in host.recovery.Values)if(item.bag.Used>0 && !item.collecting)visibleRecoveries[item.token]=item.position;
            }
            if(!ActiveWorld)return;
            foreach(var pair in visibleRecoveries)
            {
                Re3RecoveryMarker existing;if(recoveryMarkers.TryGetValue(pair.Key,out existing) && existing!=null)continue;
                if((LocalPlayer.Transform.position-pair.Value).sqrMagnitude>250f*250f)continue;
                var prefabs=TheForest.Utils.Prefabs.Instance;if(prefabs==null || prefabs.DeadBackpackPrefab==null)continue;
                var original=UnityEngine.Object.Instantiate(prefabs.DeadBackpackPrefab);var obj=original.gameObject;
                // Only the original visible bag is needed for restored saves or
                // a corpse native cleanup removed. RE items remain in the mod.
                Destroy(original);obj.name="ForestRE3_Mochila_"+pair.Key;obj.transform.position=pair.Value;obj.SetActive(true);
                var marker=obj.AddComponent<Re3RecoveryMarker>();marker.token=pair.Key;marker.position=pair.Value;marker.fallback=true;
                if(obj.GetComponentInChildren<Collider>()==null){var c=obj.AddComponent<BoxCollider>();c.center=Vector3.up*.5f;c.size=new Vector3(1.2f,1,1.2f);}
                recoveryMarkers[pair.Key]=marker;
            }
            var gone=new List<uint>();foreach(var pair in recoveryMarkers)if(!visibleRecoveries.ContainsKey(pair.Key))gone.Add(pair.Key);
            foreach(uint token in gone){var marker=recoveryMarkers[token];if(marker!=null && marker.fallback)Destroy(marker.gameObject);recoveryMarkers.Remove(token);}
        }
        private static void MergeRecovery(Re3Bag target,Re3Recovery recovery)
        {
            for(int i=0;i<recovery.bag.slots.Length;i++)
            {
                var slot=recovery.bag.slots[i];if(slot.id==0 || slot.id==Re3Bag.Continued)continue;
                // Transfers are atomic per stack. Any overflow stays persisted
                // and is delivered once the owner frees enough inventory space.
                Re3Bag.Transfer(recovery.bag,target,i,slot.count);
            }
        }
        private string ProcessLife(string key,Re3Bag bag,byte operation,uint token,Vector3 position,Vector3 actorPosition,ulong actor)
        {
            if(token==0 || !ValidPosition(position))return "Mochila RE3R no válida.";
            var store=Storage(key);Re3Recovery record;
            if(operation==5)
            {
                if(store.recovery.ContainsKey(token)){lifeAcknowledged=true;return "";}
                List<DeathEvidence> history=null;DeathEvidence evidence=null;
                if(key!="host")
                {
                    if(deathEvidence.TryGetValue(key,out history))foreach(var item in history)
                        if(item.actor!=actor && (item.position-position).sqrMagnitude<=20f*20f){evidence=item;break;}
                    if(evidence==null)return "Esperando la confirmación de reaparición de tu jugador.";
                }
                if(store.recovery.Count>=64)
                {
                    uint old=0;foreach(var item in store.recovery.Values)if(item.bag.Used==0){old=item.token;break;}
                    if(old==0){lifeAcknowledged=true;return "Demasiadas mochilas pendientes: el inventario se conserva.";}store.recovery.Remove(old);
                }
                record=new Re3Recovery{token=token,position=position,bag=bag};store.recovery.Add(token,record);if(history!=null && evidence!=null){history.Remove(evidence);if(history.Count==0)deathEvidence.Remove(key);}
                var empty=new Re3Bag(20,4);empty.revision=bag.revision+1;if(empty.revision==0)empty.revision=1;bags[key]=empty;
                if(key=="host")player=empty;
                lifeAcknowledged=true;return "";
            }
            if(!store.recovery.TryGetValue(token,out record))return "No se encontró la mochila RE3R de este jugador.";
            if((record.position-position).sqrMagnitude>4f*4f || (record.position-actorPosition).sqrMagnitude>14f*14f)return "Acércate a tu mochila para recuperar las armas RE3R.";
            record.collecting=true;MergeRecovery(bag,record);lifeAcknowledged=true;
            return record.bag.Used==0 ? "Armas y objetos RE3R recuperados.":"Mochila RE3R recuperada; los objetos restantes se entregarán al liberar espacio.";
        }
        private void ConfirmLife(byte operation,uint token)
        {
            if(lifeQueue.Count==0)return;var item=lifeQueue.Peek();
            if(item.operation!=operation || item.token!=token)return;
            lifeQueue.Dequeue();networkReady=!Client || lifeQueue.Count==0;
        }
        private void WriteRecoveries(BinaryWriter w,Re3Storage store)
        {
            int n=0;foreach(var item in store.recovery.Values)if(item.bag.Used>0 && !item.collecting)n++;
            w.Write((byte)n);foreach(var item in store.recovery.Values)if(item.bag.Used>0 && !item.collecting){w.Write(item.token);w.Write(item.position.x);w.Write(item.position.y);w.Write(item.position.z);}
        }
    }
    public sealed class Re3RecoveryMarker : MonoBehaviour
    {
        internal uint token;internal Vector3 position;internal bool fallback;private bool aimed;private float next;
        private void Update()
        {
            aimed=false;if(!fallback || Re3InventoryRuntime.Instance==null || !Re3InventoryRuntime.Instance.ActiveWorld || LocalPlayer.MainCam==null || Re3InventoryRuntime.BlockControls)return;
            RaycastHit hit;aimed=Physics.Raycast(LocalPlayer.MainCam.transform.position,LocalPlayer.MainCam.transform.forward,out hit,10f,~0,QueryTriggerInteraction.Collide) && hit.collider.GetComponentInParent<Re3RecoveryMarker>()==this;
            if(aimed && Time.realtimeSinceStartup>=next && NativeInput.GetButtonAfterDelay("Take",.5f,false)){next=Time.realtimeSinceStartup+1f;Re3InventoryRuntime.NativeBackpackCollected(this);}
        }
        private void OnGUI(){if(aimed)GUI.Box(new Rect(Screen.width*.5f-55,Screen.height*.65f,110,30),"[E] Mochila");}
    }
    public class Re3InventoryRespawnPatch : TheForest.Save.PlayerRespawnMP
    {
        public new virtual void Respawn()
        {
            GameObject corpse=LocalPlayer.GameObject;Vector3 position=corpse!=null ? corpse.transform.position:Vector3.zero;
            uint token=Re3InventoryRuntime.BeforeRespawn(corpse);base.Respawn();Re3InventoryRuntime.AfterRespawn(corpse,token,position);GC.KeepAlive(this);
        }
    }
    public class Re3InventoryBackpackPatch : TheForest.Networking.StealItemTrigger
    {
        public new virtual void Update()
        {
            var marker=GetComponentInParent<Re3RecoveryMarker>();bool wasActive=gameObject.activeSelf;
            base.Update();
            // Native Update disables this trigger only after the actual Take
            // action. Merely looking at, leaving, or disabling a bag does not
            // reclaim the RE inventory.
            if(marker!=null && wasActive && !gameObject.activeSelf)Re3InventoryRuntime.NativeBackpackCollected(marker);
            GC.KeepAlive(this);
        }
    }
}
