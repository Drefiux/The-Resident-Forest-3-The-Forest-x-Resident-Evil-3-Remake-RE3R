﻿using UnityEngine;

namespace ForestRE3JillVisualProbe
{
    // Each character owns its actual RE rest pose, helper samples and assets.
    // No anatomy or decoded animation cache is shared across characters.
    internal sealed class CharacterProfile
    {
        internal static readonly CharacterProfile Jill = new CharacterProfile("jill", "Jill", "pl2000", "pl2001", "pl2005", 1.72f);
        internal static readonly CharacterProfile Carlos = new CharacterProfile("carlos", "Carlos", "pl0000", "pl0001", "pl0005", 1.82f);
        internal static readonly CharacterProfile[] All = { Jill, Carlos };
        internal readonly string Id, Name, BodyId, HeadId, HairId;
        internal readonly float HeightRatio;
        internal GameObject Prefab;
        internal MotionData Motion;
        internal float[][][] Shoulders;
        internal string Skeleton { get { return Name+"Skeleton"; } }
        internal string Resource(string suffix) { return "ForestRE3JillVisualProbe."+Id+suffix; }
        private CharacterProfile(string id, string name, string body, string head, string hair, float referenceHeight)
        {
            Id=id; Name=name; BodyId=body; HeadId=head; HairId=hair;
            // Design heights relative to the native standing capsule; game
            // units, actual camera and collision height remain unchanged.
            HeightRatio=referenceHeight/1.78f;
        }
    }
}
