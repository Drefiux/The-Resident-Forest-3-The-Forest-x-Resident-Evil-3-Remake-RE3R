﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using LocalPlayer = TheForest.Utils.LocalPlayer;

namespace ForestRE3JillVisualProbe
{
    // A small protocol alongside the native transform/Mecanim replication.
    // No assets, bone transforms or physics are sent by this layer.
    // Inventory sends bounded RE3 IDs/counts; the host owns atomic transfers.
    public sealed class CoopSync : MonoBehaviour
    {
        private const uint Magic = 0x43523346; // FR3C, little endian
        private const ushort Protocol = 9;
        private const uint Catalog = 0x08090001; // Characters, rolls, voices and separate RE3 inventory IDs
        private const int MaxPlayers = 64;
        private enum Message : byte { Hello=1, Welcome=2, Select=3, State=4, Snapshot=5, Voice=6, Dodge=7, DodgeDenied=8, TestSpawn=9, DodgeSnapshot=10, InventoryRequest=11, InventoryState=12, G19Request=13, G19State=14, RocketState=15, OptionsState=16 }
        private sealed class Peer { internal bool ready; internal float helloAt, snapshotAt, rateAt, spawnAt; internal int messages; }
        private sealed class Actor
        {
            internal ulong id;
            internal byte character;
            internal uint revision, voiceSequence;
            internal BoltConnection origin;
            internal CoopRemoteAvatar avatar;
            internal bool hasVoiceSequence;
            internal bool hasDodgeSequence;
            internal uint dodgeSequence;
            internal float dodgeAt=-100f;
            internal DodgeAction dodge;
        }
        internal static CoopSync Instance;
        private static UdpKit.UdpChannelName control, effects;
        private static bool registered;
        private readonly Dictionary<BoltConnection,Peer> peers = new Dictionary<BoltConnection,Peer>();
        private readonly Dictionary<ulong,BoltEntity> players = new Dictionary<ulong,BoltEntity>();
        private readonly Dictionary<ulong,Actor> actors = new Dictionary<ulong,Actor>();
        private readonly List<ulong> remove = new List<ulong>();
        private uint epoch, localRevision, voiceSequence;
        private ulong localId;
        private byte localCharacter = 255;
        private float tickAt, selectionAt, warningAt;
        private bool enumerated;
        private string problem = "";
        private int rejected;
        internal static bool CanStartDodge
        {
            get
            {
                if (!BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer) return true;
                Actor actor;
                return Instance!=null && registered && Instance.epoch!=0
                    && Instance.actors.TryGetValue(Instance.localId,out actor) && actor.revision==Instance.localRevision
                    && actor.character==Instance.localCharacter;
            }
        }

        internal static void Ensure(GameObject host)
        {
            if (Instance == null)
            {
                Instance = host.AddComponent<CoopSync>();
                host.AddComponent<Callbacks>();
                host.AddComponent<Re3CoopOptions>();
            }
        }
        // Nested in an added MonoBehaviour so ModAPI preserves a real listener
        // subclass instead of treating it as an injection into ALL listeners.
        public sealed class Callbacks : Bolt.GlobalEventListener
        {
            public override bool PersistBetweenStartupAndShutdown() { return true; }
            public override void Connected(BoltConnection connection) { if (Instance!=null) Instance.Connected(connection); }
            public override void Disconnected(BoltConnection connection) { if (Instance!=null) Instance.Disconnected(connection); }
            public override void EntityAttached(BoltEntity entity) { if (Instance!=null) Instance.Track(entity); }
            public override void EntityDetached(BoltEntity entity) { if (Instance!=null) Instance.EntityDetached(entity); }
            public override void BoltShutdownBegin(Bolt.AddCallback registerDone) { if (Instance!=null) Instance.ClearSession(); }
        }

        // Called after the game's Voice channel in the SAME native callback on
        // both sides. UdpKit assigns numeric IDs in creation order, not by name.
        // Called from the injected Assembly-CSharp methods, across assemblies.
        public static void RegisterChannels()
        {
            if (Instance == null) return;
            Instance.ClearSession();
            try
            {
                control = BoltNetwork.CreateStreamChannel("ForestRE3.Control.v9", UdpKit.UdpChannelMode.Reliable, 1);
                effects = BoltNetwork.CreateStreamChannel("ForestRE3.Effects.v9", UdpKit.UdpChannelMode.Unreliable, 1);
                registered = true;
                if (BoltNetwork.isServer) Instance.epoch = NewEpoch();
                ModAPI.Log.Write("[ForestRE3] COOP_CHANNELS version=0.8.9; protocol=9; catalog="+Catalog
                    +"; control="+control+"; effects="+effects+"; nativeVoiceFirst=true");
            }
            catch (Exception error) { Instance.Warn("No se pudo iniciar el canal cooperativo", error); registered=false; }
        }
        private static uint NewEpoch()
        {
            uint value=unchecked((uint)Guid.NewGuid().GetHashCode());
            return value==0 ? 1u : value;
        }
        public static bool IsNativeVoice(UdpKit.UdpStreamData data)
        {
            return data!=null && data.Channel.Equals(CoopVoice.VoiceChannel);
        }
        public static void Receive(BoltConnection connection, UdpKit.UdpStreamData data)
        {
            if (Instance==null || !registered || data==null || data.Data==null) return;
            bool isEffects=data.Channel.Equals(effects);
            if (!isEffects && !data.Channel.Equals(control)) return;
            try { Instance.Read(connection,data.Data,isEffects); }
            catch (Exception error) { Instance.rejected++; Instance.Warn("Paquete coop descartado",error); }
        }
        private void Warn(string description, Exception error)
        {
            if (Time.realtimeSinceStartup<warningAt) return;
            warningAt=Time.realtimeSinceStartup+10f;
            ModAPI.Log.Write("[ForestRE3] COOP_WARNING "+description+"; rejected="+rejected+"; "+error);
        }
        private void Connected(BoltConnection connection)
        {
            if (connection!=null && !peers.ContainsKey(connection)) peers.Add(connection,new Peer());
        }
        private void Disconnected(BoltConnection connection)
        {
            Re3InventoryRuntime.PeerGone(connection);G19Runtime.PeerGone(connection);
            if (connection!=null) peers.Remove(connection);
            remove.Clear();
            foreach (var pair in actors) if (pair.Value.origin==connection) remove.Add(pair.Key);
            foreach (ulong id in remove) RemoveActor(id);
            if (BoltNetwork.isClient)
            {
                foreach (Actor actor in actors.Values) if (actor.avatar!=null) actor.avatar.Dispose();
                actors.Clear(); players.Clear(); DodgeRuntime.ClearRemotes(); epoch=0; selectionAt=0; enumerated=false;
            }
        }
        private void EntityDetached(BoltEntity entity)
        {
            if (entity==null) return;
            Re3InventoryRuntime.ActorDetached(entity);
            ulong id=entity.networkId.PackedValue;
            players.Remove(id); RemoveActor(id);
        }
        private void Track(BoltEntity entity)
        {
            if (entity!=null && entity.isAttached && entity.StateIs<IPlayerState>() && players.Count<MaxPlayers)
                players[entity.networkId.PackedValue]=entity;
        }
        private void RemoveActor(ulong id)
        {
            Actor actor;
            if (actors.TryGetValue(id,out actor) && actor.avatar!=null) actor.avatar.Dispose();
            actors.Remove(id);
            DodgeRuntime.RemoveRemote(id);
        }
        private void ClearSession()
        {
            Re3InventoryRuntime.NetworkReset();G19Runtime.NetworkReset();
            Re3CoopOptions.ResetSession();
            foreach (Actor actor in actors.Values) if (actor.avatar!=null) actor.avatar.Dispose();
            actors.Clear(); players.Clear(); peers.Clear();
            DodgeRuntime.ClearRemotes();
            epoch=localRevision=voiceSequence=0; localId=0; localCharacter=255;
            tickAt=selectionAt=warningAt=0; enumerated=false; registered=false; problem=""; rejected=0;
        }
        private void Update()
        {
            if (!registered || !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer) return;
            if (Time.realtimeSinceStartup<tickAt) return;
            tickAt=Time.realtimeSinceStartup+.35f;
            try
            {
                if (!enumerated)
                {
                    foreach (BoltEntity entity in BoltNetwork.entities) Track(entity);
                    enumerated=true;
                }
                foreach (BoltConnection connection in BoltNetwork.connections)
                    if (connection!=null && !peers.ContainsKey(connection)) peers.Add(connection,new Peer());
                foreach (var pair in peers)
                {
                    if (!BoltNetwork.isServer && !pair.Value.ready && Time.realtimeSinceStartup>=pair.Value.helloAt)
                    {
                        pair.Value.helloAt=Time.realtimeSinceStartup+3f;
                        Send(pair.Key,Message.Hello,delegate(BinaryWriter writer) { writer.Write(Catalog); });
                    }
                }
                ObserveLocal();
                if (BoltNetwork.isServer)
                    foreach (var pair in peers) if (pair.Value.ready && Time.realtimeSinceStartup>=pair.Value.snapshotAt)
                    { pair.Value.snapshotAt=Time.realtimeSinceStartup+10f; SendSnapshot(pair.Key); }
                UpdateAvatars();
            }
            catch (Exception error) { Warn("Actualizacion coop",error); }
        }
        private void ObserveLocal()
        {
            JillPlayerAvatar avatar=JillPlayerAvatar.Current;
            BoltEntity entity=LocalPlayer.Entity;
            if (avatar==null || !avatar.NetworkReady || entity==null || !entity.isAttached) return;
            Track(entity);
            ulong id=entity.networkId.PackedValue;
            byte choice=CharacterId(avatar.NetworkCharacter);
            if (id!=localId || choice!=localCharacter)
            {
                localId=id; localCharacter=choice; localRevision++;
                if (localRevision==0) localRevision=1;
                selectionAt=0;
            }
            if (epoch==0 || Time.realtimeSinceStartup<selectionAt) return;
            Actor accepted;
            bool acknowledged=actors.TryGetValue(id,out accepted) && accepted.revision==localRevision && accepted.character==choice;
            if (acknowledged) return;
            selectionAt=Time.realtimeSinceStartup+2f;
            if (BoltNetwork.isServer) Accept(id,choice,localRevision,null);
            else
            {
                Peer server;
                if (BoltNetwork.server!=null && peers.TryGetValue(BoltNetwork.server,out server) && server.ready)
                    Send(BoltNetwork.server,Message.Select,delegate(BinaryWriter writer) { WriteIdentity(writer,id,choice,localRevision); });
            }
        }
        private static byte CharacterId(CharacterProfile character) { return character==CharacterProfile.Carlos ? (byte)1 : (byte)0; }
        internal static CharacterProfile Profile(byte id) { return id==1 ? CharacterProfile.Carlos : CharacterProfile.Jill; }
        private static bool Newer(uint value,uint previous) { return unchecked((int)(value-previous))>0; }
        private static void WriteIdentity(BinaryWriter writer,ulong id,byte character,uint revision)
        { writer.Write(id); writer.Write(character); writer.Write(revision); }
        private static void ReadIdentity(BinaryReader reader,out ulong id,out byte character,out uint revision)
        {
            id=reader.ReadUInt64(); character=reader.ReadByte(); revision=reader.ReadUInt32();
            if (id==0 || character>1 || revision==0) throw new InvalidDataException("Invalid actor identity");
        }
        private void Send(BoltConnection connection,Message kind,Action<BinaryWriter> payload)
        {
            if (connection==null) return;
            try
            {
                using (var stream=new MemoryStream())
                {
                    using (var writer=new BinaryWriter(stream))
                    { writer.Write(Magic); writer.Write(Protocol); writer.Write((byte)kind); writer.Write(epoch); payload(writer); writer.Flush(); }
                    connection.StreamBytes(kind==Message.Voice ? effects : control, stream.ToArray());
                }
            }
            catch (Exception error) { Warn("Envio coop",error); }
        }
        private void SendState(BoltConnection connection,Actor actor)
        { Send(connection,Message.State,delegate(BinaryWriter writer) { WriteIdentity(writer,actor.id,actor.character,actor.revision); }); }
        private void SendSnapshot(BoltConnection connection)
        {
            Re3CoopOptions.SendSnapshot(connection);
            G19Runtime.SendSnapshot(connection);G19Runtime.RocketSnapshot(connection);
            Send(connection,Message.Snapshot,delegate(BinaryWriter writer)
            {
                writer.Write((byte)actors.Count);
                foreach (Actor actor in actors.Values) WriteIdentity(writer,actor.id,actor.character,actor.revision);
            });
            Send(connection,Message.DodgeSnapshot,delegate(BinaryWriter writer)
            {
                int count=0; foreach (Actor actor in actors.Values) if (actor.dodge!=null && actor.dodge.Playing) count++;
                writer.Write((byte)count);
                foreach (Actor actor in actors.Values) if (actor.dodge!=null && actor.dodge.Playing) WriteDodge(writer,actor,actor.dodge);
            });
        }
        internal static void G19Request(Action<BinaryWriter> payload)
        {
            if(Instance==null || !CanStartDodge || !BoltNetwork.isClient)return;
            Instance.Send(BoltNetwork.server,Message.G19Request,delegate(BinaryWriter w){w.Write(Instance.localId);payload(w);});
        }
        internal static void RocketState(BoltConnection connection,Action<BinaryWriter> payload)
        {
            if(Instance==null || !BoltNetwork.isServer || !registered || Instance.epoch==0)return;
            if(connection!=null)Instance.Send(connection,Message.RocketState,payload);
            else foreach(var pair in Instance.peers)if(pair.Value.ready)Instance.Send(pair.Key,Message.RocketState,payload);
        }
        internal static void G19State(BoltConnection connection,Action<BinaryWriter> payload)
        {
            if(Instance==null || !BoltNetwork.isServer || !registered || Instance.epoch==0)return;
            if(connection!=null)Instance.Send(connection,Message.G19State,payload);
            else foreach(var pair in Instance.peers)if(pair.Value.ready)Instance.Send(pair.Key,Message.G19State,payload);
        }
        internal static void OptionsState(BoltConnection connection,Action<BinaryWriter> payload)
        {
            if(Instance==null || !BoltNetwork.isServer || !registered || Instance.epoch==0)return;
            if(connection!=null)Instance.Send(connection,Message.OptionsState,payload);
            else foreach(var pair in Instance.peers)if(pair.Value.ready)Instance.Send(pair.Key,Message.OptionsState,payload);
        }
        private Actor SetIdentity(ulong id,byte character,uint revision,BoltConnection origin)
        {
            Actor actor;
            if (actors.TryGetValue(id,out actor))
            {
                if (revision!=actor.revision && !Newer(revision,actor.revision)) return actor;
                if (revision==actor.revision && character!=actor.character) return actor;
            }
            else
            {
                if (actors.Count>=MaxPlayers) throw new InvalidDataException("Too many actors");
                actor=new Actor { id=id }; actors.Add(id,actor);
            }
            if (actor.character!=character || actor.revision!=revision)
            {
                actor.hasVoiceSequence=false;
                actor.hasDodgeSequence=false; actor.dodge=null; actor.dodgeAt=-100f; DodgeRuntime.RemoveRemote(id);
                ModAPI.Log.Write("[ForestRE3] COOP_CHARACTER entity="+id+"; character="+Profile(character).Name+"; revision="+revision);
            }
            actor.character=character; actor.revision=revision; actor.origin=origin;
            return actor;
        }
        private void Accept(ulong id,byte character,uint revision,BoltConnection origin)
        {
            Actor existing;
            if(origin!=null && actors.TryGetValue(id,out existing) && existing.character!=character){SendState(origin,existing);return;}
            Actor actor=SetIdentity(id,character,revision,origin);
            foreach (var pair in peers) if (pair.Value.ready) SendState(pair.Key,actor);
        }
        private bool Owns(BoltConnection connection,ulong id)
        {
            BoltEntity entity= BoltNetwork.FindEntity(new Bolt.NetworkId(id));
            return entity!=null && entity.isAttached && entity.StateIs<IPlayerState>() && entity!=LocalPlayer.Entity
                && (entity.source==connection || entity.controller==connection);
        }
        private void Read(BoltConnection connection,byte[] bytes,bool isEffects)
        {
            if (connection==null || bytes.Length<11 || bytes.Length>(isEffects ? 64:2300)) throw new InvalidDataException("Packet size");
            Peer peer;
            if (!peers.TryGetValue(connection,out peer)) { peer=new Peer(); peers.Add(connection,peer); }
            if (Time.realtimeSinceStartup-peer.rateAt>=1f) { peer.rateAt=Time.realtimeSinceStartup; peer.messages=0; }
            if (++peer.messages>32) throw new InvalidDataException("Packet rate");
            using (var stream=new MemoryStream(bytes,false))
            using (var reader=new BinaryReader(stream))
            {
                if (reader.ReadUInt32()!=Magic || reader.ReadUInt16()!=Protocol) { problem="Version coop incompatible"; return; }
                Message kind=(Message)reader.ReadByte(); uint session=reader.ReadUInt32();
                if ((kind==Message.Voice)!=isEffects) throw new InvalidDataException("Wrong channel");
                if (kind==Message.Hello)
                {
                    if (!BoltNetwork.isServer) return;
                    if (reader.ReadUInt32()!=Catalog) { problem="El otro equipo necesita el mismo paquete 0.8.9"; return; }
                    End(reader);
                    peer.ready=true; problem="";
                    Send(connection,Message.Welcome,delegate(BinaryWriter writer) { writer.Write(Catalog); });
                    SendSnapshot(connection); peer.snapshotAt=Time.realtimeSinceStartup+10f;
                    ModAPI.Log.Write("[ForestRE3] COOP_HELLO_ACCEPTED connection="+connection+"; epoch="+epoch);
                    return;
                }
                if (kind==Message.Welcome)
                {
                    if (BoltNetwork.isServer || connection!=BoltNetwork.server || session==0) return;
                    if (reader.ReadUInt32()!=Catalog) { problem="Catalogo coop incompatible"; return; }
                    End(reader);
                    if (epoch!=session)
                    {
                        foreach (Actor old in actors.Values) if (old.avatar!=null) old.avatar.Dispose();
                        actors.Clear(); DodgeRuntime.ClearRemotes(); epoch=session;
                    }
                    peer.ready=true; selectionAt=0; problem="";
                    ModAPI.Log.Write("[ForestRE3] COOP_WELCOME epoch="+epoch+"; localAssets=true"); return;
                }
                if (!peer.ready || session==0 || session!=epoch) return;
                ulong id; byte character; uint revision;
                if (kind==Message.Select)
                {
                    if (!BoltNetwork.isServer) return;
                    ReadIdentity(reader,out id,out character,out revision); End(reader);
                    if (!Owns(connection,id)) return; // entity replication can arrive later; sender retries until ACK
                    Accept(id,character,revision,connection);
                }
                else if (kind==Message.State || kind==Message.Snapshot)
                {
                    if (BoltNetwork.isServer || connection!=BoltNetwork.server) return;
                    int count=kind==Message.State ? 1:reader.ReadByte();
                    if (count>MaxPlayers || stream.Length-stream.Position!=count*13) throw new InvalidDataException("Roster length");
                    for (int i=0;i<count;i++)
                    { ReadIdentity(reader,out id,out character,out revision); SetIdentity(id,character,revision,null); }
                    End(reader);
                }
                else if (kind==Message.Voice)
                {
                    ReadIdentity(reader,out id,out character,out revision);
                    uint sequence=reader.ReadUInt32(); byte category=reader.ReadByte(),clip=reader.ReadByte(); float time=reader.ReadSingle(); End(reader);
                    if (category>2 || clip>=10 || (category==2 && clip>=(character==0 ? 2:4)) || float.IsNaN(time) || float.IsInfinity(time)) throw new InvalidDataException("Voice value");
                    float age=BoltNetwork.serverTime-time;
                    if (age>4f || age< -2f) return;
                    Actor actor;
                    if (!actors.TryGetValue(id,out actor) || actor.character!=character || actor.revision!=revision) return;
                    if (actor.hasVoiceSequence && !Newer(sequence,actor.voiceSequence)) return;
                    if (BoltNetwork.isServer ? !Owns(connection,id) : connection!=BoltNetwork.server) return;
                    actor.hasVoiceSequence=true; actor.voiceSequence=sequence;
                    if (actor.avatar!=null) actor.avatar.PlayVoice(Profile(character),category,clip);
                    if (BoltNetwork.isServer) RelayVoice(actor,sequence,category,clip,time,connection);
                }
                else if (kind==Message.Dodge || kind==Message.DodgeSnapshot)
                {
                    if (kind==Message.DodgeSnapshot && (BoltNetwork.isServer || connection!=BoltNetwork.server)) return;
                    int count=kind==Message.Dodge ? 1:reader.ReadByte();
                    if (count>MaxPlayers || stream.Length-stream.Position!=count*34) throw new InvalidDataException("Dodge length");
                    for (int i=0;i<count;i++)
                    {
                        ReadIdentity(reader,out id,out character,out revision);
                        var action=new DodgeAction { sequence=reader.ReadUInt32(),clip=reader.ReadByte(),serverStart=reader.ReadSingle(),
                            direction=new Vector3(reader.ReadSingle(),reader.ReadSingle(),reader.ReadSingle()) };
                        ReceiveDodge(connection,id,character,revision,action);
                    }
                    End(reader);
                }
                else if (kind==Message.DodgeDenied)
                {
                    id=reader.ReadUInt64(); uint sequence=reader.ReadUInt32(); End(reader);
                    if (!BoltNetwork.isServer && connection==BoltNetwork.server && id==localId) DodgeRuntime.Reject(sequence);
                }
                else if (kind==Message.TestSpawn)
                {
                    ReadIdentity(reader,out id,out character,out revision); End(reader);
                    // Diagnostic spawning is local-host only. Never honor a client request.

                }
                else if (kind==Message.InventoryRequest)
                {
                    id=reader.ReadUInt64();
                    if (BoltNetwork.isServer && Owns(connection,id)) Re3InventoryRuntime.ReceiveRequest(connection,id,reader);
                }
                else if (kind==Message.InventoryState)
                {
                    if (!BoltNetwork.isServer && connection==BoltNetwork.server) Re3InventoryRuntime.ReceiveState(reader);
                }
                else if(kind==Message.G19Request)
                {id=reader.ReadUInt64();if(BoltNetwork.isServer && Owns(connection,id))G19Runtime.ReceiveRequest(connection,id,reader);}
                else if(kind==Message.RocketState)
                {if(!BoltNetwork.isServer && connection==BoltNetwork.server)G19Runtime.ReceiveRocket(reader);}
                else if(kind==Message.G19State)
                {if(!BoltNetwork.isServer && connection==BoltNetwork.server)G19Runtime.ReceiveState(reader);}
                else if(kind==Message.OptionsState)
                {if(!BoltNetwork.isServer && connection==BoltNetwork.server)Re3CoopOptions.Receive(reader);}
                else throw new InvalidDataException("Unknown message");
            }
        }
        private static void End(BinaryReader reader)
        { if (reader.BaseStream.Position!=reader.BaseStream.Length) throw new InvalidDataException("Trailing data"); }
        internal static void InventoryRequest(Action<BinaryWriter> payload)
        {
            if(Instance==null || !CanStartDodge || !BoltNetwork.isClient) return;
            Instance.Send(BoltNetwork.server,Message.InventoryRequest,delegate(BinaryWriter writer) { writer.Write(Instance.localId); payload(writer); });
        }
        internal static void InventoryState(BoltConnection connection,Action<BinaryWriter> payload)
        {
            if(Instance!=null && BoltNetwork.isServer && registered && Instance.epoch!=0) Instance.Send(connection,Message.InventoryState,payload);
        }
        private static void WriteDodge(BinaryWriter writer,Actor actor,DodgeAction action)
        {
            WriteIdentity(writer,actor.id,actor.character,actor.revision);
            writer.Write(action.sequence); writer.Write(action.clip); writer.Write(action.serverStart);
            writer.Write(action.direction.x); writer.Write(action.direction.y); writer.Write(action.direction.z);
        }
        private void SendDodge(BoltConnection connection,Actor actor,DodgeAction action)
        { Send(connection,Message.Dodge,delegate(BinaryWriter writer) { WriteDodge(writer,actor,action); }); }
        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
        private void ReceiveDodge(BoltConnection connection,ulong id,byte character,uint revision,DodgeAction action)
        {
            if (BoltNetwork.isServer ? !Owns(connection,id):connection!=BoltNetwork.server) return;
            Actor actor;
            if (!actors.TryGetValue(id,out actor) || actor.character!=character || actor.revision!=revision) return;
            if (actor.hasDodgeSequence && !Newer(action.sequence,actor.dodgeSequence)) return;
            float age=BoltNetwork.serverTime-action.serverStart;
            bool valid=action.sequence!=0 && action.clip<4 && Finite(action.serverStart)
                && Finite(action.direction.x) && Finite(action.direction.y) && Finite(action.direction.z)
                && Mathf.Abs(action.direction.y)<.01f && Mathf.Abs(action.direction.sqrMagnitude-1f)<.02f
                && age>=-.25f && age<DodgeRuntime.ImmuneSeconds;
            if (BoltNetwork.isServer && actor.dodge!=null) valid=valid && action.serverStart-actor.dodge.serverStart>=DodgeRuntime.RecoverySeconds-.05f;
            if (!valid)
            {
                if (BoltNetwork.isServer) Send(connection,Message.DodgeDenied,delegate(BinaryWriter writer) { writer.Write(id); writer.Write(action.sequence); });
                return;
            }
            action.localStart=Time.time-Mathf.Max(0f,age);
            actor.hasDodgeSequence=true; actor.dodgeSequence=action.sequence; actor.dodgeAt=Time.realtimeSinceStartup; actor.dodge=action;
            if (id!=localId) DodgeRuntime.SetRemote(id,action);
            if (BoltNetwork.isServer) foreach (var pair in peers) if (pair.Value.ready) SendDodge(pair.Key,actor,action);
        }
        internal static void DodgeStarted(DodgeAction action)
        {
            if (Instance==null || !registered || !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer) return;
            try
            {
                Instance.ObserveLocal(); Actor actor;
                if (Instance.epoch==0 || !Instance.actors.TryGetValue(Instance.localId,out actor) || actor.revision!=Instance.localRevision) return;
                if (BoltNetwork.isServer)
                {
                    actor.dodge=action; actor.hasDodgeSequence=true; actor.dodgeSequence=action.sequence; actor.dodgeAt=Time.realtimeSinceStartup;
                    foreach (var pair in Instance.peers) if (pair.Value.ready) Instance.SendDodge(pair.Key,actor,action);
                }
                else Instance.SendDodge(BoltNetwork.server,actor,action);
            }
            catch (Exception error) { Instance.Warn("Esquiva coop",error); }
        }
        internal static void RequestCannibal()
        {
            if(Re3DeveloperTools.Enabled && LocalPlayer.Transform!=null)DodgeDiagnostics.SpawnCannibal(LocalPlayer.Transform);
        }
        internal static void VoiceStarted(CharacterProfile profile,bool hurt,int clip)
        { VoiceStarted(profile,(byte)(hurt ? 1:0),clip); }
        internal static void VoiceStarted(CharacterProfile profile,byte category,int clip)
        {
            if (Instance==null || !registered || !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer) return;
            try { Instance.SendLocalVoice(profile,category,clip); }
            catch (Exception error) { Instance.Warn("Voz coop",error); }
        }
        private void SendLocalVoice(CharacterProfile profile,byte category,int clip)
        {
            ObserveLocal(); // commits a change before the first voice of that character
            Actor actor;
            if (epoch==0 || localId==0 || !actors.TryGetValue(localId,out actor) || actor.revision!=localRevision
                || actor.character!=CharacterId(profile) || clip<0 || clip>=10) return;
            voiceSequence++;
            float time=BoltNetwork.serverTime;
            if (BoltNetwork.isServer) RelayVoice(actor,voiceSequence,category,(byte)clip,time,null);
            else SendVoice(BoltNetwork.server,actor,voiceSequence,category,(byte)clip,time);
        }
        private void SendVoice(BoltConnection connection,Actor actor,uint sequence,byte category,byte clip,float time)
        {
            Send(connection,Message.Voice,delegate(BinaryWriter writer)
            { WriteIdentity(writer,actor.id,actor.character,actor.revision); writer.Write(sequence); writer.Write(category); writer.Write(clip); writer.Write(time); });
        }
        private void RelayVoice(Actor actor,uint sequence,byte category,byte clip,float time,BoltConnection exclude)
        { foreach (var pair in peers) if (pair.Value.ready && pair.Key!=exclude) SendVoice(pair.Key,actor,sequence,category,clip,time); }

        private void UpdateAvatars()
        {
            remove.Clear();
            foreach (var pair in players) if (pair.Value==null || !pair.Value.isAttached) remove.Add(pair.Key);
            foreach (ulong id in remove) { players.Remove(id); RemoveActor(id); }
            if (CharacterProfile.Jill.Prefab==null || CharacterProfile.Carlos.Prefab==null) return;
            int built=0;
            foreach (Actor actor in actors.Values)
            {
                BoltEntity entity;
                if (!players.TryGetValue(actor.id,out entity))
                {
                    entity=BoltNetwork.FindEntity(new Bolt.NetworkId(actor.id)); Track(entity);
                    if (entity==null || !entity.isAttached || !entity.StateIs<IPlayerState>()) continue;
                }
                if (entity==LocalPlayer.Entity || entity.hasControl) continue;
                if (actor.avatar==null)
                {
                    if (built>=1) continue; // stagger geometry/rig initialization across ticks
                    GameObject holder=new GameObject("ForestRE3_Remote_"+actor.id);
                    actor.avatar=holder.AddComponent<CoopRemoteAvatar>(); actor.avatar.Initialize(entity); built++;
                }
                actor.avatar.SetCharacter(Profile(actor.character));
            }
        }
        internal bool MuteRemoteVocal(Vector3 position)
        {
            foreach (Actor actor in actors.Values)
                if (actor.avatar!=null && actor.avatar.MatchesVocalPosition(position)) return true;
            return false;
        }
        internal bool MuteRemoteSfx(global::PlayerSfx sfx)
        {
            if (sfx==null) return false;
            foreach (Actor actor in actors.Values) if (actor.avatar!=null && actor.avatar.Owns(sfx)) return true;
            return false;
        }
        private void OnGUI()
        {
            if ((!Re3DeveloperTools.Enabled && problem.Length==0) || !registered || !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer || LocalPlayer.FpCharacter==null) return;
            int compatible=0,visible=0;
            foreach (Peer peer in peers.Values) if (peer.ready) compatible++;
            foreach (Actor actor in actors.Values) if (actor.avatar!=null && actor.avatar.Visible) visible++;
            string state=peers.Count==0 ? "esperando companero" : (epoch==0 || compatible<peers.Count ? "esperando al mod del companero":"sincronizado");
            string text=problem.Length>0 ? problem : (BoltNetwork.isServer ? "Host":"Cliente")+" | mod conectado "+compatible+"/"+peers.Count
                +" | personajes remotos "+visible+" | "+state;
            GUI.Label(new Rect(12,108,1250,24),"Coop 0.8.9 | "+text);
        }
    }

    // All injected methods have one terminal return, as required by ModAPI.
    public class CoopPlayerCallbacksPatch : global::CoopPlayerCallbacks
    {
        public override void BoltStartBegin()
        {
            base.BoltStartBegin();
            CoopSync.RegisterChannels();
        }
        public override void StreamDataReceived(BoltConnection connection,UdpKit.UdpStreamData data)
        {
            if (CoopSync.IsNativeVoice(data)) base.StreamDataReceived(connection,data);
            else CoopSync.Receive(connection,data);
            GC.KeepAlive(connection);
        }
    }
}
