﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace ForestRE3JillVisualProbe
{
    internal static class JillFirstPersonView
    {
        internal static Shader Surface;
        internal static void Configure(List<Renderer> renderers, List<Material> owned)
        {
            if (Surface==null || !Surface.isSupported) throw new InvalidOperationException("Missing first-person lit surface.");
            var bodyCopies=new Dictionary<Material,Material>();
            var armCopies=new Dictionary<Material,Material>();
            var closureCopies=new Dictionary<Material,Material>();
            foreach (Renderer renderer in renderers)
            {
                bool arms=renderer.name.Contains("_JillFPArms");
                bool closure=renderer.name.Contains("_JillFPNeckClosure");
                var copies=closure ? closureCopies:arms ? armCopies:bodyCopies;
                Material[] slots=renderer.sharedMaterials;
                for (int i=0;i<slots.Length;i++)
                {
                    Material copy;
                    if (!copies.TryGetValue(slots[i],out copy))
                    {
                        copy=new Material(slots[i]); copy.shader=Surface;
                        copy.name=slots[i].name+"_JillFP0762";
                        copy.SetFloat("_FPCutout",slots[i].HasProperty("_Mode") && slots[i].GetFloat("_Mode")==1f ? 1f:0f);
                        copy.SetFloat("_FPClipRadius",0f);
                        copy.SetFloat("_FPClipScale",closure ? 0f:arms ? .3f:1f);
                        if (closure) copy.DisableKeyword("_NORMALMAP");
                        copies.Add(slots[i],copy); owned.Add(copy);
                    }
                    slots[i]=copy;
                }
                renderer.sharedMaterials=slots;
            }
        }
        internal static void BeforeCamera(Camera camera, List<Material> owned, float height)
        {
            bool own=JillPlayerAvatar.IsOwnCamera(camera);
            foreach (Material material in owned) if (material!=null && material.shader==Surface)
            {
                material.SetVector("_FPEye",camera.transform.position);
                material.SetFloat("_FPClipRadius",own ? Mathf.Max(.05f,height*.12f):0f);
            }
        }
    }
}
