﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using ModAPI.Configurations;
using ModAPI.Data;
using ModAPI.Data.Models;

internal static class PackageJillBundleProbe
{
    private static string appRoot;

    private static void InstallResolver()
    {
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs args)
        {
            var name = new AssemblyName(args.Name).Name + ".dll";
            var candidates = new[]
            {
                Path.Combine(appRoot, name),
                Path.Combine(appRoot, "libs", name),
                Path.Combine(appRoot, "libs", "polyfills", name)
            };
            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate)) return Assembly.LoadFrom(candidate);
            }
            return null;
        };
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    public static int Main()
    {
        try
        {
            appRoot = Path.GetFullPath(Directory.GetCurrentDirectory());
            InstallResolver();
            Require(Configuration.Load() == Configuration.ResultCode.Ok, "ModAPI no pudo cargar su configuración local.");

            var gamePath = @"C:\Program Files (x86)\Steam\steamapps\common\The Forest";
            Configuration.SetPath("OriginalGameFiles", Path.Combine(appRoot, "gamefiles", "original"), true);
            Configuration.SetPath("ModdedGameFiles", Path.Combine(appRoot, "gamefiles", "modded"), true);
            Configuration.SetPath("SavegameBackups", Path.Combine(appRoot, "gamefiles", "savegames"), true);
            Configuration.SetPath("Projects", Path.Combine(appRoot, "projects"), true);
            Configuration.SetPath("Mods", Path.Combine(appRoot, "mods"), true);
            Configuration.SetPath("ModLib", Path.Combine(appRoot, "modlib"), true);
            Configuration.SetPath("Libraries", Path.Combine(appRoot, "libs"), true);

            var game = new Game(Configuration.Games["TheForest"], true);
            game.GamePath = gamePath;
            var versionsPath = Path.Combine(appRoot, "configs", "games", "TheForest", "Versions.xml");
            var versionElement = XDocument.Load(versionsPath).Root.Elements("version")
                .FirstOrDefault(e => (string)e.Attribute("id") == "1.11b");
            Require(versionElement != null, "No se encontró el registro local 1.11b.");
            var version = new Game.Versions.Version(versionElement);
            game.GameVersion = version;
            game.BackupVersion = version;
            game.ModLibrary = new ModLib(game);
            Require(game.ModLibrary.Exists && game.ModLibrary.GameVersion == "1.11b", "La biblioteca ModAPI no coincide con 1.11b.");

            const string projectId = "ForestRE3JillBundleProbe";
            var projectRoot = Path.Combine(Configuration.GetPath("Projects"), "TheForest", projectId);
            var modOutput = Path.Combine(Configuration.GetPath("Mods"), "TheForest");
            var project = new ModProject(game, projectId);
            project.Name.SetString("EN", "Forest RE3 Jill Bundle Probe");
            project.Description.SetString("EN", "Local-only runtime probe for loading a user-generated Jill AssetBundle.");
            project.Version = "0.1.0.0";
            project.SaveConfiguration();
            Require(!project.SaveFailed, "ModAPI no pudo escribir la configuración del proyecto.");

            var modFolder = Path.Combine(projectRoot, "Mod");
            Directory.CreateDirectory(modFolder);
            var compiledDll = Path.Combine(appRoot, "build", "ForestRE3JillBundleProbe.dll");
            Require(File.Exists(compiledDll), "No se encontró la DLL del sondeo compilada.");
            File.Copy(compiledDll, Path.Combine(modFolder, projectId + ".dll"), true);

            project.Create(null);
            var package = Directory.GetFiles(modOutput, "*.mod", SearchOption.TopDirectoryOnly)
                .Select(path => new FileInfo(path))
                .OrderByDescending(file => file.LastWriteTimeUtc)
                .FirstOrDefault(file => file.Name.StartsWith(projectId + "-", StringComparison.OrdinalIgnoreCase));
            Require(package != null && package.Exists, "ModAPI no generó el paquete .mod esperado.");

            var packagedMod = new Mod { Game = game, FileName = package.FullName };
            Require(packagedMod.Load() && packagedMod.Valid, "ModAPI no pudo volver a abrir el paquete .mod generado.");
            var bundleResourceFound = packagedMod.Module.Resources
                .Any(resource => resource.Name == "ForestRE3JillBundleProbe.forest-re3-jill");
            Require(bundleResourceFound, "El .mod no conserva el AssetBundle embebido dentro del ensamblado.");

            Console.WriteLine("PACKAGE=" + package.FullName);
            Console.WriteLine("SIZE=" + package.Length);
            Console.WriteLine("EMBEDDED_BUNDLE_RESOURCE=ForestRE3JillBundleProbe.forest-re3-jill");
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine(exception);
            return 1;
        }
    }
}
