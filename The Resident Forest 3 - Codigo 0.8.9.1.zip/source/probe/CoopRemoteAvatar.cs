﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using LocalPlayer=TheForest.Utils.LocalPlayer;

namespace ForestRE3JillVisualProbe
{
    // Cosmetic companion of an existing Bolt player. Never instantiate another
    // player controller, collider, Rigidbody, inventory or network entity.
    [DefaultExecutionOrder(11000)]
    public sealed class CoopRemoteAvatar : MonoBehaviour
    {
        private BoltEntity entity;
        private Animator source;
        private AnimatorCullingMode originalCulling;
        private bool cullingChanged, disposed;
        private CharacterProfile character;
        private GameObject body;
        private JillMotionPreview pose;
        private readonly Dictionary<Renderer,bool> native=new Dictionary<Renderer,bool>();
        private readonly Dictionary<Renderer,bool> dodgeEquipment=new Dictionary<Renderer,bool>();
        private readonly HashSet<Renderer> equipmentTargets=new HashSet<Renderer>();
        private readonly Dictionary<coopAnimatorVis,SkinnedMeshRenderer> visibilitySkins=new Dictionary<coopAnimatorVis,SkinnedMeshRenderer>();
        private readonly List<Material> materials=new List<Material>();
        private AudioSource voice;
        private double voiceUntil;
        private float retryAt, scanAt, loopAt;
        private int failures;
        private readonly Dictionary<FMOD.Studio.EventInstance,float> vocalLoops=new Dictionary<FMOD.Studio.EventInstance,float>();
        internal bool Visible { get { return !disposed && body!=null && pose!=null && pose.PoseAvailable; } }

        internal void Initialize(BoltEntity player)
        {
            entity=player;
            voice=gameObject.AddComponent<AudioSource>();
            voice.playOnAwake=false; voice.loop=false; voice.spatialBlend=1f;
            voice.rolloffMode=AudioRolloffMode.Logarithmic; voice.minDistance=5f; voice.maxDistance=90f;
            voice.volume=1f; voice.dopplerLevel=0f; voice.ignoreListenerPause=true;
        }
        internal void SetCharacter(CharacterProfile profile)
        {
            if (disposed) return;
            if (character!=profile)
            {
                RemoveBody(); character=profile; failures=0; retryAt=0;
            }
            if (Visible || failures>=3 || Time.realtimeSinceStartup<retryAt) return;
            retryAt=Time.realtimeSinceStartup+2f;
            source=FindAnimator();
            if (source==null || !source.isInitialized || profile.Prefab==null) return;
            try { CreateBody(); }
            catch (Exception error)
            {
                failures++; RemoveBody();
                ModAPI.Log.Write("[ForestRE3] COOP_AVATAR_FALLBACK entity="+entity.networkId.PackedValue
                    +"; attempt="+failures+"/3; nativeRestored=true; "+error);
            }
        }
        private Animator FindAnimator()
        {
            if (entity==null || !entity.isAttached) return null;
            foreach (CoopMecanimReplicator replica in entity.GetComponentsInChildren<CoopMecanimReplicator>(true))
                if (replica.TargetAnimator!=null) return replica.TargetAnimator;
            foreach (Animator candidate in entity.GetComponentsInChildren<Animator>(true))
                foreach (Transform bone in candidate.GetComponentsInChildren<Transform>(true))
                    if (bone.name=="char_Hips") return candidate;
            return null;
        }
        private void CreateBody()
        {
            body=UnityEngine.Object.Instantiate(character.Prefab);
            body.name="ForestRE3_RemoteBody_"+character.Name;
            body.transform.position=Vector3.zero; body.transform.rotation=Quaternion.identity; body.transform.localScale=Vector3.one;
            JillPlayerAvatar.MakeVisualOnly(body);
            AvatarGeometry.AdjustEyes(body,materials);
            foreach (SkinnedMeshRenderer skin in body.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                skin.updateWhenOffscreen=true; skin.receiveShadows=true;
                skin.shadowCastingMode=ShadowCastingMode.On;
            }
            pose=body.AddComponent<JillMotionPreview>(); pose.AttachToRemote(entity,source); pose.Initialize(character);
            if (!pose.PoseAvailable || pose.NativeToJillRatio<.001f) throw new InvalidOperationException("Remote rig mapping incomplete");
            originalCulling=source.cullingMode; cullingChanged=true; source.cullingMode=AnimatorCullingMode.AlwaysAnimate;
            Place(); pose.StepPlayerPose();
            if (!pose.PoseAvailable) throw new InvalidOperationException("Remote evaluated pose failed");
            ScanNative(); HideNative();
            SkinnedMeshRenderer proxy=null;
            foreach (SkinnedMeshRenderer skin in body.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                if (skin.enabled && skin.sharedMesh!=null) { proxy=skin; break; }
            if (proxy!=null)
                foreach (coopAnimatorVis visibility in entity.GetComponentsInChildren<coopAnimatorVis>(true))
                {
                    visibilitySkins[visibility]=visibility.skinRenderer;
                    // The old hidden skin must not tell the game its visible
                    // replacement is offscreen and freeze the source Animator.
                    visibility.skinRenderer=proxy;
                }
            ModAPI.Log.Write("[ForestRE3] COOP_AVATAR_READY entity="+entity.networkId.PackedValue+"; character="+character.Name
                +"; source="+source.name+"; nativeSkins="+native.Count+"; fullHead=true; nativePhysicsUntouched=true");
        }
        private void Place()
        {
            body.SetActive(source.gameObject.activeInHierarchy);
            Vector3 forward=Vector3.ProjectOnPlane(source.transform.forward,Vector3.up);
            body.transform.position=source.transform.position;
            body.transform.rotation=forward.sqrMagnitude>.00001f ? Quaternion.LookRotation(forward,Vector3.up) : Quaternion.identity;
            DodgeAction dodge=DodgeRuntime.Pose(entity);
            if (dodge!=null) body.transform.rotation=DodgeRuntime.Heading(dodge);
            body.transform.localScale=Vector3.one*(Mathf.Abs(source.transform.lossyScale.y)/pose.NativeToJillRatio*character.HeightRatio);
            transform.position=source.transform.position+Vector3.up*3f;
        }
        private void ScanNative()
        {
            foreach (CoopPlayerVariations variation in entity.GetComponentsInChildren<CoopPlayerVariations>(true))
                foreach (Renderer renderer in new Renderer[] { variation.Hat,variation.Top,variation.Pants,variation.FullBody })
                    SaveNative(renderer);
            foreach (Renderer renderer in entity.GetComponentsInChildren<Renderer>(true))
                if (JillPlayerAvatar.IsNativeSkinRenderer(renderer)) SaveNative(renderer);
        }
        private void SaveNative(Renderer renderer)
        { if (renderer!=null && !native.ContainsKey(renderer)) native.Add(renderer,renderer.enabled); }
        private void HideNative()
        { foreach (Renderer renderer in native.Keys) if (renderer!=null) renderer.enabled=false; }
        private void LateUpdate()
        {
            if (disposed || !Visible) return;
            if (entity==null || !entity.isAttached || source==null) { Dispose(); return; }
            try
            {
                if (Time.realtimeSinceStartup>=scanAt) { scanAt=Time.realtimeSinceStartup+1f; ScanNative(); }
                Place(); pose.StepPlayerPose();
                if (!pose.PoseAvailable) throw new InvalidOperationException("Remote pose stopped");
                HideNative();
                bool dodging=DodgeRuntime.Pose(entity)!=null;
                bool armed=G19Runtime.Pose(entity)!=null && !G19Runtime.NativeOwnsHands(entity,source);
                if(dodging || armed)
                {
                    equipmentTargets.Clear();
                    if(dodging)CollectEquipment(source.transform);
                    else
                    {
                        // RE weapons replace only the native hand items.
                        // Logs, carried bodies and interaction tools keep
                        // their native renderer state and replicated pose.
                        foreach(CoopPlayerRemoteSetup setup in entity.GetComponentsInChildren<CoopPlayerRemoteSetup>(true))
                        {
                            if(setup.rightHand!=null)CollectEquipment(setup.rightHand.ActiveItem);
                            if(setup.leftHand!=null)CollectEquipment(setup.leftHand.ActiveItem);
                        }
                    }
                    var released=new List<Renderer>();
                    foreach(var saved in dodgeEquipment)
                        if(saved.Key==null || !equipmentTargets.Contains(saved.Key))
                        {if(saved.Key!=null)saved.Key.enabled=saved.Value;released.Add(saved.Key);}
                    foreach(var renderer in released)dodgeEquipment.Remove(renderer);
                    foreach(Renderer renderer in dodgeEquipment.Keys)if(renderer!=null)renderer.enabled=false;
                }
                else RestoreDodgeEquipment();
                if (Time.realtimeSinceStartup>=loopAt) { loopAt=Time.realtimeSinceStartup+.5f; MuteVocalLoops(); }
            }
            catch (Exception error)
            {
                failures++; RemoveBody(); retryAt=Time.realtimeSinceStartup+2f;
                ModAPI.Log.Write("[ForestRE3] COOP_POSE_FALLBACK entity="+entity.networkId.PackedValue+"; "+error);
            }
        }
        internal void PlayVoice(CharacterProfile profile,byte category,int index)
        {
            // Busy events are discarded: no cutting, overlap or replay queue.
            if (!Visible || voice==null || voice.isPlaying || AudioSettings.dspTime<voiceUntil) return;
            AudioClip clip=JillVoice.SharedClip(profile,category,index);
            if (clip==null) return;
            voice.clip=clip; voiceUntil=AudioSettings.dspTime+clip.length+.025; voice.Play();
        }
        internal bool Owns(global::PlayerSfx sfx)
        { return Visible && sfx!=null && sfx!=LocalPlayer.Sfx && (sfx.transform==entity.transform || sfx.transform.IsChildOf(entity.transform)); }
        internal bool MatchesVocalPosition(Vector3 position)
        {
            if (!Visible || source==null) return false;
            Vector3 center=source.transform.position+Vector3.up*2.4f;
            float distance=(position-center).sqrMagnitude;
            if (distance>49f) return false;
            if (LocalPlayer.FpCharacter!=null)
            {
                var capsule=LocalPlayer.FpCharacter.capsule;
                Vector3 local=capsule!=null ? capsule.bounds.center : LocalPlayer.FpCharacter.transform.position;
                if ((position-local).sqrMagnitude<=distance) return false;
            }
            return true;
        }
        private void MuteVocalLoops()
        {
            const System.Reflection.BindingFlags flags=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.NonPublic;
            var breath=typeof(global::PlayerSfx).GetField("staminaBreathInstance",flags);
            if (breath!=null)
                foreach (global::PlayerSfx sfx in entity.GetComponentsInChildren<global::PlayerSfx>(true))
                    MuteLoop(breath.GetValue(sfx) as FMOD.Studio.EventInstance);
            var burning=typeof(global::CoopPlayerFX).GetField("BurningEventInstance",flags);
            if (burning!=null)
                foreach (global::CoopPlayerFX fx in entity.GetComponentsInChildren<global::CoopPlayerFX>(true))
                    MuteLoop(burning.GetValue(fx) as FMOD.Studio.EventInstance);
        }
        private void MuteLoop(FMOD.Studio.EventInstance instance)
        {
            if (instance==null || !instance.isValid()) return;
            if (!vocalLoops.ContainsKey(instance))
            {
                float volume;
                if (instance.getVolume(out volume)!=FMOD.RESULT.OK) return;
                vocalLoops.Add(instance,volume);
            }
            instance.setVolume(0f);
        }
        private void CollectEquipment(Transform root)
        {
            if(root==null)return;
            foreach(Renderer renderer in root.GetComponentsInChildren<Renderer>(true))
            {
                if(native.ContainsKey(renderer) || JillPlayerAvatar.IsNativeSkinRenderer(renderer)
                    || renderer.GetComponentInParent<JillMotionPreview>()!=null)continue;
                equipmentTargets.Add(renderer);
                if(renderer.enabled && renderer.gameObject.activeInHierarchy && !dodgeEquipment.ContainsKey(renderer))dodgeEquipment[renderer]=true;
            }
        }
        private void RestoreDodgeEquipment()
        { foreach (var saved in dodgeEquipment) if (saved.Key!=null) saved.Key.enabled=saved.Value; dodgeEquipment.Clear(); }
        private void RemoveBody()
        {
            RestoreDodgeEquipment();
            foreach (var saved in native) if (saved.Key!=null) saved.Key.enabled=saved.Value;
            native.Clear();
            foreach (var saved in visibilitySkins) if (saved.Key!=null) saved.Key.skinRenderer=saved.Value;
            visibilitySkins.Clear();
            if (cullingChanged && source!=null) source.cullingMode=originalCulling;
            cullingChanged=false;
            if (body!=null) { body.SetActive(false); UnityEngine.Object.Destroy(body); }
            body=null; pose=null;
            foreach (Material material in materials) if (material!=null) UnityEngine.Object.Destroy(material);
            materials.Clear();
            foreach (var saved in vocalLoops) if (saved.Key!=null && saved.Key.isValid()) saved.Key.setVolume(saved.Value);
            vocalLoops.Clear();
        }
        internal void Dispose()
        {
            if (disposed) return;
            disposed=true; RemoveBody();
            if (voice!=null) voice.Stop();
            gameObject.SetActive(false); UnityEngine.Object.Destroy(gameObject);
        }
        private void OnDestroy() { RemoveBody(); }
    }
}
