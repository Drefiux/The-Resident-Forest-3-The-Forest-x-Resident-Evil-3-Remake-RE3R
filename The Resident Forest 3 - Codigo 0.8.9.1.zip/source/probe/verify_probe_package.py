﻿#!/usr/bin/env python3
"""Statically inspect the local diagnostic .mod package without launching the game."""

import base64
import gzip
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import dnfile


def value(obj):
    return getattr(obj, "value", obj)


def main() -> int:
    package = Path(sys.argv[1])
    report_path = Path(sys.argv[2]) if len(sys.argv) > 2 else package.with_suffix(".verification.json")
    raw = gzip.decompress(package.read_bytes())
    marker = raw.find(b"</Mod>")
    if marker < 0:
        raise ValueError("No se encontró el cierre del encabezado Mod.")
    end = marker + len(b"</Mod>")
    header = ET.fromstring(raw[:end])
    encoded = raw[end:].strip()
    dll_bytes = base64.b64decode(encoded, validate=True)
    dll_path = package.with_suffix(".extracted.dll")
    dll_path.write_bytes(dll_bytes)
    pe = dnfile.dnPE(str(dll_path))

    assembly_type = next((t for t in pe.net.mdtables.TypeDef if str(value(t.TypeName)) == "EntryPoints"), None)
    if assembly_type is None:
        raise ValueError("Falta ForestRe3LoaderProbe.EntryPoints en el ensamblado.")
    methods = {str(value(m.row.Name)): m.row for m in assembly_type.MethodList}
    expected = {
        "OnApplicationStart": "ExecuteOnApplicationStart",
        "OnGameStart": "ExecuteOnGameStart",
    }
    attribute_map = {}
    for method_name in expected:
        method = methods.get(method_name)
        if method is None:
            raise ValueError(f"Falta el método {method_name}.")
        attrs = []
        for custom_attribute in pe.net.mdtables.CustomAttribute:
            if getattr(custom_attribute.Parent, "row", None) is method:
                attr_type = custom_attribute.Type.row.Class.row
                attrs.append(str(value(attr_type.TypeName)))
        attribute_map[method_name] = attrs
        if expected[method_name] not in attrs:
            raise ValueError(f"El atributo esperado {expected[method_name]} no está en {method_name}.")

    runtime_version = pe.net.metadata.struct.Version.rstrip(b"\x00").decode("ascii")
    if runtime_version != "v2.0.50727":
        raise ValueError(f"El CLR metadata version no se remapeó a Mono 2.0: {runtime_version}")

    log_calls = []
    for member in pe.net.mdtables.MemberRef:
        if str(value(member.Name)) == "Write":
            owner = member.Class.row
            signature = bytes(member.Signature.value)
            if str(value(getattr(owner, "TypeName", ""))) == "Log" and getattr(owner, "TypeNamespace", None) == "ModAPI":
                log_calls.append({"owner": "ModAPI.Log", "signatureHex": signature.hex(), "parameterCount": signature[1] if len(signature) > 1 else None})
    if not any(call["parameterCount"] == 2 for call in log_calls):
        raise ValueError("No se encontró la sobrecarga Log.Write remapeada con el identificador del mod.")

    result = {
        "result": "STATIC_PACKAGE_CHECK_PASSED",
        "gameCompatibility": header.findtext("Compatible"),
        "modId": header.attrib.get("ID"),
        "modVersion": header.findtext("Version"),
        "packageBytes": package.stat().st_size,
        "embeddedAssemblyBytes": len(dll_bytes),
        "monoMetadataVersion": runtime_version,
        "entryPointAttributes": attribute_map,
        "remappedLogCalls": log_calls,
        "gameLaunched": False,
    }
    report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
