﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace ForestRE3JillVisualProbe
{
    // Construct once from the actual open neck boundary. Jill owns that rim
    // in body Skin_Mat; Carlos owns it in head Face_Mat, not his arm/hand skin.
    // Only the closing fan is copied: no head/face geometry, collider or rig.
    internal static class JillNeckClosure
    {
        internal static Mesh Create(SkinnedMeshRenderer skin, Transform model)
        {
            bool jillBodyNeck=skin.name.Contains("__Skin_Mat");
            bool carlosHeadNeck=skin.name.EndsWith("__pl0001_Face_Mat",StringComparison.OrdinalIgnoreCase);
            if (!jillBodyNeck && !carlosHeadNeck) return null;
            Transform neck=null, head=null;
            foreach (Transform bone in skin.bones)
            { if (bone.name=="neck_0") neck=bone; if (bone.name=="head") head=bone; }
            if (head==null || neck==null) foreach (Transform bone in model.GetComponentsInChildren<Transform>(true))
            { if (bone.name=="neck_0") neck=bone; if (bone.name=="head") head=bone; }
            if (head==null || neck==null) return null;
            Mesh source=skin.sharedMesh;
            Vector3[] points=source.vertices; Vector2[] uv=source.uv; BoneWeight[] weights=source.boneWeights;
            var welded=new Dictionary<string,int>(); var ids=new int[points.Length];
            for (int i=0;i<points.Length;i++)
            {
                Vector3 p=points[i];
                string key=Mathf.RoundToInt(p.x*100000f)+","+Mathf.RoundToInt(p.y*100000f)+","+Mathf.RoundToInt(p.z*100000f);
                int id; if (!welded.TryGetValue(key,out id)) { id=i; welded.Add(key,id); } ids[i]=id;
            }
            var edgeCounts=new Dictionary<long,int>(); int[] tris=source.triangles;
            for (int i=0;i<tris.Length;i+=3) for (int j=0;j<3;j++)
            {
                int a=ids[tris[i+j]], b=ids[tris[i+(j+1)%3]]; if (a==b) continue;
                long key=((long)Math.Min(a,b)<<32)|(uint)Math.Max(a,b);
                int count; edgeCounts.TryGetValue(key,out count); edgeCounts[key]=count+1;
            }
            var neighbours=new Dictionary<int,List<int>>();
            foreach (var edge in edgeCounts) if (edge.Value==1)
            {
                int a=(int)(edge.Key>>32), b=(int)edge.Key;
                Add(neighbours,a,b); Add(neighbours,b,a);
            }
            Vector3 neckPoint=model.InverseTransformPoint(neck.position), headPoint=model.InverseTransformPoint(head.position);
            float height=Mathf.Max(.1f,headPoint.y);
            var visited=new HashSet<int>(); List<int> rim=null;
            foreach (int start in neighbours.Keys)
            {
                if (visited.Contains(start)) continue;
                var component=new List<int>(); var pending=new Queue<int>(); pending.Enqueue(start); visited.Add(start);
                bool closed=true; float low=float.PositiveInfinity, high=float.NegativeInfinity; Vector3 center=Vector3.zero;
                while (pending.Count>0)
                {
                    int index=pending.Dequeue(); component.Add(index);
                    Vector3 p=model.InverseTransformPoint(skin.transform.TransformPoint(points[index]));
                    center+=p; low=Mathf.Min(low,p.y); high=Mathf.Max(high,p.y);
                    closed &= neighbours[index].Count==2;
                    foreach (int next in neighbours[index]) if (visited.Add(next)) pending.Enqueue(next);
                }
                center/=component.Count;
                if (closed && component.Count>=12 && low>neckPoint.y-height*.02f && high<headPoint.y
                    && Vector3.ProjectOnPlane(center-neckPoint,Vector3.up).magnitude<height*.08f)
                { rim=component; break; }
            }
            if (rim==null) throw new InvalidOperationException("Neck boundary was not found on "+skin.name+".");
            var order=new List<int>(); int at=rim[0], previous=-1;
            do
            {
                order.Add(at); List<int> next=neighbours[at];
                int step=next[0]==previous ? next[1]:next[0]; previous=at; at=step;
            } while (at!=order[0] && order.Count<=rim.Count);
            if (order.Count!=rim.Count || at!=order[0]) throw new InvalidOperationException("Invalid neck rim cycle.");
            var vertices=new Vector3[order.Count+1]; var texcoords=new Vector2[vertices.Length];
            var skinWeights=new BoneWeight[vertices.Length]; var accumulated=new Dictionary<int,float>();
            for (int i=0;i<order.Count;i++)
            {
                int index=order[i]; vertices[i+1]=points[index]; vertices[0]+=points[index]/order.Count;
                texcoords[i+1]=uv[index]; texcoords[0]+=uv[index]/order.Count; skinWeights[i+1]=weights[index];
                BoneWeight w=weights[index]; Accumulate(accumulated,w.boneIndex0,w.weight0); Accumulate(accumulated,w.boneIndex1,w.weight1);
                Accumulate(accumulated,w.boneIndex2,w.weight2); Accumulate(accumulated,w.boneIndex3,w.weight3);
            }
            var ranked=new List<KeyValuePair<int,float>>(accumulated); ranked.Sort(delegate(KeyValuePair<int,float> a,KeyValuePair<int,float> b) { return b.Value.CompareTo(a.Value); });
            float total=0f; for (int i=0;i<Math.Min(4,ranked.Count);i++) total+=ranked[i].Value;
            BoneWeight centerWeight=new BoneWeight();
            if (ranked.Count>0) { centerWeight.boneIndex0=ranked[0].Key; centerWeight.weight0=ranked[0].Value/total; }
            if (ranked.Count>1) { centerWeight.boneIndex1=ranked[1].Key; centerWeight.weight1=ranked[1].Value/total; }
            if (ranked.Count>2) { centerWeight.boneIndex2=ranked[2].Key; centerWeight.weight2=ranked[2].Value/total; }
            if (ranked.Count>3) { centerWeight.boneIndex3=ranked[3].Key; centerWeight.weight3=ranked[3].Value/total; }
            skinWeights[0]=centerWeight;
            var cap=new int[order.Count*6];
            for (int i=0;i<order.Count;i++)
            {
                int a=i+1,b=(i+1)%order.Count+1;
                // Both sides close the skin during seated and prone openings.
                cap[i*6]=0; cap[i*6+1]=a; cap[i*6+2]=b;
                cap[i*6+3]=0; cap[i*6+4]=b; cap[i*6+5]=a;
            }
            var mesh=new Mesh(); mesh.name=source.name+"_JillFPNeckClosure";
            mesh.vertices=vertices; mesh.uv=texcoords; mesh.boneWeights=skinWeights; mesh.bindposes=source.bindposes;
            mesh.triangles=cap;
            var normals=new Vector3[vertices.Length]; var tangents=new Vector4[vertices.Length];
            Vector3 up=skin.transform.InverseTransformDirection(model.up), right=skin.transform.InverseTransformDirection(model.right);
            for (int i=0;i<vertices.Length;i++) { normals[i]=up; tangents[i]=new Vector4(right.x,right.y,right.z,1f); }
            mesh.normals=normals; mesh.tangents=tangents; mesh.RecalculateBounds();
            ModAPI.Log.Write("[ForestRE3] JILL_NECK_CLOSED rimVertices="+order.Count+"; sharedSkeleton=true; source="+skin.name+"; character="+(carlosHeadNeck ? "Carlos":"Jill"));
            return mesh;
        }
        private static void Add(Dictionary<int,List<int>> neighbours,int a,int b)
        { List<int> list; if (!neighbours.TryGetValue(a,out list)) { list=new List<int>(); neighbours.Add(a,list); } list.Add(b); }
        private static void Accumulate(Dictionary<int,float> weights,int bone,float weight)
        { if (weight<=0f) return; float before; weights.TryGetValue(bone,out before); weights[bone]=before+weight; }
    }
}
