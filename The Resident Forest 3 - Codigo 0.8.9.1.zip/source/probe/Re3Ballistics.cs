﻿using System;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TheForest.Utils;
using TheForest.World;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class G19Runtime
    {
        private sealed class Impact
        {
            internal Component target;internal MethodInfo method;internal RaycastHit hit;
            internal EnemyHealth health;internal mutantScriptSetup setup;internal mutantAI ai;internal BoltEntity player;
            internal bool head,mutant,suitcase;internal int pellets,heads,damage;
        }
        private static readonly FieldInfo hitHealth=typeof(mutantHitReceiver).GetField("health",BindingFlags.Instance|BindingFlags.NonPublic);
        private static readonly FieldInfo animalHitHealth=typeof(animalHitReceiver).GetField("health",BindingFlags.Instance|BindingFlags.NonPublic);
        private static readonly FieldInfo gooseHitHealth=typeof(animalHitReceiver).GetField("gHealth",BindingFlags.Instance|BindingFlags.NonPublic);
        private static readonly FieldInfo healthAI=typeof(EnemyHealth).GetField("ai",BindingFlags.Instance|BindingFlags.NonPublic);
        private static readonly FieldInfo healthSetup=typeof(EnemyHealth).GetField("setup",BindingFlags.Instance|BindingFlags.NonPublic);
        private static readonly FieldInfo ragdollField=typeof(EnemyHealth).GetField("ragDollSetup",BindingFlags.Instance|BindingFlags.NonPublic);
        private static readonly Dictionary<Type,MethodInfo> nativeHits=new Dictionary<Type,MethodInfo>();
        private static readonly Dictionary<clsragdollify,float> headCuts=new Dictionary<clsragdollify,float>();

        private static MethodInfo HitMethod(Type type)
        {
            MethodInfo result;if(nativeHits.TryGetValue(type,out result))return result;
            const BindingFlags flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance;
            // Same contracts used by Forest projectiles and melee. Select only
            // one receiver, avoiding SendMessageUpwards applying damage twice.
            result=type.GetMethod("Hit",flags,null,new[]{typeof(int)},null)
                ?? type.GetMethod("Hit",flags,null,new[]{typeof(float)},null)
                ?? type.GetMethod("LocalizedHit",flags,null,new[]{typeof(LocalizedHitData)},null)
                ?? type.GetMethod("Hit",flags,null,Type.EmptyTypes,null);
            nativeHits[type]=result;return result;
        }
        private static Impact Trace(Vector3 origin,Vector3 direction,BoltEntity shooter)
        {
            var hits=Physics.RaycastAll(origin,direction,Range,~0,QueryTriggerInteraction.Collide);
            Array.Sort(hits,delegate(RaycastHit a,RaycastHit b){return a.distance.CompareTo(b.distance);});
            foreach(var hit in hits)
            {
                Collider c=hit.collider;if(c==null)continue;
                if(shooter!=null && c.transform.IsChildOf(shooter.transform))continue;
                if(shooter==null && LocalPlayer.Transform!=null && c.transform.IsChildOf(LocalPlayer.Transform))continue;
                // Use the native player collider/entity, never visual skin bones.
                // Disabled friendly fire still lets a player stop the projectile.
                BoltEntity player=Re3FriendlyFire.Player(c);
                if(player!=null)return new Impact{target=player,player=player,hit=hit};
                if(c.GetComponentInParent<JillMotionPreview>()!=null || c.GetComponentInParent<PlayerStats>()!=null || c.GetComponentInParent<CoopRemoteAvatar>()!=null)continue;
                if(c.CompareTag("PlayerNet") || c.CompareTag("Player"))continue;
                var receiver=c.GetComponentInParent<mutantHitReceiver>();
                var health=c.GetComponentInParent<EnemyHealth>() ?? (receiver!=null && hitHealth!=null ? hitHealth.GetValue(receiver) as EnemyHealth:null);
                if(health==null && (c.CompareTag("enemyRoot") || c.CompareTag("enemyCollide")))health=c.transform.GetComponentInChildren<EnemyHealth>();
                if(health!=null)
                {
                    var setup=healthSetup!=null ? healthSetup.GetValue(health) as mutantScriptSetup:null;
                    var ai=setup!=null ? setup.ai:healthAI!=null ? healthAI.GetValue(health) as mutantAI:null;
                    bool mutant=ai!=null && (ai.creepy || ai.creepy_male || ai.creepy_fat || ai.creepy_baby || ai.creepy_boss);
                    bool head=!mutant && ((receiver!=null && receiver.isHead) || HeadIntersection(setup,origin,direction,hit.distance));
                    return new Impact{target=health,health=health,setup=setup,ai=ai,mutant=mutant,head=head,hit=hit};
                }
                // Trigger volumes without a receiver (chest interaction,
                // foliage detectors, water) do not stop a bullet.
                if(c.GetComponentInParent<Re3Chest>()!=null){if(c.isTrigger)continue;return null;}
                // All colliders of one animal resolve to one native health
                // component, so a shotgun volley applies one summed hit.
                Component animal=c.GetComponentInParent<animalHealth>();
                var animalReceiver=c.GetComponentInParent<animalHitReceiver>();
                if(animal==null && animalReceiver!=null)
                    animal=animalReceiver.goose && gooseHitHealth!=null ? gooseHitHealth.GetValue(animalReceiver) as Component:animalHitHealth!=null ? animalHitHealth.GetValue(animalReceiver) as Component:null;
                if(animal==null && c.CompareTag("animalRoot"))animal=c.GetComponentInChildren<animalHealth>();
                if(animal!=null)return new Impact{target=animal,method=HitMethod(animal.GetType()),hit=hit};
                // TreeHealth.Hit() fells a tree immediately; TreeCutChunk.Hit
                // consumes axe-chop units. Neither contract is bullet damage.
                // Stop at the trunk without reaching the reflective receiver.
                if(BulletTree(c))return null;
                bool suitcase=c.CompareTag("suitCase");
                for(Transform at=c.transform;at!=null;at=at.parent)
                {
                    foreach(var component in at.GetComponents<MonoBehaviour>())
                    {
                        if(component==null || component is PlayerStats)continue;
                        MethodInfo method=HitMethod(component.GetType());
                        if(method!=null)return new Impact{target=component,method=method,hit=hit,suitcase=suitcase};
                    }
                    // Some animals keep their health beside the collider,
                    // reached by animalHitReceiver's own native Hit method.
                    if(at.GetComponent<BoltEntity>()!=null)break;
                }
                if(c.isTrigger)continue;
                return null; // First solid obstacle; no wall penetration.
            }
            return null;
        }
        private static bool BulletTree(Collider c)
        {
            for(Transform at=c.transform;at!=null;at=at.parent)
            {
                string tag=at.tag;
                if(tag=="Tree" || tag=="MidTree" || tag=="SmallTree" || at.GetComponent<TreeHealth>()!=null
                    || at.GetComponent<TreeCutChunk>()!=null || at.GetComponent<LOD_Trees>()!=null || at.GetComponent<CoopTreeId>()!=null)return true;
                // A constructed wall/treehouse is its own damage receiver.
                if(tag=="structure" || at.GetComponent<BoltEntity>()!=null)break;
            }
            return false;
        }
        private static bool HeadIntersection(mutantScriptSetup setup,Vector3 origin,Vector3 direction,float bodyDistance)
        {
            if(setup==null || setup.headJoint==null)return false;
            Ray ray=new Ray(origin,direction);float headDistance;
            if(setup.headColliderGo!=null)
            {
                foreach(var c in setup.headColliderGo.GetComponentsInChildren<Collider>(true))
                {
                    RaycastHit actual;
                    if(c.enabled && c.gameObject.activeInHierarchy && c.Raycast(ray,out actual,Range))return actual.distance<=bodyDistance+3f;
                    // Native head hitboxes can be disabled in favor of the
                    // broad root capsule. Evaluate their original geometry.
                    var sphere=c as SphereCollider;
                    if(sphere!=null)
                    {
                        Vector3 scale=sphere.transform.lossyScale;
                        float radius=sphere.radius*Mathf.Max(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z));
                        if(RaySphere(origin,direction,sphere.transform.TransformPoint(sphere.center),radius,out headDistance))return headDistance<=bodyDistance+radius*3f;
                    }
                    var box=c as BoxCollider;
                    if(box!=null)
                    {
                        var localRay=new Ray(box.transform.InverseTransformPoint(origin),box.transform.InverseTransformVector(direction));
                        if(new Bounds(box.center,box.size).IntersectRay(localRay,out headDistance))
                        {float distance=Vector3.Distance(origin,box.transform.TransformPoint(localRay.GetPoint(headDistance)));if(distance<=Mathf.Min(Range,bodyDistance+3f))return true;}
                    }
                }
            }
            // Anatomical fallback, never a threshold against root capsule Y.
            float height=setup.controller!=null ? setup.controller.height*Mathf.Abs(setup.controller.transform.lossyScale.y):4.5f;
            float r=Mathf.Clamp(height*.065f,.12f,.42f);
            return RaySphere(origin,direction,setup.headJoint.transform.position,r,out headDistance) && headDistance<=bodyDistance+r*3f;
        }
        private static bool RaySphere(Vector3 origin,Vector3 direction,Vector3 center,float radius,out float distance)
        {
            Vector3 delta=origin-center;float b=Vector3.Dot(delta,direction),d=b*b-delta.sqrMagnitude+radius*radius;
            distance=0;if(d<0)return false;distance=-b-Mathf.Sqrt(d);return distance>=0 && distance<=Range;
        }
        private static void Shoot(Vector3 origin,Vector3 direction,BoltEntity shooter,G19Pose pose)
        {
            if(BoltNetwork.isRunning && !BoltNetwork.isServer && !BoltNetwork.IsSinglePlayer)return;
            if(headCuts.Count>0){var expired=new List<clsragdollify>();foreach(var pair in headCuts)if(pair.Key==null || pair.Value<Time.time)expired.Add(pair.Key);foreach(var key in expired)headCuts.Remove(key);}
            int count=pose.weapon==3 ? 10:1;var groups=new Dictionary<Component,Impact>();
            Vector3 right=Vector3.Cross(Mathf.Abs(direction.y)>.99f ? Vector3.forward:Vector3.up,direction).normalized;
            Vector3 up=Vector3.Cross(direction,right).normalized;
            float spread=Mathf.Tan(Re3Weapon.Spread(pose.aim,pose.movement)*Mathf.Deg2Rad);
            for(int i=0;i<count;i++)
            {
                Vector2 disk=i==0 ? Vector2.zero:UnityEngine.Random.insideUnitCircle*spread;
                Vector3 ray=(direction+right*disk.x+up*disk.y).normalized;
                Impact hit=Trace(origin,ray,shooter);if(hit==null || hit.target==null)continue;
                Impact group;if(!groups.TryGetValue(hit.target,out group)){group=hit;groups.Add(hit.target,group);}
                group.pellets++;if(hit.head)group.heads++;
                group.damage+=pose.weapon==3 ? (i==0 ? 23:8):(hit.head ? 90:18);
            }
            foreach(var hit in groups.Values)
            {
                bool full=pose.weapon==3 && hit.pellets==10,decapitate=full && hit.heads==10 && !hit.mutant && hit.player==null;
                int damage=full ? Mathf.FloorToInt(hit.damage*1.5f+.5f):hit.damage;
                try
                {
                    if(hit.player!=null)Re3FriendlyFire.Hit(hit.player,shooter,damage);
                    else if(hit.health!=null)
                    {
                        Re3EnemyBalance.Apply(hit.health);
                        if(hit.health.Health<=0)continue;
                        EnemyHealth.CurrentAttacker=shooter;hit.health.getAttackDirection(full && !hit.mutant ? 5:3);
                        if(hit.health.targetSwitcher!=null)hit.health.targetSwitcher.attackerType=4;
                        hit.health.hitBlock=false; // One aggregated hit per shot, not per pellet.
                        var rag=ragdollField!=null ? ragdollField.GetValue(hit.health) as clsragdollify:null;
                        bool previousHack=rag!=null && rag.hackVelocity;Vector3 previousVelocity=rag!=null ? rag.getVelocity:Vector3.zero;
                        // Death can create the ragdoll inside HitReal itself.
                        if(full && !hit.mutant && rag!=null){rag.getVelocity=direction*12f;rag.hackVelocity=true;}
                        if(decapitate)
                        {
                            if(rag!=null)headCuts[rag]=Time.time+30f;
                            damage=Mathf.Max(damage,hit.health.Health+hit.health.maxHealth+1);
                        }
                        hit.health.HitReal(damage);
                        if(rag!=null && hit.health.Health>0){rag.hackVelocity=previousHack;rag.getVelocity=previousVelocity;}
                        if(full && !hit.mutant)
                        {
                            if(hit.health.Health>0)
                            {
                                // Native knockdown also subtracts 20 HP. Offset
                                // that implicit hit so the only damage is 95x1.5.
                                int remaining=hit.health.Health;hit.health.Health=remaining+20;
                                hit.health.hitFallDown(0f);hit.health.Health=remaining;
                                var knock=hit.health.GetComponent<Re3Knockback>() ?? hit.health.gameObject.AddComponent<Re3Knockback>();
                                knock.Begin(hit.setup,direction);
                            }
                        }
                        else if(!hit.mutant && hit.health.Health>0)
                        {var stun=hit.health.GetComponent<G19Stun>() ?? hit.health.gameObject.AddComponent<G19Stun>();stun.Begin(hit.ai);}
                    }
                    else ApplyNativeHit(hit,damage);
                    ModAPI.Log.Write("[ForestRE3] RE_WEAPON_HIT weapon="+Re3Weapon.Name(pose.weapon)+"; receiver="+hit.target.GetType().Name+"; pellets="+hit.pellets+"; headPellets="+hit.heads+"; damage="+damage+"; fullBonus="+full+"; decapitate="+decapitate);
                }
                catch(Exception e){ModAPI.Log.Write("[ForestRE3] RE_WEAPON_HIT_ERROR "+e);}
            }
        }
        private static void ApplyNativeHit(Impact hit,int damage)
        {
            var parameters=hit.method.GetParameters();object[] args=null;
            if(parameters.Length==1)
            {
                Type type=parameters[0].ParameterType;
                args=new[]{type==typeof(float) ? (object)(float)damage:type==typeof(LocalizedHitData) ? new LocalizedHitData(hit.hit.point,damage):(object)damage};
            }
            hit.method.Invoke(hit.target,args);
            // SuitCase.Hit opens the lid. This existing native
            // event opens remote scene copies and updates ISuitcaseState.
            if(hit.suitcase && BoltNetwork.isRunning)
            {
                var e=OpenSuitcase.Create(Bolt.GlobalTargets.Others);e.Position=hit.hit.collider.transform.position;e.Damage=damage;e.Send();
            }
        }
        public static void RagdollCreated(clsragdollify source,Transform corpse)
        {
            float until;if(!headCuts.TryGetValue(source,out until))return;headCuts.Remove(source);
            if(until>=Time.time && corpse!=null && Instance!=null)Instance.StartCoroutine(CutShotgunHead(corpse));
        }
        private static IEnumerator CutShotgunHead(Transform corpse)
        {
            // Native ragdoll components and Bolt body part arrays attach later
            // in the frame. Match this exact corpse, never a nearby enemy.
            float until=Time.time+5f;
            while(corpse!=null && Time.time<until)
            {
                foreach(var head in corpse.GetComponentsInChildren<DamageCorpse>(true))if(head.isHead)
                {
                    if(BoltNetwork.isRunning)
                    {
                        var slice=head.GetComponentInParent<CoopSliceAndDiceMutant>();var entity=head.GetComponentInParent<BoltEntity>();
                        if(slice==null || entity==null || !entity.isAttached || !entity.isOwner)continue;
                        int index=slice.GetBodyPartIndex(head);if(index<0)continue;
                        // Native array stores REMAINING health, not damage.
                        slice.BodyPartsDamage[index]=0;
                    }
                    else head.DoLocalCut(0);
                    ModAPI.Log.Write("[ForestRE3] M3_HEAD_DISMEMBERED nativeBodyPart=true; networkOwner=true");yield break;
                }
                yield return null;
            }
            ModAPI.Log.Write("[ForestRE3] M3_HEAD_DISMEMBER_FAILED nativeHeadUnavailable=true");
        }
    }
    public class Re3RagdollPatch : clsragdollify
    {
        public new virtual Transform metgoragdoll(Vector3 velocity)
        {Transform corpse=base.metgoragdoll(velocity);G19Runtime.RagdollCreated(this,corpse);return corpse;}
    }
    public sealed class Re3Knockback : MonoBehaviour
    {
        private mutantScriptSetup setup;private EnemyHealth health;private Vector3 direction;private float until;private bool active,aiEnabled;
        internal void Begin(mutantScriptSetup value,Vector3 forward)
        {
            if(value==null || value.controller==null)return;setup=value;health=GetComponent<EnemyHealth>();
            if(!active){aiEnabled=setup.ai!=null && setup.ai.enabled;active=true;}
            direction=Vector3.ProjectOnPlane(forward,Vector3.up).normalized;until=Time.time+.45f;
            // Face the attack, then the native hurtLevel=4 falls backwards.
            if(setup.rotateTr!=null && direction.sqrMagnitude>.1f)setup.rotateTr.rotation=Quaternion.LookRotation(-direction,Vector3.up);
            if(setup.ai!=null)setup.ai.enabled=false;
        }
        private void FixedUpdate()
        {
            if(!active)return;
            if(Time.time>=until || setup==null || setup.controller==null){Restore();return;}
            // Move through the existing CharacterController, retaining terrain,
            // cave walls and construction collisions. Native Bolt syncs the root.
            if(setup.controller.enabled)setup.controller.Move(direction*(20f*Mathf.Clamp01((until-Time.time)/.45f)*Time.fixedDeltaTime));
        }
        private void Restore(){if(active && setup!=null && setup.ai!=null && health!=null && health.Health>0)setup.ai.enabled=aiEnabled;active=false;}
        private void OnDisable(){Restore();}
    }
}
