﻿using System;
using System.IO;
using System.Linq;
using Mono.Cecil;
using ForestRE3JillVisualProbe;

internal static class VerifyMotionData
{
    public static int Main(string[] args)
    {
        try
        {
            if (args.Length > 1 && args[1] == "--assembly")
            {
                using (ModuleDefinition module = ModuleDefinition.ReadModule(args[0]))
                {
                    EmbeddedResource resource = module.Resources.OfType<EmbeddedResource>().Single(r => r.Name == "ForestRE3JillVisualProbe.jill-motion-preview.bin");
                    using (Stream stream = resource.GetResourceStream()) Check(stream);
                }
            }
            else using (Stream stream = File.OpenRead(args[0])) Check(stream);
            return 0;
        }
        catch (Exception exception) { Console.Error.WriteLine(exception); return 1; }
    }
    private static void Check(Stream stream)
    {
        MotionData data = JillMotionDataReader.Read(stream);
        foreach (MotionClip clip in data.clips)
            Console.WriteLine("JRM1_OK " + clip.mode + " bones=" + clip.bones.Length + " tracks=" + clip.tracks.Length + " frames=" + clip.frames + " floats=" + clip.tracks.Sum(t => t.values.Length));
    }
}
