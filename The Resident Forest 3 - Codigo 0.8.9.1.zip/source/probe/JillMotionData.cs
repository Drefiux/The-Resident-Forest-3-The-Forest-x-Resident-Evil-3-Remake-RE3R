﻿using System;
using System.IO;
using System.Text;

namespace ForestRE3JillVisualProbe
{
    // Explicit format avoids Unity JsonUtility's runtime serialization path.
    public sealed class MotionData { public MotionClip[] clips; }
    public sealed class MotionClip { public string mode, name; public float frames, fps; public MotionBone[] bones; public MotionTrack[] tracks; }
    public sealed class MotionBone { public string name; public float[] restPosition, restRotation; }
    public sealed class MotionTrack { public string bone, kind; public float[] values; }

    public static class JillMotionDataReader
    {
        public static MotionData Read(Stream stream)
        { return ReadBank(stream, 0); }
        public static MotionData ReadDodge(Stream stream)
        { return ReadBank(stream, 1); }
        public static MotionData ReadRocket(Stream stream) { return ReadBank(stream,4); }
        public static MotionData ReadM3(Stream stream) { return ReadBank(stream,3); }
        public static MotionData ReadG19(Stream stream) { return ReadBank(stream,2); }
        private static MotionData ReadBank(Stream stream, int bank)
        {
            using (BinaryReader reader = new BinaryReader(stream))
            {
                if (reader.ReadUInt32() != 0x314D524A) throw new InvalidDataException("Invalid JRM1 motion header.");
                int clips = Count(reader, bank>=2 ? 32:8);
                if (clips != (bank==4 ? 12:bank==3 ? 16:bank==2 ? 14:bank==1 ? 4:3)) throw new InvalidDataException("Unexpected motion clip count.");
                MotionData data = new MotionData { clips = new MotionClip[clips] };
                string[] modes = { "idle", "walk", "run" };
                for (int c = 0; c < clips; c++)
                {
                    MotionClip clip = new MotionClip { mode = Text(reader), name = Text(reader), frames = Number(reader), fps = Number(reader) };
                    if ((bank<2 && clip.mode != (bank==1 ? "dodge_"+c : modes[c])) || clip.frames <= 0f || clip.fps <= 0f) throw new InvalidDataException("Invalid motion clip " + c);
                    clip.bones = new MotionBone[Count(reader, 2048)];
                    for (int b = 0; b < clip.bones.Length; b++)
                        clip.bones[b] = new MotionBone { name = Text(reader), restPosition = Numbers(reader, 3), restRotation = Numbers(reader, 4) };
                    clip.tracks = new MotionTrack[Count(reader, 8192)];
                    for (int t = 0; t < clip.tracks.Length; t++)
                    {
                        string bone = Text(reader);
                        byte kind = reader.ReadByte();
                        if (kind > 2) throw new InvalidDataException("Invalid motion track kind.");
                        int count = Count(reader, 2000000);
                        int stride = kind == 1 ? 5 : 4;
                        if (count == 0 || count % stride != 0) throw new InvalidDataException("Invalid motion key count.");
                        float[] values = Numbers(reader, count);
                        for (int k = 0; k < count; k += stride)
                            if (values[k] < 0f || (k > 0 && values[k] < values[k-stride])) throw new InvalidDataException("Unsorted motion keys.");
                        clip.tracks[t] = new MotionTrack { bone = bone, kind = kind == 0 ? "position" : (kind == 1 ? "rotation" : "scale"), values = values };
                    }
                    data.clips[c] = clip;
                }
                if (reader.BaseStream.ReadByte() != -1) throw new InvalidDataException("Unexpected data after motion clips.");
                return data;
            }
        }

        private static int Count(BinaryReader reader, int maximum)
        {
            int value = reader.ReadInt32();
            if (value < 0 || value > maximum) throw new InvalidDataException("Motion count outside supported range.");
            return value;
        }
        private static string Text(BinaryReader reader)
        {
            int length = reader.ReadUInt16();
            if (length == 0 || length > 4096) throw new InvalidDataException("Invalid motion name length.");
            byte[] bytes = reader.ReadBytes(length);
            if (bytes.Length != length) throw new EndOfStreamException("Truncated motion name.");
            return new UTF8Encoding(false, true).GetString(bytes);
        }
        private static float Number(BinaryReader reader)
        {
            float value = reader.ReadSingle();
            if (float.IsNaN(value) || float.IsInfinity(value)) throw new InvalidDataException("Nonfinite motion value.");
            return value;
        }
        private static float[] Numbers(BinaryReader reader, int count)
        {
            float[] values = new float[count];
            for (int i = 0; i < count; i++) values[i] = Number(reader);
            return values;
        }
    }
}
