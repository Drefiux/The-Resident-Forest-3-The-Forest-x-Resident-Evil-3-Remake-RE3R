﻿using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;

namespace ForestRE3JillVisualProbe
{
    public sealed partial class Re3InventoryRuntime
    {
        private bool networkReady,pending; private float pendingAt; private uint requestSequence,pendingSequence,receivedSequence;
        private readonly Dictionary<BoltConnection,uint> requests=new Dictionary<BoltConnection,uint>();
        internal static void NetworkReset()
        {
            if(Instance==null) return;
            Instance.requests.Clear(); Instance.receivedSequence=Instance.requestSequence=0; Instance.pending=false;
            Instance.networkReady=!Client; Instance.requestAt=0;
            for(int i=0;i<5;i++) Instance.hasTest[i]=false;
        }
        internal static void PeerGone(BoltConnection connection) { if(Instance!=null && connection!=null) Instance.requests.Remove(connection); }
        private static string PeerKey(BoltConnection connection)
        {
            if(connection==null) return "host";
            MethodInfo get=typeof(CoopKick).GetMethod("GetSteamId",BindingFlags.NonPublic|BindingFlags.Static,null,new[] {typeof(BoltConnection)},null);
            ulong steam=get==null ? 0:(ulong)get.Invoke(null,new object[] {connection});
            return steam!=0 ? "steam:"+steam:"connection:"+connection.ConnectionId;
        }
        internal static string ConnectionKey(BoltConnection connection){return PeerKey(connection);}
        internal static bool OwnsWeapon(BoltConnection connection,int id)
        {Re3Bag bag;return Instance!=null && Instance.bags.TryGetValue(PeerKey(connection),out bag) && G19Runtime.HasWeapon(bag,id);}
        private void SendRequest(byte operation,int chest,int slot,int id,int count,Vector3 position,uint lifeToken=0)
        {
            bool life=operation==5 || operation==6;
            if((!life && (lifeQueue.Count>0 || operation!=0 && pending)) || !ready) return;
            uint sequence=++requestSequence; if(sequence==0) sequence=++requestSequence;
            uint chestRevision=chest>=0 && chest<5 ? boxes[chest].revision:0;
            if(Client)
            {
                if(!CoopSync.CanStartDodge || (!networkReady && !life)) { Notice("Esperando al host para sincronizar los inventarios RE3R."); if(operation!=0) return; }
                if(operation!=0 && !life) { pending=true; pendingSequence=sequence; pendingAt=Time.realtimeSinceStartup; }
                CoopSync.InventoryRequest(delegate(BinaryWriter w)
                {
                    w.Write(sequence); w.Write(operation); w.Write((byte)chest); w.Write(player.revision); w.Write(chestRevision);
                    w.Write((byte)slot); w.Write((ushort)id); w.Write((ushort)count);
                    w.Write(position.x); w.Write(position.y); w.Write(position.z);w.Write(lifeToken);
                });
            }
            else
            {
                string message=Process(null,operation,chest,slot,(ushort)id,count,position,player.revision,chestRevision,LocalPlayer.Transform.position,lifeToken);
                if(life && lifeAcknowledged)ConfirmLife(operation,lifeToken);
                if(message.Length>0) Notice(message);
            }
        }
        internal static void ReceiveRequest(BoltConnection connection,ulong actor,BinaryReader r)
        {
            uint sequence=r.ReadUInt32(); byte operation=r.ReadByte(); int chest=r.ReadByte();
            uint bagRevision=r.ReadUInt32(),chestRevision=r.ReadUInt32(); int slot=r.ReadByte(); ushort id=r.ReadUInt16(); int count=r.ReadUInt16();
            var position=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());uint lifeToken=r.ReadUInt32();
            if(r.BaseStream.Position!=r.BaseStream.Length || sequence==0 || operation>7 || ((operation==5 || operation==6) && lifeToken==0) || (operation==1 || operation==2 || operation==4) && chest>=5)
                throw new InvalidDataException("Inventory request");
            if(Instance==null || !Instance.ready || Client) return;
            uint seen; if(Instance.requests.TryGetValue(connection,out seen) && unchecked((int)(sequence-seen))<=0) return;
            Instance.requests[connection]=sequence;
            BoltEntity entity=BoltNetwork.FindEntity(new Bolt.NetworkId(actor)); if(entity==null) return;
            string message=Instance.Process(connection,operation,chest,slot,id,count,position,bagRevision,chestRevision,entity.transform.position,lifeToken,actor);
            Instance.SendState(connection,sequence,message,(operation==5 || operation==6) && Instance.lifeAcknowledged ? operation:(byte)0,lifeToken);
        }
        private string Process(BoltConnection connection,byte operation,int chest,int slot,ushort id,int count,Vector3 position,uint bagRevision,uint chestRevision,Vector3 actorPosition,uint lifeToken=0,ulong actor=0)
        {
            lifeAcknowledged=false;string key=PeerKey(connection); Re3Bag bag;
            if(!bags.TryGetValue(key,out bag))
            { if(bags.Count>=64) return "Límite de jugadores del inventario alcanzado."; bag=new Re3Bag(20,4); bags.Add(key,bag); }
            var store=Storage(key);SeedStorage(key);
            if(operation==5 || operation==6)return ProcessLife(key,bag,operation,lifeToken,position,actorPosition,actor);
            if(operation==0) return "";
            if((operation==3 || operation==4) && (connection!=null || !Re3DeveloperTools.Enabled))return "Las herramientas de prueba sólo están disponibles para el host que las active en el iniciador.";
            if(operation==7)
            {
                if(count<0 || count>3 || bag.revision!=bagRevision)return "El inventario cambió; vuelve a mover el objeto.";
                bool sourceChest=(count&1)!=0,targetChest=(count&2)!=0;
                if(count!=0 && (chest<0 || chest>=5 || !Near(chest,actorPosition,14f)))return "Acércate al baúl para mover objetos.";
                if(count!=0 && store.boxes[chest].revision!=chestRevision)return "El baúl cambió; vuelve a mover el objeto.";
                return Re3Bag.Move(sourceChest ? store.boxes[chest]:bag,targetChest ? store.boxes[chest]:bag,slot,id) ? "":"No hay espacio en esa posición para mover o intercambiar el objeto.";
            }
            if(operation==4)
            {
                if(chest<0 || chest>=5 || !Finite(position) || (position-actorPosition).sqrMagnitude>15f*15f) return "El punto de prueba no es válido.";
                hasTest[chest]=true; testPoints[chest]=position; RefreshWorld();
                return "Copia de prueba de "+Re3ChestLocation.All[chest].name+" colocada. Comparte sus 4 slots con el original.";
            }
            if(bag.revision!=bagRevision) return "El inventario cambió: ya está actualizado; vuelve a seleccionar el objeto.";
            if(operation==3)
            {
                Re3Item item=Re3Catalog.Find(id);
                if(item==null || count<1 || count>item.stack) return "Objeto RE3R no válido.";
                return bag.Add(id,count) ? "Objeto de prueba añadido: "+item.name:"No queda espacio suficiente.";
            }
            if(chest<0 || chest>=5 || !Near(chest,actorPosition,14f)) return "Acércate al baúl para transferir objetos.";
            if(store.boxes[chest].revision!=chestRevision) return "El baúl cambió: ya está actualizado; vuelve a seleccionar el objeto.";
            Re3Bag from=operation==1 ? bag:store.boxes[chest],to=operation==1 ? store.boxes[chest]:bag;
            return Re3Bag.Transfer(from,to,slot,count) ? "Transferencia realizada.":"No se pudo transferir: revisa la cantidad y el espacio libre.";
        }
        private static bool Finite(Vector3 v)
        { return !float.IsNaN(v.x) && !float.IsNaN(v.y) && !float.IsNaN(v.z) && !float.IsInfinity(v.x) && !float.IsInfinity(v.y) && !float.IsInfinity(v.z); }
        private void SendState(BoltConnection connection,uint sequence,string message,byte lifeOperation=0,uint lifeToken=0)
        {
            string key=PeerKey(connection); Re3Bag bag; if(!bags.TryGetValue(key,out bag)) return;
            var store=Storage(key);
            CoopSync.InventoryState(connection,delegate(BinaryWriter w)
            {
                w.Write(sequence); w.Write(message); bag.Write(w);
                for(int i=0;i<5;i++)
                { store.boxes[i].Write(w); w.Write(hasTest[i]); w.Write(testPoints[i].x); w.Write(testPoints[i].y); w.Write(testPoints[i].z);w.Write(anchors[i].x);w.Write(anchors[i].y);w.Write(anchors[i].z); }
                w.Write(outdoorResolved);w.Write(lifeOperation);w.Write(lifeToken);WriteRecoveries(w,store);
            });
        }
        internal static void ReceiveState(BinaryReader r)
        {
            uint sequence=r.ReadUInt32(); string message=r.ReadString(); if(message.Length>300) throw new InvalidDataException("Inventory feedback");
            Re3Bag bag=Re3Bag.Read(r,20,4); var boxes=new Re3Bag[5]; var points=new Vector3[5];var anchors=new Vector3[5]; var tests=new bool[5];
            for(int i=0;i<5;i++) { boxes[i]=Re3Bag.Read(r,4,2); tests[i]=r.ReadBoolean(); points[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());anchors[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle()); if(!Finite(points[i]) || !Finite(anchors[i])) throw new InvalidDataException("Chest position"); }
            bool coastReady=r.ReadBoolean();byte lifeOperation=r.ReadByte();uint lifeToken=r.ReadUInt32();
            if(lifeOperation!=0 && lifeOperation!=5 && lifeOperation!=6)throw new InvalidDataException("Inventory life ack");
            int recoveries=r.ReadByte();if(recoveries>64)throw new InvalidDataException("Recovery count");var recoveryPoints=new Dictionary<uint,Vector3>();
            for(int i=0;i<recoveries;i++){uint token=r.ReadUInt32();var point=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());if(token==0 || !ValidPosition(point))throw new InvalidDataException("Recovery position");recoveryPoints.Add(token,point);}
            if(r.BaseStream.Position!=r.BaseStream.Length) throw new InvalidDataException("Inventory trailing bytes");
            if(Instance==null || !Client || unchecked((int)(sequence-Instance.receivedSequence))<=0) return;
            Instance.receivedSequence=sequence; Instance.player=bag; Instance.boxes=boxes; Instance.networkReady=true;
            for(int i=0;i<5;i++) { Instance.hasTest[i]=tests[i]; Instance.testPoints[i]=points[i];Instance.anchors[i]=anchors[i]; }
            Instance.outdoorResolved=coastReady;
            Instance.visibleRecoveries.Clear();foreach(var item in recoveryPoints)Instance.visibleRecoveries[item.Key]=item.Value;
            Instance.ConfirmLife(lifeOperation,lifeToken);
            foreach(var queued in Instance.lifeQueue)if(queued.operation==5)Instance.visibleRecoveries[queued.token]=queued.position;
            if(Instance.lifeQueue.Count>0)Instance.networkReady=false;
            if(Instance.pending && unchecked((int)(sequence-Instance.pendingSequence))>=0) Instance.pending=false;
            if(message.Length>0) Instance.Notice(message);
        }
    }
}
