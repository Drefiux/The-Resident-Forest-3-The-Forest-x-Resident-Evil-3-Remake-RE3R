﻿using System;
using System.IO;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
namespace ForestRE3JillVisualProbe
{
    public sealed class Re3CoopOptions : MonoBehaviour
    {
        private const string Preference="ForestRE3.FriendlyFire.v1";
        private static bool friendlyFire=true;
        internal static bool FriendlyFire {get{return friendlyFire;}}
        private static bool Host {get{return !BoltNetwork.isRunning || BoltNetwork.IsSinglePlayer || BoltNetwork.isServer;}}
        private void Awake(){ResetSession();}
        internal static void ResetSession()
        {friendlyFire=Host ? PlayerPrefs.GetInt(Preference,1)!=0:true;}
        internal static void SendSnapshot(BoltConnection connection)
        {if(Host)CoopSync.OptionsState(connection,delegate(BinaryWriter w){w.Write((byte)(friendlyFire ? 1:0));});}
        internal static void Receive(BinaryReader r)
        {
            byte value=r.ReadByte();
            if(value>1 || r.BaseStream.Position!=r.BaseStream.Length)throw new InvalidDataException("RE3 coop options");
            friendlyFire=value==1;
        }
        private static void Set(bool value)
        {
            if(!Host || friendlyFire==value)return;
            friendlyFire=value;PlayerPrefs.SetInt(Preference,value ? 1:0);PlayerPrefs.Save();SendSnapshot(null);
            ModAPI.Log.Write("[ForestRE3] COOP_OPTIONS friendlyFire="+value+"; authority=host");
        }
        internal static void DrawToggle(Rect rect,GUIStyle style)
        {
            bool previous=GUI.enabled;GUI.enabled=Host;
            bool value=GUI.Toggle(rect,friendlyFire,Host ? "Fuego amigo RE3R":"Fuego amigo RE3R (lo decide el host)",style);
            GUI.enabled=previous;if(Host)Set(value);
        }
        private void OnGUI()
        {
            if(LocalPlayer.Inventory==null || !LocalPlayer.IsInPauseMenu)return;
            float scale=Mathf.Clamp(Mathf.Min(Screen.width/1920f,Screen.height/1080f),.65f,1.5f);
            Matrix4x4 previous=GUI.matrix;
            GUI.matrix=Matrix4x4.TRS(new Vector3(24f*scale,Screen.height-132f*scale,0),Quaternion.identity,Vector3.one*scale);
            GUI.Box(new Rect(0,0,340,104),"Opciones RE3R");
            DrawToggle(new Rect(18,31,310,28),GUI.skin.toggle);
            GUI.Label(new Rect(18,65,310,25),"Daño reducido/completo: opción PvP nativa.");
            GUI.matrix=previous;
        }
    }
}
