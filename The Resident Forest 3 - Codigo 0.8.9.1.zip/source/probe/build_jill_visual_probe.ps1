﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$workspace = (Resolve-Path -LiteralPath (Join-Path $root '..\..')).Path
$source = Join-Path $PSScriptRoot 'ForestRE3JillVisualProbe.cs'
$outputDirectory = Join-Path $root 'build'
$outputDll = Join-Path $outputDirectory 'ForestRE3JillVisualProbe.dll'
$baseModLib = Join-Path $workspace 'work\tools\ModAPI\app\libs\BaseModLib.dll'
$unityEngine = Join-Path $workspace 'work\tools\ModAPI\app\libs\UnityEngine.dll'
$gameAssembly = Join-Path $root 'modapi-workspace\modlib\TheForest\TheForest_data\Managed\Assembly-CSharp.dll'
$gameModding = Join-Path $root 'modapi-workspace\modlib\TheForest\TheForest_data\Managed\TheForest.Modding.dll'
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'

$buildReceiptPath = Join-Path $workspace 'outputs\forest-re3-mashup\unity-pipeline\jill-complete-build.json'
if (-not (Test-Path -LiteralPath $buildReceiptPath -PathType Leaf)) {
    throw 'Falta compilar el esqueleto unificado. Ejecuta Build-CompleteJill.cmd.'
}
$buildReceipt = Get-Content -LiteralPath $buildReceiptPath -Raw | ConvertFrom-Json
if ($buildReceipt.stage -ne 'unified-jill-rig-lighting') {
    throw 'El bundle anterior de Jill estática no corresponde a la fase del esqueleto unificado. Ejecuta Build-CompleteJill.cmd.'
}
$resources = @()
$resources += '/resource:' + (Join-Path $workspace 'outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\Interface\forest-re3-interface') + ',ForestRE3JillVisualProbe.re3-interface'
foreach ($g19Space in @('gamma','linear')) {
    $g19Bundle = Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\G19\$g19Space\forest-re3-g19"
    $resources += '/resource:' + $g19Bundle + ',ForestRE3JillVisualProbe.g19-' + $g19Space
}
foreach ($g19Data in @('g19-motions','g19-sounds')) {
    $resources += '/resource:' + (Join-Path $root "research-g19\$g19Data.bin") + ',ForestRE3JillVisualProbe.' + $g19Data + '.bin'
}
foreach ($m3Space in @('gamma','linear')) {
    $m3Bundle = Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\M3\$m3Space\forest-re3-m3"
    $resources += '/resource:' + $m3Bundle + ',ForestRE3JillVisualProbe.m3-' + $m3Space
}
foreach ($m3Data in @('m3-motions','m3-sounds')) {
    $resources += '/resource:' + (Join-Path $root "research-m3\$m3Data.bin") + ',ForestRE3JillVisualProbe.' + $m3Data + '.bin'
}
foreach ($rocketSpace in @('gamma','linear')) {
    $resources += '/resource:' + (Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\Rocket\$rocketSpace\forest-re3-rocket") + ',ForestRE3JillVisualProbe.rocket-' + $rocketSpace
}
foreach ($rocketData in @('rocket-motions','rocket-sounds','rocket-ballistics')) {
    $resources += '/resource:' + (Join-Path $root "research-rocket\$rocketData.bin") + ',ForestRE3JillVisualProbe.' + $rocketData + '.bin'
}
foreach ($inventorySpace in @('gamma','linear')) {
    $inventoryBundle = Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\Inventory\$inventorySpace\forest-re3-inventory"
    if (-not (Test-Path -LiteralPath $inventoryBundle -PathType Leaf)) { throw 'Falta compilar el baul original de RE3R.' }
    $resources += '/resource:' + $inventoryBundle + ',ForestRE3JillVisualProbe.inventory-' + $inventorySpace
}
foreach ($dodgeName in @('dodge-motions','jill-dodge-voice','carlos-dodge-voice')) {
    $dodgePath = Join-Path $root "research-dodge\$dodgeName.bin"
    if (-not (Test-Path -LiteralPath $dodgePath -PathType Leaf)) { throw "Falta $dodgeName; ejecuta research-dodge/build_dodge_assets.py." }
    $resources += '/resource:' + $dodgePath + ',ForestRE3JillVisualProbe.' + $dodgeName + '.bin'
}
foreach ($surfaceSpace in @('gamma','linear')) {
    $surfaceBundle = Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\FirstPerson\$surfaceSpace\jill-first-person-surface"
    if (-not (Test-Path -LiteralPath $surfaceBundle -PathType Leaf)) { throw 'Falta compilar la superficie de primera persona.' }
    $resources += '/resource:' + $surfaceBundle + ',ForestRE3JillVisualProbe.jill-first-person-surface-' + $surfaceSpace
}
$motionManifest = Join-Path $workspace 'work\jill\corrected\jill-motion-preview.bin'
if (-not (Test-Path -LiteralPath $motionManifest -PathType Leaf)) { throw 'Faltan las pistas de movimiento de Jill. Ejecuta decode_motion_preview.py.' }
$resources += '/resource:' + $motionManifest + ',ForestRE3JillVisualProbe.jill-motion-preview.bin'
$shoulderManifest = Join-Path $workspace 'work\jill\corrected\jill-shoulder-correctives.bin'
if (-not (Test-Path -LiteralPath $shoulderManifest -PathType Leaf)) { throw 'Faltan los correctivos originales de hombros. Ejecuta build_shoulder_samples.py.' }
$resources += '/resource:' + $shoulderManifest + ',ForestRE3JillVisualProbe.jill-shoulder-correctives.bin'
$voiceManifest = Join-Path $workspace 'work\jill\corrected\jill-voice-bank.bin'
if (-not (Test-Path -LiteralPath $voiceManifest -PathType Leaf)) { throw 'Faltan las voces de Jill. Ejecuta build_voice_bank.py.' }
$resources += '/resource:' + $voiceManifest + ',ForestRE3JillVisualProbe.jill-voice-bank.bin'
foreach ($space in @('gamma', 'linear')) {
    $bundle = Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\forest-re3-jill-$space"
    if (-not (Test-Path -LiteralPath $bundle -PathType Leaf)) { throw "Falta el bundle de Jill para $space." }
    if ($buildReceipt.bundles.$space.sha256 -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $bundle).Hash) {
        throw "El bundle $space cambió desde la compilación confirmada."
    }
    $resources += '/resource:' + $bundle + ',ForestRE3JillVisualProbe.forest-re3-jill-' + $space
}
$carlosReceipt = Get-Content -LiteralPath (Join-Path $workspace 'outputs\forest-re3-mashup\unity-pipeline\carlos-complete-build.json') -Raw | ConvertFrom-Json
if ($carlosReceipt.stage -ne 'unified-carlos-rig-lighting') { throw 'Falta el esqueleto unificado de Carlos.' }
foreach ($space in @('gamma','linear')) {
    $bundle = Join-Path $workspace "outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\forest-re3-carlos-$space"
    if ($carlosReceipt.bundles.$space.sha256 -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $bundle).Hash) { throw "Cambio el bundle de Carlos $space." }
    $resources += '/resource:' + $bundle + ',ForestRE3JillVisualProbe.forest-re3-carlos-' + $space
}
foreach ($dataName in @('motion-preview','shoulder-correctives','voice-bank')) {
    $dataPath = Join-Path $workspace "work\carlos\corrected\carlos-$dataName.bin"
    if ($carlosReceipt.data.$dataName.sha256 -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $dataPath).Hash) { throw "Cambio el recurso Carlos $dataName." }
    $resources += '/resource:' + $dataPath + ',ForestRE3JillVisualProbe.carlos-' + $dataName + '.bin'
}
if (-not (Test-Path -LiteralPath $baseModLib -PathType Leaf)) { throw 'No se encontró BaseModLib.dll de ModAPI.' }
if (-not (Test-Path -LiteralPath $unityEngine -PathType Leaf)) { throw 'No se encontró UnityEngine.dll de ModAPI.' }
if (-not (Test-Path -LiteralPath $gameAssembly -PathType Leaf)) { throw 'No se encontro Assembly-CSharp.dll en la biblioteca de The Forest.' }
if (-not (Test-Path -LiteralPath $gameModding -PathType Leaf)) { throw 'No se encontro TheForest.Modding.dll en la biblioteca de The Forest.' }
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) { throw 'No se encontró el compilador C# de .NET Framework.' }

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
$referenceBuilder = Join-Path $root 'modapi-workspace\PrepareDodgeReference.exe'
$referenceCecil = Join-Path $root 'modapi-workspace\Mono.Cecil.dll'
& $compiler /nologo /target:exe /out:$referenceBuilder "/reference:$referenceCecil" (Join-Path $PSScriptRoot 'PrepareDodgeReference.cs')
if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar la referencia de compilacion de esquiva.' }
$dodgeReference = Join-Path $outputDirectory 'dodge-reference\Assembly-CSharp.dll'
& $referenceBuilder $gameAssembly $dodgeReference (Join-Path $root 'modapi-workspace\gamefiles\original\TheForest\TheForest_data\Managed')
if ($LASTEXITCODE -ne 0) { throw 'Fallo la referencia de compilacion.' }
$gameAssembly = $dodgeReference
$motionSource = Join-Path $PSScriptRoot 'JillMotionPreview.cs'
$interfaceSource = Join-Path $PSScriptRoot 'Re3Interface.cs'
$motionReaderSource = Join-Path $PSScriptRoot 'JillMotionData.cs'
$shoulderReaderSource = Join-Path $PSScriptRoot 'JillShoulderData.cs'
$nativeActionsSource = Join-Path $PSScriptRoot 'JillNativeActions.cs'
$nativeStateTableSource = Join-Path $PSScriptRoot 'JillNativeStateTable.cs'
$playerSource = Join-Path $PSScriptRoot 'JillPlayerAvatar.cs'
$planeSource = Join-Path $PSScriptRoot 'JillPlaneAvatar.cs'
$voiceSource = Join-Path $PSScriptRoot 'JillVoice.cs'
$voiceReaderSource = Join-Path $PSScriptRoot 'JillVoiceData.cs'
$viewSource = Join-Path $PSScriptRoot 'JillFirstPersonView.cs'
$dodgeCameraSource = Join-Path $PSScriptRoot 'DodgeFirstPersonCamera.cs'
$closureSource = Join-Path $PSScriptRoot 'JillNeckClosure.cs'
$boltAssembly = Join-Path $root 'modapi-workspace\modlib\TheForest\TheForest_data\Managed\Bolt.dll'
$boltUserAssembly = Join-Path $root 'modapi-workspace\modlib\TheForest\TheForest_data\Managed\bolt.user.dll'
$udpAssembly = Join-Path $root 'modapi-workspace\modlib\TheForest\TheForest_data\Managed\udpkit.dll'
$firstpassAssembly = Join-Path $root 'modapi-workspace\modlib\TheForest\TheForest_data\Managed\Assembly-CSharp-firstpass.dll'
$legacyManaged = Join-Path $root 'modapi-workspace\gamefiles\original\TheForest\TheForest_data\Managed'
$legacyCore = Join-Path $legacyManaged 'mscorlib.dll'
$legacySystem = Join-Path $legacyManaged 'System.dll'
$legacyLinq = Join-Path $legacyManaged 'System.Core.dll'
$legacyXml = Join-Path $legacyManaged 'System.Xml.dll'
# Target the game's Mono API, not the newer Framework installed on this PC.
& $compiler /noconfig /nologo /nostdlib+ /target:library /optimize+ /out:$outputDll "/reference:$legacyCore" "/reference:$legacySystem" "/reference:$legacyLinq" "/reference:$legacyXml" "/reference:$baseModLib" "/reference:$unityEngine" "/reference:$gameAssembly" "/reference:$gameModding" "/reference:$boltAssembly" "/reference:$boltUserAssembly" "/reference:$udpAssembly" "/reference:$firstpassAssembly" $resources $source $motionSource $motionReaderSource $shoulderReaderSource $nativeActionsSource $nativeStateTableSource $playerSource $planeSource $voiceSource $voiceReaderSource $viewSource $interfaceSource $closureSource $dodgeCameraSource (Join-Path $PSScriptRoot 'CharacterProfile.cs') (Join-Path $PSScriptRoot 'CoopSync.cs') (Join-Path $PSScriptRoot 'CoopRemoteAvatar.cs') (Join-Path $PSScriptRoot 'DodgeRuntime.cs') (Join-Path $PSScriptRoot 'DodgeDiagnostics.cs') (Join-Path $PSScriptRoot 'Re3InventoryData.cs') (Join-Path $PSScriptRoot 'Re3InventoryRuntime.cs') (Join-Path $PSScriptRoot 'Re3InventoryNetwork.cs') (Join-Path $PSScriptRoot 'Re3InventoryUI.cs') (Join-Path $PSScriptRoot 'G19Runtime.cs') (Join-Path $PSScriptRoot 'G19Network.cs') (Join-Path $PSScriptRoot 'G19Audio.cs') (Join-Path $PSScriptRoot 'G19Presentation.cs') (Join-Path $PSScriptRoot 'Re3Weapon.cs') (Join-Path $PSScriptRoot 'Re3WeaponAssets.cs') (Join-Path $PSScriptRoot 'Re3Ballistics.cs') (Join-Path $PSScriptRoot 'Re3WeaponPose.cs') (Join-Path $PSScriptRoot 'Re3EnemyBalance.cs') (Join-Path $PSScriptRoot 'Re3RocketRuntime.cs') (Join-Path $PSScriptRoot 'Re3InventoryLifecycle.cs') (Join-Path $PSScriptRoot 'Re3FriendlyFire.cs') (Join-Path $PSScriptRoot 'Re3CoopOptions.cs') (Join-Path $PSScriptRoot 'Re3DeveloperTools.cs')
if ($LASTEXITCODE -ne 0) { throw "La compilación de la prueba visual falló con código $LASTEXITCODE." }

$packageProbe = Join-Path $PSScriptRoot 'PackageJillVisualProbe.cs'
$packageWorkspace = Join-Path $workspace 'work\forest-re3-mashup\modapi-workspace'
$packageBuildDirectory = Join-Path $packageWorkspace 'build'
$packageProbeDll = Join-Path $packageBuildDirectory 'ForestRE3JillVisualProbe.dll'
New-Item -ItemType Directory -Path $packageBuildDirectory -Force | Out-Null
Copy-Item -LiteralPath $outputDll -Destination $packageProbeDll -Force
$packageProbeExe = Join-Path $packageWorkspace 'PackageJillVisualProbe.exe'
$modApiDll = Join-Path $workspace 'work\tools\ModAPI\app\ModAPI.exe'
$dataDll = Join-Path $workspace 'work\tools\ModAPI\app\ModAPI_Shared.dll'
$cecilDll = Join-Path $workspace 'work\tools\ModAPI\app\Mono.Cecil.dll'
& $compiler /nologo /target:exe /out:$packageProbeExe "/reference:$modApiDll" "/reference:$dataDll" "/reference:$baseModLib" "/reference:$cecilDll" $packageProbe $motionReaderSource $shoulderReaderSource $voiceReaderSource
if ($LASTEXITCODE -ne 0) { throw "La compilación del empaquetador falló con código $LASTEXITCODE." }

Push-Location $packageWorkspace
try {
    & $packageProbeExe
    if ($LASTEXITCODE -ne 0) { throw "El empaquetado ModAPI falló con código $LASTEXITCODE." }
}
finally {
    Pop-Location
}

Get-FileHash -Algorithm SHA256 -LiteralPath $outputDll

