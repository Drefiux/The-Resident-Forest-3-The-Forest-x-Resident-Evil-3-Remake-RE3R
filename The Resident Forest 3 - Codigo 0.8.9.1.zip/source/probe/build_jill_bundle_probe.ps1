﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$workspace = (Resolve-Path -LiteralPath (Join-Path $root '..\..')).Path
$source = Join-Path $PSScriptRoot 'ForestRE3JillBundleProbe.cs'
$outputDirectory = Join-Path $root 'build'
$outputDll = Join-Path $outputDirectory 'ForestRE3JillBundleProbe.dll'
$bundle = Join-Path $workspace 'outputs\forest-re3-mashup\unity-pipeline\Assets\AssetBundles\forest-re3-jill'
$baseModLib = Join-Path $workspace 'work\tools\ModAPI\app\libs\BaseModLib.dll'
$unityEngine = Join-Path $workspace 'work\tools\ModAPI\app\libs\UnityEngine.dll'
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'

if (-not (Test-Path -LiteralPath $bundle -PathType Leaf)) { throw "No se encontró el AssetBundle local: $bundle" }
if (-not (Test-Path -LiteralPath $baseModLib -PathType Leaf)) { throw 'No se encontró BaseModLib.dll de ModAPI.' }
if (-not (Test-Path -LiteralPath $unityEngine -PathType Leaf)) { throw 'No se encontró UnityEngine.dll de ModAPI.' }
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) { throw 'No se encontró el compilador C# de .NET Framework.' }

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
$resource = '/resource:' + $bundle + ',ForestRE3JillBundleProbe.forest-re3-jill'
& $compiler /nologo /target:library /optimize+ /out:$outputDll "/reference:$baseModLib" "/reference:$unityEngine" $resource $source
if ($LASTEXITCODE -ne 0) { throw "La compilación del sondeo falló con código $LASTEXITCODE." }

$packageProbe = Join-Path $PSScriptRoot 'PackageJillBundleProbe.cs'
$packageWorkspace = Join-Path $workspace 'work\forest-re3-mashup\modapi-workspace'
$packageBuildDirectory = Join-Path $packageWorkspace 'build'
$packageProbeDll = Join-Path $packageBuildDirectory 'ForestRE3JillBundleProbe.dll'
New-Item -ItemType Directory -Path $packageBuildDirectory -Force | Out-Null
Copy-Item -LiteralPath $outputDll -Destination $packageProbeDll -Force
$packageProbeExe = Join-Path $packageWorkspace 'PackageJillBundleProbe.exe'
$modApiDll = Join-Path $workspace 'work\tools\ModAPI\app\ModAPI.exe'
$dataDll = Join-Path $workspace 'work\tools\ModAPI\app\ModAPI_Shared.dll'
$cecilDll = Join-Path $workspace 'work\tools\ModAPI\app\Mono.Cecil.dll'
& $compiler /nologo /target:exe /out:$packageProbeExe "/reference:$modApiDll" "/reference:$dataDll" "/reference:$baseModLib" "/reference:$cecilDll" $packageProbe
if ($LASTEXITCODE -ne 0) { throw "La compilación del empaquetador falló con código $LASTEXITCODE." }

Push-Location $packageWorkspace
try {
    & $packageProbeExe
    if ($LASTEXITCODE -ne 0) { throw "El empaquetado ModAPI falló con código $LASTEXITCODE." }
}
finally {
    Pop-Location
}

Get-FileHash -Algorithm SHA256 -LiteralPath $outputDll
