﻿using System;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace ForestRE3JillBundleProbe
{
    public static class EntryPoints
    {
        private const string BundleResourceName = "ForestRE3JillBundleProbe.forest-re3-jill";

        [ModAPI.Attributes.ExecuteOnGameStart]
        public static void OnGameStart()
        {
            try
            {
                byte[] bundleBytes;
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(BundleResourceName))
                {
                    if (stream == null)
                    {
                        ModAPI.Log.Write("[ForestRE3] Bundle probe could not find its embedded AssetBundle resource.");
                        return;
                    }

                    if (stream.Length > int.MaxValue)
                        throw new InvalidOperationException("Embedded AssetBundle is larger than the supported byte-array limit.");
                    bundleBytes = new byte[(int)stream.Length];
                    int offset = 0;
                    while (offset < bundleBytes.Length)
                    {
                        int read = stream.Read(bundleBytes, offset, bundleBytes.Length - offset);
                        if (read <= 0)
                            throw new EndOfStreamException("Unexpected end of embedded AssetBundle resource.");
                        offset += read;
                    }
                }

                AssetBundle bundle = AssetBundle.LoadFromMemory(bundleBytes);
                if (bundle == null)
                {
                    ModAPI.Log.Write("[ForestRE3] Bundle probe failed: AssetBundle.LoadFromMemory returned null.");
                    return;
                }

                UnityEngine.Object[] assets = bundle.LoadAllAssets();
                int prefabCount = 0;
                string foundPrefab = "";
                for (int i = 0; i < assets.Length; i++)
                {
                    GameObject prefab = assets[i] as GameObject;
                    if (prefab != null)
                    {
                        prefabCount++;
                        if (prefab.name == "JillAvatarPreview")
                            foundPrefab = prefab.name;
                    }
                }

                ModAPI.Log.Write("[ForestRE3] Bundle probe loaded AssetBundle; assets=" + assets.Length + ", prefabs=" + prefabCount + ".");
                if (foundPrefab.Length > 0)
                    ModAPI.Log.Write("[ForestRE3] Bundle probe found prefab " + foundPrefab + ". No scene objects or saves were changed.");
                else
                    ModAPI.Log.Write("[ForestRE3] Bundle probe did not find JillAvatarPreview among loaded assets.");

                bundle.Unload(false);
            }
            catch (Exception exception)
            {
                ModAPI.Log.Write("[ForestRE3] Bundle probe exception: " + exception);
            }
        }
    }
}
