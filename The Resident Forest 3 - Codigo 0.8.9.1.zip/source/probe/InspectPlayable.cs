﻿using System;
using System.Linq;
using Mono.Cecil;

internal static class InspectPlayable
{
    public static void Main(string[] args)
    {
        using (var module = ModuleDefinition.ReadModule(args[0]))
            foreach (var type in module.Types.Where(t => args[1].Split(',').Contains(t.Name)))
            {
                Console.WriteLine("TYPE " + type.FullName);
                foreach (var field in type.Fields) Console.WriteLine("FIELD " + field.Attributes + " " + field.FullName);
                foreach (var method in type.Methods)
                {
                    Console.WriteLine("METHOD " + method.Attributes + " " + method.FullName);
                    if (!method.HasBody || args.Length < 3 || !args[2].Split(',').Contains(method.Name)) continue;
                    foreach (var instruction in method.Body.Instructions) Console.WriteLine(instruction);
                }
            }
    }
}
