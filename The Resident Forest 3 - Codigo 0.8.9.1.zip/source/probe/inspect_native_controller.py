﻿"""Read Unity 5.6 serialized object metadata and controller string tables.

Read-only local inspection; no meshes, textures or clips are copied.
"""
import json
import re
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
GAME = Path(r'C:\Program Files (x86)\Steam\steamapps\common\The Forest\TheForest_Data')


class Reader:
    def __init__(self, value):
        self.value, self.at = value, 0

    def number(self, fmt):
        value = struct.unpack_from('<'+fmt, self.value, self.at)[0]
        self.at += struct.calcsize(fmt)
        return value

    def cstring(self):
        end = self.value.index(b'\0', self.at)
        value = self.value[self.at:end].decode('utf-8')
        self.at = end+1
        return value

    def align(self):
        self.at = (self.at+3)//4*4


def strings(blob):
    # Unity aligned strings have an explicit little-endian byte count. Avoid
    # accepting arbitrary printable fragments of binary animation data.
    result = []
    for match in re.finditer(rb'[A-Za-z_][A-Za-z0-9_. /()\-]{2,180}', blob):
        offset = match.start()
        if offset < 4:
            continue
        count = struct.unpack_from('<I', blob, offset-4)[0]
        if count == len(match[0]):
            result.append(match[0].decode('ascii'))
    return result


def inspect(path):
    with path.open('rb') as stream:
        header = stream.read(20)
        size, _, version, data_offset = struct.unpack('>4I', header[:16])
        if version != 17 or header[16] != 0:
            raise ValueError(f'Unsupported version/endian {version}/{header[16]}')
        meta = Reader(stream.read(size))
        unity = meta.cstring()
        meta.number('i')  # build platform
        tree = meta.number('B')
        types = []
        for _ in range(meta.number('i')):
            class_id = meta.number('i')
            meta.number('B'); meta.number('h')
            if class_id == 114:
                meta.at += 16
            meta.at += 16
            if tree:
                nodes, string_bytes = meta.number('i'), meta.number('i')
                meta.at += nodes*24+string_bytes
            types.append(class_id)
        objects = []
        for _ in range(meta.number('i')):
            meta.align()
            path_id = meta.number('q')
            start, byte_count, type_id = meta.number('I'), meta.number('I'), meta.number('i')
            if types[type_id] in (74, 91):
                objects.append((path_id, start+data_offset, byte_count, types[type_id]))
        result = []
        for path_id, start, byte_count, class_id in objects:
            stream.seek(start)
            blob = stream.read(byte_count if class_id == 91 else min(byte_count, 256))
            values = strings(blob)
            if values:
                result.append(dict(pathId=path_id, classId=class_id, strings=values))
        return dict(file=path.name, unityVersion=unity, objects=result)


if __name__ == '__main__':
    inspected, errors = [], []
    for path in sorted(GAME.glob('*.assets')) + [GAME/'globalgamemanagers', GAME/'globalgamemanagers.assets']:
        if not path.is_file():
            continue
        try:
            inspected.append(inspect(path))
        except (ValueError, IndexError, struct.error) as error:
            errors.append(dict(file=path.name, error=str(error)))
    report = dict(files=inspected, errors=errors)
    output = ROOT/'work/forest-re3-mashup/native-controller-metadata.json'
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    for file in inspected:
        for obj in file['objects']:
            if obj['classId'] == 91 and any('fullBodyActions' in s or 'axeAttackGround1' in s for s in obj['strings']):
                print(json.dumps(dict(file=file['file'], **obj), ensure_ascii=False))
    print(f'Inspected {len(inspected)} files; {len(errors)} unsupported/errors; metadata saved to {output}')
