﻿using System;
using System.IO;
using System.Linq;
using Mono.Cecil;

// Compile-time visibility only. The launcher patches the original method in
// place through ModAPI; this reference is never installed or redistributed.
internal static class PrepareDodgeReference
{
    public static void Main(string[] args)
    {
        var resolver=new DefaultAssemblyResolver(); resolver.AddSearchDirectory(Path.GetDirectoryName(args[0]));
        resolver.AddSearchDirectory(args[2]);
        using (var module=ModuleDefinition.ReadModule(args[0],new ReaderParameters { AssemblyResolver=resolver }))
        {
            var method=module.Types.Single(t => t.Name=="enemyWeaponMelee").Methods.Single(m => m.Name=="OnTriggerEnter");
            method.IsPublic=true; method.IsVirtual=true; method.IsNewSlot=true;
            var controller=module.Types.Single(t => t.Name=="FirstPersonCharacter");
            foreach (string name in new[] { "DetermineVelocityChange","ClampVelocity","HandleFrictionParams" })
            {
                var motor=controller.Methods.Single(m => m.Name==name);
                motor.IsPublic=true; motor.IsVirtual=true; motor.IsNewSlot=true;
            }
            var save=module.Types.Single(t => t.FullName=="TheForest.Items.Inventory.PlayerInventory").Methods.Single(m => m.Name=="OnSerializing");
            save.IsPublic=true; save.IsVirtual=true; save.IsNewSlot=true;
            var health=module.Types.Single(t => t.Name=="EnemyHealth");
            foreach(string name in new[] {"OnEnable","Update"})
            {var hook=health.Methods.Single(m => m.Name==name);hook.IsPublic=true;hook.IsVirtual=true;hook.IsNewSlot=true;}
            foreach(var entry in new[]{new[]{"Bomb","Start"},new[]{"Explode","RunExplode"}})
            {var hook=module.Types.Single(t=>t.Name==entry[0]).Methods.Single(m=>m.Name==entry[1]);hook.IsPublic=true;hook.IsVirtual=true;hook.IsNewSlot=true;}
            var playerExplosion=module.Types.Single(t=>t.Name=="PlayerStats").Methods.Single(m=>m.Name=="Explosion" && m.Parameters.Count==2);
            playerExplosion.IsPublic=true;playerExplosion.IsVirtual=true;playerExplosion.IsNewSlot=true;
            foreach(var entry in new[]{new[]{"PlayerRespawnMP","Respawn"},new[]{"StealItemTrigger","Update"}})
            {var hook=module.Types.Single(t=>t.Name==entry[0]).Methods.Single(m=>m.Name==entry[1]);hook.IsPublic=true;hook.IsVirtual=true;hook.IsNewSlot=true;}
            Directory.CreateDirectory(Path.GetDirectoryName(args[1])); module.Write(args[1]);
        }
    }
}
