﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace ForestRE3JillVisualProbe
{
    // Route the evaluated native pose, rather than replaying individual clips.
    // Current AND destination states on every contributing layer retain the
    // charge/release/recovery and attach/loop/detach portions of an action.
    internal sealed class JillNativeActions
    {
        internal enum GroundSupport { Feet, Body, Free }
        private sealed class Layer
        {
            public readonly List<AnimatorClipInfo> current = new List<AnimatorClipInfo>(16);
            public readonly List<AnimatorClipInfo> next = new List<AnimatorClipInfo>(16);
            public string name;
        }
        private sealed class Clip
        {
            public string name, action;
        }
        private readonly Animator animator;
        private readonly bool useLocalPlayer;
        private readonly IPlayerState remoteState;
        private readonly Layer[] layers;
        private readonly HashSet<string> bools = new HashSet<string>(StringComparer.Ordinal);
        private readonly Dictionary<int, Clip> clips = new Dictionary<int, Clip>();
        private readonly Dictionary<int, Clip> states = new Dictionary<int, Clip>();
        private readonly HashSet<int> heldStates = new HashSet<int>();
        private readonly Dictionary<int, string> tags = new Dictionary<int, string>();
        private float releaseUntil;
        private string previousAction = "", recoveryAction = "", signature = "", dominantState = "";
        private GroundSupport recoverySupport;
        internal string Action = "";
        internal GroundSupport Support = GroundSupport.Feet;
        internal bool Native, Airborne, Impact;
        internal bool HeldPose;
        internal string Phase = "";
        internal string StateDescription = "";

        private static readonly string[] ActionBools = {
            "chargingBool", "doAttackHeavyBool", "heavyAttackBool", "swimmingBool", "swimDiveBool",
            "jumpBool", "climbBool", "climbTopBool", "exitClimbTopBool", "injuredBool",
            "bookHeld", "lookAtPhoto", "lookAtItem", "lookAtItemRight", "logHeld", "bodyHeld",
            "hangGliderHeld", "zipLineAttach", "craneAttach", "shellRideBool", "dragAwayBool",
            "deathBool", "deathFromInjuredBool", "hangingBool", "drawBowBool", "spearThrowBool",
            "aimSlingBool", "parryBool", "fillPotBool", "mapHeld", "onHand"
        };

        internal JillNativeActions(Animator source) : this(source, true, null) { }
        internal JillNativeActions(Animator source, bool local, IPlayerState state)
        {
            animator = source;
            useLocalPlayer=local; remoteState=state;
            layers = new Layer[source.layerCount];
            for (int i = 0; i < layers.Length; i++) layers[i] = new Layer { name = source.GetLayerName(i) };
            foreach (AnimatorControllerParameter parameter in source.parameters)
                if (parameter.type == AnimatorControllerParameterType.Bool) bools.Add(parameter.name);
            foreach (string tag in new[] { "swimming", "climbing", "climbIdle", "enterClimb", "climbOut",
                "explode", "knockBack", "death", "hanging", "attacking", "smash", "block", "onSled" })
                tags[Animator.StringToHash(tag)] = TagAction(tag);
            string[,] definitions = JillNativeStateTable.Definitions;
            for (int i = 0; i < definitions.GetLength(0); i++)
                states.Add(Animator.StringToHash(definitions[i,0]), new Clip { name = definitions[i,0], action = definitions[i,1] });
            foreach (string name in new[] { "artifactIdle", "ballIdle", "bowIdle", "camCorderIdle", "chainSawIdle",
                "crossbowIdle", "flameThrowerIdle", "flareGunIdle", "flareIdle", "flashLightIdle", "flintlockIdle",
                "genericHoldIdle", "holdWideIdle", "laserPointerIdle", "lighterIdle", "molotovIdle", "potHeldIdle",
                "rockIdle", "rockIdleHigh", "shellHeldIdle", "slingShotIdle", "spearIdle", "spearIdleHigh",
                "stickJabIdle", "waterSkinHeldIdle", "walkmanIdle" }) heldStates.Add(Animator.StringToHash("upperBody."+name));
            foreach (string name in new[] { "flashlightIdle", "lighterIdle", "pedometerIdle", "sapIdle", "walkmanIdle", "walkmanIdle 0" })
                heldStates.Add(Animator.StringToHash("leftArm."+name));
            heldStates.Add(Animator.StringToHash("fullBodyActions.rockIdle"));
            if (source.runtimeAnimatorController != null)
                foreach (AnimationClip clip in source.runtimeAnimatorController.animationClips) Describe(clip);
            ModAPI.Log.Write("[ForestRE3] NATIVE_ACTION_ROUTER_READY layers=" + layers.Length
                + "; clips=" + clips.Count + "; knownStates=" + states.Count + "; currentAndNext=true; allWeightedLayers=true; unknownActions=native; locomotion=RE3");
            foreach (string name in ActionBools)
                ModAPI.Log.Write("[ForestRE3] NATIVE_ACTION_PARAMETER name=" + name + "; present=" + bools.Contains(name));
        }

        private bool Bool(string name) { return bools.Contains(name) && animator.GetBool(name); }
        private static string TagAction(string tag)
        {
            if (tag == "swimming") return "nadar";
            if (tag.StartsWith("climb", StringComparison.Ordinal) || tag == "enterClimb") return "escalar";
            if (tag == "explode" || tag == "knockBack") return "impacto";
            if (tag == "death" || tag == "hanging") return "derribo";
            if (tag == "onSled") return "transporte";
            return "combate";
        }

        // Action terms precede neutral locomotion terms: swimIdle, climbWalk,
        // injuredIdle and aimIdle must never be mistaken for RE idle/walk.
        private static string ClipAction(string name)
        {
            string n = name.ToLowerInvariant();
            if (Has(n, "swim", "dive", "underwater", "waterjump")) return "nadar";
            if (Has(n, "climb", "rope", "ladder")) return "escalar";
            if (Has(n, "explode", "explosion", "knockback", "knock_back", "gethit", "gothit", "hitreact", "hit_react", "getup", "get_up", "landheavy")) return "impacto";
            if (Has(n, "death", "dead", "dying", "injur", "dragaway", "hanging", "falling", "knockdown")) return "derribo";
            if (Has(n, "jump", "fall", "land")) return "salto";
            if (Has(n, "book", "map", "photo", "lookat", "lookitem", "checkblood", "checkarm", "checkitem", "onhand")) return "interaccion";
            if (Has(n, "eat", "drink", "fillpot", "fillwater", "wash", "meds")) return "consumir";
            if (Has(n, "sled", "raft", "paddle", "oar", "rowboat", "rowing", "zipline", "crane", "glider", "shellride")) return "transporte";
            if (Has(n, "carry", "pickup", "pick_up", "skinn", "harvest", "chop", "puttimmy", "reviv", "repair", "build", "craft", "place", "throw")) return "interaccion";
            if (Has(n, "attack", "charge", "combo", "smash", "swing", "block", "parry", "aim", "drawbow", "shoot", "fire", "reload", "lightweapon", "flarelight", "chainsaw", "slingshot")) return "combate";
            if (Has(n, "crouch", "duck", "standup", "stand_up")) return "agacharse";
            if (Has(n, "sit", "bench", "wake", "sleep", "planecrash", "cutscene")) return "interaccion";
            // Empty layers, held-weapon neutral poses and locomotion allow the
            // three already accepted RE clips. Other clips are native by default.
            if (Has(n, "idle", "walk", "run", "sprint", "jog", "loco", "strafe", "turn", "empty", "default", "neutral", "tpose", "t_pose", "hold", "held")) return "";
            return "accion";
        }
        private static bool Has(string value, params string[] terms)
        {
            foreach (string term in terms) if (value.IndexOf(term, StringComparison.Ordinal) >= 0) return true;
            return false;
        }
        private Clip Describe(AnimationClip clip)
        {
            int id = clip.GetInstanceID(); Clip result;
            if (clips.TryGetValue(id, out result)) return result;
            result = new Clip { name = clip.name, action = ClipAction(clip.name) };
            clips.Add(id, result);
            ModAPI.Log.Write("[ForestRE3] NATIVE_CLIP_CATALOG name=" + result.name + "; category="
                + (result.action.Length == 0 ? "neutral_RE_allowed" : result.action) + "; duration=" + clip.length);
            return result;
        }
        private static int Priority(string action)
        {
            switch (action) {
                case "impacto": case "derribo": return 90;
                case "escalar": return 80;
                case "nadar": return 70;
                case "salto": return 60;
                case "transporte": return 50;
                case "combate": return 40;
                case "consumir": case "interaccion": return 30;
                case "agacharse": return 20;
                case "accion": return 10;
                default: return 0;
            }
        }
        private void Choose(string action)
        {
            if (Priority(action) > Priority(Action)) Action = action;
        }
        private void Observe(int layer, bool destination, AnimatorStateInfo state, List<AnimatorClipInfo> values, bool contributing)
        {
            Clip definition;
            bool known = states.TryGetValue(state.fullPathHash, out definition);
            if (contributing)
            {
                if (heldStates.Contains(state.fullPathHash)) HeldPose = true;
                if (known)
                {
                    if (definition.action.Length != 0 && Priority(definition.action) >= Priority(Action)) dominantState = definition.name;
                    Choose(definition.action);
                    if (definition.action.Length != 0)
                        StateDescription += (StateDescription.Length == 0 ? "" : " | ")
                            + (destination ? "next=" : "current=") + definition.name;
                }
                else
                {
                    string tag;
                    if (tags.TryGetValue(state.tagHash, out tag)) Choose(tag);
                }
            }
            foreach (AnimatorClipInfo value in values)
            {
                if (value.clip == null) continue;
                Clip clip = Describe(value.clip);
                // Exact state classifications also identify neutral additive
                // spine and arm layers whose clip names do not contain 'idle'.
                if (known) continue;
                // Destination clips can have zero weight at the very beginning
                // of a crossfade. Observe them once their layer contributes.
                if (!contributing || (!destination && value.weight <= .001f)) continue;
                if (clip.action.Length == 0) continue;
                Choose(clip.action);
                StateDescription += (StateDescription.Length == 0 ? "" : " | ") + layers[layer].name
                    + (destination ? ":next=" : ":current=") + clip.name;
            }
        }

        internal void Read()
        {
            Action = ""; StateDescription = ""; Phase = ""; dominantState = ""; Airborne = Impact = HeldPose = false;
            FirstPersonCharacter fpc = useLocalPlayer ? TheForest.Utils.LocalPlayer.FpCharacter : null;
            playerAnimatorControl control = useLocalPlayer ? TheForest.Utils.LocalPlayer.AnimControl : null;
            PlayerStats stats = useLocalPlayer ? TheForest.Utils.LocalPlayer.Stats : null;
            bool swimming = fpc != null && (fpc.swimming || fpc.Diving);
            if (remoteState!=null)
            {
                swimming=remoteState.inWater;
                if (remoteState.crouch>.1f) Choose("agacharse");
            }
            bool climbing = false;
            if (fpc != null)
            {
                if (fpc.crouching) Choose("agacharse");
                if (fpc.drinking) Choose("consumir");
                if (!fpc.Grounded || fpc.jumping) { Airborne = true; Choose("salto"); }
            }
            if (control != null)
            {
                swimming |= control.swimming;
                climbing = control.onRope || control.cliffClimb;
                if (control.knockedDown || control.injured || control.upsideDown) Choose("derribo");
                if (control.introCutScene || control.skinningAnimal || control.holdingGirl || control.carry || control.sitting
                    || control.loadingAnimation || control.enteringACave || control.exitingACave || control.endGameCutScene) Choose("interaccion");
                if (control.doSledPushMode || control.doShellRideMode || control.flyingGlider || control.holdingGlider
                    || (fpc != null && fpc.SailingRaft)) Choose("transporte");
                if (control.PlayerIsAttacking()) Choose("combate");
                // Root motion owns important action intervals before their tag
                // appears and after it disappears (e.g. explosion recovery).
                if (control.useRootMotion) Choose("accion");
            }
            if (stats != null && stats.Dead) Choose("derribo");
            if (swimming) Choose("nadar");
            if (climbing) Choose("escalar");
            foreach (string name in ActionBools)
                if (Bool(name))
                {
                    string action = ClipAction(name);
                    if (name == "injuredBool" || name == "dragAwayBool" || name == "hangingBool") action = "derribo";
                    if (name == "logHeld" || name == "bodyHeld") action = "interaccion";
                    Choose(action.Length == 0 ? "accion" : action);
                }
            for (int i = 0; i < layers.Length; i++)
            {
                bool contributing = i == 0 || animator.GetLayerWeight(i) > .001f;
                animator.GetCurrentAnimatorClipInfo(i, layers[i].current);
                Observe(i, false, animator.GetCurrentAnimatorStateInfo(i), layers[i].current, contributing);
                if (animator.IsInTransition(i))
                {
                    animator.GetNextAnimatorClipInfo(i, layers[i].next);
                    Observe(i, true, animator.GetNextAnimatorStateInfo(i), layers[i].next, contributing);
                }
            }
            Impact = Action == "impacto" || Action == "derribo";
            Support = swimming || climbing || Action == "nadar" || Action == "escalar"
                || (!Impact && Airborne) ? GroundSupport.Free : (Impact ? GroundSupport.Body : GroundSupport.Feet);
            if (Action.Length != 0)
            {
                releaseUntil = Time.time + .12f; recoveryAction = Action; recoverySupport = Support;
                string stateName = dominantState.ToLowerInvariant();
                if (Bool("chargingBool") || stateName.Contains("windup")) Phase = "carga";
                else if (Has(stateName, "standup", "getup")) Phase = "recuperacion";
                else if (Has(stateName, "toidle", "exit", "close", "return")) Phase = "salida";
                else if (Bool("doAttackHeavyBool") || Bool("heavyAttackBool")) Phase = "liberacion";
                else if (Has(stateName, "idleto", "enter") || stateName.Substring(stateName.LastIndexOf('.')+1).StartsWith("to", StringComparison.Ordinal)) Phase = "entrada";
                else if (Has(stateName, "loop", "idle")) Phase = "ciclo";
                else Phase = "accion";
            }
            else if (Time.time < releaseUntil)
            {
                Action = recoveryAction; Support = recoverySupport; Phase = "salida";
                Impact = Action == "impacto" || Action == "derribo";
            }
            Native = Action.Length != 0;
            string nextSignature = Action + ";" + Phase + ";" + StateDescription + ";held=" + HeldPose;
            if (nextSignature != signature)
            {
                signature = nextSignature;
                ModAPI.Log.Write("[ForestRE3] NATIVE_ACTION action=" + (Native ? Action : "locomocion_RE")
                    + "; phase=" + Phase + "; support=" + Support + "; previous=" + previousAction
                    + "; heldPose="+HeldPose+"; states=" + StateDescription);
                previousAction = Action;
            }
        }

        internal void LogPose()
        {
            ModAPI.Log.Write("[ForestRE3] PAUSED_ACTION action=" + Action + "; phase=" + Phase + "; support=" + Support + "; states=" + StateDescription);
            for (int i = 0; i < layers.Length; i++)
            {
                AnimatorStateInfo state = animator.GetCurrentAnimatorStateInfo(i);
                ModAPI.Log.Write("[ForestRE3] PAUSED_NATIVE_STATE layer=" + layers[i].name + "; weight=" + animator.GetLayerWeight(i)
                    + "; current=" + state.fullPathHash + "; tag=" + state.tagHash + "; time=" + state.normalizedTime
                    + "; transition=" + animator.IsInTransition(i));
                if (animator.IsInTransition(i))
                {
                    state = animator.GetNextAnimatorStateInfo(i);
                    ModAPI.Log.Write("[ForestRE3] PAUSED_NATIVE_NEXT layer=" + layers[i].name + "; state=" + state.fullPathHash
                        + "; tag=" + state.tagHash + "; time=" + state.normalizedTime);
                }
            }
        }
    }
}
