﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using ModAPI.Configurations;
using ModAPI.Data;
using ModAPI.Data.Models;

internal static class PackageJillVisualProbe
{
    private static string appRoot;

    // ModAPI inserts the mod ID before each Log.Write call. Cecil does not
    // widen short branches automatically when those instructions move their
    // targets past +/-127 bytes, so normalize BEFORE ModProject.Create.
    private static void ExpandBranches(Mono.Cecil.TypeDefinition type)
    {
        foreach(var method in type.Methods)
        {
            if(!method.HasBody)continue;
            foreach(var instruction in method.Body.Instructions)
                switch(instruction.OpCode.Code)
                {
                    case Mono.Cecil.Cil.Code.Br_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Br;break;
                    case Mono.Cecil.Cil.Code.Brfalse_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Brfalse;break;
                    case Mono.Cecil.Cil.Code.Brtrue_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Brtrue;break;
                    case Mono.Cecil.Cil.Code.Beq_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Beq;break;
                    case Mono.Cecil.Cil.Code.Bge_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Bge;break;
                    case Mono.Cecil.Cil.Code.Bgt_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Bgt;break;
                    case Mono.Cecil.Cil.Code.Ble_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Ble;break;
                    case Mono.Cecil.Cil.Code.Blt_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Blt;break;
                    case Mono.Cecil.Cil.Code.Bne_Un_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Bne_Un;break;
                    case Mono.Cecil.Cil.Code.Bge_Un_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Bge_Un;break;
                    case Mono.Cecil.Cil.Code.Bgt_Un_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Bgt_Un;break;
                    case Mono.Cecil.Cil.Code.Ble_Un_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Ble_Un;break;
                    case Mono.Cecil.Cil.Code.Blt_Un_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Blt_Un;break;
                    case Mono.Cecil.Cil.Code.Leave_S: instruction.OpCode=Mono.Cecil.Cil.OpCodes.Leave;break;
                }
        }
        foreach(var nested in type.NestedTypes)ExpandBranches(nested);
    }

    private static void CopyWithLongBranches(string source,string destination)
    {
        using(var module=Mono.Cecil.ModuleDefinition.ReadModule(source))
        {
            foreach(var type in module.Types)ExpandBranches(type);
            module.Write(destination);
        }
        Console.WriteLine("PACKAGING_LONG_BRANCHES=true");
    }

    private static void InstallResolver()
    {
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs args)
        {
            var name = new AssemblyName(args.Name).Name + ".dll";
            var candidates = new[]
            {
                Path.Combine(appRoot, name),
                Path.Combine(appRoot, "libs", name),
                Path.Combine(appRoot, "libs", "polyfills", name)
            };
            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate)) return Assembly.LoadFrom(candidate);
            }
            return null;
        };
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    public static int Main()
    {
        try
        {
            appRoot = Path.GetFullPath(Directory.GetCurrentDirectory());
            InstallResolver();
            Require(Configuration.Load() == Configuration.ResultCode.Ok, "ModAPI no pudo cargar su configuración local.");

            Configuration.SetPath("OriginalGameFiles", Path.Combine(appRoot, "gamefiles", "original"), true);
            Configuration.SetPath("ModdedGameFiles", Path.Combine(appRoot, "gamefiles", "modded"), true);
            Configuration.SetPath("SavegameBackups", Path.Combine(appRoot, "gamefiles", "savegames"), true);
            Configuration.SetPath("Projects", Path.Combine(appRoot, "projects"), true);
            Configuration.SetPath("Mods", Path.Combine(appRoot, "mods"), true);
            Configuration.SetPath("ModLib", Path.Combine(appRoot, "modlib"), true);
            Configuration.SetPath("Libraries", Path.Combine(appRoot, "libs"), true);

            var game = new Game(Configuration.Games["TheForest"], true);
            game.GamePath = @"C:\Program Files (x86)\Steam\steamapps\common\The Forest";
            var versionsPath = Path.Combine(appRoot, "configs", "games", "TheForest", "Versions.xml");
            var versionElement = XDocument.Load(versionsPath).Root.Elements("version")
                .FirstOrDefault(e => (string)e.Attribute("id") == "1.11b");
            Require(versionElement != null, "No se encontró el registro local 1.11b.");
            var version = new Game.Versions.Version(versionElement);
            game.GameVersion = version;
            game.BackupVersion = version;
            game.ModLibrary = new ModLib(game);
            Require(game.ModLibrary.Exists && game.ModLibrary.GameVersion == "1.11b", "La biblioteca ModAPI no coincide con 1.11b.");

            const string projectId = "ForestRE3JillVisualProbe";
            var projectRoot = Path.Combine(Configuration.GetPath("Projects"), "TheForest", projectId);
            var modOutput = Path.Combine(Configuration.GetPath("Mods"), "TheForest");
            var project = new ModProject(game, projectId);
            project.Name.SetString("EN", "Forest RE3 Jill / Carlos - cooperative preview");
            project.Name.SetString("ES", "Forest RE3 Jill / Carlos - prueba cooperativa");
            project.Description.SetString("EN", "The Resident Forest 3 0.8.9.1: drag, swap and merge RE inventory items with host authority; corrected launcher icon; branded launcher and host-only optional developer tools. Coop protocol 9/catalog 0x08090001. Gameplay confirmation pending.");
            project.Description.SetString("ES", "The Resident Forest 3 0.8.9.1: arrastrar, intercambiar y apilar objetos con validación del host; icono del lanzamisiles corregido; iniciador renovado y herramientas de prueba opcionales sólo para host. Protocolo 9/catálogo 0x08090001. Confirmación en juego pendiente.");
            project.Version = "0.8.9.1";
            project.SaveConfiguration();
            Require(!project.SaveFailed, "ModAPI no pudo escribir la configuración del proyecto.");

            var modFolder = Path.Combine(projectRoot, "Mod");
            Directory.CreateDirectory(modFolder);
            var compiledDll = Path.Combine(appRoot, "build", "ForestRE3JillVisualProbe.dll");
            Require(File.Exists(compiledDll), "No se encontró la DLL de la prueba visual compilada.");
            CopyWithLongBranches(compiledDll, Path.Combine(modFolder, projectId + ".dll"));

            project.Create(null);
            var package = Directory.GetFiles(modOutput, "*.mod", SearchOption.TopDirectoryOnly)
                .Select(path => new FileInfo(path))
                .OrderByDescending(file => file.LastWriteTimeUtc)
                .FirstOrDefault(file => file.Name.StartsWith(projectId + "-0.8.9.1-", StringComparison.OrdinalIgnoreCase));
            Require(package != null && package.Exists, "ModAPI no generó el paquete .mod esperado.");

            var packagedMod = new Mod { Game = game, FileName = package.FullName };
            Require(packagedMod.Load() && packagedMod.Valid, "ModAPI no pudo volver a abrir el paquete .mod generado.");
            foreach (string space in new[] { "gamma", "linear" })
            {
                Require(packagedMod.Module.Resources.Any(resource => resource.Name == "ForestRE3JillVisualProbe.forest-re3-jill-" + space),
                    "El .mod no conserva el bundle " + space + ".");
                Require(packagedMod.Module.Resources.Any(resource => resource.Name == "ForestRE3JillVisualProbe.jill-first-person-surface-" + space),
                    "El .mod no conserva la superficie de primera persona " + space + ".");
            }
            Require(packagedMod.Module.Resources.Any(resource => resource.Name == "ForestRE3JillVisualProbe.jill-motion-preview.bin"),
                "El .mod no conserva las pistas de animacion.");
            var motionResource = (Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(resource => resource.Name == "ForestRE3JillVisualProbe.jill-motion-preview.bin");
            using (var motionStream = motionResource.GetResourceStream())
            {
                var motionData = ForestRE3JillVisualProbe.JillMotionDataReader.Read(motionStream);
                foreach (var clip in motionData.clips)
                    Console.WriteLine("PACKAGED_MOTION_READ_OK mode=" + clip.mode + "; tracks=" + clip.tracks.Length + "; bones=" + clip.bones.Length);
            }
            var shoulderResource = (Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(resource => resource.Name == "ForestRE3JillVisualProbe.jill-shoulder-correctives.bin");
            using (var shoulderStream = shoulderResource.GetResourceStream())
            {
                var samples = ForestRE3JillVisualProbe.JillShoulderDataReader.Read(shoulderStream);
                Console.WriteLine("PACKAGED_SHOULDER_READ_OK format=JSC1; samples="+samples[0].Length+"/"+samples[1].Length);
            }
            var voiceResource = (Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(resource => resource.Name == "ForestRE3JillVisualProbe.jill-voice-bank.bin");
            using (var voiceStream = voiceResource.GetResourceStream())
            {
                var samples = ForestRE3JillVisualProbe.JillVoiceDataReader.Read(voiceStream);
                Console.WriteLine("PACKAGED_VOICE_READ_OK format=JRV1; clips="+samples.Length+"; effort="+samples.Count(v => !v.hurt)+"; hurt="+samples.Count(v => v.hurt));
            }
            foreach (string space in new[] { "gamma", "linear" })
                Require(packagedMod.Module.Resources.Any(resource => resource.Name=="ForestRE3JillVisualProbe.forest-re3-carlos-"+space), "Missing Carlos bundle "+space);
            using (var stream=((Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(r => r.Name=="ForestRE3JillVisualProbe.carlos-motion-preview.bin")).GetResourceStream())
            {
                var motions=ForestRE3JillVisualProbe.JillMotionDataReader.Read(stream);
                Require(motions.clips.Length==3, "Carlos movement clips incomplete");
                Console.WriteLine("PACKAGED_CARLOS_MOTION clips="+motions.clips.Length);
            }
            using (var stream=((Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(r => r.Name=="ForestRE3JillVisualProbe.carlos-shoulder-correctives.bin")).GetResourceStream())
            {
                var shoulders=ForestRE3JillVisualProbe.JillShoulderDataReader.Read(stream);
                Console.WriteLine("PACKAGED_CARLOS_SHOULDERS samples="+shoulders[0].Length+"/"+shoulders[1].Length);
            }
            using (var stream=((Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(r => r.Name=="ForestRE3JillVisualProbe.carlos-voice-bank.bin")).GetResourceStream())
            {
                var voices=ForestRE3JillVisualProbe.JillVoiceDataReader.Read(stream);
                Require(voices.Any(v => v.hurt) && voices.Any(v => !v.hurt), "Carlos voice categories incomplete");
                Console.WriteLine("PACKAGED_CARLOS_VOICES effort="+voices.Count(v => !v.hurt)+"; hurt="+voices.Count(v => v.hurt));
            }
            Require(packagedMod.HeaderData.GetInjectIntos().Any(i => i.Method.Name == "PlayHurtSound"), "Falta la inyección del sonido de daño de Jill.");
            Console.WriteLine("PACKAGED_HURT_HOOK_OK method=PlayHurtSound");
            Require(packagedMod.HeaderData.GetAddClasses().Any(c => c.Type.Name=="CoopSync"), "CoopSync must remain a standalone component");
            Require(!packagedMod.HeaderData.GetInjectIntos().Any(i => i.Method.DeclaringType.Name=="CoopSync"), "CoopSync cannot modify every Bolt listener");
            var coopType=packagedMod.Module.Types.Single(t => t.Name=="CoopSync");
            foreach (string hook in new[] { "RegisterChannels", "IsNativeVoice", "Receive" })
                Require(coopType.Methods.Single(m => m.Name==hook).IsPublic, "Cross-assembly coop hook must be public: "+hook);
            Require(coopType.NestedTypes.Any(t => t.Name=="Callbacks" && t.BaseType.FullName=="Bolt.GlobalEventListener"), "Missing standalone nested Bolt listener");
            Console.WriteLine("PACKAGED_COOP_COMPONENT_AND_PUBLIC_HOOKS_OK");
            Require(packagedMod.HeaderData.GetAddClasses().Any(c => c.Type.Name=="DodgeRuntime"), "Dodge runtime must remain standalone");
            Require(packagedMod.HeaderData.GetAddClasses().Any(c => c.Type.Name=="DodgeDiagnostics"), "Missing dodge laboratory");
            Require(packagedMod.HeaderData.GetAddClasses().Any(c => c.Type.Name=="DodgeFirstPersonCamera"), "Missing animated eye camera");
            foreach (string hook in new[] { "DetermineVelocityChange", "ClampVelocity", "HandleFrictionParams" })
                Require(packagedMod.HeaderData.GetInjectIntos().Any(i => i.Method.DeclaringType.Name=="DodgeMotorPatch" && i.Method.Name==hook), "Missing native dodge motor hook: "+hook);
            foreach (string hook in new[] { "setCurrentAttacker", "hitFromEnemy", "Hit", "HealthChange" })
                Require(packagedMod.HeaderData.GetInjectIntos().Any(i => i.Method.DeclaringType.Name=="DodgeStatsPatch" && i.Method.Name==hook), "Missing dodge damage hook: "+hook);
            Require(packagedMod.HeaderData.GetInjectIntos().Any(i => i.Method.DeclaringType.Name=="DodgeEnemyWeaponPatch" && i.Method.Name=="OnTriggerEnter"), "Missing melee contact hook");
            foreach(var hook in new[]{new[]{"Re3DynamiteBombPatch","Start"},new[]{"Re3DynamiteBlastPatch","RunExplode"},new[]{"Re3EnemyHealthPatch","Explosion"}})
                Require(packagedMod.HeaderData.GetInjectIntos().Any(i=>i.Method.DeclaringType.Name==hook[0] && i.Method.Name==hook[1]),"Missing dynamite hook "+hook[0]+"/"+hook[1]);
            using(var stream=((Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(r=>r.Name=="ForestRE3JillVisualProbe.rocket-motions.bin")).GetResourceStream())
                Console.WriteLine("PACKAGED_ROCKET_CLIPS="+ForestRE3JillVisualProbe.JillMotionDataReader.ReadRocket(stream).clips.Length);
            Require(packagedMod.HeaderData.GetInjectIntos().Any(i=>i.Method.DeclaringType.Name=="Re3FriendlyFireStatsPatch" && i.Method.Name=="Explosion"),"Missing friendly fire explosion hook");
            foreach(var hook in new[]{new[]{"Re3InventoryRespawnPatch","Respawn"},new[]{"Re3InventoryBackpackPatch","Update"}})
                Require(packagedMod.HeaderData.GetInjectIntos().Any(i=>i.Method.DeclaringType.Name==hook[0] && i.Method.Name==hook[1]),"Missing RE inventory backpack hook "+hook[0]+"/"+hook[1]);
            using (var stream=((Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(r => r.Name=="ForestRE3JillVisualProbe.dodge-motions.bin")).GetResourceStream())
                Console.WriteLine("PACKAGED_DODGE_ROLLS="+ForestRE3JillVisualProbe.JillMotionDataReader.ReadDodge(stream).clips.Length);
            foreach (string character in new[] { "jill","carlos" })
                using (var stream=((Mono.Cecil.EmbeddedResource)packagedMod.Module.Resources.Single(r => r.Name=="ForestRE3JillVisualProbe."+character+"-dodge-voice.bin")).GetResourceStream())
                    Console.WriteLine("PACKAGED_DODGE_VOICE character="+character+"; clips="+ForestRE3JillVisualProbe.JillVoiceDataReader.ReadDodge(stream).Length);
            foreach (var injection in packagedMod.HeaderData.GetInjectIntos())
            {
                if (!injection.Method.HasBody) continue;
                int exits=injection.Method.Body.Instructions.Count(instruction => instruction.OpCode.Code == Mono.Cecil.Cil.Code.Ret);
                Require(exits == 1, "ModAPI requires one terminal return per injection: "+injection.Method.FullName);
            }
            Console.WriteLine("PACKAGED_INJECTIONS_SINGLE_RETURN=true");
            foreach (var expected in new[] {
                new { Type="JillPlayerSfxPatch", Method="PlayJumpSound", Count=1 },
                new { Type="JillPlayerSfxPatch", Method="PlayStaminaBreath", Count=1 },
                new { Type="JillPlayerSfxPatch", Method="PlayEvent", Count=2 },
                new { Type="JillFmodCommonPatch", Method="PlayOneshot", Count=3 },
                new { Type="JillFmodCommonPatch", Method="PlayOneshotNetworked", Count=1 },
                new { Type="JillFmodSystemPatch", Method="PlayOneShot", Count=1 },
                new { Type="JillVocalEmitterPatch", Method="Play", Count=1 },
                new { Type="CoopPlayerCallbacksPatch", Method="BoltStartBegin", Count=1 },
                new { Type="CoopPlayerCallbacksPatch", Method="StreamDataReceived", Count=1 },
                new { Type="JillFmodEventStartPatch", Method="start", Count=1 } })
            {
                int count=packagedMod.HeaderData.GetInjectIntos().Count(i => i.Method.DeclaringType.Name == expected.Type && i.Method.Name == expected.Method);
                Require(count == expected.Count, "Faltan ganchos vocales: "+expected.Type+"."+expected.Method);
                Console.WriteLine("PACKAGED_VOCAL_HOOK type="+expected.Type+"; method="+expected.Method+"; count="+count);
            }

            string backups = Path.GetFullPath(Path.Combine(appRoot, "package-backups", "before-g19-0.8.9.1"));
            Require(backups.StartsWith(appRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), "Ruta de respaldo fuera del proyecto.");
            Directory.CreateDirectory(backups);
            foreach (string old in Directory.GetFiles(modOutput, projectId + "-*.mod"))
            {
                string resolved = Path.GetFullPath(old);
                if (string.Equals(resolved, package.FullName, StringComparison.OrdinalIgnoreCase)) continue;
                Require(resolved.StartsWith(Path.GetFullPath(modOutput) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), "Paquete fuera del directorio previsto.");
                string destination = Path.Combine(backups, Path.GetFileName(old));
                if (File.Exists(destination)) destination += "." + DateTime.UtcNow.Ticks;
                File.Move(resolved, destination);
            }

            Console.WriteLine("PACKAGE=" + package.FullName);
            Console.WriteLine("SIZE=" + package.Length);
            Console.WriteLine("HOTKEY=F8");
            Console.WriteLine("EMBEDDED_BUNDLE_RESOURCES=Gamma+Linear");
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine(exception);
            return 1;
        }
    }
}

