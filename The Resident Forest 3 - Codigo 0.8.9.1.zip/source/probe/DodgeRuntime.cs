﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using TheForest.Utils;

namespace ForestRE3JillVisualProbe
{
    public sealed class DodgeAction
    {
        public byte clip;
        public uint sequence;
        public float localStart, serverStart;
        public Vector3 direction;
        public float Age { get { return Mathf.Max(0f, Time.time-localStart); } }
        public bool Playing { get { return Age<DodgeRuntime.AnimationSeconds; } }
    }

    // Owns a short action window; movement runs through the native motor.
    [DefaultExecutionOrder(11000)]
    public sealed class DodgeRuntime : MonoBehaviour
    {
        public const float InputSeconds=.12f, ImmuneSeconds=1f, AnimationSeconds=.90f, RecoverySeconds=1.15f;
        internal static DodgeRuntime Instance;
        internal static MotionClip[] Clips;
        private sealed class RootPath { internal float[] frames, distances; }
        private static RootPath[] paths;
        private sealed class Contact
        {
            internal global::PlayerStats stats;
            internal enemyWeaponMelee source;
            internal int damage, frame;
            internal float at;
            internal Vector3 origin;
            internal bool grounded;
        }
        private readonly List<Contact> contacts=new List<Contact>();
        private static readonly Dictionary<ulong,DodgeAction> remotes=new Dictionary<ulong,DodgeAction>();
        private FirstPersonCharacter owner;
        private DodgeAction action;
        private float armedUntil=-1f, armedAt=-1f, immuneUntil=-1f, recoverUntil=-1f, attackerAt=-1f;
        private enemyWeaponMelee attacker;
        private Vector3 contactOrigin;
        private bool hasOrigin, moved;
        private int inputFrame=-1, nextVariant;
        private uint sequence;
        private bool replaying;
        private string feedback="";
        private float feedbackUntil, logAt;
        private Vector3 lastVelocity;
        private Vector3 motorOrigin;
        private float motorScale, motorAge;
        private int motorSteps, blockedSteps;
        private PhysicMaterial rollMaterial;
        private float savedStaticFriction, savedDynamicFriction;
        private PhysicMaterialCombine savedFrictionCombine;
        private readonly Dictionary<Renderer,bool> equipment=new Dictionary<Renderer,bool>();
        public static bool Active { get { return Instance!=null && Instance.action!=null && Instance.action.Playing && Instance.owner==LocalPlayer.FpCharacter; } }
        public static bool Immune { get { return Instance!=null && Time.time<Instance.immuneUntil && Instance.owner==LocalPlayer.FpCharacter
            && LocalPlayer.Stats!=null && !LocalPlayer.Stats.Dead; } }
        internal static bool Busy { get { return Instance!=null && Time.time<Instance.recoverUntil && Instance.owner==LocalPlayer.FpCharacter; } }

        internal void Initialize()
        {
            using (Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.dodge-motions.bin"))
            {
                if (stream==null) throw new InvalidDataException("Missing dodge motions");
                Clips=JillMotionDataReader.ReadDodge(stream).clips;
            }
            Instance=this; owner=LocalPlayer.FpCharacter;
            paths=new RootPath[Clips.Length];
            for (int c=0;c<Clips.Length;c++)
            {
                MotionTrack root=null;
                foreach (MotionTrack track in Clips[c].tracks) if (track.bone=="root" && track.kind=="position") { root=track; break; }
                if (root==null || root.values.Length<8) throw new InvalidDataException("Missing authored roll root path");
                int count=root.values.Length/4;
                var path=new RootPath { frames=new float[count], distances=new float[count] };
                for (int k=0;k<count;k++)
                {
                    path.frames[k]=root.values[k*4];
                    if (k>0)
                    {
                        float x=root.values[k*4+1]-root.values[(k-1)*4+1],z=root.values[k*4+3]-root.values[(k-1)*4+3];
                        path.distances[k]=path.distances[k-1]+Mathf.Sqrt(x*x+z*z);
                    }
                }
                if (path.distances[count-1]<.1f) throw new InvalidDataException("Empty authored roll travel");
                paths[c]=path;
            }
            ModAPI.Log.Write("[ForestRE3] DODGE_READY version=0.8.9.1; F=Update_only; contact=LateUpdate_same_frame; input=.12; immunity=1; animation=.90; recovery=1.15; globalRolls=4; motor=native_acceleration; travel=authored_root; view=animated_eyes");
        }
        internal static DodgeAction Pose(BoltEntity remote)
        {
            if (remote==null) return Active ? Instance.action : null;
            DodgeAction value;
            return remote.isAttached && remotes.TryGetValue(remote.networkId.PackedValue,out value) && value.Playing ? value:null;
        }
        internal static void SetRemote(ulong id,DodgeAction value) { remotes[id]=value; }
        internal static void RemoveRemote(ulong id) { remotes.Remove(id); }
        internal static void ClearRemotes() { remotes.Clear(); }
        internal static void Reject(uint rejected)
        { if (Instance!=null && Instance.action!=null && Instance.action.sequence==rejected) Instance.Cancel(); }
        internal static float Travel(byte clip,float age)
        {
            RootPath path=paths[clip];
            float frame=Mathf.Clamp01(age/AnimationSeconds)*Clips[clip].frames;
            int low=0,high=path.frames.Length-1;
            while (low<high) { int mid=(low+high+1)/2; if (path.frames[mid]<=frame) low=mid; else high=mid-1; }
            int next=Math.Min(low+1,path.frames.Length-1);
            float length=path.frames[next]-path.frames[low];
            return Mathf.Lerp(path.distances[low],path.distances[next],length>0f ? Mathf.Clamp01((frame-path.frames[low])/length):0f);
        }
        internal static float AnimationWeight(float age)
        { return Mathf.Min(Mathf.SmoothStep(0f,1f,Mathf.Clamp01(age/.06f)),Mathf.SmoothStep(0f,1f,Mathf.Clamp01((AnimationSeconds-age)/.12f))); }
        internal static Quaternion Heading(DodgeAction value)
        {
            // L0/R0 roll forward; L180/R180 roll backward while facing the impact.
            return Quaternion.LookRotation((value.clip==1 || value.clip==3) ? -value.direction:value.direction,Vector3.up);
        }
        private static string BlockedReason(bool requireGround)
        {
            var fp=LocalPlayer.FpCharacter; var anim=LocalPlayer.AnimControl;
            if (Re3InventoryRuntime.BlockControls) return "inventario RE3R";
            if (JillPlayerAvatar.Current==null || !JillPlayerAvatar.Current.NetworkReady) return "preparando personaje";
            if (fp==null || !fp.gameObject.activeInHierarchy || fp.rb==null || fp.capsule==null) return "jugador no disponible";
            if (LocalPlayer.Stats==null || LocalPlayer.Stats.Dead) return "jugador muerto/no disponible";
            if (LocalPlayer.Inventory==null || LocalPlayer.Inventory.CurrentView!=TheForest.Items.Inventory.PlayerInventory.PlayerViews.World
                || LocalPlayer.IsInPauseMenu || Time.timeScale<=0f || !Application.isFocused) return "menu/pausa/sin foco";
            if (JillPlaneAvatar.CharacterLocked || anim==null || anim.introCutScene || anim.endGameCutScene) return "cinematica";
            if (fp.rb.isKinematic || fp.Locked || fp.MovementLocked) return "movimiento bloqueado";
            if (fp.SailingRaft || fp.PushingSled || fp.Diving || anim.onRope || anim.cliffClimb || anim.swimming || anim.upsideDown)
                return "accion incompatible";
            if (!CoopSync.CanStartDodge) return "esperando sincronizacion coop";
            if (requireGround && !Supported(fp)) return "sin apoyo en el suelo";
            return "";
        }
        private static bool Allowed(bool requireGround) { return BlockedReason(requireGround).Length==0; }
        private static bool Supported(FirstPersonCharacter fp)
        {
            if (fp.Grounded) return true;
            // Collision callbacks can update Grounded after the attack trigger.
            // Confirm actual support instead of trusting callback ordering.
            if (fp.jumping || fp.rb.velocity.y>1f) return false;
            Bounds bounds=fp.capsule.bounds;
            float radius=Mathf.Min(bounds.extents.x,bounds.extents.z)*.85f;
            int mask=fp.CollisionLayers.value; if (mask==0) mask=~0;
            foreach (RaycastHit hit in Physics.SphereCastAll(new Vector3(bounds.center.x,bounds.min.y+radius+.03f,bounds.center.z),
                radius,Vector3.down,.10f,mask,QueryTriggerInteraction.Ignore))
                if (hit.collider!=null && hit.collider.transform.root!=fp.transform.root && hit.normal.y>.65f) return true;
            return false;
        }
        private void Report(string value,string detail)
        {
            feedback=value; feedbackUntil=Time.unscaledTime+2f;
            if (Time.unscaledTime<logAt) return;
            logAt=Time.unscaledTime+.25f;
            ModAPI.Log.Write("[ForestRE3] DODGE_INPUT "+detail);
        }
        private void PollInput()
        {
            // Update is the only reader. Physics callbacks must not consume this
            // frame before Unity refreshes GetKeyDown for the rendered update.
            if (!UnityEngine.Input.GetKeyDown(KeyCode.F)) return;
            inputFrame=Time.frameCount;
            string reason=BlockedReason(true);
            if (Busy) reason="recuperacion";
            if (reason.Length>0)
                Report("F bloqueada: "+reason,"blocked="+reason+"; grounded="+(owner!=null && owner.Grounded)+"; cursor="+Cursor.visible
                    +"; mouseLocked="+TheForest.Utils.Input.IsMouseLocked);
            else
            {
                // Time.time uses the fixed-step clock inside physics callbacks;
                // use one monotonic clock for both sides of the input window.
                armedAt=Time.realtimeSinceStartup; armedUntil=armedAt+InputSeconds;
                Report("F detectada: ventana armada","armed=true; frame="+inputFrame+"; until="+armedUntil);
            }
        }
        private void Update()
        {
            if (owner!=LocalPlayer.FpCharacter) { contacts.Clear(); Cancel(); owner=LocalPlayer.FpCharacter; attacker=null; hasOrigin=false; }
            if (!Allowed(false)) armedUntil=-1f;
            if (action!=null && (!Allowed(false) || Time.time>=recoverUntil)) Cancel();
            PollInput();
            if (armedUntil>=0f && Time.realtimeSinceStartup>armedUntil && contacts.Count==0)
            { armedUntil=-1f; feedback="F detectada: sin impacto dentro de .12 s"; feedbackUntil=Time.unscaledTime+2f; }
            if (!Active) RestoreEquipment();
        }
        private void LateUpdate()
        {
            ResolveContacts(true);
            if (Active) foreach (Renderer renderer in equipment.Keys) if (renderer!=null) renderer.enabled=false;
        }
        private void ResolveContacts(bool allowDodge)
        {
            while (contacts.Count>0)
            {
                Contact hit=contacts[0]; contacts.RemoveAt(0);
                if (hit.stats==null || hit.stats!=LocalPlayer.Stats) continue;
                bool skip=Immune;
                bool within=armedUntil>=0f && hit.at<=armedUntil && (armedAt<=hit.at || inputFrame==hit.frame);
                string reason=BlockedReason(false);
                if (!skip && allowDodge && within && hit.grounded && reason.Length==0 && !Busy)
                {
                    try { skip=StartAgainst(hit.origin); }
                    catch (Exception exception)
                    { Cancel(); ModAPI.Log.Write("[ForestRE3] DODGE_START_FAILED "+exception); }
                }
                if (skip) hit.stats.setCurrentAttacker(null);
                else
                {
                    if (reason.Length==0) reason=!hit.grounded ? "sin apoyo en el suelo" : Busy ? "recuperacion" : "direccion no disponible";
                    Report(within ? "Golpe recibido: "+reason : "Golpe recibido: F fuera de ventana",
                        "contact=true; buffered=true; armed="+within+"; grounded="+hit.grounded+"; block="+BlockedReason(false)
                        +"; inputFrame="+inputFrame+"; contactFrame="+hit.frame+"; delta="+(hit.at-armedAt));
                    // Run the entire original path, including armor/reactions,
                    // once; no health refund and no delayed multi-frame queue.
                    replaying=true;
                    try { hit.stats.setCurrentAttacker(hit.source); hit.stats.hitFromEnemy(hit.damage); }
                    catch (Exception exception) { ModAPI.Log.Write("[ForestRE3] DODGE_NATIVE_HIT_FAILED "+exception); }
                    finally { replaying=false; }
                }
            }
            contacts.Clear(); attacker=null; hasOrigin=false;
        }
        public static bool BlockInput(string name)
        {
            return Re3InventoryRuntime.BlockControls || G19Runtime.BlockNative(name) || (Active && (name=="Fire1" || name=="Fire2" || name=="Jump" || name=="Run" || name=="Crouch"));
        }
        public static bool BlockAxis(string name) { return Re3InventoryRuntime.BlockControls || (Active && (name=="Horizontal" || name=="Vertical" || name=="Mouse X" || name=="Mouse Y")); }
        public static void CaptureAttacker(global::PlayerStats stats,enemyWeaponMelee source)
        {
            if (Instance==null || stats!=LocalPlayer.Stats || source==null) return;
            Instance.attacker=source; Instance.attackerAt=Time.time;
            Instance.contactOrigin=source.transform.root.position; Instance.hasOrigin=true;
        }
        public static bool EnemyContact(enemyWeaponMelee source,Collider other)
        {
            if (Instance==null || source==null || other==null || LocalPlayer.FpCharacter==null) return false;
            if (other!=LocalPlayer.FpCharacter.capsule && !other.transform.IsChildOf(LocalPlayer.FpCharacter.transform)
                && other.GetComponentInParent<global::PlayerStats>()!=LocalPlayer.Stats) return false;
            CaptureAttacker(LocalPlayer.Stats,source);
            return Immune;
        }
        public static bool BeforeEnemyHit(global::PlayerStats stats,int damage)
        {
            if (Instance==null || stats!=LocalPlayer.Stats || damage<=0) return false;
            if (Instance.replaying) return false;
            if (Immune) { stats.setCurrentAttacker(null); return true; }
            if (Instance.hasOrigin && Time.time-Instance.attackerAt<=.3f && Allowed(false) && Instance.contacts.Count<16)
            {
                Instance.contacts.Add(new Contact { stats=stats,source=Instance.attacker,damage=damage,frame=Time.frameCount,
                    at=Time.realtimeSinceStartup,origin=Instance.contactOrigin,grounded=Supported(LocalPlayer.FpCharacter) });
                Instance.attacker=null; Instance.hasOrigin=false;
                return true; // LateUpdate decides after this frame's F sample.
            }
            Instance.Report("Golpe recibido: "+(Instance.hasOrigin ? BlockedReason(false):"sin atacante identificado"),
                "contact=true; buffered=false; origin="+Instance.hasOrigin+"; block="+BlockedReason(false));
            Instance.attacker=null; Instance.hasOrigin=false;
            return false;
        }
        public static bool SuppressDamage(global::PlayerStats stats) { return stats==LocalPlayer.Stats && Immune; }
        public static bool SuppressReaction(Component component)
        { return Immune && component!=null && LocalPlayer.FpCharacter!=null
            && (component.GetComponentInParent<global::PlayerStats>()==LocalPlayer.Stats
                || component.transform.root==LocalPlayer.FpCharacter.transform.root); }
        private bool StartAgainst(Vector3 origin)
        {
            if (owner==null || owner.capsule==null || Clips==null) return false;
            Vector3 direction=Vector3.ProjectOnPlane(owner.capsule.bounds.center-origin,Vector3.up);
            if (direction.sqrMagnitude<.0025f) return false; // never invent the incoming direction
            action=new DodgeAction { clip=(byte)(nextVariant++%Clips.Length), sequence=++sequence, direction=direction.normalized,
                localStart=Time.time, serverStart=BoltNetwork.isRunning ? BoltNetwork.serverTime:Time.time };
            motorScale=JillPlayerAvatar.Current.DodgeMotionScale;
            if (motorScale<=0f) { action=null; return false; }
            motorAge=0f; motorSteps=blockedSteps=0; motorOrigin=owner.rb.position;
            armedUntil=-1f; immuneUntil=Time.time+ImmuneSeconds; recoverUntil=Time.time+RecoverySeconds;
            HideEquipment();
            CoopSync.DodgeStarted(action);
            JillVoice.PlayDodge();
            feedback="ESQUIVA | inmunidad 1 s"; feedbackUntil=Time.unscaledTime+2f;
            ModAPI.Log.Write("[ForestRE3] DODGE_START sequence="+sequence+"; clip="+action.clip+"; away="+action.direction+"; immunityUntil="+immuneUntil
                +"; targetWorldDistance="+Travel(action.clip,AnimationSeconds)*motorScale);
            return true;
        }
        public static bool ControlsMotor(FirstPersonCharacter controller)
        { return Active && Instance.owner==controller; }
        public static void FinishMotor(FirstPersonCharacter controller)
        { if (Instance!=null && Instance.owner==controller && !Active) Instance.FinishVelocity(); }
        public static Vector3 ApplyRollMotor(FirstPersonCharacter controller)
        {
            // Apply once from the native motor hook even if uneven ground has
            // cleared Grounded for a physics tick. Its own acceleration is zero
            // during the roll; gravity and the contact solver still run normally.
            Instance.SetRollFriction(controller);
            controller.rb.AddForce(Instance.MotorAcceleration(controller),ForceMode.Acceleration);
            return Vector3.zero;
        }
        public static void RollFriction(FirstPersonCharacter controller) { Instance.SetRollFriction(controller); }
        private void SetRollFriction(FirstPersonCharacter controller)
        {
            PhysicMaterial material=controller.playerPhysicMaterial;
            if (material==null) return;
            if (rollMaterial!=material)
            {
                RestoreFriction(); rollMaterial=material;
                savedStaticFriction=material.staticFriction; savedDynamicFriction=material.dynamicFriction;
                savedFrictionCombine=material.frictionCombine;
            }
            // Blocking the walking axes would otherwise select native standing
            // friction (1.0) and brake the roll even with the motor replaced.
            material.staticFriction=material.dynamicFriction=0f;
            material.frictionCombine=PhysicMaterialCombine.Minimum;
        }
        private void RestoreFriction()
        {
            if (rollMaterial!=null)
            {
                rollMaterial.staticFriction=savedStaticFriction; rollMaterial.dynamicFriction=savedDynamicFriction;
                rollMaterial.frictionCombine=savedFrictionCombine;
            }
            rollMaterial=null;
        }
        private Vector3 MotorAcceleration(FirstPersonCharacter controller)
        {
            float dt=Mathf.Max(Time.fixedDeltaTime,.001f);
            float end=Mathf.Min(AnimationSeconds,action.Age+dt);
            float desired=Mathf.Max(0f,Travel(action.clip,end)-Travel(action.clip,motorAge))*motorScale;
            motorAge=Mathf.Max(motorAge,end);
            CapsuleCollider capsule=owner.capsule;
            Vector3 center=capsule.bounds.center;
            float radius=Mathf.Max(.05f,Mathf.Min(capsule.bounds.extents.x,capsule.bounds.extents.z)*.90f);
            float half=Mathf.Max(0f,capsule.bounds.extents.y-radius);
            float skin=Mathf.Max(.04f,capsule.bounds.size.y*.025f);
            float allowed=desired;
            int mask=owner.CollisionLayers.value;
            if (mask==0) mask=~0;
            // Raise the sweep's sole; its support surface is not a forward wall.
            // The real full capsule continues solving all terrain contacts.
            foreach (RaycastHit hit in Physics.CapsuleCastAll(center+Vector3.up*half,center-Vector3.up*half+Vector3.up*skin,radius,
                action.direction,desired+skin,mask,QueryTriggerInteraction.Ignore))
            {
                if (hit.collider==null || hit.collider.transform.root==owner.transform.root) continue;
                if (hit.normal.y>.65f || (hit.distance<=.001f && hit.collider is TerrainCollider)) continue;
                if (hit.distance<=.001f && Vector3.Dot(action.direction,center-hit.collider.bounds.center)>=0f) continue;
                if (Vector3.Dot(hit.normal,action.direction)>=-.05f) continue;
                allowed=Mathf.Min(allowed,Mathf.Max(0f,hit.distance-skin));
            }
            if (allowed+ .001f<desired) blockedSteps++;
            Vector3 velocity=owner.rb.velocity;
            lastVelocity=action.direction*(allowed/dt); moved=true; motorSteps++;
            controller.inputVelocity=Vector3.zero;
            // Convert target velocity into acceleration for this physics step.
            // No teleport or second visual translation of the authored root.
            return new Vector3(lastVelocity.x-velocity.x,0f,lastVelocity.z-velocity.z)/dt;
        }
        private void FinishVelocity()
        {
            RestoreFriction();
            if (!moved || owner==null || owner.rb==null) { moved=false; return; }
            ModAPI.Log.Write("[ForestRE3] DODGE_MOTOR_END sequence="+sequence+"; steps="+motorSteps+"; blockedSteps="+blockedSteps
                +"; actualWorldDistance="+Vector3.ProjectOnPlane(owner.rb.position-motorOrigin,Vector3.up).magnitude);
            Vector3 velocity=owner.rb.velocity;
            owner.rb.velocity=new Vector3(0f,velocity.y,0f);
            moved=false;
        }
        private void HideEquipment()
        {
            if (LocalPlayer.Animator==null) return;
            foreach (Renderer renderer in LocalPlayer.Animator.GetComponentsInChildren<Renderer>(true))
                if (renderer.enabled && !JillPlayerAvatar.IsNativeSkinRenderer(renderer)
                    && renderer.GetComponentInParent<JillMotionPreview>()==null)
                { equipment[renderer]=renderer.enabled; renderer.enabled=false; }
        }
        private void RestoreEquipment()
        { foreach (var saved in equipment) if (saved.Key!=null) saved.Key.enabled=saved.Value; equipment.Clear(); }
        private void Cancel()
        { FinishVelocity(); DodgeFirstPersonCamera.RestoreAll(); RestoreEquipment(); action=null; armedAt=armedUntil=immuneUntil=recoverUntil=-1f; }
        private void OnGUI()
        {
            if (LocalPlayer.FpCharacter==null || JillPlayerAvatar.Current==null || !JillPlayerAvatar.Current.NetworkReady) return;
            string reason=BlockedReason(false);
            string text=Time.unscaledTime<feedbackUntil ? feedback : (Busy ? "Recuperacion de esquiva" : reason.Length>0 ? "F bloqueada: "+reason : "F lista: pulsa justo antes del impacto");
            GUI.Label(new Rect(12,132,1500,24),text);
        }
        private void OnDestroy()
        { ResolveContacts(false); Cancel(); if (Instance==this) Instance=null; remotes.Clear(); }
        public static IEnumerator EmptyRoutine() { yield break; }
    }

    // Cross-assembly helpers above are public. Every injected method has one exit.
    public class DodgeMotorPatch : global::FirstPersonCharacter
    {
        public new virtual Vector3 DetermineVelocityChange()
        {
            Vector3 result;
            if (DodgeRuntime.ControlsMotor(this)) result=DodgeRuntime.ApplyRollMotor(this);
            else { DodgeRuntime.FinishMotor(this); result=base.DetermineVelocityChange(); }
            return result;
        }
        public new virtual void ClampVelocity()
        { if (!DodgeRuntime.ControlsMotor(this)) base.ClampVelocity(); GC.KeepAlive(this); }
        public new virtual void HandleFrictionParams()
        { if (DodgeRuntime.ControlsMotor(this)) DodgeRuntime.RollFriction(this); else base.HandleFrictionParams(); GC.KeepAlive(this); }
    }
    public class DodgeStatsPatch : global::PlayerStats
    {
        public new virtual void setCurrentAttacker(enemyWeaponMelee source)
        { DodgeRuntime.CaptureAttacker(this,source); base.setCurrentAttacker(source); GC.KeepAlive(this); }
        public new virtual void hitFromEnemy(int damage)
        { if (!DodgeRuntime.BeforeEnemyHit(this,damage)) base.hitFromEnemy(damage); GC.KeepAlive(this); }
        public new virtual void Hit(int damage,bool ignoreArmor,global::PlayerStats.DamageType type)
        { if (!DodgeRuntime.SuppressDamage(this)) base.Hit(damage,ignoreArmor,type); GC.KeepAlive(this); }
        public new virtual void HealthChange(float change)
        { if (!(change<0f && DodgeRuntime.SuppressDamage(this))) base.HealthChange(change); GC.KeepAlive(this); }
    }
    public class DodgeEnemyWeaponPatch : global::enemyWeaponMelee
    {
        public new virtual void OnTriggerEnter(Collider other)
        { if (!DodgeRuntime.EnemyContact(this,other)) base.OnTriggerEnter(other); GC.KeepAlive(this); }
    }
    public class DodgeInputPatch : TheForest.Utils.Input
    {
        public new static bool GetButtonDown(string name)
        { bool value=false; if (!DodgeRuntime.BlockInput(name)) value=TheForest.Utils.Input.GetButtonDown(name); return value; }
        public new static bool GetButton(string name)
        { bool value=false; if (!DodgeRuntime.BlockInput(name)) value=TheForest.Utils.Input.GetButton(name); return value; }
        public new static bool GetButtonUp(string name)
        { bool value=false; if (!DodgeRuntime.BlockInput(name)) value=TheForest.Utils.Input.GetButtonUp(name); return value; }
        public new static float GetAxis(string name)
        { float value=0f; if (!DodgeRuntime.BlockAxis(name)) value=TheForest.Utils.Input.GetAxis(name); return value; }
    }
    public class DodgeReactionsPatch : global::playerHitReactions
    {
        public new virtual void explodeForce(Transform origin)
        { if (!DodgeRuntime.SuppressReaction(this)) base.explodeForce(origin); GC.KeepAlive(this); }
        public new virtual void enableHitState()
        { if (!DodgeRuntime.SuppressReaction(this)) base.enableHitState(); GC.KeepAlive(this); }
        public new virtual void enableWeaponHitState()
        { if (!DodgeRuntime.SuppressReaction(this)) base.enableWeaponHitState(); GC.KeepAlive(this); }
        public new virtual IEnumerator enablePushBack(float force)
        { IEnumerator result=DodgeRuntime.EmptyRoutine(); if (!DodgeRuntime.SuppressReaction(this)) result=base.enablePushBack(force); return result; }
    }
}
