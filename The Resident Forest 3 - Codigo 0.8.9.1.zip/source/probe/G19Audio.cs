﻿using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class G19Runtime
    {
        private readonly Dictionary<int,AudioClip> sounds=new Dictionary<int,AudioClip>();
        private readonly Dictionary<G19Pose,ulong> inserts=new Dictionary<G19Pose,ulong>();
        private readonly Dictionary<G19Pose,float> pumps=new Dictionary<G19Pose,float>();
        private void LoadSounds()
        {
            if(sounds.Count>0)return;
            foreach(byte weapon in new byte[]{1,3,28})try
            {
                using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe."+(weapon==28 ? "rocket":weapon==3 ? "m3":"g19")+"-sounds.bin"))
                using(var r=new BinaryReader(s))
                {
                    int count=weapon==28 ? 1:weapon==3 ? 4:3;
                    if(r.ReadUInt32()!=0x31565347 || r.ReadInt32()!=count)throw new InvalidDataException("Weapon sound header");
                    for(int i=0;i<count;i++)
                    {
                        int id=r.ReadByte(),channels=r.ReadInt32(),rate=r.ReadInt32(),frames=r.ReadInt32();
                        if(id>=count || channels<1 || channels>2 || rate<8000 || rate>96000 || frames<1 || frames>rate*10)throw new InvalidDataException("Weapon PCM bounds");
                        var pcm=new float[frames*channels];for(int j=0;j<pcm.Length;j++)pcm[j]=r.ReadInt16()/32768f;
                        var clip=AudioClip.Create("RE3R_"+Re3Weapon.Name(weapon)+"_"+id,frames,channels,rate,false);clip.SetData(pcm,0);sounds.Add(weapon*10+id,clip);
                    }
                }
                ModAPI.Log.Write("[ForestRE3] RE_WEAPON_AUDIO_LOADED weapon="+Re3Weapon.Name(weapon)+"; events="+(weapon==28 ? 1:weapon==3 ? 4:3)+"; authoredLayerLevels=true");
            }
            catch(Exception e){ModAPI.Log.Write("[ForestRE3] G19_AUDIO_ERROR "+e);}
        }
        private void Sound(int id,Vector3 origin,bool spatial,byte weapon)
        {
            AudioClip clip;if(!sounds.TryGetValue(weapon*10+id,out clip))return;
            var obj=new GameObject("ForestRE3_G19_SFX");obj.transform.position=origin;
            var source=obj.AddComponent<AudioSource>();source.clip=clip;source.volume=1f;source.spatialBlend=spatial ? 1f:0f;
            source.dopplerLevel=0f;source.priority=48;
            source.minDistance=8;source.maxDistance=160;source.rolloffMode=AudioRolloffMode.Linear;source.Play();Destroy(obj,clip.length+.1f);
        }
        private void ReloadAudio()
        {
            InsertSound(local,false,TheForest.Utils.LocalPlayer.MainCam!=null ? TheForest.Utils.LocalPlayer.MainCam.transform.position:Vector3.zero);
            foreach(var pair in remote)
            {var entity=BoltNetwork.isRunning ? BoltNetwork.FindEntity(new Bolt.NetworkId(pair.Key)):null;if(entity!=null)InsertSound(pair.Value,true,entity.transform.position);}
        }
        private void InsertSound(G19Pose pose,bool spatial,Vector3 position)
        {
            if(!pose.equipped)return;
            float age=Time.time-pose.shotAt,seenShot;
            if(pose.weapon==3 && age>=.55f && age<1.3f && (!pumps.TryGetValue(pose,out seenShot) || seenShot!=pose.shotAt))
            {pumps[pose]=pose.shotAt;Sound(3,position,spatial,pose.weapon);}
            if(!pose.Reloading)return;
            float load=Time.time-pose.reloadAt;
            int phase=pose.weapon==3 ? (load>=3.45f ? 5:Mathf.Clamp(Mathf.FloorToInt((load-.8f)/.65f)+1,0,4)):(load>=.9f ? 1:0);
            if(phase==0)return;
            ulong token=((ulong)pose.reloadSequence<<8)|(uint)phase,seen;
            if(inserts.TryGetValue(pose,out seen) && seen==token)return;
            inserts[pose]=token;Sound(phase==5 ? 3:2,position,spatial,pose.weapon);
        }
    }
}
