﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $PSScriptRoot 'ForestRe3LoaderProbe.cs'
$outputDirectory = Join-Path $root 'build'
$outputDll = Join-Path $outputDirectory 'ForestRe3LoaderProbe.dll'
$baseModLib = Join-Path (Get-Location) 'work\tools\ModAPI\app\libs\BaseModLib.dll'
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$preflight = Join-Path (Get-Location) 'outputs\forest-re3-mashup\design\preflight-report.json'

if (-not (Test-Path -LiteralPath $preflight)) {
    throw 'No existe el informe de preflight. Ejecuta design\preflight.py primero.'
}
$gate = Get-Content -LiteralPath $preflight -Raw | ConvertFrom-Json
if (-not $gate.buildAllowed -or $gate.buildMilestone -ne 'MODAPI_LOADER_PROBE') {
    throw "Preflight no autoriza este hito: $($gate.result) / $($gate.buildMilestone)"
}
if (-not (Test-Path -LiteralPath $baseModLib)) { throw 'No se encontró BaseModLib.dll de ModAPI.' }
if (-not (Test-Path -LiteralPath $compiler)) { throw 'No se encontró el compilador C# de .NET Framework.' }

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
& $compiler /nologo /target:library /optimize+ /out:$outputDll "/reference:$baseModLib" $source
if ($LASTEXITCODE -ne 0) { throw "La compilación falló con código $LASTEXITCODE." }
Get-FileHash -Algorithm SHA256 -LiteralPath $outputDll | Format-List
