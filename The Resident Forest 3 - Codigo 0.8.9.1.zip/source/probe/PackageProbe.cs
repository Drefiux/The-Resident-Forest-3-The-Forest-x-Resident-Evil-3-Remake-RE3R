﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using ModAPI.Configurations;
using ModAPI.Data;
using ModAPI.Data.Models;

internal static class PackageProbe
{
    private static string appRoot;

    private static void InstallResolver()
    {
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs args)
        {
            var name = new AssemblyName(args.Name).Name + ".dll";
            var candidates = new[]
            {
                Path.Combine(appRoot, name),
                Path.Combine(appRoot, "libs", name),
                Path.Combine(appRoot, "libs", "polyfills", name)
            };
            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate)) return Assembly.LoadFrom(candidate);
            }
            return null;
        };
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    public static int Main(string[] args)
    {
        try
        {
            appRoot = Path.GetFullPath(Directory.GetCurrentDirectory());
            InstallResolver();
            Require(Configuration.Load() == Configuration.ResultCode.Ok, "ModAPI no pudo cargar su configuración local.");

            var gamePath = @"C:\Program Files (x86)\Steam\steamapps\common\The Forest";
            var projectId = "ForestRE3LoaderProbe";
            var projectRoot = Path.Combine(Configuration.GetPath("Projects"), "TheForest", projectId);
            var modOutput = Path.Combine(Configuration.GetPath("Mods"), "TheForest");

            Configuration.SetPath("OriginalGameFiles", Path.Combine(appRoot, "gamefiles", "original"), true);
            Configuration.SetPath("ModdedGameFiles", Path.Combine(appRoot, "gamefiles", "modded"), true);
            Configuration.SetPath("SavegameBackups", Path.Combine(appRoot, "gamefiles", "savegames"), true);
            Configuration.SetPath("Projects", Path.Combine(appRoot, "projects"), true);
            Configuration.SetPath("Mods", Path.Combine(appRoot, "mods"), true);
            Configuration.SetPath("ModLib", Path.Combine(appRoot, "modlib"), true);
            Configuration.SetPath("Libraries", Path.Combine(appRoot, "libs"), true);

            Require(Directory.Exists(gamePath), "No se encontró la instalación anfitriona identificada.");
            var gameConfig = Configuration.Games["TheForest"];
            var game = new Game(gameConfig, true);
            game.GamePath = gamePath;

            var versionsPath = Path.Combine(appRoot, "configs", "games", "TheForest", "Versions.xml");
            var versionElement = XDocument.Load(versionsPath).Root.Elements("version")
                .FirstOrDefault(e => (string)e.Attribute("id") == "1.11b");
            Require(versionElement != null, "El catálogo local no contiene The Forest 1.11b.");
            var matchedVersion = new Game.Versions.Version(versionElement);
            game.GameVersion = matchedVersion;
            game.BackupVersion = matchedVersion;

            game.ModLibrary = new ModLib(game);
            game.ModLibrary.Create();
            Require(game.ModLibrary.Exists, "No se pudo crear la biblioteca ModAPI en el área de trabajo.");
            Require(game.ModLibrary.GameVersion == "1.11b", "La biblioteca resultante no coincide con la versión 1.11b esperada.");

            var project = new ModProject(game, projectId);
            project.Name.SetString("EN", "Forest RE3 Loader Probe");
            project.Description.SetString("EN", "Local diagnostic package; writes only ModAPI startup markers.");
            project.Version = "0.1.0.0";
            project.SaveConfiguration();
            Require(!project.SaveFailed, "ModAPI no pudo escribir la configuración del proyecto.");

            var modFolder = Path.Combine(projectRoot, "Mod");
            Directory.CreateDirectory(modFolder);
            var compiledDll = args.Length > 0 ? Path.GetFullPath(args[0]) : "";
            Require(File.Exists(compiledDll), "No se encontró la DLL de la prueba compilada.");
            File.Copy(compiledDll, Path.Combine(modFolder, projectId + ".dll"), true);

            project.Create(null);
            var package = Directory.GetFiles(modOutput, "*.mod", SearchOption.TopDirectoryOnly)
                .Select(path => new FileInfo(path))
                .OrderByDescending(file => file.LastWriteTimeUtc)
                .FirstOrDefault(file => file.Name.StartsWith(projectId + "-", StringComparison.OrdinalIgnoreCase));
            Require(package != null && package.Exists, "ModAPI no generó el paquete .mod esperado.");
            Console.WriteLine("PACKAGE=" + package.FullName);
            Console.WriteLine("SIZE=" + package.Length);
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine(exception);
            return 1;
        }
    }
}
