﻿"""Generate the explicit action map from locally inspected controller names."""
import collections
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
metadata = json.loads((ROOT/'work/forest-re3-mashup/native-controller-metadata.json').read_text(encoding='utf-8'))
prefixes = ('Base Layer.', 'upperBody.', 'fullBodyActions.', 'leftArm.', 'spineAddititve2.', 'ClientPredictionLayer.')
states = sorted({name for file in metadata['files'] for obj in file['objects']
                 if obj['classId'] == 91 and obj['strings'][0] in ('playerController', 'playerController_net3')
                 for name in obj['strings'] if name.startswith(prefixes)})
neutral = {
    'Base Layer.idle', 'Base Layer.idleNoWobble', 'Base Layer.locomotion',
    'Base Layer.turnLeftToIdle', 'Base Layer.turnRightToIdle',
    'fullBodyActions.idle', 'fullBodyActions.idleStick', 'fullBodyActions.rockIdle',
    'leftArm.armOverride', 'leftArm.LeanForward', 'upperBody.LeanForward',
    'ClientPredictionLayer.None', 'upperBody.New State',
}
for name in ('idle', 'idleStick', 'artifactIdle', 'ballIdle', 'bowIdle', 'camCorderIdle',
             'chainSawIdle', 'flameThrowerIdle', 'flareGunIdle', 'flareIdle', 'flashLightIdle',
             'flintlockIdle', 'genericHoldIdle', 'holdWideIdle', 'laserPointerIdle', 'lighterIdle',
             'molotovIdle', 'potHeldIdle', 'rockIdle', 'rockIdleHigh', 'shellHeldIdle',
             'slingShotIdle', 'spearIdle', 'spearIdleHigh', 'stickJabIdle', 'waterSkinHeldIdle', 'walkmanIdle'):
    neutral.add('upperBody.'+name)
for name in ('flashlightIdle', 'lighterIdle', 'pedometerIdle', 'sapIdle', 'walkmanIdle', 'walkmanIdle 0'):
    neutral.add('leftArm.'+name)


def category(name):
    if name in neutral or name.startswith('spineAddititve2.'):
        return ''
    n = name.split('.', 1)[1].lower()
    # Explosion and death have priority over generic fall/standup terms.
    if any(term in n for term in ('explosion', 'knockback', 'predictionhit', 'getup', 'landheavy', 'standupinjured')):
        return 'impacto'
    if any(term in n for term in ('death', 'injur', 'hangingidle', 'hanginghead', 'dragaway')):
        return 'derribo'
    if any(term in n for term in ('swim', 'dive')):
        return 'nadar'
    if any(term in n for term in ('climb', 'rope')):
        return 'escalar'
    if 'jump' in n:
        return 'salto'
    if any(term in n for term in ('raft', 'paddle', 'sled', 'zip', 'crane', 'glider', 'shellride')) or ('thrower' in n and 'flamethrower' not in n):
        return 'transporte'
    if any(term in n for term in ('crouch', 'standup', 'standupidle')):
        return 'agacharse'
    if any(term in n for term in ('eat', 'drink', 'fillpot', 'fillwater')):
        return 'consumir'
    if any(term in n for term in ('attack', 'axe', 'swing', 'windup', 'stab', 'jab', 'shove', 'throw',
                                  'block', 'bow', 'shoot', 'fire', 'reload', 'aim', 'draw', 'saw', 'repairhammer',
                                  'lightweapon', 'lightbow', 'lightmolotov', 'flarelight', 'flamethrower')):
        return 'combate'
    return 'interaccion'


definitions = [(state, category(state)) for state in states]
source = ['// Generated from local The Forest 1.11b controller metadata, 07/10/2026.',
          '// Names/hashes only; no native animation data. Neutral rows protect RE locomotion.',
          'namespace ForestRE3JillVisualProbe', '{', '    internal static class JillNativeStateTable',
          '    {', '        internal static readonly string[,] Definitions = {']
source += ['            { '+json.dumps(name)+', '+json.dumps(action)+' },' for name, action in definitions]
source += ['        };', '    }', '}']
(HERE/'JillNativeStateTable.cs').write_text('\n'.join(source)+'\n', encoding='utf-8')
report = dict(date='07/10/2026', gameVersion='1.11b',
              source='Local Unity 5.6.5p4 AnimatorController string table; playerController and playerController_net3',
              stateCount=len(definitions), categories=dict(collections.Counter(c for _, c in definitions)),
              definitions=[dict(state=s, action=c or 'neutral_RE_allowed') for s, c in definitions],
              runtimeVisualVerification=False,
              scope='Explicit routing of known states; unknown contributing clips use native pose fallback. No multiplayer sync.')
(ROOT/'work/jill/corrected/native-action-coverage-0.6.0.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(states=report['stateCount'], categories=report['categories'])))
