﻿using System;
using System.IO;

namespace ForestRE3JillVisualProbe
{
    // JSC1 stores two banks of RE-local poses. Four rotation features (16
    // floats), then twelve helper position/rotation pairs (84 floats).
    public static class JillShoulderDataReader
    {
        public static float[][][] Read(Stream stream)
        {
            using (var reader = new BinaryReader(stream))
            {
                if (reader.ReadUInt32() != 0x3143534A || reader.ReadInt32() != 4 || reader.ReadInt32() != 12)
                    throw new InvalidDataException("Invalid JSC1 shoulder header.");
                var sides = new float[2][][];
                for (int side = 0; side < 2; side++)
                {
                    int count = reader.ReadInt32();
                    if (count < 50 || count > 2048) throw new InvalidDataException("Invalid shoulder sample count.");
                    sides[side] = new float[count][];
                    for (int s = 0; s < count; s++)
                    {
                        var values = new float[100];
                        for (int i = 0; i < values.Length; i++)
                        {
                            values[i] = reader.ReadSingle();
                            if (float.IsNaN(values[i]) || float.IsInfinity(values[i])) throw new InvalidDataException("Nonfinite shoulder sample.");
                        }
                        for (int feature = 0; feature < 4; feature++) RequireQuaternion(values, feature*4);
                        for (int helper = 0; helper < 12; helper++)
                        {
                            int start = 16+helper*7;
                            for (int axis = 0; axis < 3; axis++)
                                if (Math.Abs(values[start+axis]) > .12f) throw new InvalidDataException("Shoulder corrective outside joint range.");
                            RequireQuaternion(values, start+3);
                        }
                        sides[side][s] = values;
                    }
                }
                if (reader.BaseStream.ReadByte() != -1) throw new InvalidDataException("Unexpected shoulder data suffix.");
                return sides;
            }
        }

        private static void RequireQuaternion(float[] values, int start)
        {
            float norm = 0f;
            for (int i = 0; i < 4; i++) norm += values[start+i]*values[start+i];
            if (norm < .95f || norm > 1.05f) throw new InvalidDataException("Invalid shoulder quaternion.");
        }
    }
}
