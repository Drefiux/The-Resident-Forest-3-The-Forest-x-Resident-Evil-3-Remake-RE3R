﻿using System;
using System.IO;

namespace ForestRE3JillVisualProbe
{
    internal sealed class JillVoiceSample
    {
        internal bool hurt;
        internal int id, rate;
        internal float[] samples;
    }

    internal static class JillVoiceDataReader
    {
        internal static JillVoiceSample[] Read(Stream stream)
        { return ReadBank(stream, true); }
        internal static JillVoiceSample[] ReadDodge(Stream stream)
        { return ReadBank(stream, false); }
        private static JillVoiceSample[] ReadBank(Stream stream, bool requireBoth)
        {
            using (var reader = new BinaryReader(stream))
            {
                if (reader.ReadByte() != 'J' || reader.ReadByte() != 'R' || reader.ReadByte() != 'V' || reader.ReadByte() != '1')
                    throw new InvalidDataException("Invalid Jill voice resource.");
                int count = reader.ReadInt32();
                if (count < 2 || count > 100) throw new InvalidDataException("Invalid Jill voice count.");
                var records = new JillVoiceSample[count];
                int effort = 0, hurt = 0;
                for (int i = 0; i < count; i++)
                {
                    byte category = reader.ReadByte();
                    if (category > 1) throw new InvalidDataException("Unknown Jill voice category.");
                    var record = new JillVoiceSample { hurt=category==1, id=reader.ReadInt32(), rate=reader.ReadInt32() };
                    int length = reader.ReadInt32();
                    if (record.rate < 8000 || record.rate > 96000 || length < 1 || length > record.rate*6)
                        throw new InvalidDataException("Unexpected Jill voice duration/rate.");
                    record.samples = new float[length];
                    for (int sample = 0; sample < length; sample++) record.samples[sample] = reader.ReadInt16()/32768f;
                    records[i] = record;
                    if (record.hurt) hurt++; else effort++;
                }
                if ((requireBoth && hurt == 0) || effort == 0 || stream.Position != stream.Length)
                    throw new InvalidDataException("Incomplete Jill voice bank.");
                return records;
            }
        }
    }
}
