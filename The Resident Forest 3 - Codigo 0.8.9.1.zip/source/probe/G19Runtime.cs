﻿using System;
using System.IO;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
namespace ForestRE3JillVisualProbe
{
    internal sealed class G19Pose
    {
        internal bool equipped,aim;
        internal int ammo=15;
        internal byte weapon=1,movement;
        internal Vector3 lookDirection=Vector3.forward;
        internal int Capacity {get{return Re3Weapon.Capacity(weapon);}}
        internal float ReloadSeconds {get{return Re3Weapon.Reload(weapon);}}
        internal float shotAt=-100f,raiseAt=-100f,reloadAt=-100f,equipAt,receivedAt;
        internal uint sequence,reloadSequence;
        internal bool Reloading {get{return equipped && Time.time-reloadAt<ReloadSeconds;}}
    }
    [DefaultExecutionOrder(-400)]
    public sealed partial class G19Runtime : MonoBehaviour
    {
        internal const float ReloadSeconds=104f/60f,FireSeconds=.28f,Range=250f;
        internal static G19Runtime Instance;
        internal static GameObject Prefab,M3Prefab;
        internal static Texture2D InventoryAtlas,Icon,M3Icon;
        internal static GameObject WeaponPrefab(int id){return id==28 ? RocketPrefab:id==3 ? M3Prefab:Prefab;}
        internal static Texture2D WeaponIcon(int id){return id==28 ? RocketIcon:id==3 ? M3Icon:Icon;}
        internal static int EquippedId {get{return Equipped ? Instance.local.weapon:0;}}
        internal static readonly Dictionary<string,MotionClip> Clips=new Dictionary<string,MotionClip>();
        internal readonly G19Pose local=new G19Pose();
        private readonly Dictionary<Renderer,bool> equipment=new Dictionary<Renderer,bool>();
        private FirstPersonCharacter owner;
        private byte suspendedWeapon;private float resumeWeaponAt;private bool nativeHandsActive,nativeHolstered,cancelNativeResume;
        private readonly HashSet<Renderer> heldEquipment=new HashSet<Renderer>();
        private static readonly HashSet<int> nativeHandStates=NativeHandStates();
        private float pendingFireAt=-1f,lookSentAt;
        private Vector3 sentLook=Vector3.forward;
        private bool loading,failed; private float actionAt,aimSentAt; private uint requestSequence;
        internal static bool Equipped {get{return Instance!=null && Instance.local.equipped;}}
        internal static bool BlockNative(string name) {return Equipped && Instance.CanUse && (name=="Fire1" || name=="Fire2" || name=="AltFire" || name=="Reload");}
        internal static bool HasWeapon(Re3Bag bag,int id) {foreach(var s in bag.slots)if(s.id==id && s.count>0)return true;return false;}
        internal static G19Pose Pose(BoltEntity entity)
        {
            if(Instance==null)return null;
            if(entity==null)return Equipped && Instance.CanUse ? Instance.local:null;
            G19Pose pose; return entity.isAttached && Instance.remote.TryGetValue(entity.networkId.PackedValue,out pose) && pose.equipped && !NativeOwnsHands(entity,null) ? pose:null;
        }
        private bool CanUse {get{return LocalPlayer.FpCharacter!=null && LocalPlayer.Inventory!=null && LocalPlayer.Stats!=null && !LocalPlayer.Stats.Dead
            && !JillPlaneAvatar.CharacterLocked && LocalPlayer.Inventory.CurrentView==TheForest.Items.Inventory.PlayerInventory.PlayerViews.World
            && LocalPlayer.AnimControl!=null && !LocalPlayer.AnimControl.onRope && !LocalPlayer.AnimControl.cliffClimb && !LocalPlayer.AnimControl.swimming
            && !LocalPlayer.AnimControl.endGameCutScene && !NativeOwnsHands(null,LocalPlayer.Animator);}}
        private static HashSet<int> NativeHandStates()
        {
            var states=new HashSet<int>();string[,] table=JillNativeStateTable.Definitions;
            for(int i=0;i<table.GetLength(0);i++)
                if(NativeHandAction(table[i,1]))states.Add(Animator.StringToHash(table[i,0]));
            return states;
        }
        internal static bool NativeHandAction(string action)
        {return action.Length!=0 && action!="combate" && action!="salto" && action!="agacharse";}
        // Use native carrying flags and CURRENT/DESTINATION animator states.
        // Skinning, eating, transport and inspection own their native props and
        // arm pose, including the start/end crossfades, on every peer.
        internal static bool NativeOwnsHands(BoltEntity entity,Animator animator)
        {
            bool local=entity==null || entity==LocalPlayer.Entity;
            if(local)
            {
                var control=LocalPlayer.AnimControl;var inventory=LocalPlayer.Inventory;var fp=LocalPlayer.FpCharacter;
                if(control!=null && (control.skinningAnimal || control.carry || control.holdingGirl || control.sitting
                    || control.useRootMotion || control.useRootRotation || control.doSledPushMode || control.fullyAttachedToSled
                    || control.doShellRideMode || control.holdingGlider || control.flyingGlider || control.onRockThrower
                    || control.onRope || control.cliffClimb || control.swimming || control.knockedDown || control.injured
                    || control.introCutScene || control.endGameCutScene || control.enteringACave || control.exitingACave))return true;
                if(inventory!=null && ((inventory.Logs!=null && inventory.Logs.HasLogs)
                    || inventory.IsSlotLocked(TheForest.Items.Item.EquipmentSlot.RightHand)))return true;
                if(fp!=null && (fp.drinking || fp.PushingSled || fp.SailingRaft))return true;
                if(animator==null)animator=LocalPlayer.Animator;
            }
            else if(entity.isAttached && entity.StateIs<IPlayerState>())
            {
                IPlayerState state=entity.GetState<IPlayerState>();
                if(state.logHeld || state.logsHeld>0 || state.bodyHeld || state.inWater)return true;
                if(animator==null)
                    foreach(CoopMecanimReplicator replica in entity.GetComponentsInChildren<CoopMecanimReplicator>(true))
                        if(replica.TargetAnimator!=null){animator=replica.TargetAnimator;break;}
            }
            if(animator==null || !animator.isInitialized)return false;
            for(int layer=0;layer<animator.layerCount;layer++)
            {
                if(layer!=0 && animator.GetLayerWeight(layer)<=.001f)continue;
                if(nativeHandStates.Contains(animator.GetCurrentAnimatorStateInfo(layer).fullPathHash))return true;
                if(animator.IsInTransition(layer) && nativeHandStates.Contains(animator.GetNextAnimatorStateInfo(layer).fullPathHash))return true;
            }
            return false;
        }
        private bool YieldToNativeAction()
        {
            bool nativeSwitch=UnityEngine.Input.GetKeyDown(KeyCode.Alpha1) || UnityEngine.Input.GetKeyDown(KeyCode.Alpha2)
                || UnityEngine.Input.GetKeyDown(KeyCode.Alpha3) || UnityEngine.Input.GetKeyDown(KeyCode.Alpha4);
            if(NativeOwnsHands(null,LocalPlayer.Animator))
            {
                if(!nativeHandsActive){nativeHandsActive=true;nativeHolstered=false;cancelNativeResume=false;}
                if(nativeSwitch){cancelNativeResume=true;suspendedWeapon=0;}
                if(local.equipped && !nativeHolstered)
                {nativeHolstered=true;if(!cancelNativeResume)suspendedWeapon=local.weapon;Request(0,Vector3.zero,Vector3.forward);}
                resumeWeaponAt=Time.time+.15f;pendingFireAt=-1f;RestoreEquipment();return true;
            }
            nativeHandsActive=nativeHolstered=false;
            if(nativeSwitch)suspendedWeapon=0;
            if(suspendedWeapon!=0)
            {
                if(LocalPlayer.Stats==null || LocalPlayer.Stats.Dead || Re3InventoryRuntime.Instance==null
                    || !HasWeapon(Re3InventoryRuntime.Instance.player,suspendedWeapon))suspendedWeapon=0;
                else if(CanUse && Time.time>=resumeWeaponAt && !DodgeRuntime.Busy && !Re3InventoryRuntime.BlockControls
                    && !LocalPlayer.IsInPauseMenu && Application.isFocused)
                {byte weapon=suspendedWeapon;suspendedWeapon=0;Request(1,Vector3.zero,Vector3.forward,weapon);return true;}
            }
            return false;
        }
        private void ResetNativeHands()
        {suspendedWeapon=0;resumeWeaponAt=0;nativeHandsActive=nativeHolstered=cancelNativeResume=false;RestoreEquipment();}
        private void Awake()
        {
            Instance=this;
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.rocket-motions.bin"))
                foreach(var clip in JillMotionDataReader.ReadRocket(stream).clips)Clips[clip.mode]=clip;
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.g19-motions.bin"))
                foreach(var clip in JillMotionDataReader.ReadG19(stream).clips) Clips[clip.mode]=clip;
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.m3-motions.bin"))
                foreach(var clip in JillMotionDataReader.ReadM3(stream).clips) Clips[clip.mode]=clip;
        }
        internal static void ToggleEquip(byte weapon)
        {
            if(Instance==null || NativeOwnsHands(null,LocalPlayer.Animator) || Re3InventoryRuntime.Instance==null || !Re3Weapon.Valid(weapon) || !HasWeapon(Re3InventoryRuntime.Instance.player,weapon))return;
            if((!Equipped || Instance.local.weapon!=weapon) && (WeaponPrefab(weapon)==null || JillPlayerAvatar.Current==null || !JillPlayerAvatar.Current.NetworkReady))
            {Re3InventoryRuntime.Instance.Notice("Preparando la "+Re3Weapon.Name(weapon)+"…");return;}
            Instance.suspendedWeapon=0;Instance.Request((byte)(Equipped && Instance.local.weapon==weapon ? 0:1),Vector3.zero,Vector3.forward,weapon);
        }
        // Quick slots equip only; pressing the same key never holsters it.
        internal static void Equip(byte weapon)
        {
            if(Instance==null || !Instance.CanUse || (Equipped && Instance.local.weapon==weapon))return;
            ToggleEquip(weapon);
        }
        private void Update()
        {
            if(owner!=LocalPlayer.FpCharacter){ResetNativeHands();owner=LocalPlayer.FpCharacter;PlayerRecreated();}
            TickNetwork();ReloadAudio();TickRockets();
            if(owner==null || !owner.gameObject.activeInHierarchy)return;
            if(Prefab==null && !loading && !failed && !JillPlaneAvatar.CharacterLocked){loading=true;StartCoroutine(LoadAssets());}
            if(YieldToNativeAction())return;
            if(!local.equipped)return;
            if(!CanUse || Re3InventoryRuntime.Instance==null || !HasWeapon(Re3InventoryRuntime.Instance.player,local.weapon))
            {pendingFireAt=-1f;Request(0,Vector3.zero,Vector3.forward);return;}
            if(!Re3InventoryRuntime.Client && local.Reloading==false && local.reloadAt>-50f){local.ammo=local.Capacity;local.reloadAt=-100f;}
            if(DodgeRuntime.Active){pendingFireAt=-1f;Request(0,Vector3.zero,Vector3.forward);return;}
            if(Re3InventoryRuntime.BlockControls || LocalPlayer.IsInPauseMenu || !Application.isFocused || DodgeRuntime.Busy || Time.timeScale<=0){pendingFireAt=-1f;return;}
            bool aim=UnityEngine.Input.GetMouseButton(1);
            if(aim!=local.aim && Time.time>=aimSentAt){aimSentAt=Time.time+.1f;Request((byte)(aim ? 4:5),Vector3.zero,Vector3.forward);}
            if(LocalPlayer.MainCam!=null && Time.time>=lookSentAt && (local.aim || pendingFireAt>=0f || Time.time-local.shotAt<1.45f))
            {
                lookSentAt=Time.time+.12f;Vector3 look=LocalPlayer.MainCam.transform.forward;
                if(Vector3.Dot(look,sentLook)<.9994f){sentLook=look;Request(6,Vector3.zero,look);}
            }
            if(local.weapon!=28 && UnityEngine.Input.GetKeyDown(KeyCode.R) && !local.Reloading && local.ammo<local.Capacity){pendingFireAt=-1f;Request(3,Vector3.zero,Vector3.forward);}
            if(pendingFireAt>=0f && Time.time>=pendingFireAt)
            {pendingFireAt=-1f;if(!local.Reloading && local.ammo>0)FireFromView();}
            if(UnityEngine.Input.GetMouseButtonDown(0) && !local.Reloading && Time.time>=actionAt && local.ammo>0)
            {
                actionAt=Time.time+Re3Weapon.Fire(local.weapon);
                if(!local.aim)
                {pendingFireAt=Time.time+.12f;Request(7,Vector3.zero,Vector3.forward);}
                else FireFromView();
            }
            if(UnityEngine.Input.GetKeyDown(KeyCode.Alpha1) || UnityEngine.Input.GetKeyDown(KeyCode.Alpha2) || UnityEngine.Input.GetKeyDown(KeyCode.Alpha3) || UnityEngine.Input.GetKeyDown(KeyCode.Alpha4))Request(0,Vector3.zero,Vector3.forward);
        }
        private void FireFromView()
        {
            if(LocalPlayer.MainCam==null)return;
            Vector3 origin;Quaternion rotation;
            if(!DodgeFirstPersonCamera.TryWeaponView(out origin,out rotation))
            {origin=LocalPlayer.MainCam.transform.position;rotation=LocalPlayer.MainCam.transform.rotation;}
            Request(2,origin,rotation*Vector3.forward);
        }
        private IEnumerator LoadAssets()
        {
            byte[] bytes=null;
            try{using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.g19-"+(QualitySettings.activeColorSpace==ColorSpace.Linear ? "linear":"gamma")))
                {bytes=new byte[(int)s.Length];int at=0;while(at<bytes.Length){int n=s.Read(bytes,at,bytes.Length-at);if(n<=0)throw new EndOfStreamException();at+=n;}}}
            catch(Exception e){failed=true;ModAPI.Log.Write("[ForestRE3] G19_ASSET_ERROR "+e);}
            if(bytes!=null)
            {
                var request=AssetBundle.LoadFromMemoryAsync(bytes);yield return request;var bundle=request.assetBundle;
                if(bundle!=null)
                {
                    var p=bundle.LoadAssetAsync("Assets/Generated/G19/G19.prefab",typeof(GameObject));yield return p;Prefab=p.asset as GameObject;
                    InventoryAtlas=bundle.LoadAsset<Texture2D>("Assets/LocalAssets/Re3G19/inventory-original-atlas.png");
                    Icon=bundle.LoadAsset<Texture2D>("Assets/LocalAssets/Re3G19/g19-icon.png");bundle.Unload(false);
                }
                if(Prefab==null)failed=true;
            }
            yield return StartCoroutine(LoadM3());yield return StartCoroutine(LoadRocket());LoadSounds();loading=false;
        }
        private void LateUpdate()
        {
            if(!Equipped || !CanUse){RestoreEquipment();return;}
            // Hide only the current native hand props. Caching every renderer
            // under the animator also disabled carried logs and future action
            // tools, and restored stale disabled states after their activation.
            heldEquipment.Clear();
            if(LocalPlayer.Inventory!=null)
            {HideHeldEquipment(LocalPlayer.Inventory.RightHand);HideHeldEquipment(LocalPlayer.Inventory.LeftHand);}
            var released=new List<Renderer>();
            foreach(var saved in equipment)
                if(saved.Key==null || !heldEquipment.Contains(saved.Key))
                {if(saved.Key!=null)saved.Key.enabled=saved.Value;released.Add(saved.Key);}
            foreach(var renderer in released)equipment.Remove(renderer);
            foreach(var renderer in equipment.Keys)if(renderer!=null)renderer.enabled=false;
        }
        private void HideHeldEquipment(TheForest.Items.Inventory.InventoryItemView item)
        {
            if(item==null || item._held==null)return;
            foreach(Renderer renderer in item._held.GetComponentsInChildren<Renderer>(true))
            {
                if(JillPlayerAvatar.IsNativeSkinRenderer(renderer) || renderer.GetComponentInParent<JillMotionPreview>()!=null)continue;
                heldEquipment.Add(renderer);
                if(renderer.enabled && renderer.gameObject.activeInHierarchy && !equipment.ContainsKey(renderer))equipment[renderer]=true;
            }
        }
        private void RestoreEquipment(){foreach(var r in equipment)if(r.Key!=null)r.Key.enabled=r.Value;equipment.Clear();}
        private void OnDisable(){local.equipped=false;ResetNativeHands();}
        private void OnDestroy(){ClearRockets();OnDisable();if(Instance==this)Instance=null;foreach(var s in sounds.Values)if(s!=null)Destroy(s);if(shotgunReticle!=null)Destroy(shotgunReticle);}
        private GUIStyle ammoDigits,ammoReserve;
        private void AmmoHUD()
        {
            if(ammoDigits==null)
            {
                ammoDigits=new GUIStyle(GUI.skin.label){fontSize=48,fontStyle=FontStyle.Normal,alignment=TextAnchor.MiddleRight};
                ammoReserve=new GUIStyle(GUI.skin.label){fontSize=24,fontStyle=FontStyle.Normal,alignment=TextAnchor.LowerLeft};
            }
            if(Re3Interface.AmmoFont!=null){ammoDigits.font=Re3Interface.AmmoFont;ammoReserve.font=Re3Interface.AmmoFont;}
            float scale=Mathf.Clamp(Mathf.Min(Screen.width/1920f,Screen.height/1080f),.65f,1.5f);
            Matrix4x4 before=GUI.matrix;Color color=GUI.color;
            // Original RE ammo typography/icon, beside the native survival HUD.
            GUI.matrix=Matrix4x4.TRS(new Vector3(Screen.width-490f*scale,Screen.height-112f*scale,0),Quaternion.identity,Vector3.one*scale);
            GUI.color=new Color(0,0,0,.4f);Re3Interface.Image(new Rect(0,16,170,65),Re3Interface.Gradients,new Rect(0,64,512,32));
            Color count=local.ammo==0 ? new Color(.9f,.28f,.22f):local.ammo<=3 ? new Color(.96f,.67f,.28f):new Color(.72f,.88f,.67f);
            ammoDigits.normal.textColor=Color.black;ammoReserve.normal.textColor=Color.black;GUI.color=new Color(1,1,1,.65f);
            GUI.Label(new Rect(16,0,77,66),(local.weapon==28 ? "∞":local.ammo.ToString()),ammoDigits);if(local.weapon!=28)GUI.Label(new Rect(99,23,78,40),"/ ∞",ammoReserve);
            GUI.color=Color.white;ammoDigits.normal.textColor=count;ammoReserve.normal.textColor=new Color(.9f,.92f,.9f);
            GUI.Label(new Rect(14,-2,77,66),(local.weapon==28 ? "∞":local.ammo.ToString()),ammoDigits);if(local.weapon!=28)GUI.Label(new Rect(97,21,78,40),"/ ∞",ammoReserve);
            GUI.color=count;Re3Interface.Image(new Rect(2,60,28,28),Re3Interface.Ammo,local.weapon==28 ? new Rect(96,32,32,32):local.weapon==3 ? new Rect(32,32,32,32):new Rect(0,32,32,32));
            if(local.Reloading)
            {
                GUI.color=new Color(.9f,.92f,.9f,.85f);Re3Interface.Image(new Rect(34,62,20,20),Re3Interface.Ammo,new Rect(64,36,28,28));
            }
            GUI.matrix=before;GUI.color=color;
        }
        private void OnGUI()
        {
            if(!Equipped || !CanUse || LocalPlayer.IsInPauseMenu || Re3InventoryRuntime.BlockControls)return;
            AmmoHUD();
            if(!local.Reloading && !DodgeRuntime.Active)DrawReticle();
        }

    }
    public sealed class G19Stun : MonoBehaviour
    {
        private mutantAI ai;private Animator animator;private bool enabledBefore;private float speed,until;private bool active;
        internal void Begin(mutantAI value)
        {
            if(!active){ai=value;animator=GetComponentInChildren<Animator>();enabledBefore=ai!=null && ai.enabled;speed=animator!=null ? animator.speed:1f;active=true;}
            until=Time.time+.18f;if(ai!=null)ai.enabled=false;if(animator!=null)animator.speed=0f;
        }
        private void Update(){if(active && Time.time>=until)Restore();}
        private void Restore(){if(active){if(ai!=null && GetComponent<EnemyHealth>().Health>0)ai.enabled=enabledBefore;if(animator!=null)animator.speed=speed;active=false;}}
        private void OnDisable(){Restore();}
    }
}
