﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using LocalPlayer=TheForest.Utils.LocalPlayer;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class G19Runtime
    {
        private sealed class Authority {internal G19Pose pose=new G19Pose();internal uint request;internal ulong actor;internal BoltConnection connection;internal float fireAt;internal string key;}
        private readonly Dictionary<string,Authority> authority=new Dictionary<string,Authority>();
        private readonly Dictionary<ulong,G19Pose> remote=new Dictionary<ulong,G19Pose>();
        private readonly Dictionary<string,int> savedAmmo=new Dictionary<string,int>();
        private float networkAt;
        private readonly Dictionary<uint,float> pendingShots=new Dictionary<uint,float>();
        private void ResetLocalState()
        {
            ResetNativeHands();
            local.equipped=false;local.aim=false;local.weapon=1;local.movement=0;local.ammo=15;local.reloadAt=-100;local.shotAt=local.raiseAt=-100;pendingFireAt=-1f;
            local.sequence=0;local.reloadSequence=0;requestSequence=0;networkAt=0;networkSyncAt=0;actionAt=0;aimSentAt=0;
            lookSentAt=0f;sentLook=local.lookDirection=Vector3.forward;
            pendingShots.Clear();inserts.Clear();pumps.Clear();
        }
        internal static void PlayerRecreated(){if(Instance!=null)Instance.ResetRecreatedPlayer();}
        private void ResetRecreatedPlayer()
        {
            // A respawn replaces only this player's presentation. Keep request
            // ordering, every peer's authority and the magazines already stored.
            uint sequence=requestSequence;
            if(!Re3InventoryRuntime.Client)
            {
                Authority a;
                if(authority.TryGetValue("host",out a))
                {
                    StoreAmmo(a);a.pose.equipped=false;a.pose.aim=false;a.pose.reloadAt=-100f;
                    if(BoltNetwork.isRunning && BoltNetwork.isServer)
                        CoopSync.G19State(null,delegate(BinaryWriter w){WriteState(w,a,a.request,0,Vector3.zero);});
                }
            }
            ResetLocalState();requestSequence=sequence;local.sequence=sequence;RestoreEquipment();
        }
        internal static void ResetWorld()
        {if(Instance==null)return;Instance.ClearRockets();Instance.ResetLocalState();Instance.authority.Clear();Instance.remote.Clear();Instance.savedAmmo.Clear();Instance.RestoreEquipment();}
        private static string AmmoKey(string key,int weapon){return key+"/weapon:"+weapon;}
        private static int CurrentAmmo(G19Pose p){return !p.Reloading && p.reloadAt>-50 ? p.Capacity:p.ammo;}
        internal static int SavedAmmo(string key,int weapon)
        {if(Instance==null)return Re3Weapon.Capacity(weapon);Authority a;int ammo;if(Instance.authority.TryGetValue(key,out a) && a.pose.weapon==weapon)return CurrentAmmo(a.pose);return Instance.savedAmmo.TryGetValue(AmmoKey(key,weapon),out ammo) ? ammo:Re3Weapon.Capacity(weapon);}
        internal static void RestoreAmmo(string key,int weapon,int ammo){if(Instance!=null)Instance.savedAmmo[AmmoKey(key,weapon)]=Mathf.Clamp(ammo,0,Re3Weapon.Capacity(weapon));}
        private void StoreAmmo(Authority a){savedAmmo[AmmoKey(a.key,a.pose.weapon)]=CurrentAmmo(a.pose);}
        private int SwitchAmmo(string key,byte weapon){int ammo;return savedAmmo.TryGetValue(AmmoKey(key,weapon),out ammo) ? ammo:Re3Weapon.Capacity(weapon);}
        internal static void NetworkReset(){if(Instance!=null){foreach(var a in Instance.authority.Values)Instance.StoreAmmo(a);Instance.ClearRockets();Instance.ResetLocalState();Instance.remote.Clear();Instance.authority.Clear();Instance.RestoreEquipment();}}
        internal static void PeerGone(BoltConnection connection)
        {
            if(Instance==null)return;var gone=new List<string>();
            foreach(var a in Instance.authority.Values)if(a.connection==connection)
            {Instance.StoreAmmo(a);a.pose.equipped=false;Instance.remote.Remove(a.actor);CoopSync.G19State(null,delegate(BinaryWriter w){WriteState(w,a,a.request,0,Vector3.zero);});gone.Add(a.key);}
            foreach(var key in gone)Instance.authority.Remove(key);
        }
        private void Request(byte operation,Vector3 origin,Vector3 direction,byte weapon=0)
        {
            if(operation==0 || operation==1 || operation==3)pendingFireAt=-1f;
            if(weapon==0)weapon=local.weapon;byte movement=Re3Weapon.Movement();
            if(operation!=2 && LocalPlayer.MainCam!=null)direction=LocalPlayer.MainCam.transform.forward;
            uint sequence=++requestSequence;if(sequence==0)sequence=++requestSequence;
            if(Re3InventoryRuntime.Client)
            {
                if(!CoopSync.CanStartDodge)return;
                if(operation==7)local.raiseAt=Time.time;
                if(operation==2){if(weapon!=28)local.ammo--;local.shotAt=Time.time;pendingShots[sequence]=Time.time;Sound(0,origin,false,weapon);}
                CoopSync.G19Request(delegate(BinaryWriter w){w.Write(sequence);w.Write(operation);w.Write(weapon);w.Write(movement);WriteVector(w,origin);WriteVector(w,direction);});
            }
            else Process(null,LocalPlayer.Entity,sequence,operation,weapon,movement,origin,direction);
        }
        internal static void ReceiveRequest(BoltConnection connection,ulong actor,BinaryReader r)
        {
            uint seq=r.ReadUInt32();byte operation=r.ReadByte(),weapon=r.ReadByte(),movement=r.ReadByte();Vector3 origin=ReadVector(r),direction=ReadVector(r);
            if(r.BaseStream.Position!=r.BaseStream.Length || operation>7 || seq==0 || !Re3Weapon.Valid(weapon) || movement>2 || !Finite(origin) || !Finite(direction) || direction.sqrMagnitude<.9f || direction.sqrMagnitude>1.1f)throw new InvalidDataException("G19 request");
            if(Instance!=null){var entity=BoltNetwork.FindEntity(new Bolt.NetworkId(actor));if(entity!=null)Instance.Process(connection,entity,seq,operation,weapon,movement,origin,direction);}
        }
        private void Process(BoltConnection connection,BoltEntity actor,uint sequence,byte operation,byte weapon,byte movement,Vector3 origin,Vector3 direction)
        {
            string key=Re3InventoryRuntime.ConnectionKey(connection);Authority a;
            if(!authority.TryGetValue(key,out a)){if(authority.Count>=64)return;a=new Authority{key=key,connection=connection,actor=actor!=null && actor.isAttached ? actor.networkId.PackedValue:0};a.pose.ammo=SwitchAmmo(key,1);authority.Add(key,a);}
            if(actor!=null && actor.isAttached && a.actor!=actor.networkId.PackedValue){StoreAmmo(a);a.request=0;a.pose.equipped=false;a.pose.reloadAt=-100;}
            if(unchecked((int)(sequence-a.request))<=0)return;a.request=sequence;
            if(actor!=null && actor.isAttached)a.actor=actor.networkId.PackedValue;
            G19Pose p=a.pose;byte accepted=operation;bool owns=Re3InventoryRuntime.OwnsWeapon(connection,operation==1 ? weapon:p.weapon);
            if(operation!=2)origin=actor!=null ? actor.transform.position:LocalPlayer.Transform.position;
            if(!p.Reloading && p.reloadAt>-50){p.ammo=p.Capacity;p.reloadAt=-100;}
            if(operation==0 || !owns){StoreAmmo(a);p.equipped=false;p.aim=false;p.reloadAt=-100;accepted=0;}
            else if(operation==1){StoreAmmo(a);p.weapon=weapon;p.ammo=SwitchAmmo(key,weapon);p.reloadAt=-100;p.shotAt=p.raiseAt=-100;p.aim=false;p.equipped=true;p.equipAt=Time.time;}
            else if(operation==2)
            {
                Vector3 actorPosition=actor!=null ? actor.transform.position:LocalPlayer.Transform.position;
                if(!p.equipped || p.weapon!=weapon || p.Reloading || p.ammo==0 || Time.time<a.fireAt || NativeOwnsHands(actor,null) || !Finite(origin) || !Finite(direction)
                    || (origin-actorPosition).sqrMagnitude>10f*10f || direction.sqrMagnitude<.9f || direction.sqrMagnitude>1.1f){accepted=6;}
                else if(p.weapon==28 && !RocketReady){accepted=6;}
                else {if(p.weapon!=28)p.ammo--;a.fireAt=Time.time+Re3Weapon.Fire(p.weapon);p.shotAt=Time.time;p.movement=movement;if(p.weapon==28)
                    {LaunchRocket(a.actor,sequence,origin,direction.normalized,actor,true);
                        if(BoltNetwork.isRunning && BoltNetwork.isServer)CoopSync.RocketState(null,delegate(BinaryWriter w){w.Write((byte)0);w.Write(a.actor);w.Write(sequence);WriteVector(w,origin);WriteVector(w,direction.normalized);});}
                    else Shoot(origin,direction.normalized,actor,p);}
            }
            else if(operation==3){if(p.weapon!=28 && p.equipped && !p.Reloading && p.ammo<p.Capacity){p.reloadAt=Time.time;p.reloadSequence=sequence;}else accepted=6;}
            else if(operation==4 || operation==5){if(p.equipped)p.aim=operation==4;else accepted=6;}
            else if(operation==7)
            {if(p.equipped && p.weapon==weapon && !p.Reloading && p.ammo>0 && Time.time>=a.fireAt)p.raiseAt=Time.time;else accepted=6;}
            if(accepted!=6 || operation==6)p.lookDirection=direction.normalized;
            p.sequence=sequence;p.movement=movement;
            ApplyState(a.actor,p,sequence,accepted,origin);
            if(BoltNetwork.isRunning && BoltNetwork.isServer)CoopSync.G19State(null,delegate(BinaryWriter w){WriteState(w,a,sequence,accepted,origin);});
        }
        private void TickNetwork()
        {
            if(Time.time<networkAt)return;networkAt=Time.time+.25f;
            if(Re3InventoryRuntime.Client){if(local.equipped && Time.time>=networkSyncAt){networkSyncAt=Time.time+2f;Request(6,Vector3.zero,Vector3.forward);}return;}
            foreach(var a in authority.Values)
            {
                bool changed=false;
                if(a.pose.equipped && !Re3InventoryRuntime.OwnsWeapon(a.connection,a.pose.weapon)){StoreAmmo(a);a.pose.equipped=false;a.pose.aim=false;a.pose.reloadAt=-100;changed=true;}
                if(!a.pose.Reloading && a.pose.reloadAt>-50){a.pose.ammo=a.pose.Capacity;a.pose.reloadAt=-100;changed=true;}
                if(!changed)continue;
                ApplyState(a.actor,a.pose,a.request,6,Vector3.zero);
                if(BoltNetwork.isRunning && BoltNetwork.isServer)CoopSync.G19State(null,delegate(BinaryWriter w){WriteState(w,a,a.request,6,Vector3.zero);});
            }
        }
        private float networkSyncAt;
        private static void WriteState(BinaryWriter w,Authority a,uint sequence,byte operation,Vector3 origin)
        {
            var p=a.pose;w.Write(a.actor);w.Write(sequence);w.Write(operation);w.Write(p.equipped);w.Write(p.aim);w.Write(p.weapon);w.Write(p.movement);w.Write((byte)p.ammo);
            w.Write(p.Reloading ? p.ReloadSeconds-(Time.time-p.reloadAt):0f);w.Write(p.reloadSequence);w.Write(Mathf.Clamp(Time.time-p.shotAt,0,10));w.Write(Mathf.Clamp(Time.time-p.raiseAt,0,10));WriteVector(w,origin);WriteVector(w,p.lookDirection);
        }
        internal static void SendSnapshot(BoltConnection connection)
        {if(Instance!=null)foreach(var a in Instance.authority.Values)CoopSync.G19State(connection,delegate(BinaryWriter w){WriteState(w,a,a.request,6,Vector3.zero);});}
        internal static void ReceiveState(BinaryReader r)
        {
            ulong actor=r.ReadUInt64();uint seq=r.ReadUInt32();byte op=r.ReadByte();var pose=new G19Pose{equipped=r.ReadBoolean(),aim=r.ReadBoolean(),weapon=r.ReadByte(),movement=r.ReadByte(),ammo=r.ReadByte()};
            float remaining=r.ReadSingle();pose.reloadSequence=r.ReadUInt32();float age=r.ReadSingle(),raiseAge=r.ReadSingle();Vector3 origin=ReadVector(r);pose.lookDirection=ReadVector(r);
            if(r.BaseStream.Position!=r.BaseStream.Length || op>7 || !Re3Weapon.Valid(pose.weapon) || pose.movement>2 || pose.ammo>pose.Capacity || !Finite(remaining) || remaining<0 || remaining>pose.ReloadSeconds+.1f || !Finite(age) || age<0 || age>10 || !Finite(raiseAge) || raiseAge<0 || raiseAge>10 || !Finite(origin) || !Finite(pose.lookDirection) || pose.lookDirection.sqrMagnitude<.9f || pose.lookDirection.sqrMagnitude>1.1f)throw new InvalidDataException("G19 state");
            pose.reloadAt=remaining>0 ? Time.time-(pose.ReloadSeconds-remaining):-100;pose.shotAt=Time.time-age;pose.raiseAt=Time.time-raiseAge;
            if(Instance!=null)Instance.ApplyState(actor,pose,seq,op,origin);
        }
        private void ApplyState(ulong actor,G19Pose source,uint seq,byte operation,Vector3 origin)
        {
            bool own=actor==0 || (LocalPlayer.Entity!=null && LocalPlayer.Entity.isAttached && LocalPlayer.Entity.networkId.PackedValue==actor);
            G19Pose p;if(own)p=local;else if(!remote.TryGetValue(actor,out p)){p=new G19Pose();remote.Add(actor,p);}
            if(unchecked((int)(seq-p.sequence))<0)return;
            bool newly=source.equipped && (!p.equipped || p.weapon!=source.weapon),duplicate=seq==p.sequence;
            bool predicted=own && pendingShots.ContainsKey(seq);
            p.equipped=source.equipped;p.aim=source.aim;p.weapon=source.weapon;p.movement=source.movement;p.ammo=source.ammo;p.reloadAt=source.reloadAt;p.reloadSequence=source.reloadSequence;p.shotAt=source.shotAt;p.raiseAt=source.raiseAt;p.lookDirection=source.lookDirection;p.sequence=seq;p.receivedAt=Time.time;
            if(own && Re3InventoryRuntime.Client && pendingShots.Count>0)
            {
                var ack=new List<uint>();foreach(var pair in pendingShots)if(unchecked((int)(seq-pair.Key))>=0)ack.Add(pair.Key);
                foreach(uint key in ack)pendingShots.Remove(key);
                if(p.weapon!=28)p.ammo=Mathf.Max(0,p.ammo-pendingShots.Count);
                foreach(float sent in pendingShots.Values)p.shotAt=Mathf.Max(p.shotAt,sent);
            }
            if(newly)p.equipAt=Time.time;
            if(!duplicate && operation==2 && !predicted)Sound(0,origin,!own,p.weapon);
            if(!duplicate && operation==3)Sound(1,own && LocalPlayer.MainCam!=null ? LocalPlayer.MainCam.transform.position:origin,!own,p.weapon);
            if(own && !p.equipped)RestoreEquipment();
        }
        private static void WriteVector(BinaryWriter w,Vector3 p){w.Write(p.x);w.Write(p.y);w.Write(p.z);}
        private static Vector3 ReadVector(BinaryReader r){return new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());}
        private static bool Finite(float f){return !float.IsNaN(f) && !float.IsInfinity(f);}
        private static bool Finite(Vector3 p){return Finite(p.x)&&Finite(p.y)&&Finite(p.z);}
    }
}
