﻿using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    // Public inventory IDs remain stable across all saved versions.
    internal static class Re3Weapon
    {
        internal static bool Valid(int id){return id==1 || id==3 || id==28;}
        internal static int Capacity(int id){return id==28 ? 1:id==3 ? 4:15;}
        internal static string Name(int id){return id==28 ? "Lanzacohetes infinito":id==3 ? "M3":"G19";}
        internal static float Reload(int id){return id==3 ? 261f/60f:104f/60f;}
        internal static float Fire(int id){return id==28 ? 120f/60f:id==3 ? 87f/60f:.28f;}
        internal static float Spread(bool aim,byte movement)
        {return movement==2 ? 12f:aim ? (movement==0 ? 1.1f:2.4f):(movement==0 ? 3.2f:5.5f);}
        internal static byte Movement()
        {
            var fp=TheForest.Utils.LocalPlayer.FpCharacter;
            if(fp==null)return 0;
            var rb=fp.GetComponent<Rigidbody>();
            bool moving=rb!=null && Vector3.ProjectOnPlane(rb.velocity,Vector3.up).sqrMagnitude>.25f;
            return !moving ? (byte)0:fp.running ? (byte)2:(byte)1;
        }
    }
}
