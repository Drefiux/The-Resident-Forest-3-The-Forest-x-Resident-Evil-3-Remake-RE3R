﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using TheForest.Utils;

namespace ForestRE3JillVisualProbe
{
    [DefaultExecutionOrder(10000)]
    public sealed class JillPlayerAvatar : MonoBehaviour
    {
        internal static JillPlayerAvatar Current;
        internal bool NetworkReady { get { return attached; } }
        internal CharacterProfile NetworkCharacter { get { return rendered; } }
        internal float DodgeMotionScale { get { return bodyPose!=null ? bodyPose.DodgeMotionScale:0f; } }
        internal bool TryDodgeEyes(out Vector3 position,out Quaternion rotation)
        {
            position=Vector3.zero; rotation=Quaternion.identity;
            return attached && bodyPose!=null && bodyPose.TryDodgeEyes(out position,out rotation);
        }
        internal bool TryWeaponEyes(out Vector3 position,out Quaternion rotation)
        {position=Vector3.zero;rotation=Quaternion.identity;return attached && bodyPose!=null && bodyPose.TryWeaponEyes(out position,out rotation);}
        private GameObject prefab, body;
        private CharacterProfile selected=CharacterProfile.Jill;
        private CharacterProfile rendered=CharacterProfile.Jill;
        private FirstPersonCharacter selectionOwner;
        private JillVoice voice;
        private FirstPersonCharacter controller;
        private Animator nativeAnimator;
        private AnimatorCullingMode originalCulling;
        private JillMotionPreview bodyPose;
        private readonly List<Renderer> worldRenderers = new List<Renderer>();
        private readonly Dictionary<Renderer, ShadowCastingMode> worldShadows = new Dictionary<Renderer, ShadowCastingMode>();
        private readonly Dictionary<Renderer, bool> worldEnabled = new Dictionary<Renderer, bool>();
        private readonly List<Renderer> firstPersonRenderers = new List<Renderer>();
        private readonly Dictionary<Renderer, bool> nativeRenderers = new Dictionary<Renderer, bool>();
        private readonly List<Mesh> meshes = new List<Mesh>();
        private readonly List<Material> materials = new List<Material>();
        private readonly HashSet<Camera> reportedCameras = new HashSet<Camera>();
        private Vector3 modelBottom;
        private float unitHeight, retryAt, scanAt;
        private bool attached, cullingChanged;
        private FirstPersonCharacter failedController;
        private Animator failedAnimator;
        private string status = "";

        public void Initialize(GameObject avatarPrefab)
        {
            prefab = avatarPrefab;
            Current=this;
            Camera.onPreCull += BeforeCamera;
        }

        private void Update()
        {
            if (attached && (controller != LocalPlayer.FpCharacter || nativeAnimator != LocalPlayer.Animator
                || (controller != null && !controller.gameObject.activeInHierarchy))) { Detach(); status=""; }
            if (LocalPlayer.FpCharacter==null) selectionOwner=null;
            if (LocalPlayer.FpCharacter!=null && LocalPlayer.FpCharacter.gameObject.activeInHierarchy && selectionOwner!=LocalPlayer.FpCharacter)
            {
                selectionOwner=LocalPlayer.FpCharacter;
                selected=UnityEngine.Random.Range(0,2)==0 ? CharacterProfile.Jill : CharacterProfile.Carlos;
                ModAPI.Log.Write("[ForestRE3] CHARACTER_RANDOM_SELECTED character="+selected.Name+"; probability=0.5; opening=Jill");
            }
            if (attached && !JillPlaneAvatar.CharacterLocked && rendered!=selected)
                ReconnectCharacter(selected);
            if (Re3DeveloperTools.Enabled && attached && !DodgeRuntime.Busy && !Re3InventoryRuntime.BlockControls && UnityEngine.Input.GetKeyDown(KeyCode.F8))
            {
                if (JillPlaneAvatar.CharacterLocked) status="Avion/despertar: Jill obligatoria | F8 disponible al terminar";
                else ReconnectCharacter(selected==CharacterProfile.Jill ? CharacterProfile.Carlos : CharacterProfile.Jill);
            }
            if (failedController != LocalPlayer.FpCharacter || failedAnimator != LocalPlayer.Animator)
            { failedController=null; failedAnimator=null; }
            if (!attached && failedController == null && Time.realtimeSinceStartup >= retryAt)
            {
                retryAt = Time.realtimeSinceStartup+2f;
                if (LocalPlayer.FpCharacter == null || LocalPlayer.Animator == null || LocalPlayer.MainCam == null
                    || !LocalPlayer.FpCharacter.gameObject.activeInHierarchy || !LocalPlayer.Animator.isInitialized
                    || LocalPlayer.FpCharacter.capsule == null || LocalPlayer.FpCharacter.originalHeight <= 0f) return;
                status="Conectando cuerpo de "+selected.Name+"...";
                ModAPI.Log.Write("[ForestRE3] PLAYER_ATTACH_BEGIN version=0.8.9.1");
                try { Attach(); }
                catch (Exception exception)
                {
                    failedController=LocalPlayer.FpCharacter; failedAnimator=LocalPlayer.Animator;
                    Detach();
                    status = "No se pudo conectar "+selected.Name+"; consulta el registro.";
                    ModAPI.Log.Write("[ForestRE3] PLAYER_ATTACH_FAILED " + exception);
                }
            }
        }

        private void Attach()
        {
            controller = LocalPlayer.FpCharacter; nativeAnimator = LocalPlayer.Animator;
            if (controller.capsule == null || controller.originalHeight <= 0f)
                throw new InvalidOperationException("Missing native player collision reference.");
            // The primary actor can itself animate the intro between the seat
            // and crawl actors. It must also be Jill until the intro flag clears.
            rendered=JillPlaneAvatar.CharacterLocked ? CharacterProfile.Jill : selected;
            prefab=rendered.Prefab;
            if (prefab==null) throw new InvalidOperationException("Missing roster prefab: "+selected.Name);
            body = UnityEngine.Object.Instantiate(prefab) as GameObject;
            body.name = rendered.Name+"_PlayerBody_0771";
            MakeVisualOnly(body);
            body.transform.rotation = Quaternion.identity; body.transform.position = Vector3.zero; body.transform.localScale = Vector3.one;
            Bounds geometry = AvatarGeometry.MeasureGeometry(body);
            unitHeight = geometry.size.y;
            if (unitHeight < .05f || unitHeight > 10f) throw new InvalidOperationException("Unexpected Jill geometry height.");
            modelBottom = new Vector3(geometry.center.x, geometry.min.y, geometry.center.z);
            AvatarGeometry.AdjustEyes(body, materials);
            worldRenderers.AddRange(body.GetComponentsInChildren<Renderer>(true));
            foreach (Renderer renderer in worldRenderers)
            { worldShadows[renderer]=renderer.shadowCastingMode; worldEnabled[renderer]=renderer.enabled; }
            // Cut first-person geometry by skin weights, without changing the
            // source mesh or disabling any part of the native animator/player.
            BuildFirstPersonGeometry(body, false);
            int bodyParts = firstPersonRenderers.Count;
            BuildFirstPersonGeometry(body, true);
            if (bodyParts == 0 || firstPersonRenderers.Count == bodyParts)
                throw new InvalidOperationException("First-person Jill geometry was not generated.");
            JillFirstPersonView.Configure(firstPersonRenderers, materials);
            PlaceModels();
            // Configure the rig before Initialize: only the external laboratory
            // needs sole probes / a fixed floor. First-person arms have no feet.
            bodyPose = body.AddComponent<JillMotionPreview>(); bodyPose.AttachToPlayer(true); bodyPose.SetPlayerMeshBottom(modelBottom.y); bodyPose.Initialize(rendered);
            if (!bodyPose.PoseAvailable)
                throw new InvalidOperationException("Required native body/palm references are unavailable.");
            originalCulling = nativeAnimator.cullingMode;
            nativeAnimator.cullingMode = AnimatorCullingMode.AlwaysAnimate; cullingChanged=true;
            ScanNativeRenderers();
            if (nativeRenderers.Count == 0) throw new InvalidOperationException("Native player skins were not found.");
            bodyPose.StepPlayerPose();
            attached=true; SetVisibleBody(); HideNativeRenderers();
            if (voice==null)
            {
                voice=gameObject.AddComponent<JillVoice>();
                try { voice.Initialize(); }
                catch (Exception audioError)
                {
                    voice.Shutdown(); voice.enabled=false; UnityEngine.Object.Destroy(voice); voice=null;
                    ModAPI.Log.Write("[ForestRE3] CHARACTER_VOICE_INIT_FAILED_BODY_RETAINED "+audioError);
                }
            }
            if (voice!=null) voice.SetCharacter(selected);
            status = selected.Name+" jugable | F8: cambiar Jill / Carlos | colisiones y camara nativas";
            ModAPI.Log.Write("[ForestRE3] PLAYER_ATTACHED version=0.8.9.1; capsule="+controller.capsule.name
                +"; character="+rendered.Name+"; gameplayChoice="+selected.Name+"; originalHeight="+controller.originalHeight+"; bodyHeightRatio="+rendered.HeightRatio+"; nativeRenderers="+nativeRenderers.Count
                +"; fpRenderers="+firstPersonRenderers.Count+"; cameraUnmodified=true; collidersAdded=0; nativeAnimatorAlwaysAnimate=true");
        }

        private void PlaceModels()
        {
            CapsuleCollider capsule = controller.capsule;
            Vector3 axis = capsule.direction == 0 ? Vector3.right : capsule.direction == 2 ? Vector3.forward : Vector3.up;
            Vector3 worldAxis = capsule.transform.TransformVector(axis);
            float standing = controller.originalHeight*worldAxis.magnitude;
            float scale = standing*rendered.HeightRatio/unitHeight;
            Vector3 foot = capsule.transform.TransformPoint(capsule.center)-worldAxis*capsule.height*.5f;
            Vector3 forward = Vector3.ProjectOnPlane(nativeAnimator.transform.forward, Vector3.up);
            if (forward.sqrMagnitude < .001f) forward = Vector3.ProjectOnPlane(controller.transform.forward, Vector3.up);
            Quaternion heading = Quaternion.LookRotation(forward.normalized, Vector3.up);
            DodgeAction dodge=DodgeRuntime.Pose(null);
            if (dodge!=null) heading=DodgeRuntime.Heading(dodge);
            // The standing bottom remains tied to the moving native capsule.
            // Native COG motion supplies crouch/swim/climb/death pose offsets.
            Vector3 position = foot-heading*(modelBottom*scale);
            foreach (GameObject model in new[] { body })
            {
                model.transform.position = position; model.transform.rotation = heading;
                model.transform.localScale = Vector3.one*scale;
            }
        }

        private void LateUpdate()
        {
            if (!attached || controller == null || nativeAnimator == null) return;
            try
            {
                if (Time.realtimeSinceStartup >= scanAt) { scanAt = Time.realtimeSinceStartup+1f; ScanNativeRenderers(); }
                HideNativeRenderers(); PlaceModels();
                bodyPose.StepPlayerPose();
                SetVisibleBody();
                if (!bodyPose.PoseAvailable)
                    throw new InvalidOperationException("Player pose adapter stopped; restoring native renderers.");
            }
            catch (Exception exception)
            {
                ModAPI.Log.Write("[ForestRE3] PLAYER_POSE_FAILED " + exception);
                failedController=LocalPlayer.FpCharacter; failedAnimator=LocalPlayer.Animator;
                Detach();
                status = "Adaptacion detenida; consulta el registro.";
            }
        }

        private void ScanNativeRenderers()
        {
            var roots = new List<Transform> { nativeAnimator.transform, controller.transform };
            if (LocalPlayer.GameObject != null) roots.Add(LocalPlayer.GameObject.transform);
            if (LocalPlayer.PlayerBase != null) roots.Add(LocalPlayer.PlayerBase.transform);
            foreach (Transform root in roots)
            {
                foreach (CoopPlayerVariations variation in root.GetComponentsInChildren<CoopPlayerVariations>(true))
                    foreach (Renderer renderer in new Renderer[] { variation.Hat, variation.Top, variation.Pants, variation.FullBody })
                        if (renderer != null && !nativeRenderers.ContainsKey(renderer)) nativeRenderers.Add(renderer, renderer.enabled);
                foreach (Renderer renderer in root.GetComponentsInChildren<Renderer>(true))
                {
                    if (renderer == null || nativeRenderers.ContainsKey(renderer)) continue;
                    // Native human/arm/clothing/armor skins. Item meshes with a
                    // wrist attachment or their own rigs remain visible.
                    if (!IsNativeSkinRenderer(renderer)) continue;
                    nativeRenderers.Add(renderer, renderer.enabled);
                    ModAPI.Log.Write("[ForestRE3] PLAYER_SKIN_REPLACED renderer="+renderer.name+"; layer="+renderer.gameObject.layer);
                }
            }
        }

        internal static bool IsNativeSkinRenderer(Renderer renderer)
        {
            string name = renderer.name;
            bool namedGeometry = name.StartsWith("char_", StringComparison.Ordinal)
                || name == "playerOnFloorHeadGeo";
            SkinnedMeshRenderer skin = renderer as SkinnedMeshRenderer;
            if (skin == null) return namedGeometry && renderer is MeshRenderer;
            int human = 0;
            foreach (Transform bone in skin.bones)
                if (bone != null && bone.name.StartsWith("char_", StringComparison.Ordinal)) human++;
            // Head meshes can have fewer than eight bones. Keep explicit human
            // geometry hidden as well; books/held items retain their own names.
            return human > 0 && (human >= 8 || namedGeometry) && human >= skin.bones.Length*.6f;
        }

        private void HideNativeRenderers()
        {
            foreach (Renderer renderer in nativeRenderers.Keys) if (renderer != null) renderer.enabled = false;
        }

        private void BuildFirstPersonGeometry(GameObject model, bool armOnly)
        {
            BuildFirstPersonGeometry(model, armOnly, meshes, firstPersonRenderers);
        }

        internal static void BuildFirstPersonGeometry(GameObject model, bool armOnly, List<Mesh> meshes, List<Renderer> firstPersonRenderers)
        {
            foreach (SkinnedMeshRenderer original in model.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (!original.enabled || original.sharedMesh == null || original.name.Contains("_JillFP")) continue;
                // Carlos's intercom rests around his neck. In first person its
                // ear cups enter the sight line; the original remains intact
                // for shadows and other players' full-body renderers.
                if(original.name.Contains("pl0000_Incom_Mat"))continue;
                if (IsHeadGeometry(original.transform, model.transform))
                {
                    // Carlos's actual neck rim belongs to Face_Mat. Copy only
                    // its closing fan before excluding all head geometry.
                    if (!armOnly)
                    {
                        Mesh closure=JillNeckClosure.Create(original,model.transform);
                        if (closure!=null)
                        {
                            meshes.Add(closure);
                            GameObject cap=new GameObject(closure.name); cap.transform.SetParent(original.transform,false);
                            cap.layer=VisibleLayer(original.gameObject.layer);
                            Bounds neckBounds=original.localBounds; neckBounds.Expand(4f);
                            var closed=cap.AddComponent<SkinnedMeshRenderer>(); closed.sharedMesh=closure; closed.sharedMaterials=original.sharedMaterials;
                            closed.bones=original.bones; closed.rootBone=original.rootBone; closed.updateWhenOffscreen=true; closed.localBounds=neckBounds;
                            closed.lightProbeUsage=original.lightProbeUsage; closed.probeAnchor=original.probeAnchor;
                            closed.receiveShadows=true; closed.shadowCastingMode=ShadowCastingMode.Off; firstPersonRenderers.Add(closed);
                        }
                    }
                    continue;
                }
                Mesh source = original.sharedMesh;
                BoneWeight[] weights = source.boneWeights;
                Vector3[] vertices = source.vertices;
                // Unity returns a fresh array on every .bones property access.
                // Cache once per renderer, never four allocations per vertex.
                Transform[] bones = original.bones;
                if (weights.Length != vertices.Length) throw new InvalidOperationException("Invalid first-person skin weights.");
                float[] armWeights = new float[vertices.Length];
                for (int i = 0; i < vertices.Length; i++)
                {
                    BoneWeight w = weights[i];
                    float arm = ArmWeight(bones[w.boneIndex0])*w.weight0+ArmWeight(bones[w.boneIndex1])*w.weight1
                        +ArmWeight(bones[w.boneIndex2])*w.weight2+ArmWeight(bones[w.boneIndex3])*w.weight3;
                    armWeights[i] = arm;
                }
                var triangles = new List<int[]>(); int count = 0;
                for (int slot = 0; slot < source.subMeshCount; slot++)
                {
                    int[] all = source.GetTriangles(slot); var accepted = new List<int>();
                    for (int i = 0; i < all.Length; i += 3)
                        // Complementary triangle ownership leaves no missing
                        // strip at shoulders/armholes. The torso has no Y cutoff.
                        if (((armWeights[all[i]]+armWeights[all[i+1]]+armWeights[all[i+2]])/3f > .5f) == armOnly)
                        { accepted.Add(all[i]); accepted.Add(all[i+1]); accepted.Add(all[i+2]); }
                    triangles.Add(accepted.ToArray()); count += accepted.Count;
                }
                if (count == 0) continue;
                Mesh mesh = UnityEngine.Object.Instantiate(source) as Mesh;
                mesh.name = source.name+(armOnly ? "_JillFPArms" : "_JillFPBody");
                for (int slot = 0; slot < triangles.Count; slot++) mesh.SetTriangles(triangles[slot], slot);
                meshes.Add(mesh);
                GameObject skin = new GameObject(mesh.name);
                skin.transform.SetParent(original.transform, false);
                skin.layer = VisibleLayer(original.gameObject.layer);
                var renderer = skin.AddComponent<SkinnedMeshRenderer>();
                renderer.sharedMesh = mesh; renderer.sharedMaterials = original.sharedMaterials;
                renderer.bones = bones; renderer.rootBone = original.rootBone;
                renderer.updateWhenOffscreen = true;
                // Native wrist anchors can move beyond the imported rest bounds.
                // Keep skinned geometry eligible before any camera callback.
                Bounds bounds = original.localBounds; bounds.Expand(4f); renderer.localBounds = bounds;
                renderer.lightProbeUsage = original.lightProbeUsage; renderer.probeAnchor = original.probeAnchor;
                renderer.receiveShadows = true; renderer.shadowCastingMode = ShadowCastingMode.Off;
                renderer.enabled = true; firstPersonRenderers.Add(renderer);
                if (!armOnly)
                {
                    Mesh closure=JillNeckClosure.Create(original,model.transform);
                    if (closure!=null)
                    {
                        meshes.Add(closure);
                        GameObject cap=new GameObject(closure.name); cap.transform.SetParent(original.transform,false); cap.layer=skin.layer;
                        var closed=cap.AddComponent<SkinnedMeshRenderer>(); closed.sharedMesh=closure; closed.sharedMaterials=original.sharedMaterials;
                        closed.bones=bones; closed.rootBone=original.rootBone; closed.updateWhenOffscreen=true; closed.localBounds=bounds;
                        closed.lightProbeUsage=original.lightProbeUsage; closed.probeAnchor=original.probeAnchor;
                        closed.receiveShadows=true; closed.shadowCastingMode=ShadowCastingMode.Off; firstPersonRenderers.Add(closed);
                    }
                }
                ModAPI.Log.Write("[ForestRE3] PLAYER_FP_GEOMETRY armOnly="+armOnly+"; renderer="+original.name+"; triangles="+(count/3));
            }
        }

        private static bool IsHeadGeometry(Transform part, Transform root)
        {
            for (Transform at=part; at != null && at != root; at=at.parent)
                if (at.name.StartsWith("Head_pl",StringComparison.Ordinal) || at.name.StartsWith("Hair_pl",StringComparison.Ordinal)) return true;
            return false;
        }

        internal static int VisibleLayer(int preferred)
        {
            Camera camera = LocalPlayer.MainCam;
            if (camera == null || (camera.cullingMask & (1 << preferred)) != 0) return preferred;
            if ((camera.cullingMask & 1) != 0) return 0;
            for (int layer=0; layer<32; layer++) if ((camera.cullingMask & (1 << layer)) != 0) return layer;
            return preferred;
        }

        internal static bool IsOwnCamera(Camera camera)
        {
            if (camera == null || camera == LocalPlayer.InventoryCam) return false;
            return camera == LocalPlayer.MainCam || (LocalPlayer.MainCamTr != null
                && camera.transform.IsChildOf(LocalPlayer.MainCamTr));
        }

        private void SetVisibleBody()
        {
            bool visible = !JillPlaneAvatar.IsActive;
            foreach (Renderer renderer in worldRenderers)
                if (renderer != null) { renderer.enabled=visible && worldEnabled[renderer]; renderer.shadowCastingMode=ShadowCastingMode.ShadowsOnly; }
            foreach (Renderer renderer in firstPersonRenderers)
                if (renderer != null) { renderer.enabled=visible; renderer.gameObject.layer=VisibleLayer(renderer.gameObject.layer); }
        }

        private static float ArmWeight(Transform bone)
        {
            if (bone == null) return 0f;
            string name = bone.name;
            return name.StartsWith("l_arm_", StringComparison.Ordinal) || name.StartsWith("r_arm_", StringComparison.Ordinal)
                || name.StartsWith("l_hand_", StringComparison.Ordinal) || name.StartsWith("r_hand_", StringComparison.Ordinal) ? 1f : 0f;
        }

        // Body visibility is persistent and independent of render-camera IDs.
        // Only the headless copies are drawn. The complete originals cast shadows.
        private void BeforeCamera(Camera camera)
        {
            if (!attached || camera == null) return;
            HideNativeRenderers();
            JillFirstPersonView.BeforeCamera(camera, materials, controller.originalHeight*Mathf.Abs(controller.capsule.transform.lossyScale.y));
            if (reportedCameras.Add(camera))
                ModAPI.Log.Write("[ForestRE3] PLAYER_RENDER_CAMERA name="+camera.name+"; mask="+camera.cullingMask
                    +"; body="+body.transform.position+"; parts="+firstPersonRenderers.Count
                    +"; cinematic="+JillPlaneAvatar.IsActive+"; visibility=persistent_headless; camera=native_except_rendered_dodge_eyes");
        }

        internal static void MakeVisualOnly(GameObject model)
        {
            int count=0;
            foreach (Collider collider in model.GetComponentsInChildren<Collider>(true))
            { collider.enabled=false; UnityEngine.Object.Destroy(collider); count++; }
            foreach (Rigidbody rigidbody in model.GetComponentsInChildren<Rigidbody>(true))
            { rigidbody.detectCollisions=false; rigidbody.isKinematic=true; UnityEngine.Object.Destroy(rigidbody); count++; }
            ModAPI.Log.Write("[ForestRE3] JILL_VISUAL_ONLY model="+model.name+"; physicsComponentsRemoved="+count);
        }

        private void ReconnectCharacter(CharacterProfile target)
        {
            CharacterProfile previous=rendered;
            selected=target;
            // Keep the single audio channel alive, including an ongoing voice.
            Detach(true);
            try
            {
                Attach();
                ModAPI.Log.Write("[ForestRE3] CHARACTER_SWITCH character="+selected.Name+"; voiceInterrupted=false; nativeActorUnchanged=true");
            }
            catch (Exception error)
            {
                ModAPI.Log.Write("[ForestRE3] CHARACTER_SWITCH_FAILED target="+selected.Name+"; "+error);
                Detach(true); selected=previous;
                try { Attach(); status=previous.Name+" restaurada; cambio fallido, consulta el registro."; }
                catch (Exception restoreError)
                {
                    failedController=LocalPlayer.FpCharacter; failedAnimator=LocalPlayer.Animator;
                    Detach(); status="Cambio detenido; personaje nativo restaurado.";
                    ModAPI.Log.Write("[ForestRE3] CHARACTER_RESTORE_FAILED "+restoreError);
                }
            }
        }

        private void Detach() { Detach(false); }
        private void Detach(bool keepVoice)
        {
            if (!keepVoice && voice!=null)
            {
                voice.Shutdown(); voice.enabled=false; UnityEngine.Object.Destroy(voice); voice=null;
            }
            foreach (var pair in nativeRenderers) if (pair.Key != null) pair.Key.enabled=pair.Value;
            nativeRenderers.Clear();
            if (cullingChanged && nativeAnimator != null) nativeAnimator.cullingMode=originalCulling;
            cullingChanged=false;
            if (body != null) { body.SetActive(false); UnityEngine.Object.Destroy(body); }
            foreach (Mesh mesh in meshes) if (mesh != null) UnityEngine.Object.Destroy(mesh);
            foreach (Material material in materials) if (material != null) UnityEngine.Object.Destroy(material);
            meshes.Clear(); materials.Clear(); worldRenderers.Clear(); worldShadows.Clear(); worldEnabled.Clear(); firstPersonRenderers.Clear(); reportedCameras.Clear();
            attached=false; body=null; bodyPose=null; controller=null; nativeAnimator=null;
        }

        private void OnGUI()
        {
            if (Re3DeveloperTools.Enabled && LocalPlayer.FpCharacter != null)
                GUI.Label(new Rect(12,12,1500,24),"Forest RE3 0.8.9.1 | TAB: inventario RE3R | E: baul | F5: laboratorio | F8: Jill / Carlos | avion: Jill");
            if (Re3DeveloperTools.Enabled && status.Length > 0 && LocalPlayer.FpCharacter != null)
                GUI.Label(new Rect(12,84,1200,24), JillPlaneAvatar.CharacterLocked
                    ? "Avion/despertar: Jill | al terminar: "+selected.Name+" | F8 disponible al terminar" : status);
        }
        private void OnDestroy()
        {
            if (Current==this) Current=null;
            Camera.onPreCull -= BeforeCamera;
            Detach();
        }
    }
}
