﻿using System;
using System.IO;
using System.Xml;
using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    internal static class Re3DeveloperTools
    {
        private static bool? configured;
        internal static bool Enabled
        {
            get
            {
                if(BoltNetwork.isRunning && !BoltNetwork.IsSinglePlayer && !BoltNetwork.isServer)return false;
                if(!configured.HasValue)configured=Read();
                return configured.Value;
            }
        }
        internal static void Reload(){configured=null;}
        private static bool Read()
        {
            try
            {
                string path=Path.GetFullPath(Path.Combine(Application.dataPath,"../Mods/TheResidentForest3.Options.xml"));
                if(!File.Exists(path) || new FileInfo(path).Length>4096)return false;
                using(var reader=XmlReader.Create(path,new XmlReaderSettings{ProhibitDtd=true,XmlResolver=null}))
                {
                    reader.MoveToContent();
                    bool enabled=reader.Name=="TheResidentForest3" && reader.GetAttribute("developerTools")=="true";
                    ModAPI.Log.Write("[ForestRE3] TOOLS_CONFIG enabled="+enabled+"; authority=host_only; path="+path);
                    return enabled;
                }
            }
            catch(Exception error)
            {ModAPI.Log.Write("[ForestRE3] TOOLS_DISABLED invalidOptions="+error.GetType().Name);return false;}
        }
    }
}
