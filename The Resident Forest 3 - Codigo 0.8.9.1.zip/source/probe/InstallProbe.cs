﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using ModAPI.Configurations;
using ModAPI.Data;

internal static class InstallProbe
{
    private static string appRoot;

    private static void InstallResolver()
    {
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs args)
        {
            var name = new AssemblyName(args.Name).Name + ".dll";
            var candidates = new[]
            {
                Path.Combine(appRoot, name),
                Path.Combine(appRoot, "libs", name),
                Path.Combine(appRoot, "libs", "polyfills", name)
            };
            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate)) return Assembly.LoadFrom(candidate);
            }
            return null;
        };
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    public static int Main()
    {
        try
        {
            appRoot = Path.GetFullPath(Directory.GetCurrentDirectory());
            InstallResolver();
            Require(Configuration.Load() == Configuration.ResultCode.Ok, "ModAPI no pudo cargar su configuración local.");

            var gamePath = @"C:\Program Files (x86)\Steam\steamapps\common\The Forest";
            Configuration.SetPath("OriginalGameFiles", Path.Combine(appRoot, "gamefiles", "original"), true);
            Configuration.SetPath("ModdedGameFiles", Path.Combine(appRoot, "gamefiles", "modded"), true);
            Configuration.SetPath("SavegameBackups", Path.Combine(appRoot, "gamefiles", "savegames"), true);
            Configuration.SetPath("Projects", Path.Combine(appRoot, "projects"), true);
            Configuration.SetPath("Mods", Path.Combine(appRoot, "mods"), true);
            Configuration.SetPath("ModLib", Path.Combine(appRoot, "modlib"), true);
            Configuration.SetPath("Libraries", Path.Combine(appRoot, "libs"), true);

            var game = new Game(Configuration.Games["TheForest"], true);
            game.GamePath = gamePath;
            var versionsPath = Path.Combine(appRoot, "configs", "games", "TheForest", "Versions.xml");
            var versionElement = XDocument.Load(versionsPath).Root.Elements("version")
                .FirstOrDefault(e => (string)e.Attribute("id") == "1.11b");
            Require(versionElement != null, "No se encontró el registro local 1.11b.");
            var version = new Game.Versions.Version(versionElement);
            game.GameVersion = version;
            game.BackupVersion = version;
            game.ModLibrary = new ModLib(game);
            Require(game.ModLibrary.Exists && game.ModLibrary.GameVersion == "1.11b", "La biblioteca ModAPI no coincide con 1.11b.");

            var modPath = Path.Combine(Configuration.GetPath("Mods"), "TheForest",
                "ForestRE3LoaderProbe-0.1.0.0-4602557d23367f9d78b0b7b223d7a25b.mod");
            Require(File.Exists(modPath), "No se encontró el paquete diagnóstico en el área de trabajo ModAPI.");
            var mod = new Mod { Game = game, FileName = modPath };
            Require(mod.Load() && mod.Valid, "ModAPI no pudo leer/validar el paquete .mod.");

            game.ApplyMods(new List<Mod> { mod }, null);
            Require(game.LastAppliedModCount == 1, "ModAPI no confirmó exactamente un paquete aplicado.");

            var runtimeConfig = Path.Combine(gamePath, "Mods", "RuntimeConfiguration.xml");
            Require(File.Exists(runtimeConfig), "No apareció RuntimeConfiguration.xml en la carpeta Mods del juego.");
            var xml = XDocument.Load(runtimeConfig);
            var applicationHooks = xml.Root.Elements("ExecuteOnApplicationStart").Count();
            var gameHooks = xml.Root.Elements("ExecuteOnGameStart").Count();
            Require(applicationHooks == 1 && gameHooks == 1, "El paquete aplicado no generó exactamente los dos ganchos esperados.");

            Console.WriteLine("APPLIED_MODS=" + game.LastAppliedModCount);
            Console.WriteLine("APPLICATION_START_HOOKS=" + applicationHooks);
            Console.WriteLine("GAME_START_HOOKS=" + gameHooks);
            Console.WriteLine("RUNTIME_CONFIG=" + runtimeConfig);
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine(exception);
            return 1;
        }
    }
}
