﻿using System;
using System.IO;
using System.Reflection;
using System.Collections;
using UnityEngine;
namespace ForestRE3JillVisualProbe
{
    public sealed partial class G19Runtime
    {
        private IEnumerator LoadM3()
        {
            byte[] bytes=null;
            try
            {
                using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3JillVisualProbe.m3-"+(QualitySettings.activeColorSpace==ColorSpace.Linear ? "linear":"gamma")))
                {
                    if(s==null || s.Length>32*1024*1024)throw new InvalidDataException("M3 bundle bounds");
                    bytes=new byte[(int)s.Length];int at=0;while(at<bytes.Length){int n=s.Read(bytes,at,bytes.Length-at);if(n<=0)throw new EndOfStreamException();at+=n;}
                }
            }
            catch(Exception e){ModAPI.Log.Write("[ForestRE3] M3_ASSET_ERROR "+e);}
            if(bytes==null)yield break;
            var request=AssetBundle.LoadFromMemoryAsync(bytes);yield return request;var bundle=request.assetBundle;
            if(bundle==null){ModAPI.Log.Write("[ForestRE3] M3_ASSET_ERROR bundle=null");yield break;}
            var prefab=bundle.LoadAssetAsync("Assets/Generated/M3/M3.prefab",typeof(GameObject));yield return prefab;M3Prefab=prefab.asset as GameObject;
            M3Icon=bundle.LoadAsset<Texture2D>("Assets/LocalAssets/Re3M3/m3-icon.png");bundle.Unload(false);
            ModAPI.Log.Write("[ForestRE3] M3_ASSETS_LOADED prefab="+(M3Prefab!=null)+"; icon="+(M3Icon!=null));
        }
        private Texture2D shotgunReticle;
        private float reticleRadius=-1f,reticleScale;
        private void MakeShotgunReticle(float radius,float scale)
        {
            radius=Mathf.Round(radius*2f)*.5f;
            if(shotgunReticle!=null && radius==reticleRadius && scale==reticleScale)return;
            if(shotgunReticle!=null)Destroy(shotgunReticle);
            reticleRadius=radius;reticleScale=scale;
            int size=Mathf.CeilToInt(radius*2f+8f*scale);
            size=Mathf.Clamp(size,12,2048);
            var pixels=new Color32[size*size];float center=(size-1)*.5f;
            // Four thin RE-style arcs. Signed-distance antialiasing keeps their
            // stroke constant when the pellet cone changes size, unlike scaling
            // four low-resolution atlas quadrants into a thick blurry circle.
            for(int row=0;row<size;row++)
            {
                float dy=row-center,band=2f*scale+1f;
                if(Mathf.Abs(dy)>radius+band)continue;
                float outer=Mathf.Sqrt(Mathf.Max(0f,(radius+band)*(radius+band)-dy*dy));
                float inner=Mathf.Sqrt(Mathf.Max(0f,(radius-band)*(radius-band)-dy*dy));
                int begin=Mathf.Max(size/2,Mathf.FloorToInt(center+inner));
                int end=Mathf.Min(size-1,Mathf.CeilToInt(center+outer));
                for(int col=begin;col<=end;col++)
                {
                    float dx=col-center;
                    float distance=Mathf.Abs(Mathf.Sqrt(dx*dx+dy*dy)-radius);
                    float gap=Mathf.Clamp01(Mathf.Min(Mathf.Abs(dx),Mathf.Abs(dy))-2.5f*scale);
                    float white=Mathf.Clamp01(.5f+.65f*scale-distance)*gap;
                    float outline=Mathf.Clamp01(.5f+1.6f*scale-distance)*gap*.55f;
                    float alpha=white+outline*(1f-white),value=alpha>0f ? white/alpha:0f;
                    Color32 pixel=new Color(value,value,value,alpha*.94f);
                    pixels[row*size+col]=pixel;pixels[row*size+size-1-col]=pixel;
                }
            }
            shotgunReticle=new Texture2D(size,size,TextureFormat.RGBA32,false);
            shotgunReticle.name="RE3_M3_CleanReticle";shotgunReticle.filterMode=FilterMode.Bilinear;
            shotgunReticle.wrapMode=TextureWrapMode.Clamp;shotgunReticle.SetPixels32(pixels);shotgunReticle.Apply(false,true);
        }
        private void DrawReticle()
        {
            if(Event.current.type!=EventType.Repaint)return;
            Texture2D atlas=Re3Interface.Reticle;if(atlas==null)return;
            float x=Screen.width*.5f,y=Screen.height*.5f,scale=Mathf.Max(.65f,Screen.height/1080f);
            Color before=GUI.color;GUI.color=new Color(1f,1f,1f,.9f);
            Matrix4x4 matrix=GUI.matrix;
            if(local.weapon==28)
            {
                // Original RE3 rocket aiming frame and center glyph.
                float gap=(local.aim ? 28f:40f)*scale;
                for(int i=0;i<4;i++){GUI.matrix=matrix;GUIUtility.RotateAroundPivot(i*90f,new Vector2(x,y));Re3Interface.Image(new Rect(x-gap-16f*scale,y-gap-14f*scale,32f*scale,28f*scale),Re3Interface.Reticle,new Rect(337,184,64,56));GUI.matrix=matrix;}
                Re3Interface.Image(new Rect(x-5f*scale,y-5f*scale,10f*scale,10f*scale),Re3Interface.Reticle,new Rect(173,59,40,40));
            }
            else if(local.weapon==3)
            {
                // The displayed radius is the exact cone bounding every pellet.
                float fov=TheForest.Utils.LocalPlayer.MainCam.fieldOfView*Mathf.Deg2Rad*.5f;
                float radius=Screen.height*.5f*Mathf.Tan(Re3Weapon.Spread(local.aim,Re3Weapon.Movement())*Mathf.Deg2Rad)/Mathf.Tan(fov);
                MakeShotgunReticle(radius,scale);
                GUI.DrawTexture(new Rect(x-shotgunReticle.width*.5f,y-shotgunReticle.height*.5f,shotgunReticle.width,shotgunReticle.height),shotgunReticle);
                Re3Interface.Image(new Rect(x-scale,y-scale,2*scale,2*scale),atlas,new Rect(253,236,20,20));
            }
            else
            {
                float gap=(local.aim ? 5f:11f)*scale,length=11f*scale,thickness=2.5f*scale;
                for(int i=0;i<4;i++)
                {
                    GUI.matrix=matrix;GUIUtility.RotateAroundPivot(i*90f,new Vector2(x,y));
                    Re3Interface.Image(new Rect(x+gap,y-thickness*.5f,length,thickness),atlas,new Rect(0,0,28,10));
                }
                GUI.matrix=matrix;
                Re3Interface.Image(new Rect(x-2*scale,y-2*scale,4*scale,4*scale),atlas,new Rect(253,236,20,20));
            }
            GUI.matrix=matrix;GUI.color=before;
        }
    }
}
