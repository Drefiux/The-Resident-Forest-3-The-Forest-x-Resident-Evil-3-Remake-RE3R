﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;

namespace ForestRE3JillVisualProbe
{
    // Separate namespace/IDs: these can never be passed to Forest's item database.
    internal sealed class Re3Item
    {
        internal ushort id; internal string name,kind; internal int stack,width; internal Color color;
        internal Re3Item(int id,string name,string kind,int stack,int width,Color color)
        { this.id=(ushort)id; this.name=name; this.kind=kind; this.stack=stack; this.width=width; this.color=color; }
    }
    internal static class Re3Catalog
    {
        internal static readonly Re3Item[] Items = {
            new Re3Item(1,"G19","Pistola",1,1,new Color(.65f,.74f,.8f)),
            new Re3Item(2,"G18 (ráfaga)","Pistola",1,1,new Color(.65f,.74f,.8f)),
            new Re3Item(3,"M3","Escopeta",1,2,new Color(.65f,.74f,.8f)),
            new Re3Item(4,"CQBR","Rifle de asalto",1,2,new Color(.65f,.74f,.8f)),
            new Re3Item(5,"MGL","Lanzagranadas",1,2,new Color(.65f,.74f,.8f)),
            new Re3Item(6,"Lightning Hawk","MAG",1,2,new Color(.65f,.74f,.8f)),
            new Re3Item(7,"Cuchillo","Arma cuerpo a cuerpo",1,1,new Color(.65f,.74f,.8f)),
            new Re3Item(8,"Munición de pistola","Munición",60,1,new Color(.91f,.67f,.35f)),
            new Re3Item(9,"Cartuchos de escopeta","Munición",20,1,new Color(.91f,.67f,.35f)),
            new Re3Item(10,"Munición de rifle","Munición",180,1,new Color(.91f,.67f,.35f)),
            new Re3Item(11,"Munición MAG","Munición",20,1,new Color(.91f,.67f,.35f)),
            new Re3Item(12,"Granadas explosivas MGL","Munición",6,1,new Color(.91f,.67f,.35f)),
            new Re3Item(13,"Granadas incendiarias MGL","Munición",6,1,new Color(.91f,.67f,.35f)),
            new Re3Item(14,"Granadas ácidas MGL","Munición",6,1,new Color(.91f,.67f,.35f)),
            new Re3Item(15,"Minas MGL","Munición",6,1,new Color(.91f,.67f,.35f)),
            new Re3Item(16,"Granada de mano","Explosivo",1,1,new Color(.8f,.65f,.35f)),
            new Re3Item(17,"Granada cegadora","Explosivo",1,1,new Color(.8f,.65f,.35f)),
            new Re3Item(18,"Hierba verde","Curación",1,1,new Color(.35f,.8f,.5f)),
            new Re3Item(19,"Hierba roja","Curación",1,1,new Color(.86f,.35f,.4f)),
            new Re3Item(20,"Mezcla V+V","Curación",1,1,new Color(.35f,.8f,.5f)),
            new Re3Item(21,"Mezcla V+R","Curación",1,1,new Color(.35f,.8f,.5f)),
            new Re3Item(22,"Mezcla V+V+V","Curación",1,1,new Color(.35f,.8f,.5f)),
            new Re3Item(23,"Spray de primeros auxilios","Curación",1,1,new Color(.35f,.8f,.5f)),
            new Re3Item(24,"Pólvora","Material RE3R",1,1,new Color(.75f,.7f,.5f)),
            new Re3Item(25,"Pólvora de calidad","Material RE3R",1,1,new Color(.75f,.7f,.5f)),
            new Re3Item(26,"Explosivo A","Material RE3R",1,1,new Color(.75f,.7f,.5f)),
            new Re3Item(27,"Explosivo B","Material RE3R",1,1,new Color(.75f,.7f,.5f)),
            new Re3Item(28,"Lanzacohetes infinito","Lanzacohetes",1,2,new Color(.65f,.74f,.8f))
        };
        internal static Re3Item Find(ushort id) { return id>0 && id<=Items.Length ? Items[id-1]:null; }
    }
    internal struct Re3Slot { internal ushort id,count; }
    internal sealed class Re3Bag
    {
        internal const ushort Continued=65535;
        internal Re3Slot[] slots; internal uint revision=1; internal int columns;
        internal Re3Bag(int capacity,int columns) { slots=new Re3Slot[capacity]; this.columns=columns; }
        internal int Root(int slot) { return slots[slot].id==Continued ? slots[slot].count-1:slot; }
        internal Re3Bag Copy() { var bag=new Re3Bag(slots.Length,columns); bag.slots=(Re3Slot[])slots.Clone(); bag.revision=revision; return bag; }
        internal int Used { get { int n=0; foreach(var s in slots) if(s.id!=0) n++; return n; } }
        internal bool Add(ushort id,int amount)
        {
            Re3Item item=Re3Catalog.Find(id); if(item==null || amount<1 || amount>10000) return false;
            var copy=Copy();
            for(int i=0;i<copy.slots.Length && amount>0;i++) if(copy.slots[i].id==id && item.stack>1)
            { int n=Math.Min(amount,item.stack-copy.slots[i].count); copy.slots[i].count+=(ushort)n; amount-=n; }
            for(int i=0;i<copy.slots.Length && amount>0;i++)
            {
                if(copy.slots[i].id!=0 || (item.width==2 && (i%columns==columns-1 || copy.slots[i+1].id!=0))) continue;
                int n=Math.Min(amount,item.stack); copy.slots[i]=new Re3Slot { id=id,count=(ushort)n }; amount-=n;
                if(item.width==2) copy.slots[i+1]=new Re3Slot { id=Continued,count=(ushort)(i+1) };
            }
            if(amount!=0) return false; slots=copy.slots; revision++; return true;
        }
        internal static bool Transfer(Re3Bag from,Re3Bag to,int slot,int amount)
        {
            if(slot<0 || slot>=from.slots.Length) return false; slot=from.Root(slot);
            Re3Slot s=from.slots[slot]; Re3Item item=Re3Catalog.Find(s.id);
            if(item==null || amount<1 || amount>s.count || !to.Add(s.id,amount)) return false;
            from.slots[slot].count-=(ushort)amount;
            if(from.slots[slot].count==0) { from.slots[slot]=new Re3Slot(); if(item.width==2) from.slots[slot+1]=new Re3Slot(); }
            from.revision++; return true;
        }
        private static void ClearItem(Re3Bag bag,int slot)
        {
            var item=Re3Catalog.Find(bag.slots[slot].id);
            bag.slots[slot]=new Re3Slot();
            if(item!=null && item.width==2)bag.slots[slot+1]=new Re3Slot();
        }
        private static bool PutAt(Re3Bag bag,int slot,Re3Slot value)
        {
            var item=Re3Catalog.Find(value.id);
            if(item==null || slot<0 || slot>=bag.slots.Length || slot%bag.columns+item.width>bag.columns
                || slot+item.width>bag.slots.Length)return false;
            for(int i=0;i<item.width;i++)if(bag.slots[slot+i].id!=0)return false;
            bag.slots[slot]=value;
            if(item.width==2)bag.slots[slot+1]=new Re3Slot{id=Continued,count=(ushort)(slot+1)};
            return true;
        }
        // Move, swap or merge complete stacks atomically, including two-cell
        // weapons. Never compact the bag: positions define quick slots 5-8.
        internal static bool Move(Re3Bag from,Re3Bag to,int source,int destination)
        {
            if(source<0 || source>=from.slots.Length || destination<0 || destination>=to.slots.Length)return false;
            source=from.Root(source);destination=to.Root(destination);
            bool same=System.Object.ReferenceEquals(from,to);
            if(same && source==destination)return true;
            Re3Slot value=from.slots[source],other=to.slots[destination];
            var item=Re3Catalog.Find(value.id);if(item==null)return false;
            var a=from.Copy();var b=same ? a:to.Copy();
            if(value.id==other.id && item.stack>1 && other.count<item.stack)
            {
                int amount=Math.Min(value.count,item.stack-other.count);
                b.slots[destination].count+=(ushort)amount;a.slots[source].count-=(ushort)amount;
                if(a.slots[source].count==0)ClearItem(a,source);
            }
            else
            {
                ClearItem(a,source);if(other.id!=0)ClearItem(b,destination);
                if(!PutAt(b,destination,value) || other.id!=0 && !PutAt(a,source,other))return false;
            }
            from.slots=a.slots;if(!same)to.slots=b.slots;
            from.revision++;if(from.revision==0)from.revision=1;
            if(!same){to.revision++;if(to.revision==0)to.revision=1;}
            return true;
        }
        internal void Write(BinaryWriter w)
        { w.Write(revision); foreach(var slot in slots) { w.Write(slot.id); w.Write(slot.count); } }
        internal static Re3Bag Read(BinaryReader r,int count,int columns)
        {
            var b=new Re3Bag(count,columns); b.revision=r.ReadUInt32(); if(b.revision==0) throw new InvalidDataException("Bag revision");
            for(int i=0;i<count;i++) b.slots[i]=new Re3Slot {id=r.ReadUInt16(),count=r.ReadUInt16()};
            for(int i=0;i<count;i++)
            {
                var s=b.slots[i]; if(s.id==0) { if(s.count!=0) throw new InvalidDataException("Empty count"); continue; }
                if(s.id==Continued)
                { if(i%columns==0 || s.count!=i || Re3Catalog.Find(b.slots[i-1].id)==null || Re3Catalog.Find(b.slots[i-1].id).width!=2) throw new InvalidDataException("Continuation"); continue; }
                var item=Re3Catalog.Find(s.id);
                if(item==null || s.count<1 || s.count>item.stack) throw new InvalidDataException("Non RE3 item or invalid stack");
                if(item.width==2 && (i%columns==columns-1 || b.slots[i+1].id!=Continued || b.slots[i+1].count!=i+1)) throw new InvalidDataException("Wide item");
            }
            return b;
        }
    }
    internal sealed class Re3ChestLocation
    {
        internal readonly string name; internal readonly Vector3 position; internal readonly float yaw; internal readonly bool cave,endgame;
        internal Re3ChestLocation(string name,float x,float y,float z,float yaw,bool cave,bool endgame)
        { this.name=name; position=new Vector3(x,y,z); this.yaw=yaw; this.cave=cave; this.endgame=endgame; }
        internal static readonly Re3ChestLocation[] All={
            new Re3ChestLocation("Cueva de la katana",-384,-84,889,0,true,false),
            new Re3ChestLocation("Fondo del agujero central",122,-298,-62,0,true,false),
            new Re3ChestLocation("Costa frente al yate",447,51.35f,1204,180,false,false),
            new Re3ChestLocation("Computadora del final",-435,706,-1756,180,false,true),
            new Re3ChestLocation("Costa del extremo noroeste",1400,42,-1300,90,false,false)
        };
    }
}
