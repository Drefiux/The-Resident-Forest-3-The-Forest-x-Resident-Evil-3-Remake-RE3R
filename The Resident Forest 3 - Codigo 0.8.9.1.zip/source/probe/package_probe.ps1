﻿$ErrorActionPreference = 'Stop'
$workspace = (Get-Location).Path
$probeDirectory = Join-Path $workspace 'work\forest-re3-mashup\probe'
$sourceApp = Join-Path $workspace 'work\tools\ModAPI\app'
$packageWorkspace = Join-Path $workspace 'work\forest-re3-mashup\modapi-workspace'
$preflight = Join-Path $workspace 'outputs\forest-re3-mashup\design\preflight-report.json'
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$forestDll = Join-Path $workspace 'work\forest-re3-mashup\build\ForestRe3LoaderProbe.dll'

$gate = Get-Content -LiteralPath $preflight -Raw | ConvertFrom-Json
if (-not $gate.buildAllowed -or $gate.buildMilestone -ne 'MODAPI_LOADER_PROBE') {
    throw "Preflight no autoriza este hito: $($gate.result) / $($gate.buildMilestone)"
}
if (-not (Test-Path -LiteralPath $forestDll)) { throw 'Falta la DLL compilada de la prueba.' }
if (-not (Test-Path -LiteralPath $packageWorkspace)) {
    New-Item -ItemType Directory -Path $packageWorkspace | Out-Null
    Copy-Item -Path (Join-Path $sourceApp '*') -Destination $packageWorkspace -Recurse
}

$packageExe = Join-Path $packageWorkspace 'PackageProbe.exe'
$modApiExe = Join-Path $packageWorkspace 'ModAPI.exe'
$modApiShared = Join-Path $packageWorkspace 'ModAPI_Shared.dll'
$probeSource = Join-Path $probeDirectory 'PackageProbe.cs'
& $compiler /nologo /target:exe /optimize+ "/out:$packageExe" "/reference:$modApiExe" "/reference:$modApiShared" $probeSource
if ($LASTEXITCODE -ne 0) { throw "No se pudo compilar el empaquetador con código $LASTEXITCODE." }

$previousDirectory = Get-Location
try {
    Set-Location -LiteralPath $packageWorkspace
    & $packageExe $forestDll 2>&1 | Tee-Object -FilePath (Join-Path $probeDirectory 'package-build.log')
    if ($LASTEXITCODE -ne 0) { throw "El empaquetador ModAPI falló con código $LASTEXITCODE." }
}
finally {
    Set-Location -LiteralPath $previousDirectory
}
