﻿namespace ForestRe3LoaderProbe
{
    public static class EntryPoints
    {
        [ModAPI.Attributes.ExecuteOnApplicationStart]
        public static void OnApplicationStart()
        {
            ModAPI.Log.Write("[ForestRE3] Loader probe 0.1.0: application start reached.");
        }

        [ModAPI.Attributes.ExecuteOnGameStart]
        public static void OnGameStart()
        {
            ModAPI.Log.Write("[ForestRE3] Loader probe 0.1.0: game start reached.");
        }
    }
}
