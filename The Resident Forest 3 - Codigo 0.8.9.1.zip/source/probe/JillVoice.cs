﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using TheForest.Utils;

namespace ForestRE3JillVisualProbe
{
    public sealed class JillVoice : MonoBehaviour
    {
        private static JillVoice current;
        private sealed class Bank { internal readonly List<AudioClip> efforts=new List<AudioClip>(), hurts=new List<AudioClip>(), dodges=new List<AudioClip>(); internal int lastEffort=-1,lastHurt=-1,lastDodge=-1; }
        private readonly Dictionary<CharacterProfile,Bank> banks=new Dictionary<CharacterProfile,Bank>();
        private CharacterProfile character=CharacterProfile.Jill;
        internal void SetCharacter(CharacterProfile profile) { character=profile; }
        internal bool IsSpeaking { get { return channel!=null && (channel.isPlaying || AudioSettings.dspTime<occupiedUntil); } }
        private AudioSource channel;
        private bool charging, ready, effortConsumed;
        private float chargeStarted, chargeEnded;
        private double occupiedUntil;
        private int dropped;
        private float muteScanAt;
        private bool muteWarningReported;
        private FMOD.Studio.Bus nativeBreaths;
        private bool nativeBreathsMuted;
        private readonly HashSet<int> releaseStates=new HashSet<int>();
        private bool releaseActive;
        private readonly HashSet<int> groundStrikeStates=new HashSet<int>();
        private readonly Dictionary<int,int> groundCycles=new Dictionary<int,int>();
        private float lastGroundStrike=-100f, lastNativeEffort=-100f, lastNativeHurt=-100f;
        private bool startWarningReported;
        private readonly Dictionary<FMOD.Studio.EventInstance, float> mutedLoops = new Dictionary<FMOD.Studio.EventInstance, float>();
        private static readonly HashSet<string> reportedNativePaths = new HashSet<string>();
        // Audio entry points run in the menu too. No engine/property access
        // until a voice owner has actually connected to the local player.
        public static bool Ready { get { return !object.ReferenceEquals(current,null) && current.ready; } }
        internal static AudioClip SharedClip(CharacterProfile profile,bool hurt,int index)
        { return SharedClip(profile,(byte)(hurt ? 1:0),index); }
        internal static AudioClip SharedClip(CharacterProfile profile,byte category,int index)
        {
            Bank bank;
            if (!Ready || !current.banks.TryGetValue(profile,out bank)) return null;
            List<AudioClip> pool=category==2 ? bank.dodges:(category==1 ? bank.hurts:bank.efforts);
            return index>=0 && index<pool.Count ? pool[index] : null;
        }
        public static bool RemoteOwns(global::PlayerSfx owner)
        { return CoopSync.Instance!=null && CoopSync.Instance.MuteRemoteSfx(owner); }
        public static bool SuppressEvent(global::PlayerSfx owner,string path,Vector3 position)
        {
            if (!Ready || !NativeVocalPath(path)) return false;
            if (RemoteOwns(owner)) return true;
            return Owns(owner) && MuteAt(path,position);
        }

        public void Initialize()
        {
            foreach (CharacterProfile profile in CharacterProfile.All)
            {
                var pool=new Bank(); banks.Add(profile,pool);
                JillVoiceSample[] samples;
                using (Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream(profile.Resource("-voice-bank.bin")))
                {
                    if (stream==null) throw new InvalidDataException("Missing voices: "+profile.Name);
                    samples=JillVoiceDataReader.Read(stream);
                }
                foreach (JillVoiceSample voice in samples)
                {
                    Boost(voice);
                    AudioClip clip=AudioClip.Create(profile.Name+"_"+(voice.hurt ? "hurt_" : "effort_")+voice.id,voice.samples.Length,1,voice.rate,false);
                    if (!clip.SetData(voice.samples,0)) throw new InvalidDataException("Could not load PCM: "+profile.Name);
                    (voice.hurt ? pool.hurts : pool.efforts).Add(clip);
                }
                using (Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream(profile.Resource("-dodge-voice.bin")))
                {
                    if (stream==null) throw new InvalidDataException("Missing dodge voices: "+profile.Name);
                    foreach (JillVoiceSample voice in JillVoiceDataReader.ReadDodge(stream))
                    {
                        double energy=0; foreach (float sample in voice.samples) energy+=(double)sample*sample;
                        float gain=Mathf.Clamp(.12f/Mathf.Max(.0001f,(float)Math.Sqrt(energy/voice.samples.Length)),1f,12f);
                        for (int i=0;i<voice.samples.Length;i++) voice.samples[i]=.65f*(float)Math.Tanh(voice.samples[i]*gain/.65f);
                        AudioClip clip=AudioClip.Create(profile.Name+"_dodge_"+voice.id,voice.samples.Length,1,voice.rate,false);
                        if (!clip.SetData(voice.samples,0)) throw new InvalidDataException("Could not load dodge PCM");
                        pool.dodges.Add(clip);
                    }
                }
                if (pool.hurts.Count==0 || pool.efforts.Count==0 || pool.dodges.Count==0) throw new InvalidDataException("Incomplete voice categories: "+profile.Name);
                ModAPI.Log.Write("[ForestRE3] CHARACTER_VOICE_BANK character="+profile.Name+"; effort="+pool.efforts.Count+"; hurt="+pool.hurts.Count);
            }
            channel = gameObject.AddComponent<AudioSource>();
            channel.playOnAwake=false; channel.loop=false; channel.spatialBlend=0f; channel.pitch=1f;
            channel.ignoreListenerPause=true; // finish a started utterance, even if the menu pauses gameplay
            channel.volume=1f; // AudioListener already applies the game's master volume.
            charging = false; ready=true; current=this;
            // Native animation often retains chargingBool into the release.
            // Observe the destination/current heavy swing, excluding windup.
            foreach (string layer in new[] { "upperBody", "fullBodyActions" })
                foreach (string action in new[] { "stickHeavyAttack", "axeHeavyAttack", "axeheavyAttack", "heavyAttack", "heavyAttack 0" })
                    releaseStates.Add(Animator.StringToHash(layer+"."+action));
            foreach (string action in new[] { "axeAttackGround1 0", "axeAttackGround1", "rockAttackOnGround1", "rockAttackOnGround1 0" })
                groundStrikeStates.Add(Animator.StringToHash("fullBodyActions."+action));
            TryMuteNativeLoops();
            ModAPI.Log.Write("[ForestRE3] CHARACTER_VOICE_READY characters=Jill,Carlos; language=English; channels=1; interruption=false; queue=false; nativeVocalsMuted=true; masterAppliedOnce=true");
        }

        private static void Boost(JillVoiceSample voice)
        {
            double energy=0;
            foreach (float sample in voice.samples) energy+=(double)sample*sample;
            float rms=(float)Math.Sqrt(energy/voice.samples.Length);
            float gain=Mathf.Clamp(.30f/Mathf.Max(rms, .0001f), 5f, 18f);
            for (int i=0; i<voice.samples.Length; i++)
            {
                float value=voice.samples[i]*gain, amplitude=Mathf.Abs(value);
                // Smooth peak limiting, with a continuous slope at the knee.
                if (amplitude > .8f) value=Mathf.Sign(value)*(.8f+.18f*(1f-Mathf.Exp(-(amplitude-.8f)/.18f)));
                voice.samples[i]=value;
            }
            ModAPI.Log.Write("[ForestRE3] JILL_VOICE_GAIN id="+voice.id+"; rmsBefore="+rms+"; gain="+gain+"; peakLimit=0.98");
        }

        public static bool Owns(global::PlayerSfx owner)
        {
            return Ready && owner == LocalPlayer.Sfx && owner != null && !owner.Remote;
        }

        public static bool NativeVocalPath(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            global::PlayerSfx sfx=LocalPlayer.Sfx;
            return path.IndexOf("/player/player_vox/", StringComparison.OrdinalIgnoreCase) >= 0
                || path.IndexOf("/player/foley/breathing/", StringComparison.OrdinalIgnoreCase) >= 0
                || (sfx != null && (path == sfx.HurtEvent || path == sfx.JumpEvent || path == sfx.StaminaBreathEvent))
                // This native drop event combines a grunt and log foley.
                || path.Equals("event:/player/foley/log_drop_exert", StringComparison.OrdinalIgnoreCase);
        }

        public static bool MuteAt(string path, Vector3 position)
        {
            if (!Ready || !NativeVocalPath(path) || LocalPlayer.FpCharacter == null) return false;
            if (CoopSync.Instance!=null && CoopSync.Instance.MuteRemoteVocal(position)) return true;
            FirstPersonCharacter controller=LocalPlayer.FpCharacter;
            Vector3 center=controller.capsule != null ? controller.capsule.bounds.center : controller.transform.position;
            float radius=Mathf.Max(3f, controller.originalHeight*1.5f);
            bool local=(position-center).sqrMagnitude < radius*radius;
            // The opening's vocal events originate on seated/prone actors.
            if (!local && JillPlaneAvatar.IsActive && LocalPlayer.MainCam != null)
                local=(position-LocalPlayer.MainCam.transform.position).sqrMagnitude < radius*radius;
            // Native 2D/cached events can use the zero vector, unrelated to the
            // actor's world coordinates. This phase targets single-player.
            if (!local && !BoltNetwork.isRunning && position.sqrMagnitude<.000001f) local=true;
            if (local) current.ReplaceNativeVocal(path,"entry");
            return local;
        }

        public static void BeforeNativeEventStart(FMOD.Studio.EventInstance instance)
        {
            if (!Ready || instance==null) return;
            try
            {
                FMOD.Studio.EventDescription description; string path;
                if (instance.getDescription(out description)!=FMOD.RESULT.OK || description==null
                    || description.getPath(out path)!=FMOD.RESULT.OK || !NativeVocalPath(path)) return;
                bool spatial; FMOD.Studio.ATTRIBUTES_3D attributes;
                bool nonSpatial=description.is3D(out spatial)==FMOD.RESULT.OK && !spatial && !BoltNetwork.isRunning;
                bool local=nonSpatial;
                if (!local && instance.get3DAttributes(out attributes)==FMOD.RESULT.OK)
                    local=MuteAt(path,new Vector3(attributes.position.x,attributes.position.y,attributes.position.z));
                if (local)
                {
                    // Retain a valid instance for native FSM code, but silence
                    // the original clip before it reaches the mixer.
                    instance.setVolume(0f);
                    if (nonSpatial) current.ReplaceNativeVocal(path,"instance.start");
                }
            }
            catch (Exception error)
            {
                // Never let an audio adapter prevent the game's jump/update.
                if (Ready && !current.startWarningReported)
                { current.startWarningReported=true; ModAPI.Log.Write("[ForestRE3] NATIVE_START_FILTER_WARNING "+error); }
            }
        }

        private void ReplaceNativeVocal(string path,string entry)
        {
            if (reportedNativePaths.Add(path)) ModAPI.Log.Write("[ForestRE3] NATIVE_VOICE_MUTED path="+path+"; entry="+entry);
            string lower=path.ToLowerInvariant();
            bool hurt=lower.Contains("ouch") || lower.EndsWith("/player_hurt") || lower.Contains("vox_damage") || lower.EndsWith("/player_onfire");
            bool jump=lower.EndsWith("/jump_vox") || lower.EndsWith("/player_jump");
            bool ground=lower.EndsWith("/player_vox_ground") || lower.EndsWith("/player_land");
            bool strike=lower.Contains("hit_smash") || lower.EndsWith("/player_swing_melee") || lower.EndsWith("/player_swing_laboured");
            // Windup emits laboured/smash voices too. Preserve release timing.
            if (strike && IsCharging() && !IsHeavyRelease()) return;
            // Jumping and ordinary landing are silent. The air attack raises
            // the weapon first; effort belongs to its downward ground stroke.
            if (jump || ground) return;
            if (strike && AirAttackPreparing()) return;
            if (hurt)
            {
                if (Time.time-lastNativeHurt<.12f) return;
                lastNativeHurt=Time.time; Play(true); return;
            }
            if (strike)
            {
                if (Time.time-lastNativeEffort<.12f) return;
                lastNativeEffort=Time.time; Play(false);
            }
        }

        private void MuteLoop(FMOD.Studio.EventInstance instance)
        {
            if (instance == null || !instance.isValid()) return;
            if (!mutedLoops.ContainsKey(instance))
            {
                float volume;
                if (instance.getVolume(out volume) != FMOD.RESULT.OK) return;
                mutedLoops.Add(instance, volume);
            }
            instance.setVolume(0f);
        }

        private void MuteNativeLoops()
        {
            // This bus contains native human breaths/grunts, including cached
            // FMOD events that never pass through the public one-shot wrappers.
            bool multiplayer=BoltNetwork.isRunning && !BoltNetwork.IsSinglePlayer;
            if (multiplayer && nativeBreaths!=null)
            {
                if (nativeBreaths.isValid()) nativeBreaths.setMute(nativeBreathsMuted);
                nativeBreaths=null;
            }
            if (!multiplayer && (nativeBreaths==null || !nativeBreaths.isValid()))
            {
                FMOD_StudioSystem system=FMOD_StudioSystem.instance;
                FMOD.Studio.Bus bus;
                if (system!=null && system.System!=null && system.System.getBus("bus:/SFX/UnderwaterEffected/dying_mp/dying_sp/PC Move/breaths",out bus)==FMOD.RESULT.OK)
                {
                    bool muted;
                    if (bus.getMute(out muted)==FMOD.RESULT.OK)
                    {
                        nativeBreaths=bus; nativeBreathsMuted=muted;
                        ModAPI.Log.Write("[ForestRE3] NATIVE_BREATH_BUS_MUTED; restoresOnDetach=true");
                    }
                }
            }
            if (nativeBreaths!=null && nativeBreaths.isValid()) nativeBreaths.setMute(true);
            // Instances may have been created before Jill connected. Mute only
            // known local vocal channels; do not stop music, tools or ambience.
            global::PlayerSfx sfx=LocalPlayer.Sfx;
            if (sfx == null) return;
            const BindingFlags fields=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
            FieldInfo breath=typeof(global::PlayerSfx).GetField("staminaBreathInstance", fields);
            if (!object.ReferenceEquals(breath, null)) MuteLoop(breath.GetValue(sfx) as FMOD.Studio.EventInstance);
            Transform root=LocalPlayer.PlayerBase != null ? LocalPlayer.PlayerBase.transform : sfx.transform.root;
            FieldInfo burning=typeof(global::CoopPlayerFX).GetField("BurningEventInstance", fields);
            FieldInfo stats=typeof(global::CoopPlayerFX).GetField("playerStats", fields);
            foreach (global::CoopPlayerFX fx in root.GetComponentsInChildren<global::CoopPlayerFX>(true))
                if (!object.ReferenceEquals(burning, null) && !object.ReferenceEquals(stats, null) && stats.GetValue(fx) as PlayerStats == LocalPlayer.Stats)
                    MuteLoop(burning.GetValue(fx) as FMOD.Studio.EventInstance);
            FieldInfo eventField=typeof(global::FMOD_StudioEventEmitter).GetField("evt", fields);
            foreach (global::FMOD_StudioEventEmitter emitter in root.GetComponentsInChildren<global::FMOD_StudioEventEmitter>(true))
                if (!object.ReferenceEquals(eventField, null) && NativeVocalPath(emitter.path))
                    MuteLoop(eventField.GetValue(emitter) as FMOD.Studio.EventInstance);
        }

        private void TryMuteNativeLoops()
        {
            try { MuteNativeLoops(); }
            catch (Exception error)
            {
                if (!muteWarningReported) ModAPI.Log.Write("[ForestRE3] NATIVE_LOOP_MUTE_WARNING "+error);
                muteWarningReported=true;
            }
        }

        private static bool IsCharging()
        {
            Animator animator = LocalPlayer.Animator;
            return animator != null && animator.GetBool("chargingBool");
        }

        private void Update()
        {
            if (!ready) return;
            if (Time.realtimeSinceStartup >= muteScanAt) { muteScanAt=Time.realtimeSinceStartup+.25f; TryMuteNativeLoops(); }
            bool now = IsCharging();
            if (now && !charging) { chargeStarted=Time.time; chargeEnded=-100f; effortConsumed=false; }
            if (!now && charging) chargeEnded=Time.time;
            bool release=IsHeavyRelease();
            if (release && !releaseActive && !effortConsumed && (now || Time.time-chargeEnded<=.25f)
                && Time.time-chargeStarted>=.4f)
            { effortConsumed=true; Play(false); }
            // Consume the edge even when busy; skipped efforts are never queued.
            // A cancelled charge expires without a deferred voice request.
            if (!now && !release && Time.time-chargeEnded>.25f) effortConsumed=true;
            charging=now; releaseActive=release;
            ObserveGroundStrikes();
        }

        private void ObserveGroundStrikes()
        {
            Animator animator=LocalPlayer.Animator;
            if (animator==null) return;
            bool active=false;
            for (int layer=0;layer<animator.layerCount;layer++)
            {
                if (layer>0 && animator.GetLayerWeight(layer)<.001f) continue;
                AnimatorStateInfo state=animator.GetCurrentAnimatorStateInfo(layer);
                if (!groundStrikeStates.Contains(state.fullPathHash)) continue;
                active=true; int cycle=Mathf.FloorToInt(state.normalizedTime), consumed;
                // After the attack starts moving; never a charge/windup clip.
                if (state.normalizedTime-cycle<.15f) continue;
                if (groundCycles.TryGetValue(state.fullPathHash,out consumed) && consumed==cycle) continue;
                groundCycles[state.fullPathHash]=cycle;
                if (Time.time-lastGroundStrike>.2f && Time.time-lastNativeEffort>.12f)
                { lastGroundStrike=Time.time; Play(false); }
            }
            if (!active) groundCycles.Clear();
        }

        private bool AirAttackPreparing()
        {
            Animator animator=LocalPlayer.Animator;
            if (animator==null) return false;
            int flying=Animator.StringToHash("fullBodyActions.flyingAxeAttack");
            bool preparing=false,downstroke=false;
            for (int layer=0;layer<animator.layerCount;layer++)
            {
                if (layer>0 && animator.GetLayerWeight(layer)<.001f) continue;
                AnimatorStateInfo state=animator.GetCurrentAnimatorStateInfo(layer);
                if (state.fullPathHash==flying) preparing=true;
                if (groundStrikeStates.Contains(state.fullPathHash))
                {
                    if (state.normalizedTime-Mathf.Floor(state.normalizedTime)>=.15f) downstroke=true;
                    else preparing=true;
                }
                if (animator.IsInTransition(layer))
                {
                    int next=animator.GetNextAnimatorStateInfo(layer).fullPathHash;
                    if (next==flying || groundStrikeStates.Contains(next)) preparing=true;
                }
            }
            return preparing && !downstroke;
        }

        private bool IsHeavyRelease()
        {
            Animator animator=LocalPlayer.Animator;
            if (animator==null) return false;
            for (int layer=0;layer<animator.layerCount;layer++)
            {
                if (layer>0 && animator.GetLayerWeight(layer)<.001f) continue;
                if (releaseStates.Contains(animator.GetCurrentAnimatorStateInfo(layer).fullPathHash)) return true;
                if (animator.IsInTransition(layer) && releaseStates.Contains(animator.GetNextAnimatorStateInfo(layer).fullPathHash)) return true;
            }
            return false;
        }

        // Returning true also when busy suppresses the old male hurt voice.
        // No coroutine, deferred request or event list stores the dropped hit.
        public static bool HandleNativeHurt(global::PlayerSfx owner)
        {
            if (RemoteOwns(owner)) return true;
            if (!Owns(owner)) return false;
            if (DodgeRuntime.Immune) return true;
            current.lastNativeHurt=Time.time; current.Play(true); return true;
        }

        public static bool HandleNativeJump(global::PlayerSfx owner)
        {
            // Retain the native jump controller, suppress only its vocal call.
            return Owns(owner) || RemoteOwns(owner);
        }

        internal static void PlayDodge()
        {
            if (!Ready || current.IsSpeaking) return;
            CharacterProfile profile=current.character; Bank bank=current.banks[profile];
            int index=UnityEngine.Random.Range(0,bank.dodges.Count);
            if (bank.dodges.Count>1 && index==bank.lastDodge) index=(index+1)%bank.dodges.Count;
            bank.lastDodge=index; current.channel.clip=bank.dodges[index]; current.channel.volume=1f;
            current.occupiedUntil=AudioSettings.dspTime+current.channel.clip.length+.025; current.channel.Play();
            CoopSync.VoiceStarted(profile,(byte)2,index);
        }

        private void Play(bool hurt)
        {
            if (DodgeRuntime.Active || (hurt && DodgeRuntime.Immune)) return;
            if (channel.isPlaying || AudioSettings.dspTime < occupiedUntil)
            {
                dropped++;
                ModAPI.Log.Write("[ForestRE3] JILL_VOICE_DROP kind="+(hurt ? "hurt" : "effort")+"; busy=true; queued=false; total="+dropped);
                return;
            }
            CharacterProfile effective=JillPlaneAvatar.CharacterLocked ? CharacterProfile.Jill : character;
            Bank bank=banks[effective];
            List<AudioClip> pool = hurt ? bank.hurts : bank.efforts;
            int previous = hurt ? bank.lastHurt : bank.lastEffort;
            int index = UnityEngine.Random.Range(0, pool.Count);
            if (pool.Count > 1 && index == previous) index=(index+1)%pool.Count;
            if (hurt) bank.lastHurt=index; else bank.lastEffort=index;
            channel.clip=pool[index]; channel.volume=1f;
            occupiedUntil=AudioSettings.dspTime+channel.clip.length+.025;
            channel.Play();
            CoopSync.VoiceStarted(effective,hurt,index);
            ModAPI.Log.Write("[ForestRE3] CHARACTER_VOICE_PLAY kind="+(hurt ? "hurt" : "effort")+"; clip="+channel.clip.name+"; duration="+channel.clip.length);
        }

        private void OnDestroy()
        {
            Shutdown();

            foreach (Bank bank in banks.Values)
            {
                foreach (AudioClip clip in bank.efforts) if (clip!=null) UnityEngine.Object.Destroy(clip);
                foreach (AudioClip clip in bank.hurts) if (clip!=null) UnityEngine.Object.Destroy(clip);
                foreach (AudioClip clip in bank.dodges) if (clip!=null) UnityEngine.Object.Destroy(clip);
            }
            banks.Clear();
        }

        public void Shutdown()
        {
            ready=false; if (current == this) current=null; if (channel != null) channel.Stop();
            if (nativeBreaths!=null && nativeBreaths.isValid()) nativeBreaths.setMute(nativeBreathsMuted);
            nativeBreaths=null;
            foreach (var saved in mutedLoops) if (saved.Key!=null && saved.Key.isValid()) saved.Key.setVolume(saved.Value);
            mutedLoops.Clear(); reportedNativePaths.Clear();
        }
    }

    // ModAPI injects virtual matching methods into the original type. Keep the
    // base call for remote/unattached players; replace only the active local Jill.
    public class JillPlayerSfxPatch : global::PlayerSfx
    {
        public new virtual void PlayHurtSound()
        {
            if (!JillVoice.HandleNativeHurt(this)) base.PlayHurtSound();
        }
        public new virtual void PlayJumpSound() { if (!JillVoice.HandleNativeJump(this)) base.PlayJumpSound(); }
        public new virtual void PlayStaminaBreath() { if (!(JillVoice.Owns(this) || JillVoice.RemoteOwns(this))) base.PlayStaminaBreath(); }
        public new virtual FMOD.Studio.EventInstance PlayEvent(string path, GameObject source)
        {
            FMOD.Studio.EventInstance result=null;
            if (!(source!=null && JillVoice.SuppressEvent(this,path,source.transform.position))) result=base.PlayEvent(path, source);
            return result;
        }
        public new virtual FMOD.Studio.EventInstance PlayEvent(string path, Vector3 position)
        {
            FMOD.Studio.EventInstance result=null;
            if (!JillVoice.SuppressEvent(this,path,position)) result=base.PlayEvent(path, position);
            return result;
        }
    }

    // Direct FSM/animation events also bypass PlayerSfx. Apply the same vocal
    // filter at their own public entry points, scoped to the local actor.
    public class JillFmodCommonPatch : global::FMODCommon
    {
        public new static FMOD.Studio.EventInstance PlayOneshot(string path, Transform source)
        {
            FMOD.Studio.EventInstance result=null;
            if (!(JillVoice.Ready && source != null && JillVoice.MuteAt(path, source.position))) result=global::FMODCommon.PlayOneshot(path, source);
            return result;
        }
        public new static FMOD.Studio.EventInstance PlayOneshot(string path, Vector3 position, params object[] parameters)
        {
            FMOD.Studio.EventInstance result=null;
            if (!JillVoice.MuteAt(path, position)) result=global::FMODCommon.PlayOneshot(path, position, parameters);
            return result;
        }
        public new static FMOD.Studio.EventInstance PlayOneshot(string path, Vector3 position, global::FMODCommon.NetworkRole role, params object[] parameters)
        {
            FMOD.Studio.EventInstance result=null;
            if (!JillVoice.MuteAt(path, position)) result=global::FMODCommon.PlayOneshot(path, position, role, parameters);
            return result;
        }
        public new static FMOD.Studio.EventInstance PlayOneshotNetworked(string path, Transform source, global::FMODCommon.NetworkRole role)
        {
            FMOD.Studio.EventInstance result=null;
            if (!(JillVoice.Ready && source != null && JillVoice.MuteAt(path, source.position))) result=global::FMODCommon.PlayOneshotNetworked(path, source, role);
            return result;
        }
    }

    public class JillFmodSystemPatch : global::FMOD_StudioSystem
    {
        public new virtual FMOD.Studio.EventInstance PlayOneShot(string path, Vector3 position, global::FMOD_StudioSystem.ProcessEventInstanceDelegate setup)
        {
            FMOD.Studio.EventInstance result=null;
            if (!JillVoice.MuteAt(path, position)) result=base.PlayOneShot(path, position, setup);
            return result;
        }
    }

    public class JillVocalEmitterPatch : global::FMOD_StudioEventEmitter
    {
        public new virtual void Play()
        {
            if (JillVoice.Ready && JillVoice.MuteAt(path, transform.position)) Stop();
            else base.Play();
            // Keep one common terminal exit even with compiler optimization;
            // ModAPI cannot safely wrap branch-local returns in its catch block.
            GC.KeepAlive(this);
        }
    }

    // Cached events and direct GetEvent(...).start() bypass high-level wrappers.
    // Match the actual firstpass method; keep one terminal return for ModAPI.
    public class JillFmodEventStartPatch : FMOD.Studio.EventInstance
    {
        public JillFmodEventStartPatch(IntPtr handle) : base(handle) { }
        public new virtual FMOD.RESULT start()
        {
            JillVoice.BeforeNativeEventStart(this);
            FMOD.RESULT result=base.start();
            return result;
        }
    }
}
