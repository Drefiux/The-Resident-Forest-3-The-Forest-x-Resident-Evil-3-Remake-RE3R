"""Build the central private development ZIP/EXE and the source-only archive."""
import gzip
import hashlib
import json
import struct
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
WORKSPACE = ROOT / 'work/forest-re3-mashup/modapi-workspace'
TOOLS = ROOT / 'work/tools/ModAPI-source'
BUILD = HERE / 'build'
OUTPUT = ROOT / 'outputs/forest-re3-mashup/releases'
CSC = Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe')
VERSION = '0.8.9.1'
PACKAGE_VERSION = VERSION if VERSION.count('.') == 3 else VERSION + '.0'


def run(arguments):
    subprocess.run([str(value) for value in arguments], check=True)


def string(stream, value):
    encoded = value.encode('utf-8')
    count = len(encoded)
    while count >= 128:
        stream.write(bytes([(count & 127) | 128]))
        count >>= 7
    stream.write(bytes([count]))
    stream.write(encoded)


def main():
    BUILD.mkdir(exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    helper = BUILD / 'PrepareRuntime.exe'
    run([CSC, '/nologo', '/target:exe', '/optimize+', f'/out:{helper}',
         f'/reference:{WORKSPACE / "ModAPI_Shared.dll"}', f'/reference:{WORKSPACE / "Mono.Cecil.dll"}',
         HERE / 'PrepareRuntime.cs'])
    packages = list((WORKSPACE / 'mods/TheForest').glob(f'ForestRE3JillVisualProbe-{PACKAGE_VERSION}-*.mod'))
    if len(packages) != 1:
        raise ValueError('Expected one current private package')
    entries = {'core/PrepareRuntime.exe': helper.read_bytes(),
               f'core/mods/TheForest/{packages[0].name}': packages[0].read_bytes()}
    for name in ('ModAPI.exe', 'ModAPI_Shared.dll', 'Ionic.Zip.dll', 'Mono.Cecil.dll',
                 'Mono.Cecil.Rocks.dll', 'Mono.Cecil.Mdb.dll', 'Mono.Cecil.Pdb.dll',
                 'Portable.System.ValueTuple.dll', 'System.ValueTuple.dll'):
        entries[f'core/{name}'] = (WORKSPACE / name).read_bytes()
    for name in ('BaseModLib.dll',):
        entries[f'core/libs/{name}'] = (WORKSPACE / 'libs' / name).read_bytes()
    for name in ('AsyncBridge.dll', 'System.Threading.dll'):
        path = WORKSPACE / 'libs' / name
        if path.exists():
            entries[f'core/libs/polyfills/{name}'] = path.read_bytes()
    for path in [WORKSPACE / 'resources/Configuration.xml',
                 WORKSPACE / 'configs/games/TheForest.xml',
                 WORKSPACE / 'configs/games/GenericUnityGame.xml',
                 WORKSPACE / 'configs/games/TheForest/Versions.xml',
                 WORKSPACE / 'resources/langs/Language.EN.xaml',
                 WORKSPACE / 'resources/langs/Language.ES.xaml']:
        entries[f'core/{path.relative_to(WORKSPACE).as_posix()}'] = path.read_bytes()
    entries['core/configs/UserConfiguration.xml'] = b'<UserConfiguration><Language>EN</Language><setupdone>true</setupdone></UserConfiguration>'
    for name in ('LICENSE', 'ModAPI.License.txt', 'Mono.Cecil.License.txt', 'Ionic.Zip.License.txt'):
        entries[f'licenses/{name}'] = (TOOLS / name).read_bytes()
    entries['licenses/OFL-Montserrat.txt'] = (HERE / 'assets/OFL-Montserrat.txt').read_bytes()
    entries['PRUEBA-COOP.txt'] = (HERE / 'PRUEBA-COOP.txt').read_bytes()
    entries['PRUEBA-ESQUIVA-0.8.1.2.txt'] = (HERE / 'PRUEBA-ESQUIVA-0.8.1.2.txt').read_bytes()
    entries['INVENTARIO-Y-BAULES-0.8.2.txt'] = (HERE / 'INVENTARIO-Y-BAULES-0.8.2.txt').read_bytes()
    entries['ARMAS-Y-ENEMIGOS-0.8.9.1.txt'] = (HERE / 'ARMAS-Y-ENEMIGOS-0.8.9.1.txt').read_bytes()
    entries['HISTORIAL-DE-VERSIONES.txt'] = (ROOT / 'outputs/forest-re3-mashup/HISTORIAL-DE-VERSIONES.txt').read_bytes()
    payload = BUILD / 'launcher-payload.bin'
    with payload.open('wb') as stream:
        stream.write(b'FRP1')
        stream.write(struct.pack('<i', len(entries)))
        for name, raw in entries.items():
            string(stream, name)
            string(stream, hashlib.sha256(raw).hexdigest().upper())
            compressed = gzip.compress(raw, compresslevel=6, mtime=0)
            stream.write(struct.pack('<i', len(compressed)))
            stream.write(compressed)
    exe = OUTPUT / 'The Resident Forest 3.exe'
    run([CSC, '/nologo', '/target:winexe', '/optimize+', f'/out:{exe}',
         '/reference:System.Windows.Forms.dll', '/reference:System.Drawing.dll',
         f'/resource:{payload},ForestRE3.payload', f'/win32icon:{HERE / "assets/TR3.ico"}',
         f'/resource:{HERE / "assets/TR3.png"},TR3.logo.png',
         f'/resource:{HERE / "assets/Montserrat-Regular.ttf"},TR3.Montserrat-Regular.ttf',
         f'/resource:{HERE / "assets/Montserrat-Bold.ttf"},TR3.Montserrat-Bold.ttf', HERE / 'ForestRE3Launcher.cs'])

    archive = OUTPUT / f'The Resident Forest 3 - Codigo {VERSION}.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
        for folder in (HERE, ROOT / 'work/forest-re3-mashup/probe'):
            for path in folder.glob('*'):
                if path.suffix in ('.cs', '.py', '.ps1'):
                    output.write(path, f'source/{folder.name}/{path.name}')
        for path in (HERE / 'assets').glob('*'):
            if path.is_file(): output.write(path, f'source/launcher/assets/{path.name}')
        for path in (ROOT / 'outputs/forest-re3-mashup/unity-pipeline/Assets/Editor').glob('*.cs'):
            output.write(path, f'source/unity-editor/{path.name}')
        for path in (ROOT / 'outputs/forest-re3-mashup/unity-pipeline/Assets/Shaders').glob('*.shader'):
            output.write(path, f'source/unity-shaders/{path.name}')
        for name in ('decode_motion_preview.py', 'pack_motion_preview.py', 'inspect_rigs.py', 'build_shoulder_samples.py', 'build_voice_bank.py'):
            output.write(ROOT / 'work/jill/corrected' / name, f'source/asset-tools/{name}')
        for name in ('decode_motion_preview.py','pack_motion_preview.py','inspect_rigs.py','build_shoulder_samples.py','build_voice_bank.py','record_carlos_build.py','prepare_voice_names.py'):
            path=ROOT/'work/carlos/corrected'/name
            if path.exists(): output.write(path, f'source/asset-tools/carlos/{name}')
        for name in ('prepare_jill_assets.py','prepare_carlos_assets.py','Build-CompleteCarlos.ps1'):
            path=ROOT/'outputs/forest-re3-mashup/unity-pipeline'/name
            if path.exists(): output.write(path, f'source/asset-tools/pipeline/{name}')
        for name in ('HISTORIAL-DE-VERSIONES.txt', 'INVESTIGACION-COOP-09-10-2026.md','INVESTIGACION-ESQUIVA-09-10-2026.md'):
            output.write(ROOT / 'outputs/forest-re3-mashup' / name, name)
        output.write(ROOT/'work/forest-re3-mashup/research-dodge/build_dodge_assets.py','source/asset-tools/build_dodge_assets.py')
        output.write(ROOT/'work/forest-re3-mashup/research-dodge/dodge-motions.json','source/asset-tools/dodge-motions.json')
        output.write(ROOT/'work/forest-re3-mashup/research-inventory/build_inventory_assets.py','source/asset-tools/build_inventory_assets.py')
        output.write(ROOT/'outputs/forest-re3-mashup/unity-pipeline/Assets/LocalAssets/Re3Inventory/inventory-manifest.json','source/asset-tools/inventory-manifest.json')
        output.write(HERE/'INVENTARIO-Y-BAULES-0.8.2.txt','INVENTARIO-Y-BAULES-0.8.2.txt')
        output.write(HERE / 'ARMAS-Y-ENEMIGOS-0.8.9.1.txt','ARMAS-Y-ENEMIGOS-0.8.9.1.txt')
        for name in ('build_g19_assets.py','build_g19_audio.py','build_re3_interface_assets.py','g19-motion-manifest.json','g19-sounds-manifest.json'):
            output.write(ROOT/'work/forest-re3-mashup/research-g19'/name,'source/asset-tools/g19/'+name)
        for name in ('build_m3_assets.py','build_m3_audio.py','m3-motion-manifest.json','m3-sounds-manifest.json','InspectDamage.cs'):
            output.write(ROOT / 'work/forest-re3-mashup/research-m3' / name,'source/asset-tools/m3/'+name)
        for name in ('build_rocket_assets.py','build_rocket_audio.py','inspect_assets.py','rocket-motion-manifest.json','rocket-sounds-manifest.json','projectile-source.json','FUENTES.txt'):
            output.write(ROOT/'work/forest-re3-mashup/research-rocket'/name,'source/asset-tools/rocket/'+name)
        output.write(HERE / 'README.md', 'README.md')
        for name in ('LICENSE', 'ModAPI.License.txt', 'Mono.Cecil.License.txt', 'Ionic.Zip.License.txt'):
            output.write(TOOLS / name, f'licenses/{name}')
        # Source for the bundled GPL loader; deliberately no game DLLs or data.
        for path in TOOLS.rglob('*'):
            if path.is_file() and path.suffix.lower() in ('.cs', '.csproj', '.sln', '.props', '.targets', '.xaml', '.xml', '.md', '.txt', '.config', '.resx', '.png', '.jpg', '.ico', '.ttf', '.psd', '.svg'):
                if '.git' not in path.parts and 'bin' not in path.parts and 'obj' not in path.parts:
                    output.write(path, f'third-party/ModAPI/{path.relative_to(TOOLS).as_posix()}')
    central = OUTPUT / 'The Resident Forest 3.zip'
    with zipfile.ZipFile(central, 'w', zipfile.ZIP_DEFLATED) as output:
        output.write(exe, exe.name)
        output.write(HERE / 'LEEME.txt', 'LEEME.txt')
        output.write(HERE / 'ARMAS-Y-ENEMIGOS-0.8.9.1.txt','ARMAS-Y-ENEMIGOS-0.8.9.1.txt')
        output.write(HERE / 'PRUEBA-COOP.txt', 'PRUEBA-COOP.txt')
        output.write(HERE / 'PRUEBA-ESQUIVA-0.8.1.2.txt', 'PRUEBA-ESQUIVA-0.8.1.2.txt')
        output.write(HERE / 'INVENTARIO-Y-BAULES-0.8.2.txt','INVENTARIO-Y-BAULES-0.8.2.txt')
        output.write(ROOT / 'outputs/forest-re3-mashup/HISTORIAL-DE-VERSIONES.txt', 'HISTORIAL-DE-VERSIONES.txt')
        output.write(archive, f'codigo/{archive.name}')
        output.write(HERE / 'assets/OFL-Montserrat.txt', 'licencias/OFL-Montserrat.txt')
        for name in ('LICENSE', 'ModAPI.License.txt', 'Mono.Cecil.License.txt', 'Ionic.Zip.License.txt'):
            output.write(TOOLS / name, f'licencias/{name}')
    receipt = {'version': VERSION, 'privateExecutable': str(exe), 'privateBytes': exe.stat().st_size,
               'privateSha256': hashlib.sha256(exe.read_bytes()).hexdigest(),
               'sourceArchive': str(archive), 'sourceArchiveBytes': archive.stat().st_size,
               'sourceArchiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
               'centralArchive': str(central), 'centralArchiveBytes': central.stat().st_size,
               'centralArchiveSha256': hashlib.sha256(central.read_bytes()).hexdigest(),
               'privateContainsLocallyGeneratedREAssets': True,
               'sourceArchiveContainsGameDlls': False, 'sourceArchiveContainsConvertedREAssets': False,
               'launcherFontsAndUserLogoIncluded': True,
               'publicCleanInstallAssetGenerationReady': False,
               'meltyArchiveOrGithubFormatConfirmedByUser': True, 'gameLaunchVerified': False,
               'cooperativeProtocol': 9, 'twoPcCoopVerified': False, 'nativeMicRetained': True, 'productName': 'The Resident Forest 3',
               'developerToolsDefault': False, 'developerToolsHostOnly': True, 'inventoryDragAndDrop': True,
               'payloadFiles': [{'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name, raw in entries.items()]}
    (OUTPUT / f'launcher-{VERSION}-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({key: receipt[key] for key in ('privateExecutable', 'privateBytes', 'centralArchive', 'centralArchiveBytes', 'sourceArchive', 'sourceArchiveBytes')}, indent=2))


if __name__ == '__main__':
    main()
