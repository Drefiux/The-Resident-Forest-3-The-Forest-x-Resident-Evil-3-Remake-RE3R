﻿// GPL-3.0-or-later. Generates the loader in an isolated workspace using ModAPI.
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;
using ModAPI.Configurations;
using ModAPI.Data;

internal static class PrepareRuntime
{
    [STAThread]
    public static int Main(string[] args)
    {
        try
        {
            Console.OutputEncoding = new UTF8Encoding(false);
            Console.SetError(new StreamWriter(Console.OpenStandardError(),new UTF8Encoding(false)) { AutoFlush=true });
            string core = Path.GetFullPath(args[0]), source = Path.GetFullPath(args[1]);
            AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs request)
            {
                string name = new AssemblyName(request.Name).Name + ".dll";
                foreach (string folder in new[] { core, Path.Combine(core,"libs") })
                    if (File.Exists(Path.Combine(folder,name))) return Assembly.LoadFrom(Path.Combine(folder,name));
                return null;
            };
            return Prepare(core, source);
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
    }
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private static int Prepare(string core, string source)
    {
        Directory.SetCurrentDirectory(core);
        if (Configuration.Load() != Configuration.ResultCode.Ok) throw new InvalidOperationException(Configuration.ErrorString);
        string cache = Directory.GetParent(core).FullName;
        string original = Path.Combine(cache,"original"), stage = Path.Combine(cache,"stage");
        Configuration.SetPath("OriginalGameFiles", original, true);
        Configuration.SetPath("ModdedGameFiles", Path.Combine(cache,"generated"), true);
        Configuration.SetPath("ModLib", Path.Combine(cache,"modlib"), true);
        Configuration.SetPath("Libraries", Path.Combine(core,"libs"), true);
        var game = new Game(Configuration.Games["TheForest"], true);
        game.GamePath = stage;
        XElement versions = XDocument.Load(Path.Combine(core,"configs/games/TheForest/Versions.xml")).Root;
        XElement version = versions.Elements("version").Single(v => (string)v.Attribute("id") == "1.11b");
        string checksum = "";
        using (MD5 md5 = MD5.Create())
            foreach (XElement file in versions.Element("files").Elements("file"))
            {
                string name = Path.GetFileName(game.ParsePath(file.Value));
                string path = Path.Combine(source,name);
                if (!File.Exists(path)) throw new FileNotFoundException("Falta un archivo original de The Forest.",path);
                checksum += BitConverter.ToString(md5.ComputeHash(File.ReadAllBytes(path))).Replace("-","");
            }
        if (!checksum.Equals(version.Element("checksum").Value,StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("La carpeta seleccionada no contiene los ensamblados originales de The Forest 1.11b. Selecciona su respaldo original de ModAPI.");
        string originalManaged = Path.Combine(original,"TheForest/TheForest_data/Managed");
        string stageManaged = Path.Combine(stage,"TheForest_data/Managed");
        Directory.CreateDirectory(originalManaged); Directory.CreateDirectory(stageManaged);
        foreach (string path in Directory.GetFiles(source,"*.dll"))
        {
            string backup = Path.Combine(originalManaged,Path.GetFileName(path));
            if (!Path.GetFullPath(path).Equals(Path.GetFullPath(backup),StringComparison.OrdinalIgnoreCase)) File.Copy(path,backup,true);
            File.Copy(path,Path.Combine(stageManaged,Path.GetFileName(path)),true);
        }
        game.GameVersion = game.BackupVersion = new Game.Versions.Version(version);
        game.ModLibrary = new ModLib(game);
        if (!game.ModLibrary.Exists) game.ModLibrary.Create();
        if (!game.ModLibrary.Exists) game.ModLibrary = new ModLib(game);
        if (!game.ModLibrary.Exists) throw new InvalidOperationException("No se pudo crear el cargador local.");
        var mod = new Mod { Game = game, FileName = Directory.GetFiles(Path.Combine(core,"mods/TheForest"),"*.mod").Single() };
        if (!mod.Load() || !mod.Valid) throw new InvalidOperationException("Paquete de mashup no válido.");
        game.ApplyMods(new System.Collections.Generic.List<Mod> { mod }, null);
        if (game.LastAppliedModCount != 1) throw new InvalidOperationException("No se pudo preparar el mashup. Revisa los registros del lanzador.");
        string generated = Path.Combine(cache,"generated/TheForest");
        string runtime = Path.Combine(generated,"Mods/RuntimeConfiguration.xml");
        XDocument config = XDocument.Load(runtime);
        XElement installed = config.Root.Elements("Mod").Single();
        if ((string)installed.Attribute("ID") != "ForestRE3JillVisualProbe" || (string)installed.Attribute("Version") != mod.HeaderData.GetVersion().ToString())
            throw new InvalidDataException("La preparación no produjo la versión esperada.");
        if (config.Root.Elements("ExecuteOnGameStart").Count() != 1) throw new InvalidDataException("Falta el gancho de partida.");
        Console.WriteLine("PREPARED_RUNTIME=" + generated);
        Console.WriteLine("GAME_INSTALL_UNCHANGED=true");
        foreach (Assembly loaded in AppDomain.CurrentDomain.GetAssemblies())
            if (!loaded.IsDynamic && loaded.Location.StartsWith(core+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))
                Console.WriteLine("BUNDLED_DEPENDENCY="+loaded.GetName().Name);
        return 0;
    }
}
