﻿"""Construct the private patched assemblies inside the workspace only."""
import gzip
import hashlib
import json
import struct
import subprocess
from pathlib import Path
from build_launcher import VERSION

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CACHE = HERE/f'build/runtime-{VERSION}'
ORIGINAL = ROOT/'work/forest-re3-mashup/modapi-workspace/gamefiles/original/TheForest/TheForest_data/Managed'


def read_string(stream):
    length = shift = 0
    for _ in range(5):
        byte = stream.read(1)
        if not byte: raise ValueError('Truncated payload string')
        length |= (byte[0]&127) << shift
        if byte[0] < 128: break
        shift += 7
    else: raise ValueError('Invalid payload string length')
    value = stream.read(length)
    if len(value) != length: raise ValueError('Truncated payload name')
    return value.decode('utf-8')


def main():
    CACHE.mkdir(parents=True, exist_ok=True)
    extracted_paths = set()
    with (HERE/'build/launcher-payload.bin').open('rb') as stream:
        if stream.read(4) != b'FRP1': raise ValueError('Invalid payload')
        count, = struct.unpack('<i', stream.read(4))
        for _ in range(count):
            relative, digest = read_string(stream), read_string(stream)
            length, = struct.unpack('<i', stream.read(4))
            if length < 0: raise ValueError('Invalid compressed size')
            raw = gzip.decompress(stream.read(length))
            if hashlib.sha256(raw).hexdigest().upper() != digest: raise ValueError('Payload hash mismatch')
            path = (CACHE/relative).resolve()
            if not path.is_relative_to(CACHE.resolve()): raise ValueError('Payload path outside workspace cache')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            extracted_paths.add(path)
    # Match the launcher's cleanup when rebuilding the same version in place.
    # PrepareRuntime must see exactly one current package.
    package_dir = (CACHE/'core/mods/TheForest').resolve()
    for previous in package_dir.glob('ForestRE3JillVisualProbe-*.mod'):
        resolved = previous.resolve()
        if not resolved.is_relative_to(CACHE.resolve()):
            raise ValueError('Previous package outside workspace cache')
        if resolved not in extracted_paths:
            previous.unlink()
    command = [str(CACHE/'core/PrepareRuntime.exe'), str(CACHE/'core'), str(ORIGINAL)]
    result = subprocess.run(command, cwd=CACHE/'core', capture_output=True, text=True)
    (CACHE/'construction.log').write_text(result.stdout+'\n'+result.stderr, encoding='utf-8')
    print(result.stdout)
    if result.returncode: raise RuntimeError(result.stderr)
    config = CACHE/'generated/TheForest/Mods/RuntimeConfiguration.xml'
    receipt = dict(version=VERSION, constructedPatchedRuntime=True, gameInstallUnchanged=True,
                   runtimeDirectory=str(config.parent.parent), gameLaunchVerified=False,
                   constructionLog=str(CACHE/'construction.log'))
    (ROOT/f'outputs/forest-re3-mashup/releases/runtime-{VERSION}-construction.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    main()
