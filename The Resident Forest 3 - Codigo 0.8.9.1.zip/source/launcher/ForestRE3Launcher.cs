﻿// GPL-3.0-or-later. Single-file bootstrap; proprietary assets are private build only.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Win32;

[assembly: AssemblyTitle("The Resident Forest 3")]
[assembly: AssemblyProduct("The Resident Forest 3")]
[assembly: AssemblyVersion("0.8.9.1")]

internal static class ForestRE3Launcher
{
    internal const string Version = "0.8.9.1";
    internal static readonly string PackageVersion = Version.Split('.').Length == 4 ? Version : Version+".0";
    private static string cache;
    private static bool developerTools;
    internal const string ProductName="The Resident Forest 3";
    private static readonly HashSet<string> KnownMods = new HashSet<string>(new[] {"ForestRE3JillVisualProbe","ForestRE3JillBundleProbe","ForestRE3LoaderProbe"},StringComparer.OrdinalIgnoreCase);
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            cache = Option(args,"--cache") ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TheResidentForest3",Version);
            cache = Path.GetFullPath(cache);
            ExtractPayload();
            developerTools=LoadDeveloperPreference();
            string original = Option(args,"--original-managed");
            if (args.Contains("--prepare-only"))
            {
                if (original == null) throw new InvalidOperationException("--prepare-only requiere --original-managed.");
                Prepare(original); return 0;
            }
            string game = Option(args,"--game") ?? FindGame("The Forest","TheForest.exe");
            if (args.Contains("--detect-only"))
            {
                File.WriteAllText(Path.Combine(cache,"detected-game.txt"),game);
                return game.Length > 0 ? 0 : 2;
            }
            if (args.Contains("--install-only"))
            {
                Prepare(original ?? FindOriginal(game)); StageRuntimeOptions(); Install(game); return 0;
            }
            if (args.Contains("--restore-only"))
            {
                Restore(File.ReadAllText(Path.Combine(cache,"last-install.txt")).Trim(),true); return 0;
            }
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(true);
            string preview=Option(args,"--render-preview");
            if(preview!=null)
            {
                using(var form=new LauncherForm(game,original))
                {
                    using(Form target=args.Contains("--preview-options") ? form.OptionsPreview():form)
                    {
                        target.ShowInTaskbar=false;target.Opacity=0;target.Show();target.PerformLayout();Application.DoEvents();
                        using(var bitmap=new Bitmap(target.Width,target.Height)){target.DrawToBitmap(bitmap,new Rectangle(Point.Empty,target.Size));bitmap.Save(preview,System.Drawing.Imaging.ImageFormat.Png);}
                        target.Hide();
                    }
                }
                return 0;
            }
            Application.Run(new LauncherForm(game, original)); return 0;
        }
        catch (Exception error)
        {
            if (args.Any(arg => arg.EndsWith("-only",StringComparison.Ordinal))) File.WriteAllText(Path.Combine(cache ?? Path.GetTempPath(),"launcher-error.log"),error.ToString());
            else MessageBox.Show(error.Message,ProductName,MessageBoxButtons.OK,MessageBoxIcon.Error);
            return 1;
        }
    }
    private static string Option(string[] args,string key)
    {
        int index = Array.IndexOf(args,key); return index >= 0 && index+1 < args.Length ? args[index+1] : null;
    }
    private static string SafePath(string root,string relative)
    {
        string full = Path.GetFullPath(Path.Combine(root,relative));
        if (!full.StartsWith(Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Ruta del paquete fuera de su carpeta.");
        return full;
    }
    private static string Sha(string path)
    {
        using (var stream = File.OpenRead(path)) using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","");
    }
    private static void ExtractPayload()
    {
        Directory.CreateDirectory(cache);
        var packedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ForestRE3.payload"))
        using (var reader = new BinaryReader(stream,Encoding.UTF8))
        {
            if (reader.ReadUInt32() != 0x31505246) throw new InvalidDataException("Paquete de lanzador no válido.");
            int files = reader.ReadInt32();
            if (files < 1 || files > 10000) throw new InvalidDataException("Cantidad de archivos no válida.");
            for (int i=0;i<files;i++)
            {
                string relative = reader.ReadString(), expected = reader.ReadString();
                int compressed = reader.ReadInt32();
                if (compressed < 0 || compressed > 300000000) throw new InvalidDataException("Tamaño de archivo no válido.");
                string destination = SafePath(cache,relative);
                packedPaths.Add(destination);
                byte[] bytes = reader.ReadBytes(compressed);
                if (bytes.Length != compressed) throw new EndOfStreamException();
                if (File.Exists(destination) && Sha(destination) == expected) continue;
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                string temporary = destination+".new";
                using (var input = new GZipStream(new MemoryStream(bytes),CompressionMode.Decompress))
                using (var output = File.Create(temporary)) input.CopyTo(output);
                if (Sha(temporary) != expected) throw new InvalidDataException("Archivo del paquete incompleto: "+relative);
                File.Copy(temporary,destination,true); File.Delete(temporary);
            }
            if (stream.Position != stream.Length) throw new InvalidDataException("Contenido adicional en el paquete.");
        }
        string packageFolder = SafePath(cache,"core/mods/TheForest");
        foreach (string old in Directory.GetFiles(packageFolder,"ForestRE3JillVisualProbe-*.mod"))
            if (!packedPaths.Contains(Path.GetFullPath(old))) File.Delete(old);
    }
    private static string FindGame(string folder,string exe)
    {
        var roots = new List<string>();
        try
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
                if (key != null && key.GetValue("SteamPath") != null) roots.Add(key.GetValue("SteamPath").ToString());
        }
        catch (System.Security.SecurityException) { }
        catch (UnauthorizedAccessException) { }
        roots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Steam"));
        foreach (string root in roots.ToArray())
        {
            string vdf = Path.Combine(root,"steamapps/libraryfolders.vdf");
            if (!File.Exists(vdf)) continue;
            try
            {
                foreach (Match match in Regex.Matches(File.ReadAllText(vdf),"\"path\"\\s*\"([^\"]+)\""))
                    roots.Add(match.Groups[1].Value.Replace(@"\\",@"\"));
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
        string saved = Path.Combine(cache,"game-path.txt");
        if (File.Exists(saved) && File.Exists(Path.Combine(File.ReadAllText(saved).Trim(),exe))) return File.ReadAllText(saved).Trim();
        return roots.Distinct(StringComparer.OrdinalIgnoreCase).Select(root => Path.Combine(root,"steamapps/common",folder)).FirstOrDefault(path => File.Exists(Path.Combine(path,exe))) ?? "";
    }
    private static string FindOriginal(string game)
    {
        var candidates = new List<string> { Path.Combine(cache,"original/TheForest/TheForest_data/Managed"), Path.Combine(game,"TheForest_Data/Managed") };
        string saved = Path.Combine(cache,"original-path.txt");
        if (File.Exists(saved)) candidates.Insert(0,File.ReadAllText(saved).Trim());
        // Relative development and portable ModAPI locations; no creator-specific absolute path.
        DirectoryInfo folder = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
        while (folder != null)
        {
            candidates.Add(Path.Combine(folder.FullName,"gamefiles/original/TheForest/TheForest_data/Managed"));
            candidates.Add(Path.Combine(folder.FullName,"ModAPI/gamefiles/original/TheForest/TheForest_data/Managed"));
            candidates.Add(Path.Combine(folder.FullName,"work/forest-re3-mashup/modapi-workspace/gamefiles/original/TheForest/TheForest_data/Managed"));
            folder = folder.Parent;
        }
        return candidates.FirstOrDefault(IsOriginal) ?? Path.Combine(game,"TheForest_Data/Managed");
    }
    private static bool IsOriginal(string folder)
    {
        try
        {
            XElement versions = XDocument.Load(Path.Combine(cache,"core/configs/games/TheForest/Versions.xml")).Root;
            string expected = versions.Elements("version").Single(v => (string)v.Attribute("id")=="1.11b").Element("checksum").Value;
            string actual = "";
            using (MD5 md5 = MD5.Create()) foreach (XElement file in versions.Element("files").Elements("file"))
            {
                string path = Path.Combine(folder,Path.GetFileName(file.Value));
                if (!File.Exists(path)) return false;
                using (var stream = File.OpenRead(path)) actual += BitConverter.ToString(md5.ComputeHash(stream)).Replace("-","");
            }
            return actual.Equals(expected,StringComparison.OrdinalIgnoreCase);
        }
        catch (IOException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
    }
    private static void Prepare(string original)
    {
        string ready = Path.Combine(cache,"generated/TheForest/Mods/RuntimeConfiguration.xml");
        string package = Directory.GetFiles(Path.Combine(cache,"core/mods/TheForest"),"*.mod").Single();
        string stamp = Path.Combine(cache,"prepared-package.sha256");
        string packageSha = Sha(package);
        if (File.Exists(ready) && File.Exists(stamp) && File.ReadAllText(stamp).Trim()==packageSha)
        {
            XElement mod = XDocument.Load(ready).Root.Element("Mod");
            if (mod != null && (string)mod.Attribute("Version") == PackageVersion) return;
        }
        string core = Path.Combine(cache,"core");
        var start = new ProcessStartInfo(Path.Combine(core,"PrepareRuntime.exe"), Quote(core)+" "+Quote(original))
            { UseShellExecute=false, CreateNoWindow=true, WindowStyle=ProcessWindowStyle.Hidden, WorkingDirectory=core, RedirectStandardOutput=true, RedirectStandardError=true, StandardOutputEncoding=Encoding.UTF8, StandardErrorEncoding=Encoding.UTF8 };
        using (Process process = Process.Start(start))
        {
            var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
            process.WaitForExit();
            File.WriteAllText(Path.Combine(cache,"prepare.log"),stdout.Result+stderr.Result);
            if (process.ExitCode != 0) throw new InvalidOperationException("No se pudo preparar el mashup. "+stderr.Result.Trim());
            File.WriteAllText(stamp,packageSha);
        }
    }
    private static string Quote(string value)
    {
        if (value.IndexOf('"') >= 0) throw new ArgumentException("Ruta no válida.");
        return "\""+value.TrimEnd('\\')+"\"";
    }
    private static void Install(string game)
    {
        if (!File.Exists(Path.Combine(game,"TheForest.exe"))) throw new InvalidOperationException("Selecciona la carpeta de The Forest.");
        if (Process.GetProcessesByName("TheForest").Length > 0) throw new InvalidOperationException("Cierra The Forest antes de actualizar el mashup.");
        string liveConfig = Path.Combine(game,"Mods/RuntimeConfiguration.xml");
        if (File.Exists(liveConfig) && XDocument.Load(liveConfig).Root.Elements("Mod").Any(m => !KnownMods.Contains((string)m.Attribute("ID"))))
            throw new InvalidOperationException("Hay otros mods activos. Desactívalos antes de instalar esta prueba del mashup.");
        string generated = Path.Combine(cache,"generated/TheForest");
        var files = Directory.GetFiles(Path.Combine(generated,"TheForest_data/Managed"),"*.dll").Concat(Directory.GetFiles(Path.Combine(generated,"Mods"),"*",SearchOption.AllDirectories)).ToArray();
        if (files.All(source => { string destination = SafePath(game,source.Substring(generated.Length+1)); return File.Exists(destination) && Sha(destination)==Sha(source); })) return;
        string transaction = Path.Combine(cache,"backups",DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(transaction);
        var manifest = new XDocument(new XElement("Install",new XAttribute("game",Path.GetFullPath(game)),new XAttribute("version",Version)));
        foreach (string source in files)
        {
            string relative = source.Substring(generated.Length+1), destination = SafePath(game,relative);
            var entry = new XElement("File",new XAttribute("path",relative),new XAttribute("existed",File.Exists(destination)),new XAttribute("installedSha256",Sha(source)));
            if (File.Exists(destination))
            {
                string backup = SafePath(transaction,relative); Directory.CreateDirectory(Path.GetDirectoryName(backup)); File.Copy(destination,backup);
            }
            manifest.Root.Add(entry);
        }
        manifest.Save(Path.Combine(transaction,"install.xml"));
        try
        {
            foreach (string source in files)
            {
                string destination = SafePath(game,source.Substring(generated.Length+1));
                Directory.CreateDirectory(Path.GetDirectoryName(destination)); File.Copy(source,destination,true);
            }
            XElement mod = XDocument.Load(liveConfig).Root.Elements("Mod").Single();
            if ((string)mod.Attribute("Version") != PackageVersion) throw new InvalidDataException("La instalación no corresponde a esta versión.");
            File.WriteAllText(Path.Combine(cache,"last-install.txt"),transaction);
            File.WriteAllText(Path.Combine(cache,"game-path.txt"),Path.GetFullPath(game));
        }
        catch { Restore(transaction,false); throw; }
    }
    private static void Restore(string transaction,bool checkChanges)
    {
        XDocument manifest = XDocument.Load(Path.Combine(transaction,"install.xml"));
        string game = (string)manifest.Root.Attribute("game");
        if (Process.GetProcessesByName("TheForest").Length > 0) throw new InvalidOperationException("Cierra The Forest antes de restaurar.");
        if (checkChanges)
            foreach (XElement item in manifest.Root.Elements("File"))
            {
                string target = SafePath(game,(string)item.Attribute("path"));
                if (File.Exists(target) && Sha(target) != (string)item.Attribute("installedSha256")) throw new InvalidOperationException("Otro programa cambió archivos después de la instalación. No se restauró el respaldo.");
            }
        foreach (XElement item in manifest.Root.Elements("File"))
        {
            string relative = (string)item.Attribute("path"), target = SafePath(game,relative);
            if ((bool)item.Attribute("existed")) File.Copy(SafePath(transaction,relative),target,true);
            else if (File.Exists(target)) File.Delete(target);
        }
        File.WriteAllText(Path.Combine(transaction,"restored.txt"),DateTime.UtcNow.ToString("o"));
        string last = Path.Combine(cache,"last-install.txt");
        if (File.Exists(last) && File.ReadAllText(last).Trim()==transaction) File.Delete(last);
    }
    private static string PreferencePath
    {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TheResidentForest3","launcher-options.xml");}}
    private static bool LoadDeveloperPreference()
    {
        try{return File.Exists(PreferencePath) && (string)XDocument.Load(PreferencePath).Root.Attribute("developerTools")=="true";}
        catch(Exception){return false;}
    }
    private static void SavePreferences(string game,string original)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(PreferencePath));
        new XDocument(new XElement("TheResidentForest3",new XAttribute("developerTools",developerTools ? "true":"false"))).Save(PreferencePath);
        File.WriteAllText(Path.Combine(cache,"game-path.txt"),game);
        if(original!=null)File.WriteAllText(Path.Combine(cache,"original-path.txt"),original);
    }
    private static void StageRuntimeOptions()
    {
        string path=Path.Combine(cache,"generated/TheForest/Mods/TheResidentForest3.Options.xml");
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        new XDocument(new XElement("TheResidentForest3",new XAttribute("developerTools",developerTools ? "true":"false"))).Save(path);
    }
    private static class Theme
    {
        internal static readonly Color Yellow=Color.FromArgb(235,205,35),Dark=Color.FromArgb(18,18,18);
        private static readonly PrivateFontCollection fonts=new PrivateFontCollection();
        private static readonly List<IntPtr> buffers=new List<IntPtr>();
        [DllImport("gdi32.dll")]private static extern IntPtr AddFontMemResourceEx(IntPtr font,uint size,IntPtr reserved,ref uint count);
        static Theme()
        {
            foreach(string name in new[]{"Montserrat-Regular.ttf","Montserrat-Bold.ttf"})
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("TR3."+name))
            {
                byte[] data=new byte[(int)stream.Length];int offset=0;
                while(offset<data.Length){int n=stream.Read(data,offset,data.Length-offset);if(n==0)throw new EndOfStreamException();offset+=n;}
                IntPtr memory=Marshal.AllocCoTaskMem(data.Length);Marshal.Copy(data,0,memory,data.Length);buffers.Add(memory);
                fonts.AddMemoryFont(memory,data.Length);uint count=0;AddFontMemResourceEx(memory,(uint)data.Length,IntPtr.Zero,ref count);
            }
        }
        internal static Font Face(float size,bool bold=false){return new Font(fonts.Families[0],size,bold ? FontStyle.Bold:FontStyle.Regular);}
        internal static void Apply(Control control)
        {
            control.BackColor=Color.Black;control.ForeColor=Yellow;
            var button=control as Button;
            if(button!=null){button.FlatStyle=FlatStyle.Flat;button.FlatAppearance.BorderColor=Yellow;button.FlatAppearance.MouseOverBackColor=Color.FromArgb(42,38,10);button.FlatAppearance.MouseDownBackColor=Color.FromArgb(60,53,12);button.Cursor=Cursors.Hand;}
            var box=control as TextBox;if(box!=null){box.BackColor=Dark;box.BorderStyle=BorderStyle.FixedSingle;}
            foreach(Control child in control.Controls)Apply(child);
        }
        internal static Image Logo()
        {using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("TR3.logo.png"))using(var image=Image.FromStream(stream))return new Bitmap(image);}
    }
    private sealed class LauncherForm : Form
    {
        private readonly Label status=new Label(),toolsStatus=new Label();
        private readonly Button play=new Button(),options=new Button(),exit=new Button();
        private string gamePath,original;
        private bool working;
        internal LauncherForm(string path,string originalPath)
        {
            gamePath=path;original=originalPath;
            Text=ProductName;ClientSize=new Size(760,510);AutoScaleMode=AutoScaleMode.Dpi;
            FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;
            Font=Theme.Face(10);Icon=System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            Controls.Add(new PictureBox{Image=Theme.Logo(),SizeMode=PictureBoxSizeMode.Zoom,Bounds=new Rectangle(26,16,136,150)});
            Controls.Add(new Label{Text="THE RESIDENT",Font=Theme.Face(25,true),Bounds=new Rectangle(178,43,550,45)});
            Controls.Add(new Label{Text="FOREST 3",Font=Theme.Face(30,true),Bounds=new Rectangle(175,87,550,55)});
            Controls.Add(new Label{Text="JILL / CARLOS    ·    "+Version,Font=Theme.Face(10),Bounds=new Rectangle(38,171,685,28)});
            play.Text="JUGAR";play.Font=Theme.Face(17,true);play.SetBounds(36,217,688,66);play.Click+=delegate{StartPlay();};Controls.Add(play);
            options.Text="OPCIONES";options.SetBounds(36,307,334,48);options.Click+=delegate{OpenOptions();};Controls.Add(options);
            exit.Text="SALIR";exit.SetBounds(390,307,334,48);exit.Click+=delegate{Close();};Controls.Add(exit);
            toolsStatus.SetBounds(36,378,690,26);Controls.Add(toolsStatus);UpdateToolsLabel();
            status.SetBounds(36,421,690,67);status.Text=gamePath.Length==0 ? "Selecciona la carpeta del juego en Opciones.":"TAB: inventario RE3R   ·   E: baúl   ·   F: esquiva\nArrastra los objetos para organizar el inventario. 5–8: acceso rápido.";Controls.Add(status);
            Theme.Apply(this);
        }
        private void UpdateToolsLabel(){toolsStatus.Text="HERRAMIENTAS DE PRUEBA: "+(developerTools ? "ACTIVADAS · SÓLO ANFITRIÓN":"DESACTIVADAS");}
        internal Form OptionsPreview(){return new OptionsForm(this);}
        private void OpenOptions()
        {
            using(var dialog=new OptionsForm(this))
            {
                if(dialog.ShowDialog(this)==DialogResult.OK)
                {gamePath=dialog.GamePath;original=dialog.OriginalPath;developerTools=dialog.DeveloperTools;SavePreferences(gamePath,original);UpdateToolsLabel();status.Text="Opciones guardadas. Se aplicarán al iniciar el juego.";}
            }
        }
        private void StartPlay()
        {
            string path=gamePath.Trim();
            if(!File.Exists(Path.Combine(path,"TheForest.exe"))){status.Text="Selecciona la carpeta donde está TheForest.exe en Opciones.";OpenOptions();return;}
            if(original==null)original=FindOriginal(path);
            if(!IsOriginal(original)){status.Text="Selecciona el respaldo original de ModAPI en Opciones.";OpenOptions();return;}
            Busy(true,"PREPARANDO THE RESIDENT FOREST 3…");
            var thread=new Thread(delegate()
            {
                try
                {
                    Prepare(original);StageRuntimeOptions();Install(path);SavePreferences(path,original);
                    string engineLog=Path.Combine(cache,"engine-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".log");
                    Process.Start(new ProcessStartInfo(Path.Combine(path,"TheForest.exe")){UseShellExecute=true,WorkingDirectory=path,Arguments="-logFile \""+engineLog+"\""});
                    BeginInvoke(new Action(delegate{Busy(false,"JUEGO INICIADO. Disfruta la partida.");}));
                }
                catch(Exception error){BeginInvoke(new Action(delegate{Busy(false,error.Message);}));}
            });
            thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();
        }
        private string StartRestore()
        {
            string last=Path.Combine(cache,"last-install.txt");
            if(!File.Exists(last))return "No hay una instalación anterior que restaurar.";
            try{Restore(File.ReadAllText(last).Trim(),true);return "Instalación anterior restaurada.";}
            catch(Exception error){return error.Message;}
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {if(working){e.Cancel=true;status.Text="Espera a que termine la instalación antes de cerrar.";}base.OnFormClosing(e);}
        private void Busy(bool busy,string message){working=busy;play.Enabled=options.Enabled=exit.Enabled=!busy;status.Text=message;}
        private sealed class OptionsForm : Form
        {
            private readonly TextBox folder=new TextBox();private readonly CheckBox tools=new CheckBox();
            private readonly Label message=new Label();private string originalPath;
            internal string GamePath{get{return folder.Text.Trim();}}
            internal string OriginalPath{get{return originalPath;}}
            internal bool DeveloperTools{get{return tools.Checked;}}
            internal OptionsForm(LauncherForm parent)
            {
                Text=ProductName+" · Opciones";ClientSize=new Size(710,485);Font=Theme.Face(10);AutoScaleMode=AutoScaleMode.Dpi;
                FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;StartPosition=FormStartPosition.CenterParent;Icon=parent.Icon;
                originalPath=parent.original;
                Controls.Add(new Label{Text="OPCIONES",Font=Theme.Face(22,true),Bounds=new Rectangle(24,22,650,45)});
                Controls.Add(new Label{Text="CARPETA DE THE FOREST",Bounds=new Rectangle(24,85,650,25)});
                folder.Text=parent.gamePath;folder.SetBounds(24,117,510,28);Controls.Add(folder);
                var browse=new Button{Text="EXAMINAR",Bounds=new Rectangle(550,112,136,36)};
                browse.Click+=delegate{using(var dialog=new FolderBrowserDialog{SelectedPath=GamePath})if(dialog.ShowDialog(this)==DialogResult.OK){folder.Text=dialog.SelectedPath;originalPath=null;}};Controls.Add(browse);
                var open=new Button{Text="ABRIR CARPETA",Bounds=new Rectangle(24,164,220,37)};
                open.Click+=delegate{if(Directory.Exists(GamePath))Process.Start(new ProcessStartInfo(GamePath){UseShellExecute=true});else message.Text="Selecciona una carpeta válida.";};Controls.Add(open);
                var choose=new Button{Text="RESPALDO ORIGINAL…",Bounds=new Rectangle(260,164,426,37)};
                choose.Click+=delegate
                {
                    using(var dialog=new FolderBrowserDialog{Description="Selecciona Managed del respaldo original, o la carpeta de ModAPI."})
                    {
                        if(dialog.ShowDialog(this)!=DialogResult.OK)return;string selected=dialog.SelectedPath;
                        if(!IsOriginal(selected))selected=Path.Combine(selected,"gamefiles/original/TheForest/TheForest_data/Managed");
                        if(!IsOriginal(selected)){message.Text="Ese respaldo no corresponde a The Forest 1.11b.";return;}
                        originalPath=selected;message.Text="Respaldo original reconocido.";
                    }
                };Controls.Add(choose);
                var restore=new Button{Text="RESTAURAR INSTALACIÓN ANTERIOR",Bounds=new Rectangle(24,217,662,37)};
                restore.Click+=delegate{message.Text=parent.StartRestore();};Controls.Add(restore);
                tools.Text="Activar herramientas de prueba (sólo anfitrión)";tools.Checked=developerTools;tools.SetBounds(24,279,662,28);tools.FlatStyle=FlatStyle.Flat;Controls.Add(tools);
                Controls.Add(new Label{Text="Invocar, teletransportarse, cambiar personaje y figuras de animación.\nLos clientes no pueden utilizar estas herramientas.",Bounds=new Rectangle(24,318,662,47)});
                message.SetBounds(24,372,662,45);Controls.Add(message);
                var save=new Button{Text="GUARDAR",Bounds=new Rectangle(350,430,160,37),DialogResult=DialogResult.OK};Controls.Add(save);
                var cancel=new Button{Text="CANCELAR",Bounds=new Rectangle(526,430,160,37),DialogResult=DialogResult.Cancel};Controls.Add(cancel);
                AcceptButton=save;CancelButton=cancel;Theme.Apply(this);
            }
        }
    }
}
