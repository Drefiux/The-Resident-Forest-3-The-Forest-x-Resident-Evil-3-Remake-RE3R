from pathlib import Path
import importlib.util,json,copy,struct,hashlib
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
PROJECT=ROOT/'outputs/forest-re3-mashup/unity-pipeline';SRC=ROOT/'work/r3/natives/stm';DEST=PROJECT/'Assets/LocalAssets/Re3Rocket'
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
reader=module('reader',ROOT/'work/jill/corrected/decode_motion_preview.py');packer=module('packer',ROOT/'work/jill/corrected/pack_motion_preview.py')
mesh=module('mesh',ROOT/'work/forest-re3-mashup/research-inventory/build_inventory_assets.py');assets=module('assets',PROJECT/'prepare_carlos_assets.py')
DEST.mkdir(parents=True,exist_ok=True)
class Assets(assets.PreviewAssets):
 def save(self,key,image):return super().save(key,image).replace('CarlosCorrected','Re3Rocket')
converter=Assets(SRC,DEST,1024);base=SRC/'escape/character/weapon/wp4600/mesh'
geometry=mesh.read_mesh(base/'wp4600_rocketlauncher.mesh.2109108288')
for i,p in enumerate(geometry['parts']):p['name']='RocketLauncher_'+str(i)
mats=[converter.material('Rocket',m)for m in assets.read_mdf(base/'wp4600_rocketlauncher.mdf2.21')]
(DEST/'rocket-mesh.json').write_text(json.dumps(geometry,separators=(',',':')))
(DEST/'rocket-manifest.json').write_text(json.dumps(dict(materials=mats),indent=2))
for p in geometry['parts']:
 print('MESH',p['name'],p['material'],'bounds',[(min(p['positions'][j::3]),max(p['positions'][j::3]))for j in range(3)])
# The generic rendered rocket warhead used by RE3's weapon VFX.
base=SRC/'escape/vfx/mesh/mesh_weapon/mesh_wp9001';stem='mesh_0006_wp9001_rocketlancherbullet_0000'
projectile=mesh.read_mesh(base/(stem+'.mesh.2109108288'))
for i,p in enumerate(projectile['parts']):p['name']='RocketProjectile_'+str(i)
pmats=[converter.material('Projectile',m)for m in assets.read_mdf(base/(stem+'_00.mdf2.21'))]
(DEST/'projectile-mesh.json').write_text(json.dumps(projectile,separators=(',',':')))
(DEST/'projectile-manifest.json').write_text(json.dumps(dict(materials=pmats),indent=2))
print('PROJECTILE',[(p['material'],[(min(p['positions'][j::3]),max(p['positions'][j::3]))for j in range(3)])for p in projectile['parts']])
decode=reader.decoder();clips=[];manifest=[]
names=[('hold','0160_RL1_Hold_Idle_Loop'),('aim','0160_RL1_Hold_Idle_Loop'),('shoot','1100_RL2_Hold_Shoot'),('aimshoot','1100_RL2_Hold_Shoot'),('ready','0140_RL1_Hold_Start_L0'),('grip','50_Hold_RL1_LGT')]
for ch in ('pl2000','pl0000'):
 folder=SRC/f'escape/character/player/{ch}/animation/list/rkl';entries=[]
 for path in folder.glob('*.motlist.524'):entries.extend((path,*e)for e in reader.motions(path.read_bytes()))
 bone_map={b['hash']:b for _,_,_,raw in entries for b in reader.skeleton(raw)}
 for path in folder.parent.rglob('*.motlist.524'):
  for _,_,raw in reader.motions(path.read_bytes()):
   for b in reader.skeleton(raw):bone_map.setdefault(b['hash'],b)
 for mode,suffix in names:
  found=[e for e in entries if e[2]==ch+'_'+suffix];found.sort(key=lambda e:'finger'not in e[0].name if mode=='grip'else 'base_'not in e[0].name)
  path,offset,name,raw=found[0];local={b['hash']:b for b in reader.skeleton(raw)};own=[local.get(h,b)for h,b in bone_map.items()]
  clip=reader.decode(raw,own,decode);clip.update(mode=ch+'_rocket_'+mode,bones=own,name=name);clips.append(clip)
  manifest.append(dict(mode=clip['mode'],name=name,source=str(path.relative_to(ROOT)),frames=clip['frames'],fps=clip['fps'],tracks=len(clip['tracks'])))
packer.write_binary(dict(clips=clips),HERE/'rocket-motions.bin');(HERE/'rocket-motion-review.json').write_text(json.dumps(dict(clips=clips),separators=(',',':')))
(HERE/'rocket-motion-manifest.json').write_text(json.dumps(manifest,indent=2));print('CLIPS',json.dumps(manifest))
# Preserve exactly the source ballistic fields; runtime reads this bank.
source=json.loads((HERE/'projectile-source.json').read_text())['wp4600'];ballistic=next(r['fields']for r in source if r['type'].endswith('BulletShellBallisticSetting'))
radius_ref=ballistic['_Radius']['value'];radius=next(r['fields']['_BaseValue']['value']for r in source if r['instance']==radius_ref)
with (HERE/'rocket-ballistics.bin').open('wb')as f:
 f.write(b'RPG1');f.write(struct.pack('<4f',*(ballistic[k]['value']for k in ('_Speed','_Gravity','_FiringRange')),radius))
