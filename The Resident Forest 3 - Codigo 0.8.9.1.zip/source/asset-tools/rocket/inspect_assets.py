from pathlib import Path
import json,struct,re,importlib.util
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent;SRC=ROOT/'work/r3/natives/stm'
schema=json.loads((HERE/'rszre3rt.json').read_text())
for key,row in schema.items():
 if row['name'] in ('offline.weapon.shell.BulletRocketShellUserData','offline.weapon.generator.BulletRocketGeneratorUserData'):
  print('SCHEMA',key,json.dumps(row))
def inspect(path):
 data=path.read_bytes();base=data.index(b'RSZ\x00');head=struct.unpack_from('<6I3Q',data,base);info,raw,usr=head[6:]
 types=[struct.unpack_from('<2I',data,base+info+i*8)for i in range(head[3])]
 print('FILE',path.relative_to(SRC),'HEADER',head,'TYPES',[(hex(k),schema.get(format(k,'x'),{}).get('name'))for k,_ in types])
 print('STRINGS',re.findall(r'[A-Za-z0-9_/\\.]{5,}',data.decode('utf-16-le',errors='ignore')))
 p=base+raw;skip={struct.unpack_from('<I',data,base+usr+i*16)[0]for i in range(head[4])}
 rows=[]
 for i,(key,crc)in enumerate(types):
  if i==0 or i in skip:continue
  row=schema[format(key,'x')];values={}
  for f in row['fields']:
   def value():
    nonlocal p
    p=(p+f['align']-1)//f['align']*f['align'];off=p
    t=f['type'];size=f['size']
    if t in ('String','Resource'):
     n=struct.unpack_from('<I',data,p)[0];p+=4;v=data[p:p+n*2].decode('utf-16-le').rstrip('\0');p+=n*2
    else:
     v=struct.unpack_from('<f'if t=='F32'else '<I',data,p)[0]if size==4 else data[p:p+size].hex();p+=size
    return dict(offset=off,type=t,value=v)
   if f['array']:
    p=(p+3)//4*4;n=struct.unpack_from('<I',data,p)[0];p+=4;assert n<100000;v=[value()for _ in range(n)]
   else:v=value()
   values[f['name']]=v
  rows.append(dict(instance=i,type=row['name'],fields=values))
 print('DECODE',json.dumps(rows));return rows
results={}
for name in ('wp4400','wp4600'):
 path=SRC/f'objectroot/prefab/shell/shell/entity/bullet/{name}/bulletrocketshelluserdata_{name}.user.2'
 results[name]=inspect(path)
 p=SRC/f'objectroot/prefab/shell/shell/entity/bullet/{name}/bulletrocket_{name}.pfb.17'
 print('PREFABSTRINGS',name,re.findall(r'[A-Za-z0-9_/\\.]{5,}',p.read_bytes().decode('utf-16-le',errors='ignore')))
(HERE/'projectile-source.json').write_text(json.dumps(results,indent=2))
spec=importlib.util.spec_from_file_location('motions',ROOT/'work/jill/corrected/decode_motion_preview.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
index=[]
for ch in ('pl2000','pl0000'):
 for path in (SRC/f'escape/character/player/{ch}/animation/list/rkl').glob('*.motlist.*'):
  for off,name,raw in reader.motions(path.read_bytes()):index.append(dict(character=ch,file=path.name,name=name,frames=struct.unpack_from('<f',raw,116)[0]))
(HERE/'rocket-motion-index.json').write_text(json.dumps(index,indent=2));print('MOTIONS',json.dumps([r for r in index if 'Hold' in r['name'] or 'Focus' in r['name']or '50_'in r['name']]))

