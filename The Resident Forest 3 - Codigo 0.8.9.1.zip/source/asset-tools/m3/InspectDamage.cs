using System;
using System.Linq;
using Mono.Cecil;
internal static class InspectDamage {
 public static void Main(string[] args) {
  using(var module=ModuleDefinition.ReadModule(args[0]))
   foreach(var type in module.Types.Where(t=>args[1].Split(',').Any(s=>s.StartsWith("@") ? t.Methods.Any(m=>m.Name==s.Substring(1)):s.StartsWith("~") ? t.Name.ToLowerInvariant().Contains(s.Substring(1).ToLowerInvariant()):t.Name==s))) {
    Console.WriteLine("TYPE "+type.FullName);
    foreach(var f in type.Fields)Console.WriteLine("FIELD "+f.Attributes+" "+f.FullName);
    foreach(var m in type.Methods){Console.WriteLine("METHOD "+m.Attributes+" "+m.FullName);if(m.HasBody && args.Length>2 && (args[2]=="*" || args[2].Split(',').Contains(m.Name)))foreach(var i in m.Body.Instructions)Console.WriteLine(i);}
   }
 }
}
