from pathlib import Path
import importlib.util,json,copy
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
PROJECT=ROOT/'outputs/forest-re3-mashup/unity-pipeline';SOURCE=ROOT/'work/r3/natives/stm';DEST=PROJECT/'Assets/LocalAssets/Re3M3'
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
reader=module('reader',ROOT/'work/jill/corrected/decode_motion_preview.py');packer=module('packer',ROOT/'work/jill/corrected/pack_motion_preview.py')
mesh=module('mesh',ROOT/'work/forest-re3-mashup/research-inventory/build_inventory_assets.py');assets=module('assets',PROJECT/'prepare_carlos_assets.py')
DEST.mkdir(parents=True,exist_ok=True);base=SOURCE/'escape/character/weapon/wp1000/mesh'
geometry=mesh.read_mesh(base/'wp1000_shotgun.mesh.2109108288')
class Assets(assets.PreviewAssets):
 def save(self,key,image):return super().save(key,image).replace('CarlosCorrected','Re3M3')
converter=Assets(SOURCE,DEST,1024);mats=[converter.material('M3',m)for m in assets.read_mdf(base/'wp1000_shotgun.mdf2.21')]
print('PARTS',[(p['material'],len(p['positions'])//3)for p in geometry['parts']])
# Base M3: the optional extended barrel and stock are separate material groups.
geometry['parts']=[p for p in geometry['parts']if not any(n in p['material'].lower()for n in ('barrel','stock','shell'))]
for i,p in enumerate(geometry['parts']):p['name']='M3_'+str(i)
(DEST/'m3-mesh.json').write_text(json.dumps(geometry,separators=(',',':')));(DEST/'m3-manifest.json').write_text(json.dumps(dict(materials=mats),indent=2))
folder=SOURCE/'escape/character/player/pl2000/animation/list/stg';entries=[]
for name in ('base_stg_hold.motlist.524','stg_hold_01.motlist.524','base_stg_finger.motlist.524','stg_finger_01.motlist.524'):
 path=folder/name
 if path.exists():entries.extend((path,*e)for e in reader.motions(path.read_bytes()))
bone_map={b['hash']:b for _,_,_,raw in entries for b in reader.skeleton(raw)}
for path in (folder.parent/'cmn').glob('base_*.motlist.524'):
 for _,_,raw in reader.motions(path.read_bytes()):
  for b in reader.skeleton(raw):bone_map.setdefault(b['hash'],b)
decode=reader.decoder();clips=[];manifest=[]
# RE3R's M3 uses Hold_Idle for shoulder aiming and Hold_Shoot (delta) for recoil;
# no separate Focus clips exist. Carlos has shotgun locomotion, not M3 upper-body
# clips, so use Jill's authored M3 grip, retargeted by matching RE bone names.
names=[('hold','0160_SG_Hold_Idle_Loop'),('aim','0160_SG_Hold_Idle_Loop'),('shoot','1100_SG_Hold_Shoot'),('aimshoot','1100_SG_Hold_Shoot'),('reload','1200_SG_Hold_Reload'),('ready','0140_SG_Hold_Start_L0'),('grip','50_Hold_SG01'),('reloadend','1201_SG_Hold_Reload')]
for mode,suffix in names:
 found=[e for e in entries if e[2]=='pl2000_'+suffix]
 if mode=='grip':found.sort(key=lambda e:'finger'not in e[0].name)
 path,offset,name,raw=found[0];local={b['hash']:b for b in reader.skeleton(raw)};own=[local.get(h,b)for h,b in bone_map.items()]
 clip=reader.decode(raw,own,decode);clip.update(mode='pl2000_m3_'+mode,bones=own,name=name)
 for ch in ('pl2000','pl0000'):
  out=copy.deepcopy(clip);out['mode']=ch+'_m3_'+mode;clips.append(out)
 manifest.append(dict(mode=mode,name=name,source=str(path.relative_to(ROOT)),offset=offset,frames=clip['frames'],fps=clip['fps'],tracks=len(clip['tracks']),carlos='Jill M3 shared rig'))
packer.write_binary(dict(clips=clips),HERE/'m3-motions.bin');(HERE/'m3-motion-review.json').write_text(json.dumps(dict(clips=clips),separators=(',',':')));(HERE/'m3-motion-manifest.json').write_text(json.dumps(manifest,indent=2))
print('CLIPS',json.dumps(manifest))
