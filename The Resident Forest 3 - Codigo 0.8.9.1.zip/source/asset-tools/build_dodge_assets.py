"""Build authored evasions and quiet movement voices from locally owned RE3 files."""
import importlib.util
import json
import struct
import subprocess
import wave
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


reader = module('decoder', ROOT/'work/jill/corrected/decode_motion_preview.py')
packer = module('packer', ROOT/'work/jill/corrected/pack_motion_preview.py')


def sample(track, frame):
    size = 5 if track['kind'] == 'rotation' else 4
    keys = np.array(track['values']).reshape(-1, size)
    i = max(0, int(np.searchsorted(keys[:, 0], frame, side='right'))-1)
    j = min(i+1, len(keys)-1)
    t = np.clip((frame-keys[i, 0])/(keys[j, 0]-keys[i, 0]), 0, 1) if j != i else 0
    a, b = keys[i, 1:], keys[j, 1:]
    if size == 5 and np.dot(a, b) < 0:
        b = -b
    return a*(1-t)+b*t


def rotation(q):
    x, y, z, w = q/np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def pose(clip, frame):
    positions = {b['name']: np.array(b['restPosition']) for b in clip['bones']}
    rotations = {b['name']: np.array(b['restRotation']) for b in clip['bones']}
    for track in clip['tracks']:
        if track['bone'] in ('root', 'Null_Offset'):
            continue
        value = sample(track, frame)
        if track['kind'] == 'position':
            if track['bone'] == 'COG':
                value[0] = value[2] = 0
            positions[track['bone']] = value
        elif track['kind'] == 'rotation':
            rotations[track['bone']] = value
    matrices = []
    for bone in clip['bones']:
        m = np.eye(4)
        m[:3, :3] = rotation(rotations[bone['name']])
        m[:3, 3] = positions[bone['name']]
        if bone['parent'] >= 0:
            m = matrices[bone['parent']] @ m
        matrices.append(m)
    return {b['name']: m[:3, 3] for b, m in zip(clip['bones'], matrices)}


def motions():
    decode_frame = reader.decoder()
    clips = []
    for character, names in (
        ('pl2000', ['pl2000_es_0410_KFF_Escape_L0', 'pl2000_es_0412_KFF_Escape_L180',
                    'pl2000_es_0413_KFF_Escape_R0', 'pl2000_es_0415_KFF_Escape_R180']),
        ('pl0000', ['pl0000_es_0421_KFF_Escape_Step_01', 'pl0000_es_0422_KFF_Escape_Step_02',
                    'pl0000_es_0450_KFF_Escape_Step_Strength','pl0000_es_0470_KFF_Escape_Jog_L',
                    'pl0000_es_0471_KFF_Escape_Jog_R','pl0000_es_0500_KFF_Escape_Punch_L'])):
        path = ROOT/f'work/r3/natives/stm/escape/character/player/{character}/animation/list/cmn/base_cmn_move.motlist.524'
        entries = list(reader.motions(path.read_bytes()))
        bones = next(reader.skeleton(raw) for _, _, raw in entries if reader.skeleton(raw))
        for name in names:
            offset, _, raw = next(e for e in entries if e[1] == name)
            own_bones = reader.skeleton(raw) or bones
            clip = reader.decode(raw, own_bones, decode_frame)
            clip.update(mode='dodge_'+str(len(clips)), name=name, bones=own_bones,
                        source=str(path.relative_to(ROOT)), sourceOffset=offset)
            clips.append(clip)
    data = {'schemaVersion': 1, 'clips': clips, 'fpsAssumption': '60 Hz base motion ticks'}
    (HERE/'dodge-review.json').write_text(json.dumps(data, separators=(',', ':')), encoding='utf-8')
    links = [('COG', 'spine_1'), ('spine_1', 'neck_0'), ('neck_0', 'head')]
    for side in 'lr':
        links += [(side+'_arm_humerus', side+'_arm_radius'), (side+'_arm_radius', side+'_arm_wrist'),
                  ('COG', side+'_leg_femur'), (side+'_leg_femur', side+'_leg_tibia'),
                  (side+'_leg_tibia', side+'_leg_ankle')]
    image = Image.new('RGB', (1440, len(clips)*220), '#15202d')
    draw = ImageDraw.Draw(image)
    for row, clip in enumerate(clips):
        draw.text((8, row*220+5), clip['name'], fill='white')
        for column, fraction in enumerate((0, .2, .4, .6, .8, .98)):
            joints = pose(clip, clip['frames']*fraction)
            def screen(p):
                return (column*240+110+p[0]*40+p[2]*85, row*220+202-p[1]*85)
            for a, b in links:
                draw.line((screen(joints[a]), screen(joints[b])), width=3,
                          fill='#68c8ff' if b.startswith('l_') else '#ffb866')
            draw.ellipse((*screen(joints['head']), screen(joints['head'])[0]+5, screen(joints['head'])[1]+5), fill='white')
    image.save(HERE/'dodge-candidate-poses.png')
    # Inspect all six Carlos candidates before selecting the rolling bank.
    # Both playable rigs therefore share Jill's four actual rolling variants.
    selected = {'schemaVersion': 1, 'clips': clips[:4]}
    packer.write_binary(selected, HERE/'dodge-motions.bin')
    manifest = {'date': '09/10/2026', 'version': '0.8.1',
                'selection': 'Four Jill rolling evasions shared by both rigs; Carlos upright steps excluded after joint-pose inspection.',
                'clips': [{k: v for k, v in clip.items() if k not in ('bones', 'tracks')} for clip in clips[:4]]}
    (HERE/'dodge-motions.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('Authored motion candidates decoded:', len(clips))


def voices():
    for character, stem in (('pl2000', 'jill'), ('pl0000', 'carlos')):
        folder = ROOT/f'work/{stem}/corrected/voices'
        root = ET.parse(folder/'effort.xml').getroot()
        def fields(node, name):
            return [f for f in node.iter('field') if f.get('name') == name]
        objects, media, children = {}, {}, {}
        for node in root.iter('object'):
            own = next((f for f in node.findall('field') if f.get('name') == 'ulID'), None)
            if own is not None:
                objects[int(own.get('value'))] = node
            if node.get('name') == 'MediaHeader':
                media[int(fields(node, 'id')[0].get('value'))] = int(node.get('index'))+1
        for key, node in objects.items():
            for parent in fields(node, 'DirectParentID'):
                children.setdefault(int(parent.get('value')), []).append(key)
        def sounds(key, seen=None):
            seen = set() if seen is None else seen
            if key in seen:
                return []
            seen.add(key)
            node = objects[key]
            if node.get('name') == 'CAkSound':
                return [int(f.get('value')) for f in fields(node, 'sourceID')]
            return [s for child in children.get(key, []) for s in sounds(child, seen)]
        event_name = 'Play_'+character+'_v_mov_s'
        event = next(node for node in objects.values() if node.get('name') == 'CAkEvent'
                     and any(f.get('hashname') == event_name for f in node.findall('field')))
        sources = []
        for action_id in fields(event, 'ulActionID'):
            action = objects[int(action_id.get('value'))]
            if action.get('name') == 'CAkActionPlay':
                for target in fields(action, 'idExt'):
                    sources.extend(sounds(int(target.get('value'))))
        clips, records = [], []
        for source in sorted(set(sources)):
            path = HERE/f'{stem}-dodge-{source}.wav'
            subprocess.run([str(ROOT/'work/tools/jill-audio/vgmstream/vgmstream-cli.exe'),
                            '-s', str(media[source]), '-o', str(path), str(folder/f'{stem}-effort-en.bnk')],
                           check=True, capture_output=True)
            with wave.open(str(path), 'rb') as wav:
                if wav.getsampwidth() != 2 or wav.getnchannels() != 1:
                    raise ValueError('Expected mono PCM16')
                rate = wav.getframerate()
                pcm = wav.readframes(wav.getnframes())
            duration = len(pcm)/2/rate
            if not .06 < duration < 1.25:
                continue
            clips.append((source, rate, pcm))
            records.append({'id': source, 'seconds': duration, 'event': event_name})
        if not 2 <= len(clips) <= 10:
            raise ValueError('Unexpected movement voice count: '+str(len(clips)))
        with (HERE/f'{stem}-dodge-voice.bin').open('wb') as stream:
            stream.write(b'JRV1'+struct.pack('<i', len(clips)))
            for source, rate, pcm in clips:
                stream.write(struct.pack('<Biii', 0, source, rate, len(pcm)//2))
                stream.write(pcm)
        (HERE/f'{stem}-dodge-voice.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
        print(stem, 'short movement voices:', len(clips))


if __name__ == '__main__':
    motions()
    voices()
