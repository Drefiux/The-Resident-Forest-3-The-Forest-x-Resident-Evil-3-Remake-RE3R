"""Write the explicit JRM1 runtime format from the decoded motion JSON."""
import json
import struct
from pathlib import Path


def write_binary(data, destination):
    with destination.open('wb') as stream:
        def text(value):
            encoded = value.encode('utf-8')
            if not 0 < len(encoded) <= 4096:
                raise ValueError('Invalid motion name')
            stream.write(struct.pack('<H', len(encoded)))
            stream.write(encoded)

        def count(value):
            stream.write(struct.pack('<i', value))

        def numbers(values):
            stream.write(struct.pack('<' + 'f' * len(values), *values))

        stream.write(b'JRM1')
        count(len(data['clips']))
        for clip in data['clips']:
            text(clip['mode'])
            text(clip['name'])
            numbers([clip['frames'], clip['fps']])
            count(len(clip['bones']))
            for bone in clip['bones']:
                text(bone['name'])
                numbers(bone['restPosition'])
                numbers(bone['restRotation'])
            count(len(clip['tracks']))
            for track in clip['tracks']:
                text(track['bone'])
                stream.write(bytes([{'position': 0, 'rotation': 1, 'scale': 2}[track['kind']]]))
                count(len(track['values']))
                numbers(track['values'])


if __name__ == '__main__':
    source = Path(__file__).with_name('jill-motion-preview.json')
    destination = source.with_suffix('.bin')
    write_binary(json.loads(source.read_text(encoding='utf-8')), destination)
    print('JRM1 bytes:', destination.stat().st_size)
