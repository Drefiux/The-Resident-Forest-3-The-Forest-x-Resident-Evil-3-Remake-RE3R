"""Convert named Jill Wwise events from the locally extracted English effort bank."""
import hashlib
import json
import struct
import subprocess
import wave
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
VOICE = HERE/'voices'
VGM = ROOT/'work/tools/jill-audio/vgmstream/vgmstream-cli.exe'
EVENTS = {'effort': ('Play_pl2000_v_atk_m', 'Play_pl2000_v_atk_l'),
          'hurt': ('Play_pl2000_v_dmg_s', 'Play_pl2000_v_dmg_m')}


def fields(node, name):
    return [f for f in node.iter('field') if f.get('name') == name]


def main():
    root = ET.parse(VOICE/'effort.xml').getroot()
    objects = {}
    media = {}
    for node in root.iter('object'):
        own = next((f for f in node.findall('field') if f.get('name') == 'ulID'), None)
        if own is not None:
            objects[int(own.get('value'))] = node
        if node.get('name') == 'MediaHeader':
            own = fields(node, 'id')[0]
            media[int(own.get('value'))] = int(node.get('index'))+1
    children = {}
    for node_id, node in objects.items():
        for parent in fields(node, 'DirectParentID'):
            children.setdefault(int(parent.get('value')), []).append(node_id)

    def sounds(node_id, seen=None):
        seen = set() if seen is None else seen
        if node_id in seen:
            return []
        seen.add(node_id)
        node = objects.get(node_id)
        if node is None:
            raise ValueError(f'Missing HIRC target {node_id}')
        if node.get('name') == 'CAkSound':
            return [int(f.get('value')) for f in fields(node, 'sourceID')]
        return [source for child in children.get(node_id, []) for source in sounds(child, seen)]

    records = []
    for category, names in EVENTS.items():
        used = set()
        for event_name in names:
            event = next(n for n in objects.values() if n.get('name') == 'CAkEvent'
                         and any(f.get('hashname') == event_name for f in n.findall('field')))
            sources = []
            for action_id in fields(event, 'ulActionID'):
                action = objects[int(action_id.get('value'))]
                if action.get('name') != 'CAkActionPlay':
                    continue
                for target in fields(action, 'idExt'):
                    sources.extend(sounds(int(target.get('value'))))
            if not sources:
                raise ValueError(f'No playable sounds for {event_name}')
            for source_id in sorted(set(sources)):
                if source_id in used:
                    continue
                used.add(source_id)
                wav_path = VOICE/f'{category}-{source_id}.wav'
                subprocess.run([str(VGM), '-s', str(media[source_id]), '-o', str(wav_path),
                                str(VOICE/'jill-effort-en.bnk')], check=True, capture_output=True)
                with wave.open(str(wav_path), 'rb') as audio:
                    if audio.getsampwidth() != 2 or audio.getnchannels() != 1 or audio.getcomptype() != 'NONE':
                        raise ValueError('Expected mono PCM16 from vgmstream')
                    pcm = audio.readframes(audio.getnframes())
                    rate = audio.getframerate()
                duration = len(pcm)/2/rate
                if not 0.05 < duration < 6:
                    raise ValueError(f'Unexpected effort/hurt duration {duration}')
                records.append(dict(category=category, event=event_name, mediaId=source_id,
                                    sampleRate=rate, sampleCount=len(pcm)//2, duration=duration,
                                    pcm=pcm, wav=wav_path.name))
    binary = HERE/'jill-voice-bank.bin'
    with binary.open('wb') as stream:
        stream.write(b'JRV1')
        stream.write(struct.pack('<i', len(records)))
        for record in records:
            stream.write(struct.pack('<Biii', 0 if record['category'] == 'effort' else 1,
                                     record['mediaId'], record['sampleRate'], record['sampleCount']))
            stream.write(record['pcm'])
    manifest = dict(date='07/10/2026', language='English', character='Jill / pl2000',
                    sourceBank='work/r3/natives/stm/escape/sound/wwise/pl2000_v_effort.bnk.2.stm.en',
                    sourceBankSha256=hashlib.sha256((VOICE/'jill-effort-en.bnk').read_bytes()).hexdigest(),
                    eventNamesSource='work/r3/natives/stm/escape/sound/wwise/wwiseids.wid.2',
                    identification='Exact Wwise event hash names resolved from local WID; event -> play action -> random container -> sounds -> DIDX media',
                    decoder='vgmstream r2117 win64', parser='wwiser v20260808',
                    binary=binary.name, bytes=binary.stat().st_size,
                    sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                    clips=[{k:v for k,v in record.items() if k != 'pcm'} for record in records],
                    runtimeAudibleVerified=False)
    (HERE/'jill-voice-bank.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(clips=len(records), bytes=manifest['bytes'], categories={c:sum(r['category']==c for r in records) for c in EVENTS})))


if __name__ == '__main__':
    main()
