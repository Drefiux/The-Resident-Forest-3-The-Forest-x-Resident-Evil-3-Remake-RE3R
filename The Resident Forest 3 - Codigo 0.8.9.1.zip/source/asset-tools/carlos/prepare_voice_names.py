"""Prepare the Carlos Wwise event dictionary from the local game WID."""
import re
import shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/r3/natives/stm/escape/sound/wwise'
(HERE/'voices').mkdir(parents=True,exist_ok=True)
names=sorted(set(m.group().decode('ascii') for m in re.finditer(rb'Play_pl0000_v_[A-Za-z0-9_]+',(SOURCE/'wwiseids.wid.2').read_bytes())))
if not all(name in names for name in ['Play_pl0000_v_atk_m','Play_pl0000_v_atk_l','Play_pl0000_v_dmg_s','Play_pl0000_v_dmg_m']):
    raise ValueError('Missing Carlos attack/hurt event names')
(HERE/'voices/wwnames.txt').write_text('\n'.join(names)+'\n',encoding='utf-8')
shutil.copy2(SOURCE/'pl0000_v_effort.bnk.2.stm.en',HERE/'voices/carlos-effort-en.bnk')
print('Carlos Wwise names prepared:',len(names))
