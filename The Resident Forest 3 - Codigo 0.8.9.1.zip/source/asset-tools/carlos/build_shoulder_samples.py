"""Sample authored RE shoulder correctives for native-pose retargeting.

This reads local RE motion files. It does not change or re-export the model.
"""
import bisect
import hashlib
import json
import math
import struct
from pathlib import Path

import numpy as np
from decode_motion_preview import SOURCE, decoder, motions, skeleton, decode

HERE = Path(__file__).resolve().parent
MAIN = ['arm_clavicle', 'arm_humerus', 'arm_radius', 'arm_wrist']
HELPERS = [f'arm_humerus_twist_{i}_H' for i in range(4)] + [f'arm_radius_twist_{i}_H' for i in range(4)] + [
    'deltFront_muscle', 'deltUp_muscle', 'deltBack_muscle', 'pecA_muscle']


def normalized(q):
    q = np.array(q, dtype=float)
    return q / np.linalg.norm(q)


def sample(track, frame, fallback):
    if track is None:
        return list(fallback)
    stride = 5 if track['kind'] == 'rotation' else 4
    data = track['values']
    times = data[::stride]
    left = max(0, bisect.bisect_right(times, frame)-1)
    right = min(left+1, len(times)-1)
    a = np.array(data[left*stride+1:(left+1)*stride])
    b = np.array(data[right*stride+1:(right+1)*stride])
    blend = (frame-times[left])/(times[right]-times[left]) if times[right] != times[left] else 0
    if stride == 5 and np.dot(a, b) < 0:
        b = -b
    value = a*(1-blend)+b*blend
    return list(normalized(value)) if stride == 5 else list(value)


def main():
    base = json.loads((HERE/'carlos-motion-preview.json').read_text(encoding='utf-8'))
    reference = {b['name']: b for b in base['clips'][0]['bones']}
    decode_frame = decoder()
    poses = {'l': [], 'r': []}
    selected, errors = [], []
    # Movement/turns, held arms, reaching and damage cover more shoulder
    # directions than the three locomotion loops alone.
    files = ['cmn/base_cmn_move.motlist.524', 'cmn/base_cmn_hold.motlist.524',
             'hdg/base_hdg_move.motlist.524', 'hdg/base_hdg_hold.motlist.524',
             'cmn/base_cmn_damg.motlist.524']
    seen = set()
    for filename in files:
        path = SOURCE/filename
        if not path.exists():
            continue
        entries = list(motions(path.read_bytes()))
        common = next((skeleton(raw) for _, _, raw in entries if skeleton(raw)), [])
        # Spread selection over each file, with an upper bound for runtime lookup.
        stride = max(1, math.ceil(len(entries)/14))
        for address, name, raw in entries[::stride]:
            if name in seen:
                continue
            seen.add(name)
            bones = skeleton(raw) or common
            lookup = {b['name']: b for b in bones}
            required = [side+'_'+suffix for side in ['l','r'] for suffix in MAIN+HELPERS]
            if any(key not in lookup for key in required):
                errors.append({'clip': name, 'reason': 'incomplete shoulder skeleton'})
                continue
            try:
                clip = decode(raw, bones, decode_frame)
            except (ValueError, IndexError, struct.error) as error:
                errors.append({'clip': name, 'reason': str(error)})
                continue
            tracks = {(t['bone'], t['kind']): t for t in clip['tracks']}
            # Exclude additive/partial motions lacking actual arm rotations.
            if any((side+'_arm_humerus', 'rotation') not in tracks for side in ['l','r']):
                continue
            frame_step = max(8.0, clip['frames']/18)
            frame_count = 0
            for frame in np.arange(0, clip['frames'], frame_step):
                for side in ['l','r']:
                    features, helpers = [], []
                    for suffix in MAIN:
                        bone = lookup[side+'_'+suffix]
                        features.extend(sample(tracks.get((bone['name'], 'rotation')), frame, bone['restRotation']))
                    for suffix in HELPERS:
                        bone = lookup[side+'_'+suffix]
                        pos = sample(tracks.get((bone['name'], 'position')), frame, bone['restPosition'])
                        delta = [p-r for p,r in zip(pos, reference[bone['name']]['restPosition'])]
                        rot = sample(tracks.get((bone['name'], 'rotation')), frame, bone['restRotation'])
                        helpers.extend(delta+rot)
                    if not all(math.isfinite(x) for x in features+helpers):
                        raise ValueError('Nonfinite shoulder sample')
                    # Muscle corrections must stay near the joint, not carry
                    # source root movement or equipment translations.
                    if max(abs(x) for i,x in enumerate(helpers) if i%7 < 3) > .12:
                        continue
                    poses[side].append(features+helpers)
                frame_count += 1
            selected.append({'file': filename, 'fileSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                             'offset': address, 'clip': name, 'framesSampled': frame_count})
    # Deduplicate equivalent poses so long static holds do not bias blending.
    for side in poses:
        unique = {}
        for pose in poses[side]:
            key = tuple(round(x, 3) for x in pose[:16])
            unique.setdefault(key, pose)
        poses[side] = list(unique.values())
        if len(poses[side]) < 50:
            raise ValueError('Insufficient authored shoulder coverage')
    path = HERE/'carlos-shoulder-correctives.bin'
    with path.open('wb') as stream:
        stream.write(b'JSC1')
        stream.write(struct.pack('<ii', len(MAIN), len(HELPERS)))
        for side in ['l','r']:
            stream.write(struct.pack('<i', len(poses[side])))
            for pose in poses[side]:
                stream.write(struct.pack('<100f', *pose))
    report = {'format': 'JSC1', 'date': '08/10/2026', 'mainBones': MAIN, 'helperBones': HELPERS,
              'samples': {side: len(samples) for side,samples in poses.items()},
              'rawCoordinateSystem': 'RE_local; reflection applied by runtime',
              'helperPositions': 'delta from original locomotion reference; scaled by runtime motion ratio',
              'binaryBytes': path.stat().st_size, 'binarySha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'clips': selected, 'skipped': errors, 'visualRuntimeVerified': False}
    (HERE/'carlos-shoulder-correctives.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['samples','binaryBytes','binarySha256']},indent=2))


if __name__ == '__main__':
    main()
