"""Read local Noesis FBX hierarchy/rest transforms without importing a DCC."""
import json
import re
import struct
import zlib
from pathlib import Path


def read_fbx(path):
    data = path.read_bytes()
    version = struct.unpack_from('<I', data, 23)[0]
    assert version >= 7500

    def prop(pos):
        kind = chr(data[pos]); pos += 1
        formats = {'Y': 'h', 'C': '?', 'I': 'i', 'F': 'f', 'D': 'd', 'L': 'q'}
        if kind in formats:
            fmt = '<' + formats[kind]
            return struct.unpack_from(fmt, data, pos)[0], pos + struct.calcsize(fmt)
        if kind in ('S', 'R'):
            size = struct.unpack_from('<I', data, pos)[0]; pos += 4
            value = data[pos:pos + size]
            return value.decode('utf8', errors='replace') if kind == 'S' else value, pos + size
        if kind in 'fdlibc':
            count, encoding, size = struct.unpack_from('<III', data, pos); pos += 12
            value = data[pos:pos + size]
            if encoding: value = zlib.decompress(value)
            fmt = {'f': 'f', 'd': 'd', 'l': 'q', 'i': 'i', 'b': 'b', 'c': '?'}[kind]
            return struct.unpack('<' + str(count) + fmt, value), pos + size
        raise ValueError(kind)

    def node(pos):
        end, count, size, namesize = struct.unpack_from('<QQQB', data, pos)
        if end == 0: return None, pos + 25
        pos += 25
        name = data[pos:pos + namesize].decode(); pos += namesize
        props = []
        for _ in range(count):
            value, pos = prop(pos); props.append(value)
        children = []
        while pos < end - 25:
            child, pos = node(pos)
            if child is None: break
            children.append(child)
        return (name, props, children), end

    nodes = []; pos = 27
    while pos < len(data):
        item, pos = node(pos)
        if item is None: break
        nodes.append(item)
    return nodes


def inventory():
    models = {}; result = {}
    for part in ('pl0000', 'pl0001', 'pl0005'):
        nodes = read_fbx(Path(__file__).parent / (part + '.fbx'))
        objects = next(n for n in nodes if n[0] == 'Objects')[2]
        connections = next(n for n in nodes if n[0] == 'Connections')[2]
        bones = {n[1][0]: n for n in objects if n[0] == 'Model' and n[1][2] in ('Root', 'Limb', 'LimbNode')}
        parents = {n[1][1]: n[1][2] for n in connections if n[1][0] == 'OO' and n[1][1] in bones and n[1][2] in bones}
        records = []
        for ident, bone in bones.items():
            name = re.sub(r'^b\d+:', '', bone[1][1].split('\x00')[0])
            props = next((n[2] for n in bone[2] if n[0] == 'Properties70'), [])
            transform = {n[1][0]: n[1][4:] for n in props if n[1][0].startswith('Lcl ')}
            parent = bones.get(parents.get(ident))
            pname = re.sub(r'^b\d+:', '', parent[1][1].split('\x00')[0]) if parent else None
            records.append({'name': name, 'parent': pname, **transform})
        models[part] = {r['name']: r for r in records}
        result[part] = records
    Path(__file__).with_name('rig-source-inventory.json').write_text(json.dumps(result, indent=2))
    for part, records in models.items():
        shared = set(records) & set(models['pl0000'])
        print(part, 'bones', len(records), 'body-shared', len(shared), 'unique', len(set(records) - shared))
        for name in ('root', 'COG', 'hips', 'spine_0', 'spine_1', 'spine_2', 'neck_0', 'neck_1', 'head'):
            if name in records: print(name, records[name])


if __name__ == '__main__': inventory()
