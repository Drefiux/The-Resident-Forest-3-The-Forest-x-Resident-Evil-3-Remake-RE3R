"""Convert selected local RE3 motions into raw local-transform tracks.

The packed frame decoder is read from alphaZomega's installed Noesis plugin;
only its scalar/vector decoding helpers run, without Noesis or GUI imports.
"""
import ast
import hashlib
import json
import math
import struct
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / 'work/r3/natives/stm/escape/character/player/pl0000/animation/list'
PLUGIN = ROOT / 'work/tools/Noesis_REEnginePlugin/fmt_RE_MESH.py'


class Vec(tuple):
    def __mul__(self, other):
        return Vec(x * (other[i] if isinstance(other, tuple) else other) for i, x in enumerate(self))
    def __truediv__(self, other):
        return Vec(x / other for x in self)


class Quat(Vec):
    def transpose(self):
        return Quat((-self[0], -self[1], -self[2], self[3]))


class Quat3(Vec):
    def toQuat(self):
        return Quat((*self, math.sqrt(max(0.0, 1.0 - sum(x*x for x in self)))))


class Stream:
    def __init__(self, data):
        self.data, self.pos = data, 0
    def seek(self, offset, mode=0):
        self.pos = offset + (self.pos if mode == 1 else 0)
    def read(self, fmt):
        value = struct.unpack_from('<' + fmt, self.data, self.pos)[0]
        self.pos += struct.calcsize(fmt)
        return value
    def readFloat(self): return self.read('f')
    def readUInt(self): return self.read('I')
    def readUInt64(self): return self.read('Q')
    def readUByte(self): return self.read('B')
    def readUShort(self): return self.read('H')


def decoder():
    tree = ast.parse(PLUGIN.read_text(encoding='utf-8-sig'))
    names = {'readPackedBitsVec3', 'convertBits', 'readBytesAsBigEndian', 'readBytesAsBigEndian32'}
    body = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    mot_class = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'motFile')
    method = next(node for node in mot_class.body if isinstance(node, ast.FunctionDef) and node.name == 'readFrame')
    method.name = 'decodeFrame'
    # Fail on unsupported compression, rather than emitting silent zero tracks.
    for node in ast.walk(method):
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'print':
            node.value = ast.Call(func=ast.Name(id='unsupported', ctx=ast.Load()), args=node.value.args, keywords=[])
    body.append(method)
    def unsupported(*args): raise ValueError(' '.join(map(str, args)))
    env = {'math': math, 'NoeVec3': Vec, 'NoeQuat': Quat, 'NoeQuat3': Quat3,
           'fDefaultMeshScale': 1.0, 'unsupported': unsupported}
    exec(compile(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[])), str(PLUGIN), 'exec'), env)
    return env['decodeFrame']


def ustring(data, offset):
    end = offset
    while data[end:end+2] != b'\0\0': end += 2
    return data[offset:end].decode('utf-16le')


def motions(data):
    table = struct.unpack_from('<Q', data, 16)[0]
    count = struct.unpack_from('<I', data, 48)[0]
    for i in range(count):
        address = struct.unpack_from('<Q', data, table + 8*i)[0]
        if not address or data[address+4:address+8] != b'mot ': continue
        raw = data[address:]
        name = ustring(raw, struct.unpack_from('<Q', raw, 88)[0])
        yield address, name, raw


def skeleton(raw):
    pointer = struct.unpack_from('<Q', raw, 16)[0]
    if not pointer: return []
    start, count = struct.unpack_from('<QQ', raw, pointer)
    expected = struct.unpack_from('<H', raw, 112)[0]
    if count != expected or start == 0 or start + count*80 > len(raw): return []
    result = []
    for i in range(count):
        address = start + 80*i
        name_off, parent_off = struct.unpack_from('<QQ', raw, address)
        pos = struct.unpack_from('<4f', raw, address+32)
        quat = struct.unpack_from('<4f', raw, address+48)
        index, bone_hash = struct.unpack_from('<II', raw, address+64)
        result.append({'name': ustring(raw, name_off), 'parent': (parent_off-start)//80 if parent_off else -1,
                       'restPosition': list(pos[:3]), 'restRotation': list(quat), 'hash': bone_hash, 'index': index})
    return result


def decode(raw, bones, frame_decoder):
    version = struct.unpack_from('<I', raw)[0]
    header = struct.unpack_from('<Q', raw, 24)[0]
    frames = struct.unpack_from('<f', raw, 96)[0]
    count = struct.unpack_from('<H', raw, 114)[0]
    bone_by_hash = {bone['hash']: bone for bone in bones}
    obj = SimpleNamespace(bs=Stream(raw), version=version, motlist=SimpleNamespace(version=524))
    tracks, codecs = [], set()
    for index in range(count):
        bone_index, track_flags, bone_hash, track_address = struct.unpack_from('<HHII', raw, header + index*12)
        bone = bone_by_hash.get(bone_hash)
        if bone is None: raise ValueError('Unknown bone hash ' + str(bone_hash))
        cursor = track_address
        for axis, bit in [('position', 1), ('rotation', 2), ('scale', 4)]:
            if not track_flags & bit: continue
            flags, keys, indices, values, unpack = struct.unpack_from('<5I', raw, cursor)
            cursor += 20
            if not 0 < keys < 100000: raise ValueError('Invalid key count')
            index_kind = 'I' if flags >> 20 == 5 else ('B' if flags >> 20 == 2 else 'H')
            size = struct.calcsize(index_kind)
            times = [struct.unpack_from('<'+index_kind, raw, indices+k*size)[0] if indices else 0 for k in range(keys)]
            floats = struct.unpack_from('<8f', raw, unpack) if unpack else (0.0,)*8
            unpacks = SimpleNamespace(max=SimpleNamespace(**dict(zip('xyzw', floats[:4]))), min=SimpleNamespace(**dict(zip('xyzw', floats[4:]))))
            obj.bs.seek(values)
            decoded = []
            for k in range(keys):
                value = frame_decoder(obj, {'position': 'pos', 'rotation': 'rot', 'scale': 'scl'}[axis], flags, unpacks)
                # Noesis uses conjugated quaternions internally. Store the original
                # RE local rotation; Unity coordinate conversion happens at binding.
                if axis == 'rotation': value = value.transpose()
                value = list(value)
                if not all(math.isfinite(x) for x in value): raise ValueError('Nonfinite track')
                decoded.extend([times[k], *value])
            codecs.add(hex(flags & 0xFF000))
            tracks.append({'bone': bone['name'], 'kind': axis, 'values': decoded})
    return {'frames': frames, 'fps': 60.0, 'tracks': tracks, 'compressionTypes': sorted(codecs)}


def main():
    frame_decoder = decoder()
    path = SOURCE / 'cmn/base_cmn_move.motlist.524'
    data = path.read_bytes()
    # RE3 Carlos repeats a table pointer to the same idle clip. Deduplicate
    # addresses, never pick between distinct clips with the same name.
    entries = list({address: (address, name, raw) for address, name, raw in motions(data)}.values())
    print('Available base movement clips:', len(entries))
    common_bones = next((skeleton(raw) for _, _, raw in entries if skeleton(raw)), [])
    if not common_bones: raise ValueError('No motion rest skeleton')
    selected = {'idle': 'pl0000_0160_KFF_Gazing_Idle_F_Loop', 'walk': 'pl0000_0190_KFF_GazingWalk_F_Loop',
                'run': 'pl0000_0231_KFF_Jog_Straight_Loop'}
    clips = []
    for mode, name in selected.items():
        matches = [(address, source_name, raw) for address, source_name, raw in entries if source_name == name]
        if not matches and mode == 'run':
            matches = [(address, source_name, raw) for address, source_name, raw in entries if 'Jog' in source_name and 'F_Loop' in source_name]
        if len(matches) != 1: raise ValueError('Cannot select '+mode+': '+str([name for _, name, _ in matches]))
        address, name, raw = matches[0]
        bones = skeleton(raw) or common_bones
        result = decode(raw, bones, frame_decoder)
        result.update(mode=mode, name=name, bones=bones, sourceOffset=address, source=str(path))
        clips.append(result)
        print(mode, name, 'frames', result['frames'], 'tracks', len(result['tracks']), 'codecs', result['compressionTypes'])
    output = {'schemaVersion': 1, 'coordinateSystem': 'raw_RE_local', 'fpsAssumption': '60fps base motion ticks, header frameRate is zero; visual cadence check pending',
              'pluginSha256': hashlib.sha256(PLUGIN.read_bytes()).hexdigest(), 'sourceSha256': hashlib.sha256(data).hexdigest(), 'clips': clips}
    destination = Path(__file__).with_name('carlos-motion-preview.json')
    destination.write_text(json.dumps(output, separators=(',', ':'))+'\n', encoding='utf-8')
    from pack_motion_preview import write_binary
    write_binary(output, destination.with_suffix('.bin'))
    print('Wrote', destination, destination.stat().st_size)


if __name__ == '__main__': main()
