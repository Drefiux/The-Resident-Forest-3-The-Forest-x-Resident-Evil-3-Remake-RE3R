"""Record the completed Unity asset build and own Carlos data provenance."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
PIPE=ROOT/'outputs/forest-re3-mashup/unity-pipeline'
report=json.loads((PIPE/'carlos-rig-report.json').read_text(encoding='utf-8'))
log=(PIPE/'carlos-unified-build.log').read_text(encoding='utf-8')
if 'BUILD_COMPLETE' not in log or report['stage']!='unified-carlos-rig-lighting' or not report['allRenderersUseSingleSkeleton']:
    raise RuntimeError('Carlos Unity build incomplete')
def artifact(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
receipt=dict(date='08/10/2026',stage=report['stage'],unity='5.6.5p4',character='Carlos',
    rigReport=report,bundles={space:artifact(PIPE/'Assets/AssetBundles'/('forest-re3-carlos-'+space)) for space in ['gamma','linear']},
    data={name:artifact(Path(__file__).with_name('carlos-'+name+'.bin')) for name in ['motion-preview','shoulder-correctives','voice-bank']},
    gameplayVerified=False)
(PIPE/'carlos-complete-build.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['stage','bundles']},indent=2))
