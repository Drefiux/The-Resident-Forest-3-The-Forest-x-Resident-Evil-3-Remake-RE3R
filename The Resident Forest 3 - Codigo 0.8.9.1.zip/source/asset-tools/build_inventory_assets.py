"""Read the local RE3 RT item locker directly; no Noesis GUI dependency.

MESH 21041600 layout follows alphaZomega's fmt_RE_MESH.py (setOffsets v2).
The closed locker is a static prop: retain LOD0 positions, normals, UVs and
material partitions. Its rest mesh does not require character retargeting.
"""
from pathlib import Path
import struct, json, importlib.util, hashlib

ROOT = Path(__file__).resolve().parents[3]
PROJECT = ROOT / 'outputs/forest-re3-mashup/unity-pipeline'
SOURCE = ROOT / 'work/r3/natives/stm'
DEST = PROJECT / 'Assets/LocalAssets/Re3Inventory'
REL = 'Assets/LocalAssets/Re3Inventory/'

def read_mesh(path):
    data = path.read_bytes()
    def u(fmt, at): return struct.unpack_from('<'+fmt, data, at)
    def q(at): return u('Q',at)[0]
    if data[:4] != b'MESH' or u('I',4)[0] != 21041600: raise ValueError('Unexpected MESH version')
    lod, vb, names, indices = q(24), q(80), q(120), q(96)
    counts = u('16B',lod)
    name_list = [data[q(names+8*i):].split(b'\0',1)[0].decode() for i in range(u('I',18)[0])]
    mat_names = [name_list[u('H',indices+2*i)[0]] for i in range(counts[1])]
    elements, vertices, faces = q(vb), q(vb+8), q(vb+16)
    ec = u('H',vb+42)[0]
    desc = {u('H',elements+8*i)[0]:u('HI',elements+8*i+2) for i in range(ec)}
    pos_stride,pos_offset = desc[0]
    n_stride,n_offset = desc[1]
    uv_stride,uv_offset = desc[2]
    level = q(lod+64)
    group_count = u('B',level)[0]
    group_list = q(level+8)
    parts = []
    for gi in range(group_count):
        group = q(group_list+8*gi)
        _, sub_count, _, _, vertex_count, _ = u('BBHIII',group)
        subs = [u('HHIIIQ',group+16+24*i) for i in range(sub_count)]
        for mi,sub in enumerate(subs):
            mat,_,face_count,face_start,vertex_start,_ = sub
            face = list(u(('I' if counts[6] else 'H')*face_count,faces+face_start*(4 if counts[6] else 2)))
            count = max(face)+1
            positions=[]; normals=[]; uv=[]
            for vi in range(vertex_start, vertex_start+count):
                x,y,z = u('fff',vertices+pos_offset+vi*pos_stride)
                nx,ny,nz = u('bbb',vertices+n_offset+vi*n_stride)
                s,t = u('ee',vertices+uv_offset+vi*uv_stride)
                positions.extend((-x,y,z)); normals.extend((-nx/127,ny/127,nz/127)); uv.extend((s,1-t))
            # RE uses right handed positions; mirror X and reverse the winding.
            for i in range(0,len(face),3): face[i+1],face[i+2]=face[i+2],face[i+1]
            parts.append(dict(name=f'Locker_{gi}_{mi}',material=mat_names[mat],positions=positions,normals=normals,uv=uv,triangles=face))
    return dict(parts=parts)

def main():
    DEST.mkdir(parents=True,exist_ok=True)
    spec=importlib.util.spec_from_file_location('re_assets',PROJECT/'prepare_carlos_assets.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    class Assets(module.PreviewAssets):
        def save(self,key,image): return super().save(key,image).replace('CarlosCorrected','Re3Inventory')
    base=SOURCE/'objectroot/setmodel/sm4x_gimmick/sm41/sm41_011_itemlocker01a'
    mesh_path=base/'sm41_011_itemlocker01a_01md.mesh.2109108288'
    mesh=read_mesh(mesh_path)
    (DEST/'locker-mesh.json').write_text(json.dumps(mesh,separators=(',',':')))
    assets=Assets(SOURCE,DEST,1024)
    mats=[assets.material('Locker',m) for m in module.read_mdf(base/'sm41_011_itemlocker01a_00ms_mat.mdf2.21')]
    manifest=dict(materials=mats,sourceMesh=str(mesh_path),sourceSha256=hashlib.sha256(mesh_path.read_bytes()).hexdigest(),submeshes=len(mesh['parts']))
    (DEST/'inventory-manifest.json').write_text(json.dumps(manifest,indent=2))
    atlas=SOURCE/'escape/ui/ui3000/tex/ui3000_iam.tex.34'
    if atlas.exists():
        im,_=module.read_tex(atlas); im.save(DEST/'inventory-original-atlas.png')
    print(json.dumps(dict(submeshes=len(mesh['parts']),vertices=sum(len(x['positions'])//3 for x in mesh['parts']),materials=[m['name'] for m in mats])))

if __name__=='__main__': main()
