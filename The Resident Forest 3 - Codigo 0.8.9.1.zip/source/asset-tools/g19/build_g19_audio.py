from pathlib import Path
import re,struct,xml.etree.ElementTree as E,subprocess,wave,json
import numpy as np
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
def fnv(s):
    n=2166136261
    for c in s.lower().encode():n=((n*16777619)&0xffffffff)^c
    return n
wid=(ROOT/'work/r3/natives/stm/escape/sound/wwise/wwiseids.wid.2').read_bytes()
names={fnv(s.decode()):s.decode() for s in re.findall(rb'[A-Za-z][A-Za-z0-9_]{5,100}',wid)}
xml=E.fromstring('<all>'+re.sub(r'<\?xml[^>]+\?>','',(HERE/'g19-audio.xml').read_text())+'</all>')
def fields(n,k):return [f for f in n.iter('field') if f.get('name')==k]
objects={int(f.get('value')):n for n in xml.iter('object') for f in n.findall('field') if f.get('name')=='ulID'}
media={int(fields(n,'id')[0].get('value')):int(n.get('index'))+1 for n in xml.iter('object') if n.get('name')=='MediaHeader'}
children={}
for i,n in objects.items():
    for f in fields(n,'DirectParentID'):children.setdefault(int(f.get('value')),[]).append(i)
def sources(i,seen=None):
    seen=set() if seen is None else seen
    if i in seen:return []
    seen.add(i);n=objects.get(i)
    if n is None:return []
    if n.get('name')=='CAkSound':return [(i,int(f.get('value'))) for f in fields(n,'sourceID')]
    return [s for child in children.get(i,[]) for s in sources(child,seen)]
records=[]

def volume_db(node):
    # Retain the authored relative levels of shot/body/tail layers instead
    # of summing every Wwise layer at unity gain. Bus/master gain is supplied
    # by The Forest's audio listener; only this event's node ancestry applies.
    gain=0.0;seen=set()
    while node in objects and node not in seen:
        seen.add(node);obj=objects[node]
        for prop in obj.iter('object'):
            if prop.get('name')!='AkPropBundle':continue
            ids=prop.findall("field[@name='pID']");values=prop.findall("field[@name='pValue']")
            if ids and values and ids[0].get('value')=='0':gain+=float(values[0].get('value'))
        parents=fields(obj,'DirectParentID')
        if not parents:break
        node=int(parents[0].get('value'))
    return gain
def audible(i):
    n=objects.get(i)
    if n is None:return []
    kind=n.get('name')
    if kind=='CAkSound':return [(i,int(f.get('value')))for f in fields(n,'sourceID')]
    choices=children.get(i,[])
    if kind=='CAkSwitchCntr':
        group=int(fields(n,'ulGroupID')[0].get('value'))
        switch=fnv('wp0000')if names.get(group)=='WP_LOCAL_MESH_TYPE' else int(fields(n,'ulDefaultSwitch')[0].get('value'))
        packages=[p for p in n.iter('object')if p.get('name')=='CAkSwitchPackage'and any(int(f.get('value'))==switch for f in fields(p,'ulSwitchID'))]
        choices=[int(f.get('value'))for p in packages for f in fields(p,'NodeID')]
    elif kind=='CAkRanSeqCntr':choices=choices[:1]
    return [s for child in choices for s in audible(child)]
for category,event in enumerate(('Play_wp0000_se_shot','Play_wp0000_se_pull_reload','Play_wp0000_se_set_reload')):
    n=objects[fnv(event)];found=[]
    for f in fields(n,'ulActionID'):
        action=objects[int(f.get('value'))]
        for target in fields(action,'idExt'):found+=audible(int(target.get('value')))
    found=[p for p in found if p[1] in media and 'suppressor' not in names.get(p[0],'')]
    found.sort(key=lambda p:('shot_01' not in names.get(p[0],''),p[0]))
    layers=[]
    for index,(node,source)in enumerate(found):
        wav=HERE/('g19-layer-%s-%s.wav'%(category,index))
        subprocess.run([str(ROOT/'work/tools/jill-audio/vgmstream/vgmstream-cli.exe'),'-s',str(media[source]),'-o',str(wav),str(HERE/'wp0000_media.bnk')],check=True,capture_output=True)
        with wave.open(str(wav),'rb')as w:
            assert w.getsampwidth()==2 and w.getframerate()==48000
            layers.append(np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,w.getnchannels()).mean(axis=1).astype(float)*10**(volume_db(node)/20))
    frames=max(map(len,layers));mix=np.zeros(frames)
    for layer in layers:mix[:len(layer)]+=layer
    mix*=30000/max(1,np.max(np.abs(mix)));pcm=np.clip(mix,-32768,32767).astype('<i2').tobytes();channels=1;rate=48000
    wav=HERE/('g19-sfx-'+str(category)+'.wav')
    with wave.open(str(wav),'wb')as w:w.setnchannels(channels);w.setsampwidth(2);w.setframerate(rate);w.writeframes(pcm)
    records.append(dict(category=category,event=event,layers=found,authoredLayers=[dict(node=node,media=source,name=names.get(node,''),volumeDb=volume_db(node))for node,source in found],channels=channels,rate=rate,frames=frames,pcm=pcm))
with (HERE/'g19-sounds.bin').open('wb') as out:
    out.write(b'GSV1');out.write(struct.pack('<i',len(records)))
    for r in records:out.write(struct.pack('<Biii',r['category'],r['channels'],r['rate'],r['frames']));out.write(r['pcm'])
(HERE/'g19-sounds-manifest.json').write_text(json.dumps([{k:v for k,v in r.items() if k!='pcm'} for r in records],indent=2))
print((HERE/'g19-sounds-manifest.json').read_text())
