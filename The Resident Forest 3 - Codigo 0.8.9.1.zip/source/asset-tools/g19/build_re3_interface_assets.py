"""Import original local RE3 interface textures and decrypt its OpenType fonts.

Font cipher follows work/tools/REE.PAK.Tool/REE.Fonts.Cryptor/FontCipher.cs.
No replacement artwork or operating-system fonts are generated.
"""
from pathlib import Path
import importlib.util, hashlib, json, struct
ROOT=Path(__file__).resolve().parents[3]
PROJECT=ROOT/'outputs/forest-re3-mashup/unity-pipeline'
SOURCE=ROOT/'work/r3/natives/stm/escape/ui'
DEST=PROJECT/'Assets/LocalAssets/Re3Interface'
DEST.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('assets',PROJECT/'prepare_carlos_assets.py')
assets=importlib.util.module_from_spec(spec);spec.loader.exec_module(assets)
records=[]
for relative,target in [('ui3000/tex/ui3000_iam.tex.34','inventory-atlas.png'),('ui3000/tex/ui3003_iam.tex.34','inventory-gradients.png'),('ui2000/tex/ui2012_iam.tex.34','ammo-atlas.png'),('ui2000/tex/ui2000_iam.tex.34','reticle-atlas.png')]:
    source=SOURCE/relative;image,_=assets.read_tex(source);image.save(DEST/target)
    records.append(dict(source=str(source.relative_to(ROOT)),target=target,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
for original,target in [('neuehelveticapro-69cmmd.oft.1.stm','RE3Interface.otf'),('ocratributepro-regular.oft.1.stm','RE3Ammo.otf')]:
    source=SOURCE/'ui0000/font'/original;raw=source.read_bytes()
    if raw[:4]!=b'FBFO':raise ValueError('Unexpected encrypted font header')
    data=raw[4:];size=len(data)&63;seed=(1<<(size+1))-1;delta=0xAE6E39B58A355F45
    key=((delta>>size)|((seed&delta)<<((64-size)&63)))&0xffffffffffffffff
    mask=struct.pack('<Q',key);plain=bytes(b^mask[i%8] for i,b in enumerate(data))
    if plain[:4] not in (b'OTTO',b'ttcf',b'\0\1\0\0'):raise ValueError('Unexpected decoded OpenType header')
    (DEST/target).write_bytes(plain)
    records.append(dict(source=str(source.relative_to(ROOT)),target=target,sha256=hashlib.sha256(raw).hexdigest(),decodedSha256=hashlib.sha256(plain).hexdigest()))
(DEST/'interface-manifest.json').write_text(json.dumps(dict(source='Original RE3R local files',assets=records),indent=2)+'\n')
print(json.dumps(records,indent=2))
