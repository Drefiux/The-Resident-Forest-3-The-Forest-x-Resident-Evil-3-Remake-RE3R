from pathlib import Path
import importlib.util,json,struct
ROOT=Path(__file__).resolve().parents[3]; HERE=Path(__file__).resolve().parent
PROJECT=ROOT/'outputs/forest-re3-mashup/unity-pipeline'; SOURCE=ROOT/'work/r3/natives/stm'; DEST=PROJECT/'Assets/LocalAssets/Re3G19'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
reader=module('motion_reader',ROOT/'work/jill/corrected/decode_motion_preview.py')
packer=module('packer',ROOT/'work/jill/corrected/pack_motion_preview.py')
mesh=module('mesh',ROOT/'work/forest-re3-mashup/research-inventory/build_inventory_assets.py')
assets=module('assets',PROJECT/'prepare_carlos_assets.py')
DEST.mkdir(parents=True,exist_ok=True)
base=SOURCE/'escape/character/weapon/wp0000/mesh'
geometry=mesh.read_mesh(base/'wp0000_g19.mesh.2109108288')
class Assets(assets.PreviewAssets):
    def save(self,key,image):return super().save(key,image).replace('CarlosCorrected','Re3G19')
converter=Assets(SOURCE,DEST,1024)
mats=[converter.material('G19',m) for m in assets.read_mdf(base/'wp0000_g19.mdf2.21')]
geometry['parts']=[p for p in geometry['parts'] if not any(n in p['material'].lower() for n in ('suppressor','sight','glass'))]
for i,p in enumerate(geometry['parts']):p['name']='G19_'+str(i)
# Groups 4/8 are the optional extended magazine and its rounds. Keep the
# original 15-round magazine (group 1) and its visible cartridge stack.
geometry['parts']=[p for p in geometry['parts'] if p['name'] not in ('G19_2','G19_4')]
geometry['parts'][1]['name']='Magazine_G19_1'
(DEST/'g19-mesh.json').write_text(json.dumps(geometry,separators=(',',':')))
(DEST/'g19-manifest.json').write_text(json.dumps(dict(materials=mats),indent=2))
decode=reader.decoder(); clips=[]; manifest=[]
for character in ('pl2000','pl0000'):
    folder=SOURCE/f'escape/character/player/{character}/animation/list/hdg'
    files=['base_hdg_hold.motlist.524','hdg_hold_01.motlist.524','base_hdg_finger.motlist.524','hdg_finger_01.motlist.524']
    entries=[]
    for name in files:
        path=folder/name
        if path.exists():entries.extend((path,*e) for e in reader.motions(path.read_bytes()))
    bone_map={b['hash']:b for _,_,_,raw in entries for b in reader.skeleton(raw)}
    # Auxiliary finger/prop banks can omit their skeleton and inherit it from cmn.
    for f in (folder.parent/'cmn').glob('base_*.motlist.524'):
        for _,_,raw in reader.motions(f.read_bytes()):
            for b in reader.skeleton(raw):bone_map.setdefault(b['hash'],b)
    bones=list(bone_map.values())
    names=[('hold','0160_HG_Hold_Idle_Loop'),('aim','0210_HG_Focus_Loop'),('shoot','1100_HG_Hold_Shoot'),('aimshoot','0220_HG_Focus_Shoot'),('reload','1200_HG_Hold_Reload'),('ready','0140_HG_Hold_Start_L0'),('grip','50_Hold_HG01')]
    for mode,suffix in names:
        found=[e for e in entries if e[2]==character+'_'+suffix]
        if mode=='grip':found.sort(key=lambda e:'finger' not in e[0].name)
        path,offset,name,raw=found[0]; own=list(bones)
        local={b['hash']:b for b in reader.skeleton(raw)}
        own=[local.get(b['hash'],b) for b in own]
        clip=reader.decode(raw,own,decode);clip.update(mode=character+'_'+mode,bones=own,name=name)
        clips.append(clip); manifest.append(dict(mode=clip['mode'],name=name,source=str(path.relative_to(ROOT)),offset=offset,frames=clip['frames'],fps=clip['fps'],tracks=len(clip['tracks'])))
packer.write_binary(dict(clips=clips),HERE/'g19-motions.bin')
(HERE/'g19-motion-review.json').write_text(json.dumps(dict(clips=clips),separators=(',',':')))
(HERE/'g19-motion-manifest.json').write_text(json.dumps(manifest,indent=2))
atlas,_=assets.read_tex(SOURCE/'escape/ui/ui3000/tex/ui3000_iam.tex.34')
atlas.save(DEST/'inventory-original-atlas.png')
# Authored UI atlas rectangles, retained directly from RE3R's ui3000 atlas.
print('ATLAS',atlas.size)
print('MESH',json.dumps([(p['material'],len(p['positions'])//3) for p in geometry['parts']]))
print('CLIPS',json.dumps(manifest))
