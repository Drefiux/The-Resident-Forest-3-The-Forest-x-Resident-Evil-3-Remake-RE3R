param([string]$Python = 'python', [string]$Unity = 'C:\Program Files\Unity\Editor\Unity.exe')
$ErrorActionPreference='Stop'
$taskWorkspace=(Resolve-Path (Join-Path $PSScriptRoot '..\..\..')).Path
$taskCarlos=Join-Path $taskWorkspace 'work\carlos\corrected'
$taskSource=Join-Path $taskWorkspace 'work\r3\natives\stm\escape\character\player\pl0000'
$taskNoesis=Join-Path $taskWorkspace 'work\tools\Noesis-4.474\Noesis64.exe'
New-Item -ItemType Directory -Force -Path $taskCarlos | Out-Null
foreach ($taskPart in @(@('pl0000','mesh'),@('pl0001','pl0001\mesh'),@('pl0005','pl0005\mesh'))) {
    $taskInput=Join-Path $taskSource ($taskPart[1]+'\'+$taskPart[0]+'.mesh.2109108288')
    $taskOutput=Join-Path $taskCarlos ($taskPart[0]+'.fbx')
    $taskProcess=Start-Process -FilePath $taskNoesis -ArgumentList @('?cmode',('"'+$taskInput+'"'),('"'+$taskOutput+'"'),'-noprompt','-b','-notex','-noanims') -WindowStyle Hidden -PassThru -Wait
    if ($taskProcess.ExitCode -ne 0 -or !(Test-Path -LiteralPath $taskOutput)) { throw 'Noesis no exporto Carlos.' }
}
& $Python (Join-Path $PSScriptRoot 'prepare_carlos_assets.py') --source-root (Join-Path $taskWorkspace 'work\r3\natives\stm') --exports $taskCarlos --destination (Join-Path $PSScriptRoot 'Assets\LocalAssets\CarlosCorrected')
if ($LASTEXITCODE -ne 0) { throw 'Fallo la preparacion de materiales de Carlos.' }
foreach ($taskScript in @('decode_motion_preview.py','build_shoulder_samples.py','prepare_voice_names.py')) {
    & $Python (Join-Path $taskCarlos $taskScript)
    if ($LASTEXITCODE -ne 0) { throw ('Fallo '+$taskScript) }
}
Push-Location (Join-Path $taskCarlos 'voices')
try {
    & $Python (Join-Path $taskWorkspace 'work\tools\jill-audio\wwiser.pyz') -d xml -dn effort carlos-effort-en.bnk
    if ($LASTEXITCODE -ne 0) { throw 'Fallo la lectura del banco Carlos.' }
} finally { Pop-Location }
& $Python (Join-Path $taskCarlos 'build_voice_bank.py')
if ($LASTEXITCODE -ne 0) { throw 'Fallo la conversion de voces Carlos.' }
$taskProcess=Start-Process -FilePath $Unity -ArgumentList @('-batchmode','-quit','-projectPath',('"'+$PSScriptRoot+'"'),'-executeMethod','BuildForestRe3CarlosBundle.BuildAll','-logFile',('"'+(Join-Path $PSScriptRoot 'carlos-unified-build.log')+'"')) -WindowStyle Hidden -PassThru -Wait
if ($taskProcess.ExitCode -ne 0) { throw 'Fallo Unity Carlos.' }
& $Python (Join-Path $taskCarlos 'record_carlos_build.py')
if ($LASTEXITCODE -ne 0) { throw 'La construccion de Carlos esta incompleta.' }
