"""Prepare a local static Carlos preview from three Noesis FBX exports and RE3 RT TEX/MDF.

Only MDF2 version 21 and single-image TEX version 34 are supported. No extraction,
game installation changes, or network access are performed. Pillow is required.
This translates the base material layers; RE Engine skin/eye/hair effects and
dynamic injury/wetness layers still require their own runtime implementation.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import shutil
import struct

from PIL import Image


PARTS = {
    "pl0000": "escape/character/player/pl0000/mesh/pl0000.mdf2.21",
    "pl0001": "escape/character/player/pl0000/pl0001/mesh/pl0001.mdf2.21",
    "pl0005": "escape/character/player/pl0000/pl0005/mesh/pl0005.mdf2.21",
}


def unpack(data: bytes, fmt: str, offset: int):
    if offset < 0 or offset + struct.calcsize(fmt) > len(data):
        raise ValueError(f"Binary field outside file: {offset}, {fmt}")
    return struct.unpack_from(fmt, data, offset)


def utf16(data: bytes, offset: int) -> str:
    if offset < 0 or offset >= len(data) or offset % 2:
        raise ValueError(f"Invalid UTF-16 string offset: {offset}")
    end = offset
    while end + 2 <= len(data):
        if data[end:end + 2] == b"\0\0":
            return data[offset:end].decode("utf-16-le")
        end += 2
    raise ValueError("Unterminated MDF string")


def read_mdf(path: Path) -> list[dict]:
    if not path.name.endswith(".mdf2.21"):
        raise ValueError("Only MDF2 version 21 is supported")
    data = path.read_bytes()
    if data[:4] != b"MDF\0":
        raise ValueError(f"Invalid MDF magic: {path}")
    count, = unpack(data, "<H", 6)
    if not 1 <= count <= 1024:
        raise ValueError("Invalid MDF material count")
    materials = []
    for i in range(count):
        entry = 16 + i * 80
        name_offset, = unpack(data, "<Q", entry)
        param_count, tex_count = unpack(data, "<II", entry + 16)
        param_table, tex_table, _, param_data, shader_offset = unpack(data, "<5Q", entry + 40)
        if param_count > 4096 or tex_count > 4096:
            raise ValueError("Invalid MDF table count")
        textures = {}
        for j in range(tex_count):
            type_offset, _, _, path_offset = unpack(data, "<QIIQ", tex_table + j * 32)
            textures[utf16(data, type_offset)] = utf16(data, path_offset).replace("@", "")
        params = {}
        for j in range(param_count):
            off = param_table + j * 24
            name_off, _, _, relative, size, _ = unpack(data, "<QIIiHH", off)
            if size > 64:
                raise ValueError("Unexpected MDF parameter length")
            params[utf16(data, name_off)] = list(unpack(data, "<" + "f" * size, param_data + relative))
        materials.append({"name": utf16(data, name_offset), "shader": utf16(data, shader_offset), "textures": textures, "params": params})
    return materials


def read_tex(path: Path) -> tuple[Image.Image, dict]:
    data = path.read_bytes()
    if data[:4] != b"TEX\0":
        raise ValueError(f"Invalid TEX magic: {path}")
    version, width, height, depth, images, table_size, fmt = unpack(data, "<IHHHBBI", 4)
    if version != 34 or depth != 1 or images != 1 or table_size < 16 or table_size % 16:
        raise ValueError(f"Unsupported TEX layout: {path}")
    if not 1 <= width <= 16384 or not 1 <= height <= 16384:
        raise ValueError("Unsupported TEX dimensions")
    data_offset, pitch, length = unpack(data, "<QII", 40)
    if fmt in (71, 72, 80):
        row_bytes, rows = ((width + 3) // 4) * 8, (height + 3) // 4
    elif fmt in (77, 78, 83, 98, 99):
        row_bytes, rows = ((width + 3) // 4) * 16, (height + 3) // 4
    elif fmt in (28, 29):
        row_bytes, rows = width * 4, height
    elif fmt == 61:
        row_bytes, rows = width, height
    else:
        raise ValueError(f"Unsupported DXGI texture format {fmt}: {path}")
    if pitch < row_bytes or length < pitch * rows or data_offset + length > len(data):
        raise ValueError(f"Truncated or incompatible top mip: {path}")
    payload = b"".join(data[data_offset + y * pitch:data_offset + y * pitch + row_bytes] for y in range(rows))
    if fmt in (28, 29, 61):
        image = Image.frombytes("L" if fmt == 61 else "RGBA", (width, height), payload).convert("RGBA")
    else:
        # TEX already stores DXGI block data. Wrap only mip 0 in a DDS header.
        # BC1/BC3 sRGB variants have identical block encoding to their UNORM peers.
        dds_fmt = {72: 71, 78: 77}.get(fmt, fmt)
        header = [124, 0x81007, height, width, len(payload), 0, 1] + [0] * 11
        header += [32, 4, int.from_bytes(b"DX10", "little"), 0, 0, 0, 0, 0]
        header += [0x1000, 0, 0, 0, 0]
        dds = b"DDS " + struct.pack("<31I", *header) + struct.pack("<5I", dds_fmt, 3, 0, 1, 0) + payload
        with Image.open(io.BytesIO(dds)) as decoded:
            image = decoded.convert("RGBA")
    return image, {"source": str(path), "width": width, "height": height, "dxgiFormat": fmt}


class PreviewAssets:
    def __init__(self, source: Path, destination: Path, max_size: int):
        self.source, self.destination, self.max_size = source, destination, max_size
        self.texture_folder = destination / "Textures"
        self.texture_folder.mkdir(parents=True, exist_ok=True)
        self.images: dict[str, Image.Image] = {}
        self.written: dict[tuple, str] = {}
        self.sources: list[dict] = []

    def image(self, reference: str) -> Image.Image:
        normalized = reference.replace("\\", "/").lower()
        if normalized.startswith("/") or ":" in normalized or ".." in normalized.split("/"):
            raise ValueError("Texture reference escapes the extracted source tree")
        if normalized not in self.images:
            candidates = [self.source / "streaming" / (normalized + ".34"), self.source / (normalized + ".34")]
            path = next((p for p in candidates if p.is_file()), None)
            if path is None:
                raise FileNotFoundError(f"Missing texture: {reference}")
            image, record = read_tex(path)
            image.thumbnail((self.max_size, self.max_size), Image.Resampling.LANCZOS)
            self.images[normalized] = image
            self.sources.append(record)
        return self.images[normalized]

    def save(self, key: tuple, image: Image.Image) -> str:
        if key not in self.written:
            base = Path(key[1]).name.split(".")[0].lower()
            digest = hashlib.sha256(repr(key).encode()).hexdigest()[:10]
            name = f"{base}_{key[0]}_{digest}.png"
            image.save(self.texture_folder / name, compress_level=3)
            self.written[key] = "Assets/LocalAssets/CarlosCorrected/Textures/" + name
        return self.written[key]

    def material(self, part: str, material: dict) -> dict:
        textures, params = material["textures"], material["params"]
        shader = material["shader"].lower()
        name = material["name"]
        mode = "cutout" if "hair" in shader else "opaque"
        if "glass" in shader or "cornea" in shader or "eye_tear" in shader or "env_alpha" in shader:
            mode = "transparent"
        color = params.get("BaseColor", params.get("ColorParam", [1., 1., 1., 1.]))[:]
        if mode == "transparent":
            color[3] = params.get("Alpha", [0.08 if "eye_tear" in shader else 0.2])[0]
        albedo_type = next((t for t in ("BaseMetalMap", "BaseShiftMap", "BaseAlphaMap", "BaseMap", "BaseDielectricMap") if t in textures), None)
        normal_type = next((t for t in ("NormalRoughnessMap", "NormalMap") if t in textures), None)
        base_ref = textures.get(albedo_type) if albedo_type else None
        normal_ref = textures.get(normal_type) if normal_type else None
        atos_ref = textures.get("AlphaTranslucentOcclusionSSSMap")
        is_alpha_base = bool(base_ref and "_alba" in base_ref.lower()) or albedo_type == "BaseAlphaMap"
        opacity_ref = atos_ref if mode == "cutout" and not is_alpha_base else None
        result = {"part": part, "name": name, "albedo": "", "normal": "", "metallicGloss": "", "occlusion": "", "mode": mode, "color": color, "cutoff": params.get("AlphaTestRef", [0.15])[0] or 0.15, "smoothness": 0.3}
        base = self.image(base_ref) if base_ref else None
        if base is not None:
            albedo = base.copy()
            if opacity_ref:
                alpha = self.image(opacity_ref).getchannel("R").resize(base.size, Image.Resampling.LANCZOS)
            elif is_alpha_base:
                alpha = base.getchannel("A")
            else:
                alpha = Image.new("L", base.size, 255)
            albedo.putalpha(alpha)
            result["albedo"] = self.save(("albedo", base_ref, opacity_ref, is_alpha_base), albedo)
        normal = self.image(normal_ref) if normal_ref else None
        if normal is not None:
            result["normal"] = self.save(("normal", normal_ref), normal.convert("RGB"))
        if base is not None:
            scalar_metallic = params.get("Metallic", [1.])[0]
            if "skin" in shader or "cornea" in shader or "eye_tear" in shader:
                scalar_metallic = 0.0
            metallic = base.getchannel("A") if albedo_type == "BaseMetalMap" else Image.new("L", base.size, 0)
            metallic = metallic.point(lambda x: max(0, min(255, round(x * scalar_metallic))))
            rough_ref = textures.get("RoughnessMap")
            if rough_ref:
                roughness = self.image(rough_ref).getchannel("R")
            elif normal_type == "NormalRoughnessMap":
                roughness = normal.getchannel("A")
            else:
                roughness = Image.new("L", base.size, 150)
            scalar_roughness = params.get("Roughness", [1.])[0]
            smoothness = roughness.resize(base.size, Image.Resampling.LANCZOS).point(lambda x: 255 - max(0, min(255, round(x * scalar_roughness))))
            zero = Image.new("L", base.size, 0)
            packed = Image.merge("RGBA", (metallic, zero, zero, smoothness))
            result["metallicGloss"] = self.save(("metalgloss", base_ref, normal_ref, rough_ref, albedo_type, scalar_metallic, scalar_roughness), packed)
        if atos_ref:
            result["occlusion"] = self.save(("ao", atos_ref), self.image(atos_ref).getchannel("B").convert("RGB"))
        if mode == "transparent":
            result["smoothness"] = 0.9
        result["sourceShader"] = material["shader"]
        return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True, type=Path, help="Extracted natives/stm tree")
    parser.add_argument("--exports", required=True, type=Path, help="Folder with pl0000/pl0001/pl0005 FBX")
    parser.add_argument("--destination", required=True, type=Path, help="Unity Assets/LocalAssets/CarlosCorrected")
    parser.add_argument("--max-size", type=int, default=2048)
    args = parser.parse_args()
    if args.max_size < 64 or args.max_size > 8192:
        parser.error("max-size must be 64..8192")
    exports = {}
    for part in PARTS:
        path = args.exports / (part + ".fbx")
        data = path.read_bytes()
        if not data.startswith(b"Kaydara FBX Binary  \x00\x1a\x00") or len(data) < 1000:
            raise ValueError(f"Missing or invalid Noesis FBX: {path}")
        exports[part] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    assets = PreviewAssets(args.source_root.resolve(), args.destination.resolve(), args.max_size)
    manifest = {"schemaVersion": 1, "stage": "unified-carlos-rig-lighting", "exports": exports, "materials": []}
    for part, relative in PARTS.items():
        materials = read_mdf(args.source_root / relative)
        for material in materials:
            manifest["materials"].append(assets.material(part, material))
        shutil.copy2(args.exports / (part + ".fbx"), args.destination / (part + ".fbx"))
        print(f"{part}: {len(materials)} source materials prepared", flush=True)
    manifest["textures"] = assets.sources
    manifest["convertedImages"] = len(assets.written)
    manifest["limits"] = ["Materials prepared for unified rig build; Unity must regenerate the prefab and both bundles.", "Base layers translated to Unity Standard; RE Engine eye, skin and hair shading is approximated.", "No animations, voices, player replacement or network synchronization in this stage."]
    output = args.destination / "preview-materials.json"
    output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Prepared {len(manifest['materials'])} materials, {len(assets.sources)} source textures, {len(assets.written)} PNG maps. Manifest: {output}", flush=True)


if __name__ == "__main__":
    main()
