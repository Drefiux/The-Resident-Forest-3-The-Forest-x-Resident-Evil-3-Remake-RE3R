using System;
using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
public static class InspectG19Attachment
{
    [Serializable] public sealed class Node { public string name,parent;public Vector3 position,scale;public Quaternion rotation; }
    [Serializable] public sealed class Part { public string name;public bool enabled;public int layer;public Bounds bounds; }
    [Serializable] public sealed class Model {public string path;public Node[] nodes;public Part[] parts;}
    [Serializable] public sealed class Document {public Model[] models;}
    public static void Export()
    {
        var models=new List<Model>();
        foreach(string path in new[]{"Assets/Generated/JillAvatarPreview.prefab","Assets/Generated/CarlosAvatarPreview.prefab","Assets/Generated/G19/G19.prefab"})
        {
            var root=AssetDatabase.LoadAssetAtPath<GameObject>(path);var nodes=new List<Node>();var parts=new List<Part>();
            foreach(var t in root.GetComponentsInChildren<Transform>(true))nodes.Add(new Node{name=t.name,parent=t==root.transform ? null:t.parent.name,position=t.localPosition,rotation=t.localRotation,scale=t.localScale});
            foreach(var r in root.GetComponentsInChildren<Renderer>(true))parts.Add(new Part{name=r.name,enabled=r.enabled,layer=r.gameObject.layer,bounds=r.bounds});
            models.Add(new Model{path=path,nodes=nodes.ToArray(),parts=parts.ToArray()});
        }
        File.WriteAllText("g19-attachment-assets.json",JsonUtility.ToJson(new Document{models=models.ToArray()},true));
        Debug.Log("G19_ATTACHMENT_ASSETS_EXPORTED");
    }
}
