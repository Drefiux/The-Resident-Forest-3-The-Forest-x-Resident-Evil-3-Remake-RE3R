using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

// Read the imported rest geometry without rebuilding either accepted bundle.
public static class InspectAvatarNeckBoundaries
{
    public static void Read()
    {
        var report=new StringBuilder();
        foreach (string character in new[] { "Jill", "Carlos" })
        {
            GameObject prefab=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Generated/"+character+"AvatarPreview.prefab");
            if (prefab==null) throw new InvalidOperationException("Missing "+character+" prefab");
            Transform neck=null,head=null;
            foreach (Transform bone in prefab.GetComponentsInChildren<Transform>(true))
            { if (bone.name=="neck_0") neck=bone; if (bone.name=="head") head=bone; }
            Vector3 np=prefab.transform.InverseTransformPoint(neck.position), hp=prefab.transform.InverseTransformPoint(head.position);
            report.AppendLine(character+" neck="+np.ToString("F6")+" head="+hp.ToString("F6"));
            foreach (Transform bone in prefab.GetComponentsInChildren<Transform>(true))
                if (bone.name=="neck_1") report.AppendLine("NECK1 "+prefab.transform.InverseTransformPoint(bone.position).ToString("F6"));
            foreach (SkinnedMeshRenderer skin in prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                bool bodyPart=false,headPart=false;
                for (Transform part=skin.transform; part!=null && part!=prefab.transform; part=part.parent)
                { if (part.name.StartsWith("Body_pl",StringComparison.Ordinal)) bodyPart=true;
                  if (part.name.StartsWith("Head_pl",StringComparison.Ordinal)) headPart=true; }
                if (!bodyPart && !headPart) continue;
                Mesh source=skin.sharedMesh; Vector3[] points=source.vertices;
                if (headPart)
                {
                    int lower=0; float low=float.PositiveInfinity;
                    foreach (Vector3 local in points)
                    { Vector3 p=prefab.transform.InverseTransformPoint(skin.transform.TransformPoint(local)); low=Mathf.Min(low,p.y); if (p.y<hp.y-.06f) lower++; }
                    report.AppendLine("HEAD_NECK skin="+skin.name+" lowest="+low.ToString("F6")+" belowHeadMinus06="+lower+" total="+points.Length);
                }
                var welded=new Dictionary<string,int>(); var ids=new int[points.Length];
                for (int i=0;i<points.Length;i++)
                {
                    Vector3 p=points[i];
                    string key=Mathf.RoundToInt(p.x*100000f)+","+Mathf.RoundToInt(p.y*100000f)+","+Mathf.RoundToInt(p.z*100000f);
                    int id; if (!welded.TryGetValue(key,out id)) { id=i; welded.Add(key,id); } ids[i]=id;
                }
                var edges=new Dictionary<long,int>(); int[] tris=source.triangles;
                for (int i=0;i<tris.Length;i+=3) for (int j=0;j<3;j++)
                {
                    int a=ids[tris[i+j]],b=ids[tris[i+(j+1)%3]]; if (a==b) continue;
                    long key=((long)Math.Min(a,b)<<32)|(uint)Math.Max(a,b);
                    int count; edges.TryGetValue(key,out count); edges[key]=count+1;
                }
                var neighbours=new Dictionary<int,List<int>>();
                foreach (var edge in edges) if (edge.Value==1)
                { int a=(int)(edge.Key>>32),b=(int)edge.Key; Add(neighbours,a,b); Add(neighbours,b,a); }
                report.AppendLine("SKIN "+skin.name+" vertices="+points.Length+" boundaryVertices="+neighbours.Count);
                var visited=new HashSet<int>();
                foreach (int start in neighbours.Keys)
                {
                    if (!visited.Add(start)) continue;
                    var pending=new Queue<int>(); pending.Enqueue(start);
                    int count=0, badDegree=0, maxDegree=0; Vector3 center=Vector3.zero;
                    float low=float.PositiveInfinity, high=float.NegativeInfinity, radius=0;
                    while (pending.Count>0)
                    {
                        int index=pending.Dequeue(); count++;
                        Vector3 p=prefab.transform.InverseTransformPoint(skin.transform.TransformPoint(points[index]));
                        center+=p; low=Mathf.Min(low,p.y); high=Mathf.Max(high,p.y);
                        radius=Mathf.Max(radius,Vector3.ProjectOnPlane(p-np,Vector3.up).magnitude);
                        if (neighbours[index].Count!=2) badDegree++;
                        maxDegree=Math.Max(maxDegree,neighbours[index].Count);
                        foreach (int next in neighbours[index]) if (visited.Add(next)) pending.Enqueue(next);
                    }
                    center/=count;
                    if (high<np.y-.18f || Vector3.ProjectOnPlane(center-np,Vector3.up).magnitude>.24f) continue;
                    report.AppendLine("BOUNDARY vertices="+count+" low="+low.ToString("F6")+" high="+high.ToString("F6")+" center="+center.ToString("F6")+" maxRadius="+radius.ToString("F6")+" badDegree="+badDegree+" maxDegree="+maxDegree);
                }
            }
        }
        File.WriteAllText("avatar-neck-boundaries-0771.txt",report.ToString());
        Debug.Log("AVATAR_NECK_BOUNDARIES_READ");
    }
    private static void Add(Dictionary<int,List<int>> map,int a,int b)
    { List<int> list; if (!map.TryGetValue(a,out list)) { list=new List<int>(); map.Add(a,list); } list.Add(b); }
}
