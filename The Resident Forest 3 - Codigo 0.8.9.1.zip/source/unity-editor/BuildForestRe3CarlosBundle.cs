using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

// Unity 5.6.5p4. Unified rig and materials prepared for native scene lighting.
public static class BuildForestRe3CarlosBundle
{
    private const string LocalFolder = "Assets/LocalAssets/CarlosCorrected";
    private const string ManifestPath = LocalFolder + "/preview-materials.json";
    private const string PrefabPath = "Assets/Generated/CarlosAvatarPreview.prefab";
    private const string MaterialFolder = "Assets/Generated/CarlosCorrectedMaterials";
    private const string ScenePath = "Assets/Generated/CarlosPreview.unity";
    private const string BundleFolder = "Assets/AssetBundles";
    private const string BundleName = "forest-re3-carlos";
    private static readonly string[] ModelIds = { "pl0000", "pl0001", "pl0005" };
    private static readonly string[] PartNames = { "Body", "Head", "Hair" };
    private static readonly Dictionary<string, Texture2D> Textures = new Dictionary<string, Texture2D>();

    [Serializable]
    private sealed class MaterialManifest
    {
        public int schemaVersion;
        public string stage;
        public MaterialEntry[] materials;
    }

    [Serializable]
    private sealed class MaterialEntry
    {
        public string part;
        public string name;
        public string albedo;
        public string normal;
        public string metallicGloss;
        public string occlusion;
        public string mode;
        public float[] color;
        public float cutoff;
        public float smoothness;
        public string sourceShader;
    }

    [MenuItem("Forest RE3/1 - Configure complete Carlos imports")]
    public static void ConfigureModelImporter()
    {
        foreach (string id in ModelIds)
        {
            string path = LocalFolder + "/" + id + ".fbx";
            ModelImporter importer = AssetImporter.GetAtPath(path) as ModelImporter;
            if (importer == null) throw new InvalidOperationException("Missing Carlos source: " + path);
            importer.animationType = ModelImporterAnimationType.Generic;
            importer.importAnimation = false;
            importer.importMaterials = true;
            importer.optimizeGameObjects = false;
            importer.SaveAndReimport();
        }
        Debug.Log("[ForestRE3] Imported Carlos body pl0000, head pl0001 and hair pl0005 for rig assembly.");
    }

    [MenuItem("Forest RE3/2 - Create complete Carlos preview prefab")]
    public static void CreatePreviewPrefab()
    {
        MaterialManifest manifest = ReadManifest();
        Directory.CreateDirectory(MaterialFolder);
        AssetDatabase.Refresh();
        Textures.Clear();
        GameObject root = new GameObject("CarlosAvatarPreview");
        try
        {
            for (int i = 0; i < ModelIds.Length; i++)
            {
                string path = LocalFolder + "/" + ModelIds[i] + ".fbx";
                GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (model == null) throw new InvalidOperationException("Could not import " + path);
                GameObject part = UnityEngine.Object.Instantiate(model);
                part.name = PartNames[i] + "_" + ModelIds[i];
                part.transform.SetParent(root.transform, false);
                foreach (Animator animator in part.GetComponentsInChildren<Animator>(true)) animator.enabled = false;
                ApplyMaterials(part, ModelIds[i], manifest);
            }
            CarlosRigAssembler.Assemble(root, new[] { "Body_pl0000", "Head_pl0001", "Hair_pl0005" });
            ValidateCompletePreview(root);
            Directory.CreateDirectory("Assets/Generated");
            GameObject prefab = PrefabUtility.CreatePrefab(PrefabPath, root, ReplacePrefabOptions.ReplaceNameBased);
            if (prefab == null) throw new InvalidOperationException("Unity did not create the complete Carlos prefab.");
            AssetDatabase.SaveAssets();
            Debug.Log("[ForestRE3] Created CarlosAvatarPreview: single skeleton, body, head, hair and scene-lit materials.");
        }
        finally
        {
            UnityEngine.Object.DestroyImmediate(root);
        }
    }

    [MenuItem("Forest RE3/3 - Build Windows 64-bit Carlos AssetBundle")]
    public static void BuildBundle()
    {
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
        if (prefab == null) throw new InvalidOperationException("Create the complete Carlos prefab first.");
        ValidateCompletePreview(prefab);
        CarlosRigAssembler.Validate(prefab);
        Directory.CreateDirectory(BundleFolder);
        AssetBundleBuild build = new AssetBundleBuild();
        string colorSuffix = PlayerSettings.colorSpace == ColorSpace.Linear ? "linear" : "gamma";
        build.assetBundleName = BundleName + "-" + colorSuffix;
        build.assetNames = new[] { PrefabPath };
        AssetBundleManifest result = BuildPipeline.BuildAssetBundles(BundleFolder, new[] { build }, BuildAssetBundleOptions.ForceRebuildAssetBundle, BuildTarget.StandaloneWindows64);
        if (result == null) throw new InvalidOperationException("Unity failed to build the Carlos AssetBundle.");
        Debug.Log("[ForestRE3] UNIFIED_JILL_BUNDLE_" + colorSuffix.ToUpperInvariant() + " Built " + BundleFolder + "/" + build.assetBundleName);
    }

    [MenuItem("Forest RE3/4 - Open complete Carlos preview scene")]
    public static void OpenPreviewScene()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        CreatePreviewScene();
    }

    // Entry point for a local batch build; no editor clicks are required.
    public static void BuildAll()
    {
        ConfigureModelImporter();
        ColorSpace previous = PlayerSettings.colorSpace;
        try
        {
            foreach (ColorSpace space in new[] { ColorSpace.Gamma, ColorSpace.Linear })
            {
                PlayerSettings.colorSpace = space;
                AssetDatabase.Refresh();
                CreatePreviewPrefab();
                CreatePreviewScene();
                BuildBundle();
                RenderPreview();
            }
            Debug.Log("[ForestRE3] UNIFIED_JILL_BUILD_COMPLETE Both color spaces built; animation integration pending.");
        }
        finally { PlayerSettings.colorSpace = previous; }
    }

    private static MaterialManifest ReadManifest()
    {
        if (!File.Exists(ManifestPath)) throw new InvalidOperationException("Run Prepare-LocalAssets.ps1 to generate Carlos's texture manifest.");
        MaterialManifest manifest = JsonUtility.FromJson<MaterialManifest>(File.ReadAllText(ManifestPath));
        if (manifest == null || manifest.schemaVersion != 1 || manifest.materials == null) throw new InvalidOperationException("Unsupported Carlos material manifest.");
        if (manifest.stage != "unified-carlos-rig-lighting") throw new InvalidOperationException("Prepare Carlos's unified-rig materials before building.");
        return manifest;
    }

    private static void ApplyMaterials(GameObject part, string id, MaterialManifest manifest)
    {
        Dictionary<string, Material> mapped = new Dictionary<string, Material>(StringComparer.OrdinalIgnoreCase);
        foreach (MaterialEntry entry in manifest.materials)
        {
            if (entry.part == id) mapped.Add(entry.name, CreateMaterial(entry));
        }
        foreach (Renderer renderer in part.GetComponentsInChildren<Renderer>(true))
        {
            Material[] originals = renderer.sharedMaterials;
            for (int i = 0; i < originals.Length; i++)
            {
                string name = originals[i] == null ? "" : originals[i].name.Replace(" (Instance)", "");
                Material replacement;
                if (!mapped.TryGetValue(name, out replacement))
                {
                    // Unity 5.6 can collapse Noesis FBX material names to "No Name".
                    // Each exported submesh still encodes its exact MDF material
                    // in its renderer name. Use only that unambiguous identity.
                    replacement = null;
                    if (originals.Length == 1 && (name == "No Name" || name == ""))
                    {
                        foreach (KeyValuePair<string, Material> candidate in mapped)
                        {
                            if (renderer.name.EndsWith("__" + candidate.Key, StringComparison.OrdinalIgnoreCase))
                            {
                                if (replacement != null) throw new InvalidOperationException("Ambiguous material identity for " + renderer.name);
                                replacement = candidate.Value;
                            }
                        }
                    }
                    if (replacement == null) throw new InvalidOperationException("No source material mapping for " + id + ": " + name + " on " + renderer.name);
                }
                originals[i] = replacement;
            }
            renderer.sharedMaterials = originals;
        }
    }

    private static Material CreateMaterial(MaterialEntry entry)
    {
        string shaderName = entry.mode == "cutout" ? "ForestRE3/Preview Hair" : "Standard";
        Shader shader = Shader.Find(shaderName);
        if (shader == null) throw new InvalidOperationException("Missing preview shader " + shaderName);
        string path = MaterialFolder + "/" + entry.part + "_" + entry.name + ".mat";
        Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (material == null)
        {
            material = new Material(shader);
            AssetDatabase.CreateAsset(material, path);
        }
        else material.shader = shader;
        material.name = entry.name;
        material.shaderKeywords = new string[0];
        material.color = entry.color != null && entry.color.Length == 4 ? new Color(entry.color[0], entry.color[1], entry.color[2], entry.color[3]) : Color.white;
        material.SetTexture("_MainTex", LoadTexture(entry.albedo, false, true));
        material.SetTexture("_BumpMap", LoadTexture(entry.normal, true, false));
        material.SetTexture("_MetallicGlossMap", LoadTexture(entry.metallicGloss, false, false));
        material.SetTexture("_OcclusionMap", LoadTexture(entry.occlusion, false, false));
        material.SetFloat("_Metallic", 0f);
        material.SetFloat("_Glossiness", entry.smoothness);
        bool skin = entry.sourceShader != null && entry.sourceShader.IndexOf("Skin", StringComparison.OrdinalIgnoreCase) >= 0;
        material.SetFloat("_GlossMapScale", skin ? 0.4f : (entry.mode == "cutout" ? 0.45f : 0.7f));
        material.SetFloat("_BumpScale", 1f);
        material.SetFloat("_OcclusionStrength", 1f);
        material.SetFloat("_Cutoff", entry.cutoff);
        material.SetColor("_EmissionColor", Color.black);
        material.SetTexture("_EmissionMap", null);
        material.DisableKeyword("_EMISSION");
        material.globalIlluminationFlags = MaterialGlobalIlluminationFlags.EmissiveIsBlack;
        if (!string.IsNullOrEmpty(entry.normal)) material.EnableKeyword("_NORMALMAP");
        if (!string.IsNullOrEmpty(entry.metallicGloss)) material.EnableKeyword("_METALLICGLOSSMAP");
        if (entry.mode == "transparent")
        {
            material.SetFloat("_Mode", 3f);
            material.SetOverrideTag("RenderType", "Transparent");
            material.SetInt("_SrcBlend", (int)BlendMode.One);
            material.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            material.SetInt("_ZWrite", 0);
            material.EnableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = 3000;
        }
        else if (entry.mode == "cutout")
        {
            material.SetOverrideTag("RenderType", "TransparentCutout");
            material.renderQueue = 2450;
        }
        else
        {
            material.SetFloat("_Mode", 0f);
            material.SetOverrideTag("RenderType", "Opaque");
            material.SetInt("_SrcBlend", (int)BlendMode.One);
            material.SetInt("_DstBlend", (int)BlendMode.Zero);
            material.SetInt("_ZWrite", 1);
            material.renderQueue = -1;
        }
        EditorUtility.SetDirty(material);
        return material;
    }

    private static Texture2D LoadTexture(string path, bool normal, bool color)
    {
        if (string.IsNullOrEmpty(path)) return null;
        Texture2D texture;
        if (Textures.TryGetValue(path, out texture)) return texture;
        TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (importer == null) throw new InvalidOperationException("Missing converted texture " + path);
        importer.textureType = normal ? TextureImporterType.NormalMap : TextureImporterType.Default;
        importer.sRGBTexture = color;
        importer.alphaSource = TextureImporterAlphaSource.FromInput;
        importer.alphaIsTransparency = color;
        importer.maxTextureSize = 2048;
        importer.mipmapEnabled = true;
        importer.SaveAndReimport();
        texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        if (texture == null) throw new InvalidOperationException("Texture import failed: " + path);
        Textures.Add(path, texture);
        return texture;
    }

    private static void ValidateCompletePreview(GameObject root)
    {
        CarlosRigAssembler.Validate(root);
        for (int i = 0; i < ModelIds.Length; i++)
        {
            Transform part = root.transform.Find(PartNames[i] + "_" + ModelIds[i]);
            if (part == null || part.GetComponentsInChildren<Renderer>(true).Length == 0) throw new InvalidOperationException("Incomplete Carlos prefab: missing " + PartNames[i]);
        }
        foreach (Renderer renderer in root.GetComponentsInChildren<Renderer>(true))
        {
            foreach (Material material in renderer.sharedMaterials)
            {
                if (material == null || !AssetDatabase.GetAssetPath(material).StartsWith(MaterialFolder + "/", StringComparison.Ordinal)) throw new InvalidOperationException("Carlos prefab still contains unmapped source materials.");
            }
        }
    }

    private static void CreatePreviewScene()
    {
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
        if (prefab == null) throw new InvalidOperationException("Create Carlos's prefab before the preview scene.");
        ValidateCompletePreview(prefab);
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
        Renderer[] renderers = instance.GetComponentsInChildren<Renderer>();
        Bounds bounds = renderers[0].bounds;
        foreach (Renderer renderer in renderers) bounds.Encapsulate(renderer.bounds);
        float height = bounds.size.y;
        if (height <= 0f || height > 20f) throw new InvalidOperationException("Unexpected Carlos model bounds: " + bounds.size);
        GameObject cameraObject = new GameObject("PreviewCamera");
        Camera camera = cameraObject.AddComponent<Camera>();
        camera.tag = "MainCamera";
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.12f, 0.14f, 0.16f);
        camera.fieldOfView = 35f;
        camera.transform.position = bounds.center + new Vector3(0f, height * 0.02f, height * 2.05f);
        camera.transform.LookAt(bounds.center);
        GameObject keyObject = new GameObject("PreviewKeyLight");
        Light key = keyObject.AddComponent<Light>();
        key.type = LightType.Directional;
        key.intensity = 0.9f;
        key.transform.rotation = Quaternion.Euler(35f, 150f, 0f);
        GameObject fillObject = new GameObject("PreviewFillLight");
        Light fill = fillObject.AddComponent<Light>();
        fill.type = LightType.Directional;
        fill.intensity = 0.35f;
        fill.color = new Color(0.8f, 0.88f, 1f);
        fill.transform.rotation = Quaternion.Euler(-10f, -145f, 0f);
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.5f, 0.5f, 0.5f);
        if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new InvalidOperationException("Could not save Carlos's preview scene.");
        Debug.Log("[ForestRE3] Saved " + ScenePath + ". Carlos height=" + height + "; renderers=" + renderers.Length);
    }

    private static void RenderPreview()
    {
        Camera camera = Camera.main;
        if (camera == null) throw new InvalidOperationException("Missing preview camera.");
        Directory.CreateDirectory("PreviewRenders");
        RenderTexture target = new RenderTexture(1200, 1200, 24, RenderTextureFormat.ARGB32);
        Texture2D pixels = new Texture2D(1200, 1200, TextureFormat.RGB24, false);
        RenderTexture previous = RenderTexture.active;
        try
        {
            camera.targetTexture = target;
            camera.Render();
            RenderTexture.active = target;
            pixels.ReadPixels(new Rect(0, 0, 1200, 1200), 0, 0);
            pixels.Apply();
            File.WriteAllBytes("PreviewRenders/Carlos-complete.png", pixels.EncodeToPNG());
            string suffix = PlayerSettings.colorSpace == ColorSpace.Linear ? "linear" : "gamma";
            File.WriteAllBytes("PreviewRenders/Carlos-unified-" + suffix + ".png", pixels.EncodeToPNG());
            Debug.Log("[ForestRE3] Saved PreviewRenders/Carlos-unified-" + suffix + ".png.");
        }
        finally
        {
            camera.targetTexture = null;
            RenderTexture.active = previous;
            UnityEngine.Object.DestroyImmediate(pixels);
            UnityEngine.Object.DestroyImmediate(target);
        }
    }
}
