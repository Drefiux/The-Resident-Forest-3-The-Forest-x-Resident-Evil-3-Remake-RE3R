using UnityEditor;
using UnityEngine;
using System.IO;

public static class BuildJillFirstPersonSurface
{
    public static void Build()
    {
        AssetDatabase.Refresh();
        ColorSpace previous=PlayerSettings.colorSpace;
        try
        {
            foreach (ColorSpace space in new[] { ColorSpace.Gamma,ColorSpace.Linear })
            {
                PlayerSettings.colorSpace=space;
                string output="Assets/AssetBundles/FirstPerson/"+space.ToString().ToLowerInvariant();
                Directory.CreateDirectory(output);
                BuildPipeline.BuildAssetBundles(output,new[] { new AssetBundleBuild {
                    assetBundleName="jill-first-person-surface", assetNames=new[] { "Assets/Shaders/JillFirstPerson.shader" }
                } },BuildAssetBundleOptions.ForceRebuildAssetBundle|BuildAssetBundleOptions.ChunkBasedCompression,BuildTarget.StandaloneWindows64);
                if (!File.Exists(output+"/jill-first-person-surface")) throw new System.Exception("First-person shader bundle missing.");
            }
        }
        finally { PlayerSettings.colorSpace=previous; }
        Debug.Log("JILL_FP_SURFACE_BUILT");
    }
}
