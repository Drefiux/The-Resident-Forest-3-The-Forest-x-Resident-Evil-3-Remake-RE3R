﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
public static class BuildForestRe3RocketProjectileBundle
{
    const string Folder="Assets/LocalAssets/Re3Rocket", Generated="Assets/Generated/RocketProjectile";
    [Serializable] sealed class Geometry { public Part[] parts; }
    [Serializable] sealed class Part { public string name,material; public float[] positions,normals,uv; public int[] triangles; }
    [Serializable] sealed class Manifest { public Mat[] materials; }
    [Serializable] sealed class Mat { public string name,albedo,normal,metallicGloss,occlusion; public float[] color; }
    static Texture2D Texture(string path,bool normal,bool linear)
    {
        if(String.IsNullOrEmpty(path)) return null;
        var importer=(TextureImporter)AssetImporter.GetAtPath(path);
        importer.textureType=normal ? TextureImporterType.NormalMap:TextureImporterType.Default;
        importer.sRGBTexture=!linear;importer.maxTextureSize=1024;importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
    }
    public static void Build()
    {
        AssetDatabase.Refresh();Directory.CreateDirectory(Generated);AssetDatabase.Refresh();
        var g=JsonUtility.FromJson<Geometry>(File.ReadAllText(Folder+"/projectile-mesh.json"));
        var manifest=JsonUtility.FromJson<Manifest>(File.ReadAllText(Folder+"/projectile-manifest.json"));
        var mats=new Dictionary<string,Material>();
        foreach(var row in manifest.materials)
        {
            var m=new Material(Shader.Find("Standard"));m.name=row.name;m.color=new Color(row.color[0],row.color[1],row.color[2],1);
            m.mainTexture=Texture(row.albedo,false,false);m.SetTexture("_BumpMap",Texture(row.normal,true,true));m.EnableKeyword("_NORMALMAP");
            m.SetTexture("_MetallicGlossMap",Texture(row.metallicGloss,false,true));m.EnableKeyword("_METALLICGLOSSMAP");
            m.SetTexture("_OcclusionMap",Texture(row.occlusion,false,true));m.SetFloat("_GlossMapScale",.65f);
            AssetDatabase.CreateAsset(m,Generated+"/"+row.name+".mat");mats.Add(row.name,m);
        }
        var root=new GameObject("Rocket_RE3R");
        foreach(var p in g.parts)
        {
            var mesh=new Mesh();mesh.name=p.name;
            var positions=new Vector3[p.positions.Length/3];var normals=new Vector3[positions.Length];var uv=new Vector2[positions.Length];
            for(int i=0;i<positions.Length;i++){positions[i]=new Vector3(p.positions[3*i],p.positions[3*i+1],p.positions[3*i+2]);normals[i]=new Vector3(p.normals[3*i],p.normals[3*i+1],p.normals[3*i+2]);uv[i]=new Vector2(p.uv[2*i],p.uv[2*i+1]);}
            mesh.vertices=positions;mesh.normals=normals;mesh.uv=uv;mesh.triangles=p.triangles;mesh.RecalculateBounds();mesh.RecalculateTangents();
            AssetDatabase.CreateAsset(mesh,Generated+"/"+p.name+".asset");
            var part=new GameObject(p.name);part.transform.SetParent(root.transform,false);
            part.AddComponent<MeshFilter>().sharedMesh=mesh;part.AddComponent<MeshRenderer>().sharedMaterial=mats[p.material];
        }
        string prefab=Generated+"/RocketProjectile.prefab";PrefabUtility.CreatePrefab(prefab,root,ReplacePrefabOptions.ReplaceNameBased);
        // Inventory weapons in RE3R are model renders. Render the original Rocket for the same purpose.
        root.transform.position=new Vector3(10000,10000,10000);var cameraObject=new GameObject("InventoryCamera");var camera=cameraObject.AddComponent<Camera>();
        camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.clear;camera.orthographic=true;camera.aspect=1f;
        Bounds bounds=root.GetComponentInChildren<Renderer>().bounds;
        foreach(var renderer in root.GetComponentsInChildren<Renderer>())bounds.Encapsulate(renderer.bounds);
        camera.transform.position=bounds.center+new Vector3(-1.4f,.28f,-.15f);camera.transform.LookAt(bounds.center);
        // Fit every original mesh corner, including the barrel and buttstock.
        float extent=0f;
        foreach(int x in new[]{-1,1})foreach(int y in new[]{-1,1})foreach(int z in new[]{-1,1})
        {Vector3 local=camera.transform.InverseTransformPoint(bounds.center+Vector3.Scale(bounds.extents,new Vector3(x,y,z)));extent=Mathf.Max(extent,Mathf.Abs(local.x),Mathf.Abs(local.y));}
        camera.orthographicSize=extent*1.14f;
        RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;RenderSettings.ambientLight=new Color(.55f,.55f,.55f);RenderSettings.ambientIntensity=1;
        var lightObject=new GameObject("InventoryLight");var light=lightObject.AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.6f;light.transform.rotation=Quaternion.Euler(40,-45,0);
        var rt=new RenderTexture(256,256,24);camera.targetTexture=rt;camera.Render();RenderTexture.active=rt;
        var icon=new Texture2D(256,256,TextureFormat.RGBA32,false);icon.ReadPixels(new Rect(0,0,256,256),0,0);icon.Apply();File.WriteAllBytes(Folder+"/projectile-icon.png",icon.EncodeToPNG());
        RenderTexture.active=null;camera.targetTexture=null;UnityEngine.Object.DestroyImmediate(rt);UnityEngine.Object.DestroyImmediate(icon);
        UnityEngine.Object.DestroyImmediate(cameraObject);UnityEngine.Object.DestroyImmediate(lightObject);UnityEngine.Object.DestroyImmediate(root);AssetDatabase.Refresh();
        Texture(Folder+"/projectile-icon.png",false,false);AssetDatabase.SaveAssets();
        foreach(var space in new[]{ColorSpace.Gamma,ColorSpace.Linear})
        {
            PlayerSettings.colorSpace=space;string suffix=space==ColorSpace.Linear ? "linear":"gamma",dest="Assets/AssetBundles/Rocket/"+suffix;Directory.CreateDirectory(dest);
            var build=new AssetBundleBuild{assetBundleName="forest-re3-rocket",assetNames=new[]{prefab,Folder+"/projectile-icon.png"}};
            if(BuildPipeline.BuildAssetBundles(dest,new[]{build},BuildAssetBundleOptions.ForceRebuildAssetBundle,BuildTarget.StandaloneWindows64)==null)throw new InvalidOperationException("Rocket bundle failed");
        }
        Debug.Log("[ForestRE3] Rocket_BUNDLES_READY originalModel=true originalInventoryAtlas=true");
    }
}
