using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

// A single skeleton, with original vertex weights and bind compensation preserved.
public static class JillRigAssembler
{
    private const string MeshFolder = "Assets/Generated/JillUnifiedMeshes";
    private const string AvatarPath = "Assets/Generated/JillUnifiedAvatar.asset";
    private static readonly Regex BonePrefix = new Regex(@"^b\d+:");

    [Serializable]
    public sealed class Report
    {
        public string stage = "unified-jill-rig-lighting";
        public int sourceTransforms;
        public int unifiedTransforms;
        public int sharedTransforms;
        public int skinnedRenderers;
        public float maxSharedRestDistanceMetres;
        public float maxSkinningDriftMetres;
        public bool allRenderersUseSingleSkeleton;
        public bool animationsConnected;
        public string[] boneNames;
    }

    public static Report Assemble(GameObject root, string[] partNames)
    {
        Directory.CreateDirectory(MeshFolder);
        AssetDatabase.Refresh();
        Transform skeleton = new GameObject("JillSkeleton").transform;
        skeleton.SetParent(root.transform, false);
        var canonical = new Dictionary<string, Transform>(StringComparer.Ordinal);
        var mapped = new Dictionary<Transform, Transform>();
        var report = new Report();

        foreach (string partName in partNames)
        {
            Transform part = root.transform.Find(partName);
            if (part == null) throw new InvalidOperationException("Missing rig part " + partName);
            Transform[] originals = part.GetComponentsInChildren<Transform>(true);
            var namesInPart = new HashSet<string>(StringComparer.Ordinal);
            foreach (Transform source in originals)
            {
                if (source == part || source.GetComponent<Renderer>() != null) continue;
                string name = BonePrefix.Replace(source.name, "");
                if (!namesInPart.Add(name)) throw new InvalidOperationException("Ambiguous bone in " + partName + ": " + name);
                MapTransform(source, part, skeleton, canonical, mapped, report);
            }

            SkinnedMeshRenderer[] renderers = part.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            for (int index = 0; index < renderers.Length; index++)
            {
                SkinnedMeshRenderer renderer = renderers[index];
                Mesh sourceMesh = renderer.sharedMesh;
                if (sourceMesh == null) throw new InvalidOperationException("Missing mesh on " + renderer.name);
                Transform[] oldBones = renderer.bones;
                Matrix4x4[] oldBindposes = sourceMesh.bindposes;
                if (oldBones.Length == 0 || oldBones.Length != oldBindposes.Length)
                    throw new InvalidOperationException("Invalid bindposes on " + renderer.name);
                Mesh before = new Mesh();
                Mesh after = new Mesh();
                try
                {
                    renderer.quality = SkinQuality.Bone4;
                    renderer.BakeMesh(before);
                    Transform[] newBones = new Transform[oldBones.Length];
                    Matrix4x4[] newBindposes = new Matrix4x4[oldBindposes.Length];
                    for (int bone = 0; bone < oldBones.Length; bone++)
                    {
                        if (oldBones[bone] == null) throw new InvalidOperationException("Missing weighted bone on " + renderer.name);
                        newBones[bone] = MapTransform(oldBones[bone], part, skeleton, canonical, mapped, report);
                        // Retain the original offset, including small source rest-pose differences.
                        newBindposes[bone] = newBones[bone].worldToLocalMatrix * oldBones[bone].localToWorldMatrix * oldBindposes[bone];
                    }
                    Mesh mesh = UnityEngine.Object.Instantiate(sourceMesh);
                    mesh.name = partName + "_" + index + "_Unified";
                    mesh.bindposes = newBindposes;
                    string path = MeshFolder + "/" + mesh.name + ".asset";
                    Mesh saved = AssetDatabase.LoadAssetAtPath<Mesh>(path);
                    if (saved == null) { AssetDatabase.CreateAsset(mesh, path); saved = mesh; }
                    else { EditorUtility.CopySerialized(mesh, saved); UnityEngine.Object.DestroyImmediate(mesh); }
                    renderer.sharedMesh = saved;
                    renderer.bones = newBones;
                    renderer.rootBone = skeleton;
                    renderer.quality = SkinQuality.Bone4;
                    renderer.updateWhenOffscreen = true;
                    renderer.BakeMesh(after);
                    Vector3[] a = before.vertices, b = after.vertices;
                    if (a.Length != b.Length) throw new InvalidOperationException("Vertex count changed during rig merge.");
                    for (int vertex = 0; vertex < a.Length; vertex++)
                    {
                        float distance = renderer.transform.TransformVector(a[vertex] - b[vertex]).magnitude;
                        report.maxSkinningDriftMetres = Mathf.Max(report.maxSkinningDriftMetres, distance);
                    }
                    if (report.maxSkinningDriftMetres > 0.0001f)
                        throw new InvalidOperationException("Rig merge moved skin by " + report.maxSkinningDriftMetres + " metres; build stopped.");
                    if (b.Length == 0) throw new InvalidOperationException("Empty skinned mesh on " + renderer.name);
                    Bounds bounds = new Bounds(skeleton.InverseTransformPoint(renderer.transform.TransformPoint(b[0])), Vector3.zero);
                    foreach (Vector3 point in b) bounds.Encapsulate(skeleton.InverseTransformPoint(renderer.transform.TransformPoint(point)));
                    renderer.localBounds = bounds;
                    report.skinnedRenderers++;
                }
                finally { UnityEngine.Object.DestroyImmediate(before); UnityEngine.Object.DestroyImmediate(after); }
            }

            // Move renderers out of old rig branches, then remove those branches.
            foreach (Renderer renderer in part.GetComponentsInChildren<Renderer>(true))
                renderer.transform.SetParent(part, true);
            foreach (Animator animator in part.GetComponentsInChildren<Animator>(true))
                UnityEngine.Object.DestroyImmediate(animator);
            for (int child = part.childCount - 1; child >= 0; child--)
            {
                Transform node = part.GetChild(child);
                if (node.GetComponentsInChildren<Renderer>(true).Length == 0)
                    UnityEngine.Object.DestroyImmediate(node.gameObject);
            }
        }

        Transform anchor;
        if (!canonical.TryGetValue("spine_2", out anchor)) throw new InvalidOperationException("Unified rig lacks spine_2.");
        foreach (Renderer renderer in root.GetComponentsInChildren<Renderer>(true))
        {
            renderer.lightProbeUsage = LightProbeUsage.BlendProbes;
            renderer.probeAnchor = anchor;
            renderer.reflectionProbeUsage = ReflectionProbeUsage.BlendProbes;
            renderer.shadowCastingMode = renderer.transform.parent.name == "Hair_pl2005" ? ShadowCastingMode.TwoSided : ShadowCastingMode.On;
            renderer.receiveShadows = true;
        }
        Avatar avatar = AvatarBuilder.BuildGenericAvatar(root, "COG");
        if (avatar == null || !avatar.isValid) throw new InvalidOperationException("Unity rejected Jill's unified generic avatar.");
        Avatar savedAvatar = AssetDatabase.LoadAssetAtPath<Avatar>(AvatarPath);
        if (savedAvatar == null) { AssetDatabase.CreateAsset(avatar, AvatarPath); savedAvatar = avatar; }
        else { EditorUtility.CopySerialized(avatar, savedAvatar); UnityEngine.Object.DestroyImmediate(avatar); }
        Animator unifiedAnimator = root.AddComponent<Animator>();
        unifiedAnimator.avatar = savedAvatar;
        unifiedAnimator.applyRootMotion = false;
        unifiedAnimator.enabled = false; // Enabled when authentic clips and the player adapter are connected.
        report.unifiedTransforms = canonical.Count;
        report.allRenderersUseSingleSkeleton = true;
        var names = new List<string>(canonical.Keys); names.Sort(StringComparer.Ordinal);
        report.boneNames = names.ToArray();
        Validate(root);
        AssetDatabase.SaveAssets();
        File.WriteAllText("jill-rig-report.json", JsonUtility.ToJson(report, true));
        Debug.Log("[ForestRE3] UNIFIED_JILL_RIG bones=" + canonical.Count + "; shared=" + report.sharedTransforms + "; skinningDriftMetres=" + report.maxSkinningDriftMetres);
        return report;
    }

    private static Transform MapTransform(Transform source, Transform part, Transform skeleton,
        Dictionary<string, Transform> canonical, Dictionary<Transform, Transform> mapped, Report report)
    {
        if (source == part) return skeleton;
        if (source == null || !source.IsChildOf(part)) throw new InvalidOperationException("Bone lies outside its source part.");
        Transform target;
        if (mapped.TryGetValue(source, out target)) return target;
        string name = BonePrefix.Replace(source.name, "");
        report.sourceTransforms++;
        if (canonical.TryGetValue(name, out target))
        {
            report.sharedTransforms++;
            report.maxSharedRestDistanceMetres = Mathf.Max(report.maxSharedRestDistanceMetres, Vector3.Distance(target.position, source.position));
        }
        else
        {
            Transform parent = source.parent == part ? skeleton : MapTransform(source.parent, part, skeleton, canonical, mapped, report);
            target = new GameObject(name).transform;
            target.SetParent(source.parent, false);
            target.localPosition = source.localPosition;
            target.localRotation = source.localRotation;
            target.localScale = source.localScale;
            target.SetParent(parent, true);
            canonical.Add(name, target);
        }
        mapped.Add(source, target);
        return target;
    }

    public static void Validate(GameObject root)
    {
        Transform skeleton = root.transform.Find("JillSkeleton");
        if (skeleton == null) throw new InvalidOperationException("Outdated prefab: no JillSkeleton.");
        var names = new HashSet<string>(StringComparer.Ordinal);
        foreach (Transform bone in skeleton.GetComponentsInChildren<Transform>(true))
            if (!names.Add(bone.name)) throw new InvalidOperationException("Duplicate bone in unified skeleton: " + bone.name);
        SkinnedMeshRenderer[] renderers = root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        if (renderers.Length == 0) throw new InvalidOperationException("No skinned Jill renderers.");
        foreach (SkinnedMeshRenderer renderer in renderers)
        {
            if (renderer.rootBone != skeleton) throw new InvalidOperationException("Renderer uses a separate root bone: " + renderer.name);
            foreach (Transform bone in renderer.bones)
                if (bone == null || !bone.IsChildOf(skeleton)) throw new InvalidOperationException("Unmerged renderer bone: " + renderer.name);
        }
    }
}
