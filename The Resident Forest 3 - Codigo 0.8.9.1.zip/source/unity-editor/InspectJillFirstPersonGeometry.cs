using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text;
using System.Collections.Generic;

public static class InspectJillFirstPersonGeometry
{
    public static void Read()
    {
        GameObject prefab=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Generated/JillAvatarPreview.prefab");
        if (prefab==null) throw new System.Exception("Missing prefab.");
        var output=new StringBuilder();
        foreach (Transform bone in prefab.GetComponentsInChildren<Transform>(true))
            if (bone.name=="neck_0" || bone.name=="head" || bone.name=="COG" || bone.name.StartsWith("EyeCorner_")
                || bone.name.StartsWith("spine_") || bone.name.EndsWith("_leg_ankle")
                || bone.name.Contains("_hand_index") || bone.name.EndsWith("_arm_wrist"))
                output.AppendLine("BONE "+bone.name+" parent="+bone.parent.name+" position="+prefab.transform.InverseTransformPoint(bone.position).ToString("F6")+" local="+bone.localPosition.ToString("F6")+" rotation="+bone.localRotation.ToString("F6"));
        foreach (SkinnedMeshRenderer skin in prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true))
        {
            if (!skin.transform.IsChildOf(prefab.transform.Find("Body_pl2000"))) continue;
            Mesh mesh=skin.sharedMesh; Vector3[] vertices=mesh.vertices;
            output.AppendLine("MESH "+skin.name+" vertices="+vertices.Length+" bounds="+mesh.bounds);
            foreach (Material material in skin.sharedMaterials) output.AppendLine("MATERIAL "+material.name);
            if (skin.name.Contains("Skin_Mat"))
            {
                var welded=new Dictionary<string,int>(); var ids=new int[vertices.Length];
                for (int i=0;i<vertices.Length;i++)
                {
                    Vector3 p=vertices[i]; string key=Mathf.RoundToInt(p.x*100000f)+","+Mathf.RoundToInt(p.y*100000f)+","+Mathf.RoundToInt(p.z*100000f);
                    int id; if (!welded.TryGetValue(key,out id)) { id=i; welded.Add(key,id); } ids[i]=id;
                }
                var edges=new Dictionary<long,int>();
                int[] tris=mesh.triangles;
                for (int i=0;i<tris.Length;i+=3) for (int j=0;j<3;j++)
                {
                    int a=ids[tris[i+j]], b=ids[tris[i+(j+1)%3]]; if (a==b) continue;
                    long key=((long)Mathf.Min(a,b)<<32)|(uint)Mathf.Max(a,b); int count; edges.TryGetValue(key,out count); edges[key]=count+1;
                }
                foreach (var edge in edges) if (edge.Value==1)
                {
                    int a=(int)(edge.Key>>32), b=(int)edge.Key;
                    Vector3 p=prefab.transform.InverseTransformPoint(skin.transform.TransformPoint(vertices[a]));
                    Vector3 q=prefab.transform.InverseTransformPoint(skin.transform.TransformPoint(vertices[b]));
                    if (p.y>1.37f && q.y>1.37f && Mathf.Abs(p.x)<.13f && Mathf.Abs(q.x)<.13f)
                        output.AppendLine("NECK_EDGE "+a+" "+b+" p="+p.ToString("F6")+" q="+q.ToString("F6"));
                }
            }
            for (int i=0;i<vertices.Length;i++)
            {
                Vector3 p=prefab.transform.InverseTransformPoint(skin.transform.TransformPoint(vertices[i]));
                if (p.y>1.40f && Mathf.Abs(p.x)<.20f && p.z<.30f && p.z>-.30f)
                    output.AppendLine("TOP "+i+" p="+p.ToString("F6"));
            }
        }
        File.WriteAllText("jill-first-person-geometry-0761.txt",output.ToString());
        Debug.Log("JILL_FP_GEOMETRY_READ");
    }
}
