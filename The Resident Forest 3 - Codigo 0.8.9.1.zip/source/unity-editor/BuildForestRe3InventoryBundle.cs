using System;
using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public static class BuildForestRe3InventoryBundle
{
    const string Folder="Assets/LocalAssets/Re3Inventory";
    [Serializable] sealed class Geometry { public Part[] parts; }
    [Serializable] sealed class Part { public string name,material; public float[] positions,normals,uv; public int[] triangles; }
    [Serializable] sealed class Manifest { public Mat[] materials; }
    [Serializable] sealed class Mat { public string name,albedo,normal,metallicGloss,occlusion; public float[] color; }
    static Texture2D Texture(string path,bool normal,bool linear)
    {
        if (String.IsNullOrEmpty(path)) return null;
        TextureImporter importer=AssetImporter.GetAtPath(path) as TextureImporter;
        importer.textureType=normal ? TextureImporterType.NormalMap:TextureImporterType.Default;
        importer.sRGBTexture=!linear; importer.maxTextureSize=1024; importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
    }
    public static void Build()
    {
        AssetDatabase.Refresh(); Directory.CreateDirectory("Assets/Generated/Inventory"); AssetDatabase.Refresh();
        var geometry=JsonUtility.FromJson<Geometry>(File.ReadAllText(Folder+"/locker-mesh.json"));
        var manifest=JsonUtility.FromJson<Manifest>(File.ReadAllText(Folder+"/inventory-manifest.json"));
        var mats=new Dictionary<string,Material>();
        foreach (var row in manifest.materials)
        {
            var m=new Material(Shader.Find("Standard")); m.name=row.name;
            m.color=new Color(row.color[0],row.color[1],row.color[2],1);
            m.mainTexture=Texture(row.albedo,false,false);
            m.SetTexture("_BumpMap",Texture(row.normal,true,true)); m.EnableKeyword("_NORMALMAP");
            m.SetTexture("_MetallicGlossMap",Texture(row.metallicGloss,false,true)); m.EnableKeyword("_METALLICGLOSSMAP");
            m.SetFloat("_GlossMapScale",.65f); m.SetTexture("_OcclusionMap",Texture(row.occlusion,false,true));
            AssetDatabase.CreateAsset(m,"Assets/Generated/Inventory/"+row.name+".mat"); mats.Add(row.name,m);
        }
        var root=new GameObject("Re3ItemBox");
        foreach (var p in geometry.parts)
        {
            var mesh=new Mesh(); mesh.name=p.name;
            var positions=new Vector3[p.positions.Length/3]; var normals=new Vector3[positions.Length]; var uv=new Vector2[positions.Length];
            for (int i=0;i<positions.Length;i++)
            { positions[i]=new Vector3(p.positions[i*3],p.positions[i*3+1],p.positions[i*3+2]); normals[i]=new Vector3(p.normals[i*3],p.normals[i*3+1],p.normals[i*3+2]); uv[i]=new Vector2(p.uv[i*2],p.uv[i*2+1]); }
            mesh.vertices=positions; mesh.normals=normals; mesh.uv=uv; mesh.triangles=p.triangles; mesh.RecalculateBounds(); mesh.RecalculateTangents();
            AssetDatabase.CreateAsset(mesh,"Assets/Generated/Inventory/"+p.name+".asset");
            var part=new GameObject(p.name); part.transform.SetParent(root.transform,false);
            part.AddComponent<MeshFilter>().sharedMesh=mesh; part.AddComponent<MeshRenderer>().sharedMaterial=mats[p.material];
        }
        string prefabPath="Assets/Generated/Inventory/Re3ItemBox.prefab";
        PrefabUtility.CreatePrefab(prefabPath,root,ReplacePrefabOptions.ReplaceNameBased);
        UnityEngine.Object.DestroyImmediate(root); AssetDatabase.SaveAssets();
        foreach (var space in new[] {ColorSpace.Gamma,ColorSpace.Linear})
        {
            PlayerSettings.colorSpace=space;
            string suffix=space==ColorSpace.Linear ? "linear":"gamma";
            string destination="Assets/AssetBundles/Inventory/"+suffix; Directory.CreateDirectory(destination);
            var build=new AssetBundleBuild { assetBundleName="forest-re3-inventory",assetNames=new[] {prefabPath} };
            if (BuildPipeline.BuildAssetBundles(destination,new[] {build},BuildAssetBundleOptions.ForceRebuildAssetBundle,BuildTarget.StandaloneWindows64)==null)
                throw new InvalidOperationException("Inventory bundle failed");
        }
        Debug.Log("[ForestRE3] INVENTORY_BUNDLES_READY originalRE3Locker=true");
    }
}
