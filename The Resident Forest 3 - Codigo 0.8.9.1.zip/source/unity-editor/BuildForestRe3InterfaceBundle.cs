using System;
using System.IO;
using UnityEngine;
using UnityEditor;
public static class BuildForestRe3InterfaceBundle
{
    public static void Build()
    {
        const string folder="Assets/LocalAssets/Re3Interface/";
        AssetDatabase.Refresh();
        string[] names={"inventory-atlas.png","inventory-gradients.png","ammo-atlas.png","reticle-atlas.png","RE3Interface.otf","RE3Ammo.otf"};
        var paths=new string[names.Length];
        for(int i=0;i<names.Length;i++)
        {
            paths[i]=folder+names[i];
            if(names[i].EndsWith(".png"))
            {
                var importer=(TextureImporter)AssetImporter.GetAtPath(paths[i]);
                importer.textureType=TextureImporterType.Default;importer.sRGBTexture=true;
                importer.mipmapEnabled=false;importer.alphaIsTransparency=true;
                importer.textureCompression=TextureImporterCompression.Uncompressed;
                importer.maxTextureSize=1024;importer.SaveAndReimport();
            }
            else if(AssetDatabase.LoadAssetAtPath<Font>(paths[i])==null)throw new InvalidOperationException("Original RE3 font import failed: "+paths[i]);
        }
        const string dest="Assets/AssetBundles/Interface";Directory.CreateDirectory(dest);
        var build=new AssetBundleBuild{assetBundleName="forest-re3-interface",assetNames=paths};
        if(BuildPipeline.BuildAssetBundles(dest,new[]{build},BuildAssetBundleOptions.ForceRebuildAssetBundle,BuildTarget.StandaloneWindows64)==null)
            throw new InvalidOperationException("Original interface bundle failed");
        Debug.Log("[ForestRE3] ORIGINAL_INTERFACE_READY fonts=2 atlases=4");
    }
}
