Shader "ForestRE3/Preview Hair"
{
    Properties
    {
        _Color ("Color", Color) = (1,1,1,1)
        _MainTex ("Albedo and opacity", 2D) = "white" {}
        _Cutoff ("Alpha cutoff", Range(0,1)) = 0.15
        _BumpMap ("Normal", 2D) = "bump" {}
        _BumpScale ("Normal strength", Float) = 1
        _MetallicGlossMap ("Metallic and smoothness", 2D) = "white" {}
        _Glossiness ("Smoothness", Range(0,1)) = 0.3
        _GlossMapScale ("Smoothness map scale", Range(0,1)) = 0.45
        _Metallic ("Metallic", Range(0,1)) = 0
        _OcclusionMap ("Occlusion", 2D) = "white" {}
        _OcclusionStrength ("Occlusion strength", Range(0,1)) = 1
    }
    SubShader
    {
        Tags { "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
        Cull Off
        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows addshadow alphatest:_Cutoff
        #pragma target 3.0
        #pragma shader_feature _NORMALMAP
        #pragma shader_feature _METALLICGLOSSMAP
        #include "UnityStandardUtils.cginc"
        sampler2D _MainTex, _BumpMap, _MetallicGlossMap, _OcclusionMap;
        fixed4 _Color;
        half _BumpScale, _Glossiness, _GlossMapScale, _Metallic, _OcclusionStrength;
        struct Input { float2 uv_MainTex; float2 uv_BumpMap; };
        void surf(Input IN, inout SurfaceOutputStandard o)
        {
            fixed4 c = tex2D(_MainTex, IN.uv_MainTex) * _Color;
            o.Albedo = c.rgb;
            o.Alpha = c.a;
            #ifdef _NORMALMAP
                o.Normal = UnpackScaleNormal(tex2D(_BumpMap, IN.uv_BumpMap), _BumpScale);
            #endif
            #ifdef _METALLICGLOSSMAP
                fixed4 data = tex2D(_MetallicGlossMap, IN.uv_MainTex);
                o.Metallic = data.r;
                o.Smoothness = data.a * _GlossMapScale;
            #else
                o.Metallic = _Metallic;
                o.Smoothness = _Glossiness;
            #endif
            o.Occlusion = lerp(1.0, tex2D(_OcclusionMap, IN.uv_MainTex).g, _OcclusionStrength);
            o.Emission = 0;
        }
        ENDCG
    }
    FallBack "Transparent/Cutout/VertexLit"
}
