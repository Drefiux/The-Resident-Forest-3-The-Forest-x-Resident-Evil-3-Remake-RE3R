Shader "ForestRE3/First Person Lit"
{
    Properties
    {
        _Color ("Color", Color) = (1,1,1,1)
        _MainTex ("Albedo", 2D) = "white" {}
        _BumpMap ("Normal", 2D) = "bump" {}
        _BumpScale ("Normal strength", Float) = 1
        _MetallicGlossMap ("Metallic smoothness", 2D) = "white" {}
        _Metallic ("Metallic", Range(0,1)) = 0
        _Glossiness ("Smoothness", Range(0,1)) = 0.3
        _GlossMapScale ("Smoothness map scale", Range(0,1)) = 1
        _OcclusionMap ("Occlusion", 2D) = "white" {}
        _OcclusionStrength ("Occlusion strength", Range(0,1)) = 1
        _Cutoff ("Alpha cutoff", Range(0,1)) = 0.5
        _FPCutout ("Cutout enabled", Float) = 0
        _FPClipRadius ("Eye safety radius", Float) = 0
        _FPClipScale ("Part safety multiplier", Float) = 1
        _FPEye ("Eye world position", Vector) = (0,0,0,0)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        Cull Back
        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows
        #pragma target 3.0
        #pragma multi_compile __ _NORMALMAP
        #pragma multi_compile __ _METALLICGLOSSMAP
        #include "UnityStandardUtils.cginc"
        sampler2D _MainTex, _BumpMap, _MetallicGlossMap, _OcclusionMap;
        fixed4 _Color;
        float4 _FPEye;
        half _BumpScale, _Metallic, _Glossiness, _GlossMapScale, _OcclusionStrength, _Cutoff, _FPCutout;
        float _FPClipRadius, _FPClipScale;
        struct Input { float2 uv_MainTex; float2 uv_BumpMap; float3 worldPos; };
        void surf(Input IN, inout SurfaceOutputStandard o)
        {
            clip(distance(IN.worldPos,_FPEye.xyz)-_FPClipRadius*_FPClipScale);
            fixed4 c=tex2D(_MainTex,IN.uv_MainTex)*_Color;
            if (_FPCutout>.5) clip(c.a-_Cutoff);
            o.Albedo=c.rgb; o.Alpha=1;
            #ifdef _NORMALMAP
                o.Normal=UnpackScaleNormal(tex2D(_BumpMap,IN.uv_BumpMap),_BumpScale);
            #endif
            #ifdef _METALLICGLOSSMAP
                fixed4 m=tex2D(_MetallicGlossMap,IN.uv_MainTex);
                o.Metallic=m.r; o.Smoothness=m.a*_GlossMapScale;
            #else
                o.Metallic=_Metallic; o.Smoothness=_Glossiness;
            #endif
            o.Occlusion=lerp(1,tex2D(_OcclusionMap,IN.uv_MainTex).g,_OcclusionStrength);
            o.Emission=0;
        }
        ENDCG
    }
    FallBack Off
}
