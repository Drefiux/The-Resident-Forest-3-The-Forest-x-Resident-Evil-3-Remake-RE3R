﻿/*  
 *  ModAPI
 *  Copyright (C) 2015 FluffyFish / Philipp Mohrenstecher
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 *  To contact me you can e-mail me at info@fluffyfish.de
 */

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ModAPI.Components
{
    /// <summary>
    /// Interaktionslogik für Scale9.xaml
    /// </summary>
    public class Scale9 : ContentControl
    {
        public static readonly DependencyProperty NormalSourceProperty =
            DependencyProperty.Register("NormalSource", typeof(BitmapSource), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));
        public static readonly DependencyProperty HoverSourceProperty = DependencyProperty.Register("HoverSource", typeof(BitmapSource), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));
        public static readonly DependencyProperty ActiveSourceProperty =
            DependencyProperty.Register("ActiveSource", typeof(BitmapSource), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));
        public static readonly DependencyProperty SelectedNormalSourceProperty =
            DependencyProperty.Register("SelectedNormalSource", typeof(BitmapSource), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));
        public static readonly DependencyProperty SelectedHoverSourceProperty =
            DependencyProperty.Register("SelectedHoverSource", typeof(BitmapSource), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));
        public static readonly DependencyProperty SelectedActiveSourceProperty =
            DependencyProperty.Register("SelectedActiveSource", typeof(BitmapSource), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));

        public static readonly DependencyProperty NormalOpacityProperty = DependencyProperty.Register("NormalOpacity", typeof(Double), typeof(Scale9), new PropertyMetadata(1.0, OnPropertyChanged));
        public static readonly DependencyProperty HoverOpacityProperty = DependencyProperty.Register("HoverOpacity", typeof(Double), typeof(Scale9), new PropertyMetadata(0.0, OnPropertyChanged));
        public static readonly DependencyProperty ActiveOpacityProperty = DependencyProperty.Register("ActiveOpacity", typeof(Double), typeof(Scale9), new PropertyMetadata(0.0, OnPropertyChanged));

        public static readonly DependencyProperty InnerPaddingProperty =
            DependencyProperty.Register("InnerPadding", typeof(Thickness), typeof(Scale9), new PropertyMetadata(new Thickness(), OnPropertyChanged));
        public static readonly DependencyProperty BorderProperty = DependencyProperty.Register("Border", typeof(Thickness), typeof(Scale9), new PropertyMetadata(new Thickness(), OnPropertyChanged));
        public static readonly DependencyProperty BorderSizeProperty = DependencyProperty.Register("BorderSize", typeof(Thickness), typeof(Scale9),
            new PropertyMetadata(new Thickness(-1, -1, -1, -1), OnPropertyChanged));
        public static readonly DependencyProperty OverflowProperty = DependencyProperty.Register("Overflow", typeof(Thickness), typeof(Scale9),
            new PropertyMetadata(new Thickness(), OnPropertyChanged));
        public static readonly DependencyProperty ContentOffsetProperty =
            DependencyProperty.Register("ContentOffset", typeof(Point), typeof(Scale9), new PropertyMetadata(new Point(0, 0), OnPropertyChanged));

        public static readonly DependencyProperty InnerContentProperty = DependencyProperty.Register("InnerContent", typeof(object), typeof(Scale9), new PropertyMetadata(null, OnPropertyChanged));
        public static readonly DependencyProperty BlendNormalProperty = DependencyProperty.Register("BlendNormal", typeof(bool), typeof(Scale9), new PropertyMetadata(false, OnPropertyChanged));
        public static readonly DependencyProperty SelectedProperty = DependencyProperty.Register("Selected", typeof(bool), typeof(Scale9), new PropertyMetadata(false, OnPropertyChanged));

        public static readonly DependencyProperty TextColorProperty = DependencyProperty.Register("TextColor", typeof(Color), typeof(Scale9),
            new PropertyMetadata(Colors.Transparent, OnPropertyChanged));
        public static readonly DependencyProperty SelectedTextColorProperty =
            DependencyProperty.Register("SelectedTextColor", typeof(Color), typeof(Scale9), new PropertyMetadata(Colors.Transparent, OnPropertyChanged));

        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (var i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    var child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (var childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        public static void OnPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var myControl = (Scale9)sender;
            if ((e.Property.Name == "Selected" || e.Property.Name == "HoverOpacity" || e.Property.Name == "ActiveOpacity") && myControl.BlendNormal)
            {
                if (myControl.BaseNormalOpacity == 0.0)
                {
                    myControl.BaseNormalOpacity = myControl.NormalOpacity;
                }
                double newNormalOpacity = 1.0f;
                if ((!myControl.Selected && myControl.HoverSource != null) || (myControl.Selected && myControl.SelectedHoverSource != null))
                {
                    newNormalOpacity -= myControl.HoverOpacity;
                }
                if ((!myControl.Selected && myControl.ActiveSource != null) || (myControl.Selected && myControl.SelectedActiveSource != null))
                {
                    newNormalOpacity -= myControl.ActiveOpacity;
                }

                myControl.NormalOpacity = myControl.BaseNormalOpacity * newNormalOpacity;
            }
            if (e.Property.Name == "TextColor" || e.Property.Name == "SelectedTextColor" || e.Property.Name == "Selected")
            {
                var et = FindVisualChildren<TextBlock>(sender);

                foreach (var t in et)
                {
                    try
                    {
                        //if (t.Foreground == null || !(t.Foreground is SolidColorBrush))
                        if (myControl.Selected)
                        {
                            if (myControl.SelectedTextColor != Colors.Transparent && myControl.SelectedTextColor != Color.FromArgb(0, 255, 255, 255))
                            {
                                t.Foreground = new SolidColorBrush(myControl.SelectedTextColor);
                            }
                        }
                        else
                        {
                            if (myControl.TextColor != Colors.Transparent && myControl.TextColor != Color.FromArgb(0, 255, 255, 255))
                            {
                                t.Foreground = new SolidColorBrush(myControl.TextColor);
                            }
                        }
                        //(t.Foreground as SolidColorBrush).Color = myControl.TextColor;
                    }
                    catch (Exception)
                    {
                    }
                }
            }
            if (myControl.TemplateApplied && e.Property.Name == "Selected")
            {
                myControl.Refresh();
            }
        }

        public Rectangle NormalTopLeftRect;
        public Rectangle NormalTopRect;
        public Rectangle NormalTopRightRect;
        public Rectangle NormalLeftRect;
        public Rectangle NormalCenterRect;
        public Rectangle NormalRightRect;
        public Rectangle NormalBottomLeftRect;
        public Rectangle NormalBottomRect;
        public Rectangle NormalBottomRightRect;

        public Rectangle HoverTopLeftRect;
        public Rectangle HoverTopRect;
        public Rectangle HoverTopRightRect;
        public Rectangle HoverLeftRect;
        public Rectangle HoverCenterRect;
        public Rectangle HoverRightRect;
        public Rectangle HoverBottomLeftRect;
        public Rectangle HoverBottomRect;
        public Rectangle HoverBottomRightRect;

        public Rectangle ActiveTopLeftRect;
        public Rectangle ActiveTopRect;
        public Rectangle ActiveTopRightRect;
        public Rectangle ActiveLeftRect;
        public Rectangle ActiveCenterRect;
        public Rectangle ActiveRightRect;
        public Rectangle ActiveBottomLeftRect;
        public Rectangle ActiveBottomRect;
        public Rectangle ActiveBottomRightRect;

        public Rectangle SelectedNormalTopLeftRect;
        public Rectangle SelectedNormalTopRect;
        public Rectangle SelectedNormalTopRightRect;
        public Rectangle SelectedNormalLeftRect;
        public Rectangle SelectedNormalCenterRect;
        public Rectangle SelectedNormalRightRect;
        public Rectangle SelectedNormalBottomLeftRect;
        public Rectangle SelectedNormalBottomRect;
        public Rectangle SelectedNormalBottomRightRect;

        public Rectangle SelectedHoverTopLeftRect;
        public Rectangle SelectedHoverTopRect;
        public Rectangle SelectedHoverTopRightRect;
        public Rectangle SelectedHoverLeftRect;
        public Rectangle SelectedHoverCenterRect;
        public Rectangle SelectedHoverRightRect;
        public Rectangle SelectedHoverBottomLeftRect;
        public Rectangle SelectedHoverBottomRect;
        public Rectangle SelectedHoverBottomRightRect;

        public Rectangle SelectedActiveTopLeftRect;
        public Rectangle SelectedActiveTopRect;
        public Rectangle SelectedActiveTopRightRect;
        public Rectangle SelectedActiveLeftRect;
        public Rectangle SelectedActiveCenterRect;
        public Rectangle SelectedActiveRightRect;
        public Rectangle SelectedActiveBottomLeftRect;
        public Rectangle SelectedActiveBottomRect;
        public Rectangle SelectedActiveBottomRightRect;

        public ImageBrush NormalTopLeft;
        public ImageBrush NormalTop;
        public ImageBrush NormalTopRight;
        public ImageBrush NormalLeft;
        public ImageBrush NormalCenter;
        public ImageBrush NormalRight;
        public ImageBrush NormalBottomLeft;
        public ImageBrush NormalBottom;
        public ImageBrush NormalBottomRight;

        public ImageBrush HoverTopLeft;
        public ImageBrush HoverTop;
        public ImageBrush HoverTopRight;
        public ImageBrush HoverLeft;
        public ImageBrush HoverCenter;
        public ImageBrush HoverRight;
        public ImageBrush HoverBottomLeft;
        public ImageBrush HoverBottom;
        public ImageBrush HoverBottomRight;

        public ImageBrush ActiveTopLeft;
        public ImageBrush ActiveTop;
        public ImageBrush ActiveTopRight;
        public ImageBrush ActiveLeft;
        public ImageBrush ActiveCenter;
        public ImageBrush ActiveRight;
        public ImageBrush ActiveBottomLeft;
        public ImageBrush ActiveBottom;
        public ImageBrush ActiveBottomRight;

        public ImageBrush SelectedNormalTopLeft;
        public ImageBrush SelectedNormalTop;
        public ImageBrush SelectedNormalTopRight;
        public ImageBrush SelectedNormalLeft;
        public ImageBrush SelectedNormalCenter;
        public ImageBrush SelectedNormalRight;
        public ImageBrush SelectedNormalBottomLeft;
        public ImageBrush SelectedNormalBottom;
        public ImageBrush SelectedNormalBottomRight;

        public ImageBrush SelectedHoverTopLeft;
        public ImageBrush SelectedHoverTop;
        public ImageBrush SelectedHoverTopRight;
        public ImageBrush SelectedHoverLeft;
        public ImageBrush SelectedHoverCenter;
        public ImageBrush SelectedHoverRight;
        public ImageBrush SelectedHoverBottomLeft;
        public ImageBrush SelectedHoverBottom;
        public ImageBrush SelectedHoverBottomRight;

        public ImageBrush SelectedActiveTopLeft;
        public ImageBrush SelectedActiveTop;
        public ImageBrush SelectedActiveTopRight;
        public ImageBrush SelectedActiveLeft;
        public ImageBrush SelectedActiveCenter;
        public ImageBrush SelectedActiveRight;
        public ImageBrush SelectedActiveBottomLeft;
        public ImageBrush SelectedActiveBottom;
        public ImageBrush SelectedActiveBottomRight;

        public ColumnDefinition LeftColumn;
        public ColumnDefinition RightColumn;
        public RowDefinition TopRow;
        public RowDefinition BottomRow;

        public Rectangle MouseRect;
        public ContentControl ContentElement;
        public bool TemplateApplied;

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            FindChilds();

            var et = FindVisualChildren<TextBlock>(this);

            foreach (var t in et)
            {
                try
                {
                    //if (t.Foreground == null || !(t.Foreground is SolidColorBrush))
                    if (Selected)
                    {
                        if (SelectedTextColor != Colors.Transparent && SelectedTextColor != Color.FromArgb(0, 255, 255, 255))
                        {
                            t.Foreground = new SolidColorBrush(SelectedTextColor);
                        }
                    }
                    else
                    {
                        if (TextColor != Colors.Transparent && TextColor != Color.FromArgb(0, 255, 255, 255))
                        {
                            t.Foreground = new SolidColorBrush(TextColor);
                        }
                    }
                    //(t.Foreground as SolidColorBrush).Color = myControl.TextColor;
                }
                catch (Exception)
                {
                }
            }

            Refresh();
            TemplateApplied = true;
        }

        public void FindChilds()
        {
            TopRow = (RowDefinition)GetTemplateChild("TopRow");
            BottomRow = (RowDefinition)GetTemplateChild("BottomRow");
            LeftColumn = (ColumnDefinition)GetTemplateChild("LeftColumn");
            RightColumn = (ColumnDefinition)GetTemplateChild("RightColumn");

            MouseRect = (Rectangle)GetTemplateChild("MouseRect");
            ContentElement = (ContentControl)GetTemplateChild("ContentElement");

            NormalTopLeftRect = (Rectangle)GetTemplateChild("NormalTopLeftRect");
            NormalTopRect = (Rectangle)GetTemplateChild("NormalTopRect");
            NormalTopRightRect = (Rectangle)GetTemplateChild("NormalTopRightRect");
            NormalLeftRect = (Rectangle)GetTemplateChild("NormalLeftRect");
            NormalCenterRect = (Rectangle)GetTemplateChild("NormalCenterRect");
            NormalRightRect = (Rectangle)GetTemplateChild("NormalRightRect");
            NormalBottomLeftRect = (Rectangle)GetTemplateChild("NormalBottomLeftRect");
            NormalBottomRect = (Rectangle)GetTemplateChild("NormalBottomRect");
            NormalBottomRightRect = (Rectangle)GetTemplateChild("NormalBottomRightRect");

            HoverTopLeftRect = (Rectangle)GetTemplateChild("HoverTopLeftRect");
            HoverTopRect = (Rectangle)GetTemplateChild("HoverTopRect");
            HoverTopRightRect = (Rectangle)GetTemplateChild("HoverTopRightRect");
            HoverLeftRect = (Rectangle)GetTemplateChild("HoverLeftRect");
            HoverCenterRect = (Rectangle)GetTemplateChild("HoverCenterRect");
            HoverRightRect = (Rectangle)GetTemplateChild("HoverRightRect");
            HoverBottomLeftRect = (Rectangle)GetTemplateChild("HoverBottomLeftRect");
            HoverBottomRect = (Rectangle)GetTemplateChild("HoverBottomRect");
            HoverBottomRightRect = (Rectangle)GetTemplateChild("HoverBottomRightRect");

            ActiveTopLeftRect = (Rectangle)GetTemplateChild("ActiveTopLeftRect");
            ActiveTopRect = (Rectangle)GetTemplateChild("ActiveTopRect");
            ActiveTopRightRect = (Rectangle)GetTemplateChild("ActiveTopRightRect");
            ActiveLeftRect = (Rectangle)GetTemplateChild("ActiveLeftRect");
            ActiveCenterRect = (Rectangle)GetTemplateChild("ActiveCenterRect");
            ActiveRightRect = (Rectangle)GetTemplateChild("ActiveRightRect");
            ActiveBottomLeftRect = (Rectangle)GetTemplateChild("ActiveBottomLeftRect");
            ActiveBottomRect = (Rectangle)GetTemplateChild("ActiveBottomRect");
            ActiveBottomRightRect = (Rectangle)GetTemplateChild("ActiveBottomRightRect");

            SelectedNormalTopLeftRect = (Rectangle)GetTemplateChild("SelectedNormalTopLeftRect");
            SelectedNormalTopRect = (Rectangle)GetTemplateChild("SelectedNormalTopRect");
            SelectedNormalTopRightRect = (Rectangle)GetTemplateChild("SelectedNormalTopRightRect");
            SelectedNormalLeftRect = (Rectangle)GetTemplateChild("SelectedNormalLeftRect");
            SelectedNormalCenterRect = (Rectangle)GetTemplateChild("SelectedNormalCenterRect");
            SelectedNormalRightRect = (Rectangle)GetTemplateChild("SelectedNormalRightRect");
            SelectedNormalBottomLeftRect = (Rectangle)GetTemplateChild("SelectedNormalBottomLeftRect");
            SelectedNormalBottomRect = (Rectangle)GetTemplateChild("SelectedNormalBottomRect");
            SelectedNormalBottomRightRect = (Rectangle)GetTemplateChild("SelectedNormalBottomRightRect");

            SelectedHoverTopLeftRect = (Rectangle)GetTemplateChild("SelectedHoverTopLeftRect");
            SelectedHoverTopRect = (Rectangle)GetTemplateChild("SelectedHoverTopRect");
            SelectedHoverTopRightRect = (Rectangle)GetTemplateChild("SelectedHoverTopRightRect");
            SelectedHoverLeftRect = (Rectangle)GetTemplateChild("SelectedHoverLeftRect");
            SelectedHoverCenterRect = (Rectangle)GetTemplateChild("SelectedHoverCenterRect");
            SelectedHoverRightRect = (Rectangle)GetTemplateChild("SelectedHoverRightRect");
            SelectedHoverBottomLeftRect = (Rectangle)GetTemplateChild("SelectedHoverBottomLeftRect");
            SelectedHoverBottomRect = (Rectangle)GetTemplateChild("SelectedHoverBottomRect");
            SelectedHoverBottomRightRect = (Rectangle)GetTemplateChild("SelectedHoverBottomRightRect");

            SelectedActiveTopLeftRect = (Rectangle)GetTemplateChild("SelectedActiveTopLeftRect");
            SelectedActiveTopRect = (Rectangle)GetTemplateChild("SelectedActiveTopRect");
            SelectedActiveTopRightRect = (Rectangle)GetTemplateChild("SelectedActiveTopRightRect");
            SelectedActiveLeftRect = (Rectangle)GetTemplateChild("SelectedActiveLeftRect");
            SelectedActiveCenterRect = (Rectangle)GetTemplateChild("SelectedActiveCenterRect");
            SelectedActiveRightRect = (Rectangle)GetTemplateChild("SelectedActiveRightRect");
            SelectedActiveBottomLeftRect = (Rectangle)GetTemplateChild("SelectedActiveBottomLeftRect");
            SelectedActiveBottomRect = (Rectangle)GetTemplateChild("SelectedActiveBottomRect");
            SelectedActiveBottomRightRect = (Rectangle)GetTemplateChild("SelectedActiveBottomRightRect");

            NormalTopLeft = (ImageBrush)GetTemplateChild("NormalTopLeft");
            NormalTop = (ImageBrush)GetTemplateChild("NormalTop");
            NormalTopRight = (ImageBrush)GetTemplateChild("NormalTopRight");
            NormalLeft = (ImageBrush)GetTemplateChild("NormalLeft");
            NormalCenter = (ImageBrush)GetTemplateChild("NormalCenter");
            NormalRight = (ImageBrush)GetTemplateChild("NormalRight");
            NormalBottomLeft = (ImageBrush)GetTemplateChild("NormalBottomLeft");
            NormalBottom = (ImageBrush)GetTemplateChild("NormalBottom");
            NormalBottomRight = (ImageBrush)GetTemplateChild("NormalBottomRight");

            HoverTopLeft = (ImageBrush)GetTemplateChild("HoverTopLeft");
            HoverTop = (ImageBrush)GetTemplateChild("HoverTop");
            HoverTopRight = (ImageBrush)GetTemplateChild("HoverTopRight");
            HoverLeft = (ImageBrush)GetTemplateChild("HoverLeft");
            HoverCenter = (ImageBrush)GetTemplateChild("HoverCenter");
            HoverRight = (ImageBrush)GetTemplateChild("HoverRight");
            HoverBottomLeft = (ImageBrush)GetTemplateChild("HoverBottomLeft");
            HoverBottom = (ImageBrush)GetTemplateChild("HoverBottom");
            HoverBottomRight = (ImageBrush)GetTemplateChild("HoverBottomRight");

            ActiveTopLeft = (ImageBrush)GetTemplateChild("ActiveTopLeft");
            ActiveTop = (ImageBrush)GetTemplateChild("ActiveTop");
            ActiveTopRight = (ImageBrush)GetTemplateChild("ActiveTopRight");
            ActiveLeft = (ImageBrush)GetTemplateChild("ActiveLeft");
            ActiveCenter = (ImageBrush)GetTemplateChild("ActiveCenter");
            ActiveRight = (ImageBrush)GetTemplateChild("ActiveRight");
            ActiveBottomLeft = (ImageBrush)GetTemplateChild("ActiveBottomLeft");
            ActiveBottom = (ImageBrush)GetTemplateChild("ActiveBottom");
            ActiveBottomRight = (ImageBrush)GetTemplateChild("ActiveBottomRight");

            SelectedNormalTopLeft = (ImageBrush)GetTemplateChild("SelectedNormalTopLeft");
            SelectedNormalTop = (ImageBrush)GetTemplateChild("SelectedNormalTop");
            SelectedNormalTopRight = (ImageBrush)GetTemplateChild("SelectedNormalTopRight");
            SelectedNormalLeft = (ImageBrush)GetTemplateChild("SelectedNormalLeft");
            SelectedNormalCenter = (ImageBrush)GetTemplateChild("SelectedNormalCenter");
            SelectedNormalRight = (ImageBrush)GetTemplateChild("SelectedNormalRight");
            SelectedNormalBottomLeft = (ImageBrush)GetTemplateChild("SelectedNormalBottomLeft");
            SelectedNormalBottom = (ImageBrush)GetTemplateChild("SelectedNormalBottom");
            SelectedNormalBottomRight = (ImageBrush)GetTemplateChild("SelectedNormalBottomRight");

            SelectedHoverTopLeft = (ImageBrush)GetTemplateChild("SelectedHoverTopLeft");
            SelectedHoverTop = (ImageBrush)GetTemplateChild("SelectedHoverTop");
            SelectedHoverTopRight = (ImageBrush)GetTemplateChild("SelectedHoverTopRight");
            SelectedHoverLeft = (ImageBrush)GetTemplateChild("SelectedHoverLeft");
            SelectedHoverCenter = (ImageBrush)GetTemplateChild("SelectedHoverCenter");
            SelectedHoverRight = (ImageBrush)GetTemplateChild("SelectedHoverRight");
            SelectedHoverBottomLeft = (ImageBrush)GetTemplateChild("SelectedHoverBottomLeft");
            SelectedHoverBottom = (ImageBrush)GetTemplateChild("SelectedHoverBottom");
            SelectedHoverBottomRight = (ImageBrush)GetTemplateChild("SelectedHoverBottomRight");

            SelectedActiveTopLeft = (ImageBrush)GetTemplateChild("SelectedActiveTopLeft");
            SelectedActiveTop = (ImageBrush)GetTemplateChild("SelectedActiveTop");
            SelectedActiveTopRight = (ImageBrush)GetTemplateChild("SelectedActiveTopRight");
            SelectedActiveLeft = (ImageBrush)GetTemplateChild("SelectedActiveLeft");
            SelectedActiveCenter = (ImageBrush)GetTemplateChild("SelectedActiveCenter");
            SelectedActiveRight = (ImageBrush)GetTemplateChild("SelectedActiveRight");
            SelectedActiveBottomLeft = (ImageBrush)GetTemplateChild("SelectedActiveBottomLeft");
            SelectedActiveBottom = (ImageBrush)GetTemplateChild("SelectedActiveBottom");
            SelectedActiveBottomRight = (ImageBrush)GetTemplateChild("SelectedActiveBottomRight");
        }

        public double BaseNormalOpacity;

        public Double NormalOpacity
        {
            get => (Double)GetValue(NormalOpacityProperty);
            set => SetValue(NormalOpacityProperty, value);
        }

        public Double HoverOpacity
        {
            get => (Double)GetValue(HoverOpacityProperty);
            set => SetValue(HoverOpacityProperty, value);
        }

        public Color TextColor
        {
            get => (Color)GetValue(TextColorProperty);
            set => SetValue(TextColorProperty, value);
        }

        public Color SelectedTextColor
        {
            get => (Color)GetValue(SelectedTextColorProperty);
            set => SetValue(SelectedTextColorProperty, value);
        }

        public bool BlendNormal
        {
            get => (bool)GetValue(BlendNormalProperty);
            set => SetValue(BlendNormalProperty, value);
        }

        public bool Selected
        {
            get => (bool)GetValue(SelectedProperty);
            set => SetValue(SelectedProperty, value);
        }

        public Double ActiveOpacity
        {
            get => (Double)GetValue(ActiveOpacityProperty);
            set => SetValue(ActiveOpacityProperty, value);
        }

        public object InnerContent
        {
            get => GetValue(InnerContentProperty);
            set => SetValue(InnerContentProperty, value);
        }

        public BitmapSource NormalSource
        {
            get => GetValue(NormalSourceProperty) as BitmapSource;
            set => SetValue(NormalSourceProperty, value);
        }

        public BitmapSource HoverSource
        {
            get => GetValue(HoverSourceProperty) as BitmapSource;
            set => SetValue(HoverSourceProperty, value);
        }

        public BitmapSource ActiveSource
        {
            get => GetValue(ActiveSourceProperty) as BitmapSource;
            set => SetValue(ActiveSourceProperty, value);
        }

        public BitmapSource SelectedNormalSource
        {
            get => GetValue(SelectedNormalSourceProperty) as BitmapSource;
            set => SetValue(SelectedNormalSourceProperty, value);
        }

        public BitmapSource SelectedHoverSource
        {
            get => GetValue(SelectedHoverSourceProperty) as BitmapSource;
            set => SetValue(SelectedHoverSourceProperty, value);
        }

        public BitmapSource SelectedActiveSource
        {
            get => GetValue(SelectedActiveSourceProperty) as BitmapSource;
            set => SetValue(SelectedActiveSourceProperty, value);
        }

        public Point ContentOffset
        {
            get => (Point)GetValue(ContentOffsetProperty);
            set => SetValue(ContentOffsetProperty, value);
        }

        public Thickness Border
        {
            get => (Thickness)GetValue(BorderProperty);
            set => SetValue(BorderProperty, value);
        }

        public Thickness BorderSize
        {
            get => (Thickness)GetValue(BorderSizeProperty);
            set => SetValue(BorderSizeProperty, value);
        }

        public Thickness InnerPadding
        {
            get => (Thickness)GetValue(InnerPaddingProperty);
            set => SetValue(InnerPaddingProperty, value);
        }

        public Thickness Overflow
        {
            get => (Thickness)GetValue(OverflowProperty);
            set => SetValue(OverflowProperty, value);
        }

        /*static Scale9()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Scale9), new FrameworkPropertyMetadata(typeof(Scale9)));
        }*/

        /*protected ColumnDefinition LeftColumn;
        protected ColumnDefinition CenterColumn;
        protected ColumnDefinition RightColumn;
        protected RowDefinition TopRow;
        protected RowDefinition CenterRow;
        protected RowDefinition BottomRow;
        protected ImageBrush TopLeft;
        protected ImageBrush Top;
        protected ImageBrush TopRight;
        protected ImageBrush Left;
        protected ImageBrush Center;
        protected ImageBrush Right;
        protected ImageBrush BottomLeft;
        protected ImageBrush Bottom;
        protected ImageBrush BottomRight;
        protected Rectangle TopLeftRect;
        protected Rectangle TopRect;
        protected Rectangle TopRightRect;
        protected Rectangle LeftRect;
        protected Rectangle CenterRect;
        protected Rectangle RightRect;
        protected Rectangle BottomLeftRect;
        protected Rectangle BottomRect;
        protected Rectangle BottomRightRect;*/

        public void Refresh()
        {
            if (MouseRect == null)
            {
                return;
            }
            Margin = new Thickness(-Overflow.Left, -Overflow.Top, -Overflow.Right, -Overflow.Bottom);
            MouseRect.Margin = Overflow;

            var borderTop = BorderSize.Top;
            if (borderTop < 0)
            {
                borderTop = Border.Top;
            }
            if (borderTop < 0)
            {
                borderTop = 0;
            }

            var borderLeft = BorderSize.Left;
            if (borderLeft < 0)
            {
                borderLeft = Border.Left;
            }
            if (borderLeft < 0)
            {
                borderLeft = 0;
            }

            var borderRight = BorderSize.Right;
            if (borderRight < 0)
            {
                borderRight = Border.Right;
            }
            if (borderRight < 0)
            {
                borderRight = 0;
            }

            var borderBottom = BorderSize.Bottom;
            if (borderBottom < 0)
            {
                borderBottom = Border.Bottom;
            }
            if (borderBottom < 0)
            {
                borderBottom = 0;
            }

            TopRow.Height = new GridLength(borderTop);
            //CenterRow.Height = new GridLength(0, GridUnitType.Auto);
            BottomRow.Height = new GridLength(borderBottom);

            LeftColumn.Width = new GridLength(borderLeft);
            //CenterColumn.Width = new GridLength(0, GridUnitType.Auto);
            RightColumn.Width = new GridLength(borderRight);

            ContentElement.Margin = new Thickness(ContentOffset.X, ContentOffset.Y, 0, 0);

            var visibility = Visibility.Hidden;

            visibility = NormalSource == null || Selected ? Visibility.Collapsed : Visibility.Visible;
            NormalTopLeftRect.Visibility = borderLeft > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            NormalTopRect.Visibility = borderTop > 0 ? visibility : Visibility.Collapsed;
            NormalTopRightRect.Visibility = borderRight > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            NormalLeftRect.Visibility = borderLeft > 0 ? visibility : Visibility.Collapsed;
            NormalCenterRect.Visibility = visibility;
            NormalRightRect.Visibility = borderRight > 0 ? visibility : Visibility.Collapsed;
            NormalBottomLeftRect.Visibility = borderLeft > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;
            NormalBottomRect.Visibility = borderBottom > 0 ? visibility : Visibility.Collapsed;
            NormalBottomRightRect.Visibility = borderRight > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;

            visibility = HoverSource == null || Selected ? Visibility.Collapsed : Visibility.Visible;
            HoverTopLeftRect.Visibility = borderLeft > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            HoverTopRect.Visibility = borderTop > 0 ? visibility : Visibility.Collapsed;
            HoverTopRightRect.Visibility = borderRight > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            HoverLeftRect.Visibility = borderLeft > 0 ? visibility : Visibility.Collapsed;
            HoverCenterRect.Visibility = visibility;
            HoverRightRect.Visibility = borderRight > 0 ? visibility : Visibility.Collapsed;
            HoverBottomLeftRect.Visibility = borderLeft > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;
            HoverBottomRect.Visibility = borderBottom > 0 ? visibility : Visibility.Collapsed;
            HoverBottomRightRect.Visibility = borderRight > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;

            visibility = ActiveSource == null || Selected ? Visibility.Collapsed : Visibility.Visible;
            ActiveTopLeftRect.Visibility = borderLeft > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            ActiveTopRect.Visibility = borderTop > 0 ? visibility : Visibility.Collapsed;
            ActiveTopRightRect.Visibility = borderRight > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            ActiveLeftRect.Visibility = borderLeft > 0 ? visibility : Visibility.Collapsed;
            ActiveCenterRect.Visibility = visibility;
            ActiveRightRect.Visibility = borderRight > 0 ? visibility : Visibility.Collapsed;
            ActiveBottomLeftRect.Visibility = borderLeft > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;
            ActiveBottomRect.Visibility = borderBottom > 0 ? visibility : Visibility.Collapsed;
            ActiveBottomRightRect.Visibility = borderRight > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;

            visibility = SelectedNormalSource == null || !Selected ? Visibility.Collapsed : Visibility.Visible;
            SelectedNormalTopLeftRect.Visibility = borderLeft > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalTopRect.Visibility = borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalTopRightRect.Visibility = borderRight > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalLeftRect.Visibility = borderLeft > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalCenterRect.Visibility = visibility;
            SelectedNormalRightRect.Visibility = borderRight > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalBottomLeftRect.Visibility = borderLeft > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalBottomRect.Visibility = borderBottom > 0 ? visibility : Visibility.Collapsed;
            SelectedNormalBottomRightRect.Visibility = borderRight > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;

            visibility = SelectedActiveSource == null || !Selected ? Visibility.Collapsed : Visibility.Visible;
            SelectedActiveTopLeftRect.Visibility = borderLeft > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveTopRect.Visibility = borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveTopRightRect.Visibility = borderRight > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveLeftRect.Visibility = borderLeft > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveCenterRect.Visibility = visibility;
            SelectedActiveRightRect.Visibility = borderRight > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveBottomLeftRect.Visibility = borderLeft > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveBottomRect.Visibility = borderBottom > 0 ? visibility : Visibility.Collapsed;
            SelectedActiveBottomRightRect.Visibility = borderRight > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;

            visibility = SelectedHoverSource == null || !Selected ? Visibility.Collapsed : Visibility.Visible;
            SelectedHoverTopLeftRect.Visibility = borderLeft > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverTopRect.Visibility = borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverTopRightRect.Visibility = borderRight > 0 && borderTop > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverLeftRect.Visibility = borderLeft > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverCenterRect.Visibility = visibility;
            SelectedHoverRightRect.Visibility = borderRight > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverBottomLeftRect.Visibility = borderLeft > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverBottomRect.Visibility = borderBottom > 0 ? visibility : Visibility.Collapsed;
            SelectedHoverBottomRightRect.Visibility = borderRight > 0 && borderBottom > 0 ? visibility : Visibility.Collapsed;

            if (NormalSource != null)
            {
                NormalTopLeft.Viewbox = new Rect(0, 0, Border.Left, Border.Top);
                NormalTop.Viewbox = new Rect(Border.Left, 0, NormalSource.Width - Border.Left - Border.Right, Border.Top);
                NormalTopRight.Viewbox = new Rect(NormalSource.Width - Border.Right, 0, Border.Right, Border.Top);
                NormalLeft.Viewbox = new Rect(0, Border.Top, Border.Left, NormalSource.Height - Border.Top - Border.Bottom);
                NormalCenter.Viewbox = new Rect(Border.Left, Border.Top, NormalSource.Width - Border.Left - Border.Right, NormalSource.Height - Border.Top - Border.Bottom);
                NormalRight.Viewbox = new Rect(NormalSource.Width - Border.Right, Border.Top, Border.Right, NormalSource.Height - Border.Top - Border.Bottom);
                NormalBottomLeft.Viewbox = new Rect(0, NormalSource.Height - Border.Bottom, Border.Left, Border.Bottom);
                NormalBottom.Viewbox = new Rect(Border.Left, NormalSource.Height - Border.Bottom, NormalSource.Width - Border.Left - Border.Right, Border.Bottom);
                NormalBottomRight.Viewbox = new Rect(NormalSource.Width - Border.Right, NormalSource.Height - Border.Bottom, Border.Right, Border.Bottom);

                HoverTopLeft.Viewbox = NormalTopLeft.Viewbox;
                HoverTop.Viewbox = NormalTop.Viewbox;
                HoverTopRight.Viewbox = NormalTopRight.Viewbox;
                HoverLeft.Viewbox = NormalLeft.Viewbox;
                HoverCenter.Viewbox = NormalCenter.Viewbox;
                HoverRight.Viewbox = NormalRight.Viewbox;
                HoverBottomLeft.Viewbox = NormalBottomLeft.Viewbox;
                HoverBottom.Viewbox = NormalBottom.Viewbox;
                HoverBottomRight.Viewbox = NormalBottomRight.Viewbox;

                ActiveTopLeft.Viewbox = NormalTopLeft.Viewbox;
                ActiveTop.Viewbox = NormalTop.Viewbox;
                ActiveTopRight.Viewbox = NormalTopRight.Viewbox;
                ActiveLeft.Viewbox = NormalLeft.Viewbox;
                ActiveCenter.Viewbox = NormalCenter.Viewbox;
                ActiveRight.Viewbox = NormalRight.Viewbox;
                ActiveBottomLeft.Viewbox = NormalBottomLeft.Viewbox;
                ActiveBottom.Viewbox = NormalBottom.Viewbox;
                ActiveBottomRight.Viewbox = NormalBottomRight.Viewbox;

                SelectedNormalTopLeft.Viewbox = NormalTopLeft.Viewbox;
                SelectedNormalTop.Viewbox = NormalTop.Viewbox;
                SelectedNormalTopRight.Viewbox = NormalTopRight.Viewbox;
                SelectedNormalLeft.Viewbox = NormalLeft.Viewbox;
                SelectedNormalCenter.Viewbox = NormalCenter.Viewbox;
                SelectedNormalRight.Viewbox = NormalRight.Viewbox;
                SelectedNormalBottomLeft.Viewbox = NormalBottomLeft.Viewbox;
                SelectedNormalBottom.Viewbox = NormalBottom.Viewbox;
                SelectedNormalBottomRight.Viewbox = NormalBottomRight.Viewbox;

                SelectedHoverTopLeft.Viewbox = NormalTopLeft.Viewbox;
                SelectedHoverTop.Viewbox = NormalTop.Viewbox;
                SelectedHoverTopRight.Viewbox = NormalTopRight.Viewbox;
                SelectedHoverLeft.Viewbox = NormalLeft.Viewbox;
                SelectedHoverCenter.Viewbox = NormalCenter.Viewbox;
                SelectedHoverRight.Viewbox = NormalRight.Viewbox;
                SelectedHoverBottomLeft.Viewbox = NormalBottomLeft.Viewbox;
                SelectedHoverBottom.Viewbox = NormalBottom.Viewbox;
                SelectedHoverBottomRight.Viewbox = NormalBottomRight.Viewbox;

                SelectedActiveTopLeft.Viewbox = NormalTopLeft.Viewbox;
                SelectedActiveTop.Viewbox = NormalTop.Viewbox;
                SelectedActiveTopRight.Viewbox = NormalTopRight.Viewbox;
                SelectedActiveLeft.Viewbox = NormalLeft.Viewbox;
                SelectedActiveCenter.Viewbox = NormalCenter.Viewbox;
                SelectedActiveRight.Viewbox = NormalRight.Viewbox;
                SelectedActiveBottomLeft.Viewbox = NormalBottomLeft.Viewbox;
                SelectedActiveBottom.Viewbox = NormalBottom.Viewbox;
                SelectedActiveBottomRight.Viewbox = NormalBottomRight.Viewbox;
            }
        }
    }
}