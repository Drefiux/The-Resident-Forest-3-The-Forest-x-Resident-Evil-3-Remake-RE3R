[![English](https://img.shields.io/badge/English-🇺🇸-blue)](../README.md)
[![한국어](https://img.shields.io/badge/한국어-🇰🇷-red)](README.ko.md)
[![Deutsch](https://img.shields.io/badge/Deutsch-🇩🇪-black)](README.de.md)
[![Español](https://img.shields.io/badge/Español-🇪🇸-yellow)](README.es.md)
[![Français](https://img.shields.io/badge/Français-🇫🇷-blue)](README.fr.md)
[![Polski](https://img.shields.io/badge/Polski-🇵🇱-red)](README.pl.md)
[![Русский](https://img.shields.io/badge/Русский-🇷🇺-blue)](README.ru.md)
[![Italiano](https://img.shields.io/badge/Italiano-🇮🇹-green)](README.it.md)
[![日本語](https://img.shields.io/badge/日本語-🇯🇵-red)](README.jp.md)
[![Português](https://img.shields.io/badge/Português-🇵🇹-green)](README.pt.md)
[![Tiếng Việt](https://img.shields.io/badge/Tiếng%20Việt-🇻🇳-green)](README.vi.md)
[![简体中文](https://img.shields.io/badge/简体中文-🇨🇳-red)](README.zh-CN.md)
[![繁體中文](https://img.shields.io/badge/繁體中文-🇹🇼-blue)](README.zh-TW.md)

# ModAPI(v1) v2.0.9623 - 20260920

> オリジナル: FluffyFish / Philipp Mohrenstecher (ドイツ・エンゲルスキルヒェン)
> アップグレード: zzangae (大韓民国)

---

## 概要

ModAPIは**5つの公式サポートゲーム**のモッドを管理するデスクトップアプリケーションです。このアップグレード版には、マルチゲーム対応、全面的に再設計されたSettingsタブ、Steamパス設定、永続的なUI設定、動的フォントサイズシステム、ゲーム起動時の検証機能、Debug/Releaseビルド分離、そしてインゲームテストで検証された数多くのクラッシュ修正が含まれています。

---

## サポートゲーム

| ゲーム | エンジン | バージョン | Steam ID | 実行ファイル |
|---|---|---|---|---|
| The Forest | Unity 5 | v1.12 (VR) | 242760 | `TheForest.exe` |
| Subnautica | Unity | 2025パッチ | 264710 | `Subnautica.exe` |
| RAFT | Unity | v1.1.02 (ベータ) | 648800 | `Raft.exe` |
| Escape The Pacific | Unity 6 | v0.67.0.0 | 655290 | `EscapeThePacific.exe` |
| Green Hell | Unity 2019 | v2.9.5 | 763790 | `GH.exe` |

<details>
<summary><b>The Forest</b></summary>

| 項目 | 値 |
|---|---|
| エンジン | Unity 5 (Unity 4からアップグレード) |
| 最新バージョン | v1.12 (VR) |
| 最終更新 | 2019年9月11日 — VR対応パッチ；以降大型コンテンツ更新なし |
| 実行ファイル | `TheForest.exe` |
| データフォルダ | `TheForest_Data/Managed/` |
| Modsフォルダ | `mods/TheForest/` |
| プロジェクトフォルダ | `projects/TheForest/` |
| Steam App ID | `242760` |
| IL2CPP | ❌ Mono — 完全サポート |

The ForestはUnity 4からUnity 5へアップグレードされ、ビジュアルと物理演算が大幅に向上しました。2019年9月のVRパッチが最後の大型アップデートであり、以降は安定した完成状態を維持しているため、モッド制作に理想的です。
</details>

<details>
<summary><b>Subnautica</b></summary>

| 項目 | 値 |
|---|---|
| エンジン | Unity (2022年にBelow Zeroと統合コードベース化) |
| 最新バージョン | 2025パッチ (v18810395) |
| 最終更新 | 2025年8月12日 — モバイル版リリースに伴うバグ修正およびパフォーマンス改善 |
| 実行ファイル | `Subnautica.exe` |
| データフォルダ | `Subnautica_Data/Managed/` |
| Modsフォルダ | `mods/Subnautica/` |
| プロジェクトフォルダ | `projects/Subnautica/` |
| Steam App ID | `264710` |
| IL2CPP | ❌ Mono — サポート |

元々Unity 5をベースにリリースされたSubnauticaは、2022年末の「Living Large」アップデート(v2.0)でBelow Zeroとエンジンコードベースを統合し、最適化と安定性が向上しました。備考: 続編の*Subnautica 2*はUnreal Engine 5を使用します。

> **v2.0.9610でXMLを再作成**: `XGamingRuntime.dll`、`XblPCSandbox.dll`、`FMODUnity.dll`、`Newtonsoft.Json.dll`、`Unity.InputSystem.dll`、`Unity.Collections.dll`、`Unity.Burst.dll`が`copyAssembly`に追加されました。
</details>

<details>
<summary><b>RAFT</b></summary>

| 項目 | 値 |
|---|---|
| エンジン | Unity |
| 最新バージョン | v1.1.02 (ベータ) / v1.09 (安定版) |
| 最終更新 | 2026年3月 — ベータブランチで音声チャットおよびマルチプレイヤーのバグ修正 |
| 実行ファイル | `Raft.exe` |
| データフォルダ | `Raft_Data/Managed/` |
| Modsフォルダ | `mods/Raft/` |
| プロジェクトフォルダ | `projects/Raft/` |
| Steam App ID | `648800` |
| IL2CPP | ❌ Mono — サポート |
| Versions.xml | `1.1.01` (チェックサム含む) |

v1.0 *The Final Chapter*で公式ストーリーが完結した後も、ネットワークコードの改善と安定性のためのパッチが継続されています。2026年3月のベータブランチアップデートで音声チャットおよびマルチプレイヤーの問題が修正されました。
</details>

<details>
<summary><b>Escape The Pacific</b></summary>

| 項目 | 値 |
|---|---|
| エンジン | Unity 6 (2025年末にUnity 2021/2022から移行) |
| 最新バージョン | v0.67.0.0 |
| 最終更新 | 2025年6月26日 — 島の配置再設計とエンジン更新；2026年までホットフィックス継続中 |
| 実行ファイル | `EscapeThePacific.exe` |
| データフォルダ | `EscapeThePacific_Data/Managed/` |
| Modsフォルダ | `mods/EscapeThePacific/` |
| プロジェクトフォルダ | `projects/EscapeThePacific/` |
| IL2CPP | ❌ Mono — サポート |

2025年末に主要システムの再設計とUnity 6への移行を完了し、より動的な環境が実現されました。ゲームは現在アーリーアクセスとして開発が進行中です。

> **v2.0.9610でXMLを再作成**: `extends="GenericUnityGame"`を削除；`includeAssembly`を`Assembly-CSharp.dll`のみに設定 — `Assembly-CSharp-firstpass.dll`の継承エラーを防止。
</details>

<details>
<summary><b>Green Hell</b></summary>

| 項目 | 値 |
|---|---|
| エンジン | Unity 2019 |
| 最新バージョン | v2.9.5 |
| 最終更新 | 2026年2月4日 — Steam Deck最適化およびテキスト可読性の改善 |
| 実行ファイル | `GH.exe` |
| データフォルダ | `GH_Data/Managed/` |
| Modsフォルダ | `mods/GH/` |
| プロジェクトフォルダ | `projects/GH/` |
| Steam App ID | `763790` |
| IL2CPP | ❌ Mono — サポート |
| Versions.xml | `2.9.5` (チェックサム含む) |

ゲームのライフサイクルを通じてUnity 2017 → 2018 → 2019と開発されました。2026年2月のホットフィックスはSteam Deck互換性とUI可読性に重点が置かれました。

> **v2.0.9610でXMLを再作成**: `AmplifyBloom.dll`、`AmplifyColor.dll`、`AmplifyMotion.dll`、`com.rlabrecque.steamworks.net.dll`、`Unity.ProBuilder.dll`、`Unity.Postprocessing.Runtime.dll`を追加；存在しない`DOTweenPro.dll`を削除。
</details>

---

<details>
<summary><b>アーキテクチャ</b></summary>

### ランタイム分離

| コンポーネント | 対象 | ランタイム | 理由 |
|---|---|---|---|
| `ModAPI.exe` | .NET Framework 4.8 | Windows .NET 4.8 | デスクトップアプリケーション、最新API完全対応 |
| `ModAPI_Shared.dll` | .NET Framework 4.8 | Windows .NET 4.8 | 共有ライブラリ |
| `BaseModLib.dll` | .NET Framework 3.5 | Game Mono 2.0 | **恒久固定** — PEヘッダーが`v2.0.50727`を示す必要あり |
| Mod DLL (ユーザー) | .NET Framework 4.8 | Game Mono 2.0 (パッチ済み) | 4.8でビルド、Apply時にPEヘッダーをパッチ |

### 開発者ツール

プロジェクト管理用の独立したWPFユーティリティです。エンドユーザーには配布されません。

| ツール | プロジェクト | 目的 |
|---|---|---|
| `MODAPI_VersionTool.exe` | `VersionTool\MODAPI_VersionTool.csproj` | `AssemblyInfo.cs`および`App.xaml.cs`のバージョンを同時更新 |
| `MODAPI_LangTool.exe` | `LangTool\MODAPI_LangTool.csproj` | 言語ファイル管理 — 追加、編集、無効化、内蔵切り替え |

**VersionTool — バージョン管理**

ワンクリックでバージョン番号を更新できる独立WPFツールです。

- 現在のバージョンを自動表示 (`App.xaml.cs`から読み取り)
- 新しいバージョンを入力し**Apply Version**をクリックすると両方のファイルを同時更新
- 形式検証: `X.X.XXXX`形式のみ許可

| ファイル | パス | 変更内容 |
|---|---|---|
| `AssemblyInfo.cs` | `ModAPI\Properties\` | `AssemblyVersion`、`AssemblyFileVersion` |
| `App.xaml.cs` | `ModAPI\` | `public static string Version` |

**LangTool — 言語システム**

```
resources/langs/langs.json          ← 言語レジストリ (builtin / active フラグ)
resources/langs/Language.XX.xaml    ← 言語別翻訳キー
resources/langs/Language.XX.png     ← 国旗画像 (36×24、flagcdn.com/h24/ 提供)
```

内蔵切り替えの流れ (Updateボタン):
```
builtin: false → true (langs.json)
  → CreateDefaultLangsJson() 再作成 (LangTool\MainWindow.xaml.cs)
  → Language.XX.xaml 登録 (ModAPI\ModAPI.csproj)
  → 次回ビルド: 言語が完全に内蔵され、オフラインで使用可能
```

### Debug / Release ビルド分離

すべてのファイル検証およびアセンブリ処理は、`#if DEBUG` / `#else`によるビルド構成で分岐します。

| 箇所 | Debugビルド | Releaseビルド |
|---|---|---|
| `CheckSteam()` | `File.Exists()`のみ — ダミーファイルも通過 | `FileValidator.IsValidSteamExe()` — PEヘッダー + 最小1 MB |
| `CheckGamePath()` | `File.Exists()`のみ — ダミーファイルも通過 | `FileValidator.IsValidAssemblyDll()` — PEヘッダー + CLRメタデータ + 最小8 KB |
| `ModLib.Create()` — IncludeAssemblies | `File.Copy()` — Cecil解析を省略 | 完全なMono.Cecil解析 + IL修正 + `module.Write()` |
| `ModLib.Create()` — ファイル未検出 | 警告ログを出力してスキップ、継続 | エラーログを出力し、ポップアップとともに中断 |

**Debugテスト**では`create_dummy_Debug_games.ps1`を使用して、`bin\Debug\dummy_games\`、`bin\Debug\dummy_steam\`、`bin\Debug\gamefiles\original\`配下に0バイトのダミーファイルを生成します。これらのファイルは`File.Exists()`検査を通過し、実際のゲームをインストールせずに全UIワークフローのテストが可能です。

**Releaseビルド**では`FileValidator` (PEヘッダー + .NET CLRメタデータ検証)を適用し、0バイトファイル、テキストファイル、任意のバイナリを拒否します。有効なWindows実行ファイルと.NETアセンブリのみが通過します。

### FileValidator — PEヘッダー検証

`ModAPI_Shared\Utils\FileValidator.cs` — Releaseビルドでのみ適用されます。

| メソッド | 検査項目 | 最小サイズ |
|---|---|---|
| `IsValidSteamExe(path)` | MZ署名 + PE\0\0署名 | 1 MB |
| `IsValidGameExe(path)` | MZ署名 + PE\0\0署名 | 512 KB |
| `IsValidAssemblyDll(path)` | MZ + PE\0\0 + CLRメタデータヘッダー (データディレクトリ #14) | 8 KB |

```
検査されるPEヘッダーのレイアウト:
[0x00] 4D 5A          ← "MZ" DOS署名
[0x3C] XX XX XX XX   ← PEヘッダーオフセット (リトルエンディアン)
[offset] 50 45 00 00 ← "PE\0\0" 署名
[Optional Header → DataDirectory[14]] RVA+Size != 0 ← .NET CLRヘッダーの存在
```

### アセンブリ再マッピングパイプライン

```
[Modデベロッパーが.NET 4.8でビルド]
  → Mod DLL: PEヘッダー v4.0.30319、mscorlib 4.0.0.0

[ModAPI Apply — ModProject.cs]
  → AssemblyVersionMap.RemapAllReferences(modModule)
      mscorlib 4.0.0.0 → 2.0.0.0 など
  → modModule.RuntimeVersion = "v2.0.50727"
      PEヘッダー: v4.0.30319 → v2.0.50727

[Game Mono 2.0]
  → PEヘッダー承認 ✅  →  参照解決 ✅
```

### アセンブリリゾルバーフォールバック

```
1. gamefiles/original/{GameId}/{AssemblyPath}   ← バックアップフォルダ
2. {ActualGameInstallPath}/{AssemblyPath}        ← ゲームインストールフォルダ (フォールバック)
```

### C# 7.3 機能サポート

| 機能 | 状態 | 備考 |
|---|---|---|
| パターンマッチング (`is`, `switch`) | ✅ | インゲーム検証済み |
| 文字列補間 (`$""`) | ✅ | インゲーム検証済み |
| `out`変数インライン | ✅ | インゲーム検証済み |
| `async` / `await` | ✅ | AsyncBridge + System.Threadingポリフィル経由 |
| タプル (`ValueTuple`) | ❌ ハード制限 | Mono 2.0 `mscorlib` ABI — 回避策なし |
</details>

<details>
<summary><b>テーマシステム [詳細リファレンス](v2.0.9613_themes_en.md)</b></summary>

v2.0.9613より、テーマ選択UIがSettingsタブから専用の**Themesタブ**へ移動されました。新しいテーマの追加は`App.xaml.cs`辞書に1行追加するだけで完了します。

| インデックス | ID | ファイル | パレット |
|---|---|---|---|
| 0 | `classic` | `Dictionary.xaml`のみ | オリジナルModAPIテクスチャ背景 |
| 1 | `light` | `FluentStylesLight.xaml` | 明るいトーン + 青のアクセントカラー |
| 2 | `dark` | `FluentStyles.xaml` | 暗いトーン + 青のアクセントカラー (デフォルト) |
| 3 | `diablo` | `FluentStylesDiablo.xaml` | 赤 + 黒 |
| 4 | `nebula` | `FluentStylesNebula.xaml` | 暗い宇宙 |
| 5 | `sunset` | `FluentStylesSunset.xaml` | 明るい夕焼け |
| 6 | `ocean` | `FluentStylesOcean.xaml` | 暗い海 |
| 7 | `nordic` | `FluentStylesNordic.xaml` | 明るいノルディック |
| 8 | `citrus` | `FluentStylesCitrus.xaml` | 明るいシトラス |
| 9 | `bloom` | `FluentStylesBloom.xaml` | 明るい花柄 |

テーマ変更時、アプリは自動的に再起動します。(`theme.cfg`に保存)

| テーマ | テーマ |
| :---: | :---: |
|**01. Classicテーマ**|**02. Lightテーマ**|
| ![01. Classic theme](https://github.com/user-attachments/assets/1f8866b2-1715-45b6-9ada-c550da6d14fc) | ![02. Light theme](https://github.com/user-attachments/assets/180bb717-d4a4-490d-8fd5-c32338ad338f) |
|**03. Darkテーマ**|**04. Diabloテーマ**|
| ![03. Dark theme](https://github.com/user-attachments/assets/577934f1-9962-4042-9595-023eecc12ab0) | ![04. Diablo theme](https://github.com/user-attachments/assets/7b32e134-d661-4493-b275-54b8c2c04abf) |
|**05. Nebulaテーマ**|**06. Sunsetテーマ**|
| ![05. Nebula theme](https://github.com/user-attachments/assets/e88b5162-58f6-460a-90a1-f26f2b589591) | ![06. Sunset theme](https://github.com/user-attachments/assets/12bb187c-0187-432e-8819-235abc68d149) |
|**07. Oceanテーマ**|**08. Nordicテーマ**|
| ![07. Ocean theme](https://github.com/user-attachments/assets/3be28095-8872-471a-b066-36c58585a0db) | ![08. Nordic theme](https://github.com/user-attachments/assets/b43a8183-5b43-41a0-ba59-f9a37cc44e2e) |
|**09. Citrusテーマ**|**10. Bloomテーマ**|
| ![09. Citrus theme](https://github.com/user-attachments/assets/1f971fdf-411a-4db4-9941-4c37f6567656) | ![10. Bloom theme](https://github.com/user-attachments/assets/5b8ed319-7947-4209-b85e-1caeacac39e8) |

### 背景テクスチャ

Themesタブの**背景テクスチャ**カードで画像を選択すると、アプリ全体の背景として適用されます。対応形式: `.png` / `.jpg` / `.jpeg`、最大50MB、4K解像度以下。画像はJPEG Q75で圧縮され、16バイトのマジックヘッダーとともに`resources\textures\ui_bg\bg.dat` (隠しファイル属性)として保存されます。SHA-256ハッシュで整合性を検証；改ざんが検出されると自動的にリセット + 警告ポップアップを表示。

背景が有効な場合、UIの透明度は2つのレイヤーで処理されます: レイヤー1 (MergedDictionariesオーバーレイ)は`{DynamicResource}`パネル用、レイヤー2 (WalkStyleBackgrounds)は`{StaticResource}`ベースのパネルに半透明を適用。

### フォントサイズシステム

| リソースキー | 基本値 | 説明 |
|---|---|---|
| `AppBaseFontSize` | 13 | 通常テキスト |
| `AppBaseHeaderFontSize` | 16 | ヘッダー、パネルタイトル |
| `AppBaseSmallFontSize` | 12 | 補助ラベル |
| `AppBaseTinyFontSize` | 10 | ヒントテキスト |
| `AppBaseLargeFontSize` | 20 | 大型表示テキスト |

### 永続UI設定 — `ui.cfg`

| キー | デフォルト | 説明 |
|-----|---------|-------------|
| `ModListWidth` | `150` | Modsタブのリスト幅 (px) |
| `ProjectListWidth` | `150` | Developmentタブのプロジェクトリスト幅 (px) |
| `AppFontSize` | `13` | グローバルUIフォントサイズ (px) |
| `AlwaysOnTop` | `false` | ウィンドウを常に最前面に表示 |
| `TexturePath` | *(なし)* | 背景テクスチャの元のファイル名 (表示用) |
| `TextureHash` | *(なし)* | 背景テクスチャのSHA-256ハッシュ |
| `TextureActive` | `false` | 背景テクスチャの有効化状態 |
| `GamePathReset_{GameId}` | *(なし)* | ゲームパスのリセットフラグ |
| `SteamPathReset` | *(なし)* | Steamパスのリセットフラグ |
</details>

<details>
<summary><b>プロジェクト構造</b></summary>

```
ModAPI/
├── App.xaml / App.xaml.cs              # ThemeRegistry, ThemeIds, ApplyTheme()
├── ui.cfg                               # 永続UI設定
├── theme.cfg                            # 現在のテーマ
├── Windows/
│   ├── MainWindow.xaml / .cs            # メインUI — 6つのタブ、テーマ、設定、Steamパス、
│   │                                    #   0バイトダウンロード保護、スライダーデバウンス、サイレント設定読み取り
│   └── SubWindows/
│       ├── SpecifyGamePath.xaml / .cs   # ゲームパスポップアップ (動的GameNameLabel)
│       ├── FirstSetup.xaml / .cs        # 初回起動セットアップ + デフォルト値初期化
│       └── (その他14個のSubWindows)
├── Themes/
│   ├── Dictionary.xaml                  # Classicテーマ
│   ├── FluentStyles.xaml                # Darkテーマ
│   ├── FluentStylesLight.xaml           # Lightテーマ
│   ├── FluentStylesDiablo.xaml          # Diabloテーマ
│   ├── FluentStylesNebula.xaml          # Nebulaテーマ
│   ├── FluentStylesSunset.xaml          # Sunsetテーマ
│   ├── FluentStylesOcean.xaml           # Oceanテーマ
│   ├── FluentStylesNordic.xaml          # Nordicテーマ
│   ├── FluentStylesCitrus.xaml          # Citrusテーマ
│   └── FluentStylesBloom.xaml           # Bloomテーマ
├── Data/
│   ├── Mod.cs                           # Modファイルの読み込み、LF/CRLFヘッダー解析、診断ログ
│   ├── ModLib.cs                        # BaseModLib生成 + 再マッピング (#if DEBUG分離)
│   ├── Models/
│   │   └── ModProject.cs                # プロジェクトの作成/ビルド/適用 + nullガード
│   ├── ViewModels/
│   │   ├── ModsViewModel.cs             # FilteredMods, SelectedModItem, SelectedGameFilter,
│   │   │                                #   破損したModの再試行防止
│   │   ├── ModViewModel.cs              # フォルダパスからGameIdを抽出
│   │   ├── ModProjectsViewModel.cs      # DispatcherTimer用のDispose()
│   │   └── SettingsViewModel.cs         # UseSteam/AutoUpdate/UpdateVersionsのデフォルトtrue
│   └── AssemblyVersionMap.cs            # Mono 2.0アセンブリバージョンマッピング (20個のアセンブリ)
├── Utils/
│   ├── CustomAssemblyResolver.cs        # 名前ベースのリゾルバー (キャッシュ付き)
│   └── MonoHelper.cs                    # Mono.Cecil IL ヘルパーユーティリティ
├── resources/
│   ├── langs/                           # 13言語ファイル + langs.json (v2.0.9620でLangTool.*キー追加)
│   └── textures/ui_bg/
│       └── bg.dat                       # 圧縮・セキュア処理された背景画像 (ランタイム生成)
└── configs/
    ├── games/
    │   ├── TheForest.xml
    │   ├── Subnautica.xml               # v2.0.9610で全面再作成
    │   ├── Raft.xml
    │   ├── EscapeThePacific.xml         # v2.0.9610で全面再作成
    │   ├── GH.xml                       # v2.0.9610で全面再作成
    │   ├── SonsOfTheForest.xml          # IL2CPP — 未サポート
    │   └── {GameId}/Versions.xml        # Raft, GH, Subnautica, EscapeThePacific
    └── UserConfiguration.xml

ModAPI_Shared/
├── Configurations/
│   └── Configuration.cs                 # silentパラメータ付きのGetPath/GetString/GetInt
├── Data/
│   ├── Game.cs                          # ApplyModsバックアップ自動生成、条件付きリゾルバー、
│   │                                    #   ゲームフォルダフォールバック、軽量コンストラクタ + ModLib初期化修正
│   └── ModLib.cs                        # #if DEBUG分離、IncludeAssemblies/CopyAssemblies用ゲームフォルダフォールバック
└── Utils/
    └── FileValidator.cs                 # PEヘッダー + CLRメタデータ検証 (Release専用、最小8 KB)

BaseModLib/
├── BaseModLib.csproj                    # .NET 3.5 + LangVersion 7.3
└── libs/polyfills/
    ├── AsyncBridge.dll
    └── System.Threading.dll

VersionTool/
├── MODAPI_VersionTool.csproj            # 独立WPFバージョン更新ツール
├── App.config
├── App.xaml / App.xaml.cs
├── MainWindow.xaml / .cs               # バージョン入力、Applyボタン、現在バージョン表示
└── Properties/
    ├── AssemblyInfo.cs
    ├── Resources.Designer.cs / .resx
    └── Settings.Designer.cs / .settings

LangTool/
├── MODAPI_LangTool.csproj               # 独立WPF言語管理ツール
├── App.xaml / App.xaml.cs              # 言語読み込み/切り替え、langtool.cfg
├── MainWindow.xaml / .cs               # メインUI — 言語リスト、編集パネル、パスセレクター
├── AddLanguageDialog.xaml / .cs        # ISO 3166-1国選択ComboBox
├── ModApiDialog.xaml / .cs             # ModAPIスタイルのカスタムダイアログ (情報/警告/確認/質問)
├── Models/
│   ├── LanguageEntry.cs                # 言語エントリーモデル (isoCode, langCode, builtin, active)
│   ├── LangsJson.cs                    # langs.jsonルートモデル
│   └── IsoCountry.cs                   # ComboBox用ISO国モデル
└── Helpers/
    ├── LangsJsonHelper.cs              # langs.jsonの読み書き
    ├── FlagDownloader.cs               # flagcdn.com h24 国旗ダウンロード
    ├── XamlGenerator.cs                # Language.XX.xamlの生成/保存/解析
    ├── MissingKeyDetector.cs           # 英語基準の欠落キー検出
    ├── IsoCountryList.cs               # ISO 3166-1全196か国リスト (オフライン)
    └── BuiltinCodeWriter.cs            # CreateDefaultLangsJson()再作成 + ModAPI.csproj登録

bin\Debug\                               # Debugテスト専用
├── create_dummy_Debug_games.ps1         # ダミーゲーム/Steam構造の生成
├── dummy_games\{GameId}\               # ダミーゲームインストールパス
├── dummy_steam\Steam.exe               # ダミーSteam実行ファイル
└── gamefiles\original\{GameId}\        # ModLib用ダミーバックアップパス
```

---

</details>

<details>
<summary><b>インストールと設定</b></summary>

### ステップ1 — 前提条件

| 項目 | 必須 |
|---|---|
| Windows 10 / 11 | ✅ |
| .NET Framework 4.8 | ✅ (Windows 11にはプリインストール済み；Windows 10は[ダウンロード](https://dotnet.microsoft.com/download/dotnet-framework/net48)) |
| Steam | 必須 — Settingsタブで設定が必要 |
| サポートされているゲーム1本以上 | 必須 — Settingsタブで設定が必要 |

### ステップ2 — ModAPIのインストール

1. GitHubから最新リリースをダウンロード
2. 任意のフォルダに解凍 (例: `C:\ModAPI\`)
3. `ModAPI.exe`を実行
4. 初回起動時に**Welcome**画面が表示されます — 設定を行い**Continue**をクリック

### ステップ3 — Steamパスの設定 (Settingsタブ)

1. **Settings**タブへ移動
2. **Steam Installation Path**項目を探す
3. **Browse**をクリック → `Steam.exe`を選択
4. **Save**をクリック

### ステップ4 — ゲームパスの設定 (Settingsタブ)

1. ゲームカードのヘッダーをクリックして展開
2. **Browse**をクリック → ゲームのルートフォルダを選択 (`.exe`がある場所)
3. **Save**をクリック

| ゲーム | 実行ファイル | パスの例 |
|---|---|---|
| The Forest | `TheForest.exe` | `C:\Steam\steamapps\common\The Forest\` |
| Subnautica | `Subnautica.exe` | `C:\Steam\steamapps\common\Subnautica\` |
| RAFT | `Raft.exe` | `C:\Steam\steamapps\common\Raft\` |
| Escape The Pacific | `EscapeThePacific.exe` | `C:\Steam\steamapps\common\Escape The Pacific\` |
| Green Hell | `GH.exe` | `C:\Steam\steamapps\common\Green Hell\` |

### ステップ5 — モッドのダウンロード (Downloadsタブ)

1. **Downloads**タブへ移動
2. ゲームフィルターからゲームを選択
3. モッドを閲覧または検索し、**Download**をクリック

> **オフライン**: `modapi.survivetheforest.net`から`.mod`ファイルを手動でダウンロードし、対応するフォルダに配置してください:

| ゲーム | フォルダ |
|---|---|
| The Forest | `mods/TheForest/` |
| Subnautica | `mods/Subnautica/` |
| RAFT | `mods/Raft/` |
| Escape The Pacific | `mods/EscapeThePacific/` |
| Green Hell | `mods/GH/` |

### ステップ6 — モッドの適用とゲーム起動 (Modsタブ)

1. **Mods**タブへ移動
2. **Game Filter**からゲームを選択 (列0)
3. **Mod List**で有効化するモッドにチェック (列1)
4. **Start Game**をクリック

ゲーム起動前に以下の検査が自動的に実行されます:

| # | 検査項目 | 失敗時のポップアップ |
|---|---|---|
| 1 | Steamパスの設定と有効性確認 | SteamNotFound |
| 2 | `mods/`フォルダのゲームがSettingsタブのゲームと一致 | GameModsMismatch |
| 3 | 最低1つのモッドが選択されている | NoModSelected |
| 4 | 複数ゲームのモッドが混在選択されていない | MixedGameMods |
| 5 | ゲームパスの設定と実行ファイルの存在確認 | GamePathNotSet / GameNotInstalled |

---

</details>

<details>
<summary><b>タブ概要</b></summary>

### Welcomeタブ
初回起動セットアップ画面 (タブインデックス0)。AutoUpdate、Steam接続、VersionsDataテーブルの設定を行います。2回目以降の起動ではコミュニティリンクとリリースノートを提供します。

### Modsタブ
主要なモッド管理ワークフロー — 3列レイアウト:

| 列 | 内容 |
|---|---|
| 列0 | Game Filter — 5つのサポートゲーム用のラジオボタン |
| 列1 | Mod List — バージョンピッカーと有効化チェックボックス付きのインストール済みモッド |
| 列2 | Information — 選択したモッドの詳細情報、説明、バージョン履歴 |

### Downloadsタブ
`modapi.survivetheforest.net`からモッドを閲覧しダウンロードします。

- **Game Filter**: TheForest / DedicatedServer / VR / Subnautica / RAFT / EscapeThePacific / GH
- **Category Filter**: 12カテゴリー (バグ修正、バランス調整、チート、…)
- **Search**: モッド名、説明、作者で検索
- **Offline mode**: サポートされている5つのゲームすべてに対するフォルダ案内を表示

### Developmentタブ
モッド開発ワークフロー — Game Filterパネル (列0)はサポートされている5つのゲームすべてを含みます。

- ゲームごとのモッドプロジェクトの作成、ビルド、適用
- 言語リソース管理
- 3段階の検証を伴うModLib生成 (Steam → プロジェクト → ゲームパス)
- 軽量な`Game`コンストラクタによる安全なゲーム切り替え (`Verify()`呼び出しなし)

### Themesタブ
テーマ選択と背景テクスチャ管理。

- **テーマ選択**: 10種類のテーマ (Classic, Light, Dark, Diablo, Nebula, Sunset, Ocean, Nordic, Citrus, Bloom)
- **背景テクスチャ**: アプリ全体の背景として画像を選択 (JPEG圧縮 + セキュア処理)
- 背景テクスチャが有効な場合、テーマ選択はロックされます

### Settingsタブ
集中管理型の設定 — 4行:

| 行 | 内容 |
|---|---|
| 0 | 言語 / フォントサイズ / 最大幅 / Mod List幅 / Project List幅 |
| 1 | VersionsData保持 / 自動更新 / Steam接続 / 常に最前面に表示 |
| 2 | Steam Installation Path (テキストボックス + Browse + Save + Reset) |
| 3 | Game Installation Paths — ゲームごとの展開可能なカード (テキストボックス + Browse + Save + Reset) |

---

</details>

<details>
<summary><b>Lang Tool</b></summary>

### MODAPI_LangTool (言語管理ツール)

ModAPIの言語ファイルを管理する独立したWPFツールです。`LangTool\MODAPI_LangTool.csproj`としてソリューションに追加されます。

**場所**: `LangTool\MODAPI_LangTool.csproj`

**主な機能**

| 機能 | 説明 |
|---|---|
| 言語リスト | `langs.json`内のすべての言語をステータスアイコン付きで表示 (🔒 内蔵 / 🚫 無効 / ✅ 有効) |
| 言語追加 | ISO 3166-1のComboBoxから国を選択 → `flagcdn.com/h24/{iso}.png`から国旗を自動ダウンロード → 英語テンプレートから`Language.XX.xaml`を自動生成 |
| 言語編集 | `isoCode` / `langCode`はロック；有効状態のときのみ`langName`および翻訳キーを編集可能 |
| 無効化 / 有効化 | `langs.json`の`active`フラグをトグル — ファイルは保持され、ModAPIのリストから非表示 |
| 更新 (内蔵切り替え) | `builtin: false` → `true`へ切り替え — 元に戻せない、2段階確認あり — ソースから`CreateDefaultLangsJson()`を自動再作成し、`ModAPI.csproj`に`Language.XX.xaml`を登録 |
| 欠落キー検出 | 英語基準と比較 — 欠落/空のキー数および翻訳進捗を表示 |
| 内蔵保護 | `builtin: true`の言語は読み取り専用 — 編集、無効化、更新不可 |
| 無効保護 | `active: false`の言語は再有効化するまで読み取り専用 |
| 言語UI | LangTool自体が13言語すべてのModAPI言語をサポート — 右上に国旗付きの言語セレクター |
| パス保存 | 選択したModAPIルートパスを`langtool.cfg`に保存 — 次回起動時に自動読み込み |
| カスタムダイアログ | すべてのポップアップにシステムのMessageBoxではなく、ModAPIスタイルのダークテーマ`ModApiDialog`を使用 |

**langs.jsonの構造**

```json
{
  "languages": [
    { "isoCode": "us", "langCode": "EN",    "langName": "English",   "builtin": true,  "active": true },
    { "isoCode": "kr", "langCode": "KR",    "langName": "한국어",     "builtin": true,  "active": true },
    { "isoCode": "gb", "langCode": "EN-GB", "langName": "English (UK)", "builtin": false, "active": true }
  ]
}
```

**国旗画像のルール**

```
ISOコード (小文字) → flagcdn.com/h24/{iso}.png → Language.{LANGCODE}.png
                                                  resources/langs/
```

**Updateボタンの動作**

非内蔵の有効な言語でUpdateボタンをクリックすると:

1. `langs.json` — `builtin: false` → `true`
2. `LangTool\MainWindow.xaml.cs` — 現在`builtin: true`の言語全体で`CreateDefaultLangsJson()`を再作成
3. `ModAPI\ModAPI.csproj` — `<Resource Include="resources\langs\Language.XX.xaml" />`を登録
4. 次回ビルド — 言語が完全に内蔵され、オフラインで使用可能

**追加された言語キー** (`Lang.LangTool.*`)

LangToolのUI文字列、ダイアログメッセージ、ステータステキストを含む53個の新規キーが13言語ファイル全体に追加されました。

---

</details>

<details>
<summary><b>Version Tool</b></summary>

### MODAPI_VersionTool (バージョン更新ツール)

ワンクリックでバージョン番号を更新できる独立WPFツールです。

**場所**: `VersionTool\MODAPI_VersionTool.csproj`

<img width="331" height="220" alt="Image" src="https://github.com/user-attachments/assets/1310a99b-d4ac-4baa-89c3-cd0640fbbe26" />

**機能**
- 現在のバージョンを自動表示 (`App.xaml.cs`から読み取り)
- 新しいバージョンを入力し**Apply Version**をクリックすると両方のファイルを同時更新
- 形式検証: `X.X.XXXX`形式のみ許可

**変更されるファイル**

| ファイル | パス | 変更内容 |
|---|---|---|
| `AssemblyInfo.cs` | `ModAPI\Properties\` | `AssemblyVersion`、`AssemblyFileVersion` |
| `App.xaml.cs` | `ModAPI\` | `public static string Version` |

**使い方**
1. `MODAPI_VersionTool.exe`を実行
2. 新しいバージョンを入力 (例: `2.0.9619`)
3. **Apply Version**をクリック
4. Visual StudioでModAPIソリューションをリビルド

**StatusBarのバージョン表示**

- `VersionLabel.Text`がハードコードされた説明子ではなく`App.Version`を参照するように変更
- VersionToolでバージョンを更新しリビルドすると、StatusBarに即座に反映されます

---

</details>

<details>
<summary><b>Log</b></summary>

### ロギングシステム — 2ファイル分離 (`ModAPI.log` / `ModAPI.detailed.log`)

開発者専用の診断ログは以前`#if DEBUG`に制限されていたため、ユーザーの問題解決に最も必要となるReleaseビルドで確認できないという問題がありました。これを2ファイルシステムに置き換えます:

| ファイル | 内容 |
|---|---|
| `ModAPI.log` | ユーザー向けの主要ログ — 従来と同じ形式で、以前より増加しない |
| `ModAPI.detailed.log` | Release/Debugに関係なく、すべてのログ呼び出しを常に記録 — ユーザー問い合わせ時の診断用 |

**`Debug.cs`** — `Log()`に`detailedOnly`パラメータが追加されました。`true`の場合、メッセージは`ModAPI.detailed.log`にのみ記録されます；既存のすべての`#if DEBUG`ブロックを完全に削除する代わりにこのフラグへ切り替えることで、Releaseでも常にdetailedファイルへ記録されます。結果として4段階の重大度体系が構成されます:

| 段階 | 意味 |
|---|---|
| Verbose (`detailedOnly: true`) | 反復的/機械的なトレース — タイプ別、ファイル別、メソッド別 |
| Notice | 人が読む流れ — 進行状況および成功メッセージ |
| Warning | 潜在的な問題、まだ失敗ではない |
| Error | 確実な失敗 |

**`ModAPI.log`を圧迫していたログノイズの発生箇所と`detailedOnly: true`への切り替え対象:**

| ファイル | `ModAPI.log`にあふれていた内容 |
|---|---|
| `ModsViewModel.cs` | 1秒ごとに繰り返される`FindMods()`のスキャン/スキップ/キューメッセージ |
| `Game.cs` | `UpdateVersions()`のTLS/URLトレース行、Cecilの型マッピング項目 |
| `ModLib.cs` | Cecilによる型/メソッド単位のアセンブリ処理 (`Validating`、`Processing`、`Changed ... accessibility`) — Green Hellのモッドビルド1回で数万行が出力され、`ModAPI.log`の容量の大半を占めていた主犯 |
| `Mod.cs` | モッド読み込みごとにモッドヘッダーXML全体をダンプ (`configuration.ToString()`) |

**チェックサム不一致ログ — 項目ごとから要約へ:** `Header.Verify()`は以前、互換性のない`InjectInto`/`AddMethod`/`AddField`/`AddClass`項目ごとに`Mismatched checksum at "..."`という行を1つずつ出力しており、1つの古いモッドから数十行出ることもありました。現在は`ModAPI.log`に単一のWarningレベルの要約のみが記録されます (例: `Mod "MarsarahMod" has 14 checksum mismatch(es). This usually means the mod is incompatible with the current game version. See ModAPI.detailed.log for the full list.`)。項目ごとの全リストは引き続き`ModAPI.detailed.log`で確認できます。

---

</details>

<details open>
<summary><b>v2.0.9623の変更点</b></summary>

## v2.0.9623の変更点

### アップデート確認と適用 — ランチャー方式、手動、非強制

初回起動ポップアップ(`FirstSetup`ウィンドウ)には元々**最新バージョンを維持**、**アップデート検索**、**Steam接続**の3つのオプションがありましたが、開発が一時保留になっていました。作業再開前に実際のコード状態を調査したところ、Steam接続と最新バージョンを維持はすでに完全に動作しており、アップデート検索(ModAPIの新バージョンがあるか確認する機能)だけが未完成でした — ダウンロード/インストールのパイプライン自体は存在していましたが、それを呼び出すコードがどこにもありませんでした。

**今回実装した内容:**

- **`Game.CheckForNewVersion(out releaseNotes)`**(`ModAPI_Shared\Data\Game.cs`)— GitHub Releases API(`/repos/{owner}/ModAPI/releases/latest`)を呼び出し、最新タグとリリースノート(`body`フィールド、新規依存関係を追加せず最小限のJSON文字列アンエスケープ処理でパース)を返します。`UpdateRepoOwner`は一般ユーザーには常に`FluffyFishGames`(運用リポジトリ)を指し、`--dev`フラグで起動したときのみメンテナーの開発用リポジトリに切り替わります — 設定タブの「開発者ログ」チェックボックスでは絶対に切り替わりません。このチェックボックスはクラッシュログの詳細度のためだけのものであり、ユーザーがログを有効にしただけで未検証のテストチャンネルに静かに移動させてはならないためです。
- **設定タブ**: 動作していなかった「アップデート検索」チェックボックスを廃止し、**アップデート**ボタン1つに置き換えました(バックグラウンドのトグルではなくランチャー方式)。ボタンを押すと新バージョンを確認し、存在すれば「今すぐ/後で」のような中間選択なしにすぐダウンロード→展開→適用の流れに進みます。
- **初回起動ポップアップ**: 機能していなかった「自動アップデート」オプションとその設定書き込みコードを削除しました。ポップアップはSteam接続と最新バージョンを維持の2つだけを尋ねます。
- **`OperationPending`ウィンドウ**にデフォルトで折りたたまれたリリースノート表示エリアと`Confirmed`イベントを追加しました。ダウンロード/展開が100%に達するとリリースノートが表示され「完了」ボタンが有効になります — このボタンを押すことで実際に`Updater.exe`が起動しModAPIが終了します(以前は展開完了と同時に自動的にこの処理が実行され、何が変わったか確認する機会がありませんでした)。`Updater.exe`自体(原作者のコード、変更なし)はModAPIの終了を待ってからファイルを上書きし、自動的に再起動します。
- ModAPIは旧バージョンだからといって実行をブロックしません — バージョン確認はユーザーが「アップデート」ボタンを押したときのみ実行され、起動時には一切割り込みません。一般的なゲームランチャーの強制アップデートゲートとは異なります。

### UI修正 — リリースノート欄が折り返されない問題

`OperationPending`進捗ウィンドウに新規追加したリリースノート欄は、当初は横スクロールが必要な1行だけで表示されていましたが、原因は2つ重なっていました:

1. `TextBox`の`HorizontalScrollBarVisibility`の既定値は`Hidden`であり`Disabled`ではありません — 明示的に`Disabled`にしない限り、WPFは`TextWrapping="Wrap"`を無視して行を際限なく伸ばし続けます。
2. すべてのポップアップウィンドウが使う`SubWindow`スタイルは`SizeToContent="WidthAndHeight"`(`FluentStyles.xaml`)なので、`*`グリッド列で伸びる領域には折り返しの基準となる固定幅がありません — 幅を明示的に指定する必要があります。

`ProgressBar.ActualWidth`にバインドした固定幅を与えて(進捗バーの右端に揃うように)解決し、`TextBox`の代わりに読み取り専用の`TextBlock`+`ScrollViewer`の組み合わせに変更しました(`TextBox`の`PART_ContentHost`の折り返し無視の問題を完全に回避)。背景もデフォルトでウィンドウの透明度を継承していたため`FluentCardBrush`で不透明に指定しました。ウィンドウを強制的に大きくするために入れていた手動の`Height +=`コードは`SizeToContent`と競合するだけなので削除しました — 領域が表示された瞬間にウィンドウが正しく自動で大きくなります。

### 実機検証(手動テスト、エンドツーエンド)

使い捨てのダミーリリースデータを使って、確認→ダウンロード→展開→完了確認→再起動までの全体フローを実際に動かし、原作者の`Updater.exe`(変更なし)を含めてすべて正常に動作することを確認しました。テスト中にわかった有用な事実が1つあります: `App.xaml.cs`はModAPI**自体の起動時**にすでに残っている`_update`フォルダを自分で先に処理(適用)してしまいます — そのため、ModAPIを起動する*前に*偽の`_update`フォルダをあらかじめ作っておく方式でテストすると、`Updater.exe`が見る前に静かに消費されてしまいます。`_update`フォルダは必ず**ModAPIがすでに起動している状態**で作成しないと、実際のダウンロードが埋める状況と同じ再現になりません。今後こうした問題を元の再起動ロジックに手を加えずに簡単に診断できるよう、`Updater.cs`にオプションの診断ログ(`Updater.diag.log`、try/catchで囲み通常ロジックと分離)を追加しました。

### 開発メモ — `--dev`での実行

`App.DevMode`(`ModAPI\App.xaml.cs`)は`--dev`コマンドライン引数で起動したときのみ`true`になります — 設定タブの「開発者ログ」チェックボックスとは別物であり、そのチェックボックスはログの詳細度にのみ影響を与えるべきで、それ以外の何か(例えばどのサーバー/リポジトリを参照するか)を左右してはいけません。

ローカルで`--dev`を使って実行するには:
- **Visual Studio(F5デバッグ)**: `ModAPI`プロジェクト → プロパティ → デバッグタブ → 「コマンドライン引数」に`--dev`を入力。
- **ビルド済みexe**: ターミナルから`ModAPI.exe --dev`で実行するか、ショートカットのリンク先(ターゲット)欄の末尾に`--dev`を追加。

### 「バージョンテーブル維持」チェックボックス — 実際に機能する状態になるまで無効化

`Game.Verify()`は、ゲームパスが有効な場合(`CheckGamePath()`が通過した場合)にのみ`VersionsData.Refresh()`(実際にバージョンテーブルをダウンロードする処理)に到達します — それ以外は早期リターンします。つまり、ゲームパスが未設定のまま「バージョンテーブル維持」をオンにしても静かに何も起きておらず、これは混乱の元でした(実際に手動テストで確認済み: ゲームパス未設定の状態でチェックボックスをオンにしても`[UpdateVersions]`ログが一行も出力されませんでした)。

`SettingsViewModel.CanUpdateVersionsTable`(`App.Game != null && App.Game.CheckGamePath()`)を追加し、チェックボックスの`IsEnabled`にバインドしました。ゲームパスの保存/リセット時、またはDevelopmentタブのゲームフィルターでゲームを切り替えるたびに再評価されます。無効時はホバーで理由を説明するツールチップが表示され、有効時はオンにすると何が起きるかを説明します。また韓国語ラベルを「最新버전 유지」(「最新バージョンを維持」)から「버전 테이블 유지」(「バージョンテーブルを維持」)に変更しました — 他のすべての言語はすでに「テーブル」という語を含んでいましたが、韓国語だけがこの語を欠いており、無関係な「アップデート」ボタンと混同されていました。

### 全体的な修正 — デフォルト(classic)テーマでツールチップにスタイルが無かった問題

今回追加した上記のツールチップは、アプリのテーマに合ったデザインではなく、素のシステムツールチップとして表示されていました。調べたところ、デフォルトの「classic」テーマではアプリ内のどのツールチップも一度もテストされていなかったことが判明しました: `FluentStyles*.xaml`(非デフォルトテーマ)にはそれぞれテーマ化された`ToolTip`スタイルが定義されていますが、`classic`は`Dictionary.xaml`のみを読み込み、そこには一切定義がありませんでした。`Dictionary.xaml`に対応する`ToolTip`スタイルを追加しました(背景を不透明にしています — このテーマの他の半透明カードブラシは背景画像の上に重ねる前提のため、フローティングのツールチップには適さないためです)。これによりデフォルトテーマ下でアプリ全体のツールチップが修正され、今回追加した分だけにとどまりません。

### 初回起動ポップアップの再設計

初回起動ポップアップはもはやSteam接続 / バージョンテーブル維持について一切尋ねません — どちらもすでにSettingsタブにあるため、ここで再度尋ねるのは冗長でした。代わりに、ポップアップはスクロール可能な「このバージョンの変更点」の要約を表示するようになりました。導入テキストとボタンも見直されました:

- Steam接続 / バージョンテーブル維持のチェックボックスとその説明は廃止され、代わりにリリースのハイライトを表示する固定幅のスクロールパネルが配置されました。
- Welcomeタブ自体の「환영합니다!」(「ようこそ!」)という見出しは、同じ名前のボタンに置き換えられました — クリックすると初回起動ポップアップをいつでも再度開けます(例: 現在のバージョンで何が変わったかを読み返すため)。この方法で再度開いた場合、ポップアップのボタンは「Continue」ではなく「閉じる」と表示され、初回セットアップを再実行せず(`SetupDone`の書き込みも`FirstSetupDone()`の呼び出しも行わない)、閉じてもアプリは終了しません(`FirstSetup`コンストラクタの`isReopen: true`がこれらすべてをゲーティングしています)。
- **クロステーマテストで発見したウィンドウサイズのバグ**: ポップアップの`SubWindow`スタイルは`AllowsTransparency="True"` + `WindowStyle="None"` + `SizeToContent="WidthAndHeight"`を組み合わせていますが、この組み合わせではWPFが自動サイズ計算時に`MaxWidth`を確実には尊重しません。`classic`では偶然問題なく見えていましたが、Diabloなど他のテーマでは大幅に幅が広くなりすぎ、テキストが折り返されずに切れて表示されていました。このウィンドウにローカルで`SizeToContent="Height"`を上書き指定することで修正しました(このポップアップのカードは設計上固定幅なので、幅の自動計算はそもそも不要でした) — これにより、テーマごとの個別パッチを必要とせず、すべてのテーマで同じようにレイアウトが修正されます。
- **可読性、`classic`テーマのみ**: `classic`の共有`NormalLabel`スタイル(白文字 + ドロップシャドウ、写真調の画像パネルの上に表示するテキスト向けに設計)は、このポップアップの単色`PanelCenter`カード背景の上では読みにくくなっていました。あらゆる場所で使われる共有スタイルに手を入れたり、他のすべてのテーマで見た目がおかしくなる色をハードコードしたりする代わりに、`App.GetCurrentTheme() == "classic"`のときだけ厳密にゲーティングされる`FirstSetup.ApplyClassicThemeTextFix()`を追加し、このポップアップ・このテーマの場合だけ影のない濃色の見た目に切り替えるようにしました。他のすべてのテーマは変更されず、引き続きそれぞれ既に正しい`NormalLabel`/`PanelCenter`の配色を使用します。

### ゲーム整合性チェック — ステップCが毎回のクリックでポップアップしなくなった

起動前の整合性チェックについて、ユーザーから実際の不満が報告されていました: デジタル署名なしで配布されているゲーム(Green Hellのようなインディータイトルでは一般的)の場合、「署名がありません」という警告ポップアップが**Start Gameをクリックするたびに毎回**表示され、実際には何も問題がないにもかかわらず、その都度手動で「続行」をクリックする必要がありました。署名がないというだけでは改ざんの証拠にはならないため、これは実質的な安全チェックというより単なる摩擦でした。

```mermaid
flowchart LR
    Start(["Start Gameをクリック"]) --> A{"A — PEヘッダー\nIsValidGameExe()"}
    A -- 失敗 --> ABlock["🛑 起動をブロック\nGameExeCorruptedポップアップ"]
    A -- 合格 --> B{"B — アセンブリチェックサム\nMD5 vs Versions.xml"}
    B -- 不一致 --> BBlock["🛑 起動をブロック\nGameAssemblyTamperedポップアップ"]
    B -- 一致 --> C{"C — デジタル署名\nHasDigitalSignature()"}
    C -- なし --> CLog["📝 ログのみ、ポップアップなし\n自動的に続行"]
    C -- あり --> CLog2["📝 ログのみ"]
    CLog --> Launch(["✅ ゲーム起動"])
    CLog2 --> Launch
```

- **A(PEヘッダー)**と**B(アセンブリチェックサム)**は変更なし — 実際の破損や改ざんは引き続き警告ポップアップとともに起動をブロックします(`NoProjectWarning`、アプリの他のすべてのポップアップと同様に共有`SubWindow`スタイルでテーマ化されており、有効なテーマに自動的に合わせられます)。
- **C(デジタル署名)**はどちらの方向でもポップアップや確認を表示しなくなりました — `Notice`レベルの1行をログに記録するだけです(`[Integrity] Game executable has no digital signature (not necessarily tampered — many games ship unsigned)`)。ゲームはそのまま起動します。これまで開いていた`GameIntegrityWarning`ポップアップクラスはどこからも呼び出されなくなりました(削除はせずそのまま残しています)。
- この図は、今後この検査の形について議論しやすくするためのものです — 例えばステップCを軽量な形で再導入する場合(プロンプトを完全に削除するのではなく「二度と表示しない」方式にすることも検討されましたが、ユーザーの方針により完全削除が採用されました)、上の図がその際の参照になります。

### Steam接続 — 自動検出されるパスと、手動編集のバグ

原作者の「Steam接続」機能が(ユーザーがSteamパスを選択できるようにする以外に)実際に何をしていたかを調べたところ、`Steam.exe -applaunch {AppId}`経由でゲームを起動する処理(オーバーレイ対応のため)と、`steam://validate/{AppId}`経由で破損ファイルを修復する処理もすでに実装済みで、今回は変更していないことがわかりました。

- 「Steam接続」がオンになった瞬間、`MainWindow.UseSteamCheckBox_Checked`がレジストリ(`HKEY_CURRENT_USER\Software\Valve\Steam`)から直接Steamパスを読み取り、自動的に入力します — これはSteamがどのドライブにインストールされていても(`C:`だけでなく)動作します。
- Steam接続がオンの間、手動パス操作コントロール(テキストボックス、Browse、Save、Reset)はパスが自動管理されるため無効化されるはずでした。**発見・修正したバグ**: それらのコントロールを含むコンテナGrid(`SteamAndGamePathsPanel`)は、コードビハインドで`DataContext`が設定されていませんでした — 設定されていたのは`Settings`と`SettingsCheckboxes`のみでした — そのため`{Binding CanEditSteamPathManually}`が静かに失敗し、既定の`IsEnabled="true"`のままになっていました。コントロールは見た目上は無効に見えても、Resetボタンは実際にはクリック可能なままでした。`SteamAndGamePathsPanel.DataContext = SettingsVm;`を他の2つと同様に明示的に設定して修正しました。
- 別件として、classicテーマ下ではアプリ全体で無効化されたコントロールに視覚的なフィードバックが全くありませんでした — `NormalButton`の`ControlTemplate`には`IsEnabled="False"`トリガーがありませんでした(Fluentテーマにはすでにありました)。classic全体で、無効時にボタンを40%の不透明度に暗くする対応するトリガーを追加しました。

### テーマシステムの統一 — ClassicとFluentのパリティ

「そもそも意味のある違いがないなら、なぜclassicをFluentテーマファミリーと別に維持する必要があるのか」という疑問をきっかけに、`Dictionary.xaml`(classic)と9個の`FluentStyles*.xaml`ファイルの明示的・暗黙的なスタイルすべてを比較する全数監査を実施しました。

- 実際に存在するギャップを発見: `Slider`(SettingsタブのMod List/Project List幅スライダーで使用)と`ComponentsInputs:MultilingualTextField`(Mod名/説明フィールドで使う言語フラグ+テキストのコンボ)はclassicにしか存在せず、Fluent側に相当するものがありませんでした — Fluentテーマ下ではこの2つのコントロールが静かにclassicのScale9画像スキンにフォールバックし、フラットなFluentの見た目が崩れていました。両方についてフラットな`DynamicResource`駆動の代替を新規作成し、共有ファイル**`ModAPI\Themes\FluentStylesShared.xaml`**にまとめ、`ResourceDictionary.MergedDictionaries`経由で9個の`FluentStyles*.xaml`すべてにマージしました — 色の調整が今後は9箇所ではなく1箇所で済むようになりました。
- 逆方向のギャップも発見: `GridSplitter`(`MainWindow.xaml`のMod List/Version Listの分割線)は9つのテーマすべてにFluentスタイルがありましたが、classicには存在せず、classic下ではOS標準の灰色スプリッターのまま表示されていました。`Dictionary.xaml`に対応するフラットスタイルを追加しました。
- その過程で本当に使われていないデッドコードも発見 — スタイルは定義されているが実際のUIではどこからも参照されていないもの: `PasswordBox`(`LoginWindow.xaml`でのみ使用されるが、そのウィンドウ自体がどこからもインスタンス化されていない — ログインシステムはv2.0.9400ですでに削除済み)、`Components:ModProjectButton`、4つのソーシャルログインボタンスタイル(`FacebookButton`/`TwitterButton`/`YoutubeButton`/`TwitchButton`)、そして`TimeSlider`/`TimeHorizontalSlider`/`TimeSliderThumbStyle`一式(おそらく実装されなかった昼夜サイクルスライダー)。プロジェクトの「原作者の作業を削除しない」という方針に従い、これらは一切削除せず、それぞれ未参照である理由を記したXMLコメントで囲んで、履歴から消えることなくファイルに残しました。
- ビルドに一切組み込まれていない使われていないファイルも2つ発見: `ModAPI\Windows\Dictionary.xaml`(リファクタリングの途中で作られた行き止まりの重複ファイルで、初期のコミットで作成されて以降`App.xaml`や`.csproj`から一度も参照されていない)と`ModAPI\Themes\FluentStylesClassic.xaml`(テーマシステムの初期プロトタイプ — 各テーマが専用ファイルを持つようになる前、`light`以外のすべてのテーマのフォールバックスキンだった名残で、そのフォールバックロジックが置き換えられた後に孤立)。両方ともgit履歴で原作者のコードとは無関係であることを確認済みのため、上記のデッドスタイルとは異なり、コメントアウトではなく完全に削除し、`.csproj`内で宙に浮いていた`FluentStylesClassic.xaml`の`<Page>`エントリも合わせて削除しました。
- classic自体の`Slider`は、古いScale9画像バーではなく、Fluent共有スタイルのフラットな見た目に合わせて再設計されました(同じ`Border`+`Track`構造で、classicの金/茶パレットに合わせて再配色: `#B8963E`のつまみ、半透明`#40FFFFFF`のトラック) — 旧実装(`SliderThumbStyle`、`SliderButtonStyle`、`HorizontalSlider`、`VerticalSlider`、および旧来の暗黙`Slider`スタイル)は同様に削除ではなくコメントアウトしました。

### Settingsタブの残りのチェックボックス向けON/OFFツールチップ

「ホバーで何をするか確認できる」というパターンを、「バージョンテーブル維持」から他の4つのSettingsタブのチェックボックス — **Steam接続**、**開発者ログ**、**起動時にログを初期化**、**常に最前面** — にも拡張しました。それぞれ自身のチェック状態に応じて異なるツールチップを表示し、オン/オフそれぞれで実際に何が起きるかを説明します(例: Steam接続の有効時のツールチップは、上記の自動パス検出とオーバーレイ対応について説明します)。新規言語キー8個 × 13言語。

### Welcomeポップアップ — リリースノートと同期した詳細な全文コンテンツ

「このバージョンの新機能」パネルは今回のセッション中に何段階か進化しました: 短い箇条書きの要約 → `Docs/RELEASE_NOTES_2.0.9623.md`に対応するセクションごとの詳細なまとめ(`TextBlock`はMarkdownを描画できないため、プレーンテキストの`■`/`▸`/`•`記号を使用)、13言語すべてに翻訳。この過程で関連する2つのレイアウトバグが見つかり、修正されました:

- スクロール可能なテキストは元々`Width="450"`のハードコードされた幅を持っており、スクロールバーの手前に隙間ができていました(classicテーマでは特に、テキストの折り返しがやや早すぎる問題もありました)。固定幅を廃止し、代わりに`ScrollViewer`に`Padding="14"`を指定することで修正しました — これは`OperationPending`の詳細パネルですでに実証済みの同じパターンです。
- 続いて周囲のボックス(`WhatsNewBorder`)にも幅が必要になりましたが、固定ピクセル値を指定するのは分の悪い賭けでした: `SubWindow`テンプレート自体のコンテンツマージンはテーマごとに異なり(classicでは合計32px、Fluentでは72px — Fluentのテンプレートは外側の`Border`マージンと`ContentPresenter`マージンの両方を追加するため)。classicの余裕あるレイアウトにぴったり合わせた幅を選ぶと、**Fluentテーマ下ではスクロールバーが可視領域の外にクリップされてしまいました**。明示的な幅指定と`HorizontalAlignment="Left"`を完全に削除することで修正しました — これによりボックスは既定で`Stretch`となり、各テーマのクロームが実際に残すスペースを正しく埋めるようになりました。
- このポップアップのテキストは意図的にGitHub Releasesページから直接取得**していません** — それをすると、非英語話者に生の英語を表示するか、翻訳パイプライン(リリースごとに公開する言語別JSONファイル、または機械翻訳API)を新たに構築する必要がありますが、このプロジェクトには現状どちらもありません。今後も短い、手動翻訳の要約のままとし、現バージョンのリリースノートが更新されるたびに(その場で — 値全体を置き換え、追記はしない)書き直されます。

### 新規/更新された言語キー(13言語)

| キー | 日本語の値 |
|---|---|
| `Lang.Options.Buttons.Update` | アップデート |
| `Lang.Windows.OperationPending.Tasks.Update.Done` | アップデートの準備ができました — 下の変更内容を確認して「完了」を押してください。 |
| `Lang.Windows.NoUpdateAvailable.Title` | 最新バージョンです |
| `Lang.Windows.NoUpdateAvailable.Text` | 現在、最新バージョンのModAPIを使用しています。 |
| `Lang.Windows.NoUpdateAvailable.Buttons.OK` | OK |
| `Lang.Options.Labels.UpdateVersionsTableDisabledHint` | まずゲームパスを設定してください。 |
| `Lang.Options.Labels.UpdateVersionsTableEnabledHint` | ゲームがパッチ適用されると、ModAPIは新しいバージョンを認識する必要があります。この情報を自動的に最新の状態に保つには、これをオンにしてください。 |
| `Lang.Options.Labels.UseSteamEnabledHint` / `UseSteamDisabledHint` | Steamパスの自動検出(または手動入力)が何を行うかを説明 |
| `Lang.Options.Labels.DevLogEnabledHint` / `DevLogDisabledHint` | 通常のログに対して追加される`ModAPI.dev.log`ファイルについて説明 |
| `Lang.Options.Labels.ClearLogsOnStartEnabledHint` / `ClearLogsOnStartDisabledHint` | 起動のたびに前回のログを消去するか、追記するかを説明 |
| `Lang.Options.Labels.AlwaysOnTopEnabledHint` / `AlwaysOnTopDisabledHint` | ウィンドウを常に他より前面に保つか、隠れることを許すかを説明 |
| `Lang.Windows.FirstSetup.WhatsNewTitle` | このバージョンの新機能 |
| `Lang.Windows.FirstSetup.WhatsNewText` | セクションごとの詳細な要約(■/▸/•記号) — リリースごとにその場で書き直し、現在のテキストはアプリ内で確認可能 |
| `Lang.Windows.FirstSetup.Buttons.Close` | 閉じる |
| `Lang.Mods.Welcome.Buttons.OpenWelcomePopup` | ようこそ! |

**削除**(機能していなかった「自動アップデート」機能): `Lang.Options.Labels.AutoUpdate`(上記`Lang.Options.Buttons.Update`に置き換え)、`Lang.Windows.FirstSetup.AutoUpdate`、`Lang.Windows.FirstSetup.AutoUpdateText`。

**削除**(初回起動ポップアップの再設計): `Lang.Windows.FirstSetup.Steam`、`Lang.Windows.FirstSetup.SteamText`、`Lang.Windows.FirstSetup.UpdateVersions`、`Lang.Windows.FirstSetup.UpdateVersionsText`、`Lang.Mods.Welcome.Title0`(`Lang.Mods.Welcome.Buttons.OpenWelcomePopup`に置き換え)。

---

</details>

<details>
<summary><b>v2.0.9622の変更点</b></summary>

## v2.0.9622の変更点

### バグ修正 — チェックサム計算の統一

`StartGame()`の整合性チェック(検証B)は、`FileValidator.ComputeAssemblyChecksum()`を使って自前でチェックサムを再計算していましたが、このメソッドは常に固定された2ファイル(`Assembly-CSharp` + `Assembly-CSharp-firstpass`)のみをハッシュ化します。これは、4ファイル(firstpass + 本体 + UnityScript-firstpass + UnityScript)をリンクするThe Forestのようなゲームと構造的に噛み合わず、ゲームファイルが全く改変されていなくても誤ったチェックサム不一致を報告していました。

- `Game.CheckSumGame`(`Verify()`実行時に`GenerateCheckSums()`が各ゲームの実際の`VersionsData.CheckFiles`リストに基づいてすでに正しく計算済みの値 — Green Hellは2ファイル、The Forestは4ファイルなど)を`public`として公開し、別の固定ファイルセットで再計算する代わりに`StartGame()`内で直接再利用するようにしました。
- チェックサム計算は、そのゲームが実際に必要とするファイル数に関わらず、単一の情報源(`GenerateCheckSums()`)に統一されました。

### 変更されたファイル

| ファイル | パス | 変更内容 |
|---|---|---|
| `Game.cs` | `ModAPI_Shared\Data\` | `CheckSumGame`を`protected`から`public`に変更 |
| `MainWindow.xaml.cs` | `ModAPI\Windows\` | `StartGame()`の整合性チェックが`FileValidator.ComputeAssemblyChecksum()`での再計算ではなく`targetGame.CheckSumGame`を再利用するように変更 |

---

</details>

<details>
<summary><b>v2.0.9621の変更点</b></summary>

## v2.0.9621の変更点

### 新機能

#### Steamライブラリ全体の自動検出

`FindGamePath()` は、固定の `SearchPaths` でゲームが見つからない場合、**システムに登録されているすべてのSteamライブラリ**（`libraryfolders.vdf` から一度だけ解析し、セッション中キャッシュ）も検索するようになりました。対象は現在アクティブなゲームだけでなく、対応する5ゲームすべてです。

- 新規 `Game.GetSteamLibraryFolders()` — `libraryfolders.vdf` を解析し、セッション単位で静的キャッシュ
- **Steam連携**チェックボックスでゲーティング：オフ（新規インストール時の初期値）→ 5ゲームすべてで自動検出自体をスキップし、手動設定するまでパスは空のまま。オン → 5ゲームすべてが同じ方式で一貫して検索される

#### 別ゲーム用Modの自動検出

`.mod` ファイルが間違ったゲームフォルダに置かれている場合（例：Green Hell用Modが `mods\TheForest\` にコピーされた場合）、Apply処理が静かに破損する代わりに自動で検出されるようになりました。

- `Game.CheckModGameCompatibility()`（`ApplyMods()` 内で使用）は、注入開始前に、Modが宣言するすべての `AddMethod`/`AddField`/`InjectInto` タイプが対象ゲームの実際のアセンブリに存在するかを検証します。不一致のModはそのApplyから自動的に除外され、残りは通常どおり適用されます。
- `Game.CheckModGameCompatibilityLight()` + `Game.GetCachedTypeNames()` は、Modのロード時点で同じ検査を軽量に実行します（アセンブリのバイト列をメモリに読み込み、型名だけを抽出してファイルは即座に解放）。不一致のModは、Applyを押す前からModsタブに**⚠警告バッジ**とツールチップで表示されます。
- Modが除外された場合や、結果的に何も適用されなかった場合、Start Gameは複数のポップアップを重ねて表示する代わりに、**1つに統合したポップアップ**を表示します。適用されたModが0個ならゲームは起動しません（`Game.LastAppliedModCount`）。

#### 設定タブ — 開発者ログ / 起動時にログを初期化

**Steam連携**の後、**常に最前面**の前に新しいチェックボックスが2つ追加されました：

| キー | 説明 |
|---|---|
| `Lang.Options.Labels.DevLog` | `ModAPI.dev.log`（`ModAPI.detailed.log` から改称）を有効化 — `--dev` で実行した場合と同じ状態 |
| `Lang.Options.Labels.ClearLogsOnStart` | 起動のたびに `logs\` フォルダを空にする |

`Debug.ClearLogs()` はファイルを削除する前に開いているログストリームを閉じるため、「ファイル使用中」エラーを防ぎます。

#### グローバルな未処理例外ロギング

`App.xaml.cs` はこれで `DispatcherUnhandledException`（UIスレッド）と `AppDomain.UnhandledException`（バックグラウンドスレッド）の両方をフックします。以前はログに一切痕跡を残さずアプリを落としていた例外も、プロセス終了前に種類・メッセージ・完全なスタックトレースが記録されるようになりました。

---

### 重大なバグ修正

| # | ファイル | 問題 | 修正 |
|---|---|---|---|
| 1 | `Configuration.cs` | `GetPath()` は、明示的にリセットされた（空文字列の）パスを `""` ではなく `RootPath` として解決していた（`Path.GetFullPath(RootPath + 区切り文字 + "")` が `RootPath` に正規化されるため） | 保存値が空文字列の場合、パス結合前に直接 `""` を返すように変更 |
| 2 | `MainWindow.xaml.cs` | Start Gameの検証順序が「All」フィルターと特定フィルターで異なり、より根本的な問題（Steam/ゲームパス未設定）よりも先にMod選択・ゲーム選択のポップアップが表示されることがあった | 両方の経路で「Steam → ゲームパス → Mod選択 → ゲーム選択」の順序に統一 |
| 3 | `MainWindow.xaml.cs` | Start GameのMod収集が現在のフィルターを無視していた — 見えていない別ゲームでチェックされたModもカウントされ、誤ったポップアップが表示された | Mod収集が現在のフィルターを反映するように修正、「All」のときのみ全ゲームを集計 |
| 4 | `ModsViewModel.cs` | `Mod.Mods` が `{ModId}-{バージョン}` のみでキー化されていたため、異なるゲームフォルダにある同名ファイルが衝突し、2つ目の `Load()` が呼び出されなかった | キーにGameIdを含める：`{GameId}-{ModId}-{バージョン}` |
| 5 | `ModsViewModel.cs` | #4の修正後も `UpdateMods()` は依然としてModIdのみで画面項目をグループ化しており、異なるゲームの同名Modが1つの項目に統合され、両方が同じバージョンを宣言すると `ArgumentException: An item with the same key has already been added` でクラッシュした | 画面表示のグルーピングでGameIdも比較するように修正 |
| 6 | `Game.cs` | Green Hellの `Versions.xml` の `<files>` リストに、同じ2ファイルが大文字小文字違い（`_Data`/`_data`）で二重登録されており、`CheckFiles` が大文字小文字を区別する `HashSet<string>` だったため両方がハッシュ化され、計算されたチェックサムが2倍になって整合性エラーを誤検知していた | `CheckFiles` を `StringComparer.OrdinalIgnoreCase` に変更 |
| 7 | `Game.cs` / `ModLib.cs` | `ModLib.Create()` の「古いファイル削除」ステップにロックされた `BaseModLib.dll` に対するリトライ保護がなく、`Game.CreateModLibrary()` には例外処理が一切なかった — ロック状態だとバックグラウンドスレッドでアプリ全体がクラッシュしていた | 削除ステップに10回×500msのリトライループを追加、`CreateModLibrary()` を try/catch で包む |
| 8 | `MainWindow.xaml.cs` | `ApplyMods()` が実際にはMod0個の適用で終了しても（全部除外された場合など）、本当の成功と同じ完了シグナルを送っていたため、何も改造されていない状態でゲームが起動してしまっていた | `Game.LastAppliedModCount` で「何も適用されていない」と「N個適用」を区別、0のときは起動をスキップ |
| 9 | `MainWindow.xaml.cs` | フォントサイズ変更時、起動時に保存された大きいフォントサイズを読み込むとき、設定タブへの切り替え時（`Tabs_SelectionChanged` が空だった）のいずれでもウィンドウの高さが再計算されず、大きいフォントサイズで一番下のゲームパスカードが切れていた | 3箇所すべてに高さの再計算を追加 |
| 10 | `MainWindow.xaml.cs` | `UpdateWindowHeight()` に上限がなかったため、5個のゲームパスカードを一度に展開するとウィンドウが画面全体かそれ以上のサイズになりうる問題があった | `SystemParameters.WorkArea.Height` を上限として設定 |
| 11 | `MainWindow.xaml.cs` | ゲームがインストールされているかどうかに関係なく、起動のたびに5ゲームすべてに対して無条件に `mods\`/`projects\` フォルダが作成されていた | パスが検証済みで実行ファイルが存在するゲームに対してのみフォルダを作成するように変更 |
| 12 | `Game.cs` | 保存先フォルダがまだ存在しない場合、`UpdateVersions()` が `Versions.xml` の保存に失敗する可能性があった（5つのフォルダがすべて事前コミット済みで配布されているため、これまで表面化していなかった） | 保存直前に `Directory.CreateDirectory()` でフォルダを作成 |

---

### 設定タブ — 初回起動時の初期値変更

`AutoUpdate`、`UseSteam`（Steam連携）、`UpdateVersionsTable`（最新バージョン維持）が、新規インストール時の初期値として**オフ**に変更されました（従来はオンが初期値）。この3つはサーバー側の実装がまだ完全ではないため、`DevLog`/`ClearLogsOnStart` と同様にopt-in方式になりました。

### UI

- 設定タブのチェックボックス行（`SettingsCheckboxes`）：`StackPanel` → `WrapPanel` に変更。大きいフォントサイズでラベルが切れる代わりに次の行に折り返されるようになりました。

### 新しい言語キー（13言語）

| キー | 英語の値 |
|---|---|
| `Lang.Options.Labels.DevLog` | Developer Log |
| `Lang.Options.Labels.ClearLogsOnStart` | Clear Logs on Start |
| `Lang.Windows.IncompatibleModsExcluded.Title` | Some Mods Excluded |
| `Lang.Windows.IncompatibleModsExcluded.Text` | The following mod(s) appear to be built for a different game and were excluded: {0} |
| `Lang.Windows.IncompatibleModsExcluded.OK` | OK |
| `Lang.Windows.NoModsApplied.Title` | No Mods Applied |
| `Lang.Windows.NoModsApplied.Text` | No valid mods remained to apply, so the game was not started. |
| `Lang.Windows.NoModsApplied.OK` | OK |

### 変更されたファイル

| ファイル | パス | 変更内容 |
|---|---|---|
| `MainWindow.xaml.cs` | `ModAPI\Windows\` | Start Game検証順序の統一、フィルター対応のMod収集、統合結果ポップアップ、UseSteamでゲーティングされた4ゲームのSteamライブラリ自動検出、ウィンドウ高さの修正（フォントサイズ／タブ切替／上限） |
| `MainWindow.xaml` | `ModAPI\Windows\` | 設定タブのDevLog/ClearLogsOnStartチェックボックス、`WrapPanel` |
| `Game.cs` | `ModAPI_Shared\Data\` | Steamライブラリ検索、大文字小文字を区別しない `CheckFiles`、Mod互換性検査（精密＋軽量）、`LastAppliedModCount`/`LastExcludedModsSummary`、`CreateModLibrary()` の例外処理、UseSteamでゲーティングされた自動検出 |
| `ModLib.cs` | `ModAPI_Shared\Data\` | 古いファイル削除のリトライループ |
| `Mod.cs` | `ModAPI_Shared\Data\` | `GameMismatchReason` フィールド |
| `Configuration.cs` | `ModAPI_Shared\Configurations\` | `GetPath()` の空文字列バグ修正 |
| `Debug.cs` | `ModAPI_Shared\` | `ModAPI.dev.log` への改称、`DevMode` フィールド、`ClearLogs()` |
| `App.xaml.cs` | `ModAPI\` | グローバル例外ハンドラー、`Debug.DevMode` との連携 |
| `ModsViewModel.cs` | `ModAPI\Data\ViewModels\` | ゲーム別 `Mod.Mods` キー、ゲーム別画面グルーピング、不一致バッジ、ログスパム抑制 |
| `ModViewModel.cs` | `ModAPI\Data\ViewModels\` | `HasGameMismatch`/`GameMismatchTooltip` |
| `SettingsViewModel.cs` | `ModAPI\Data\ViewModels\` | `DevLog`/`ClearLogsOnStart`、既存3チェックボックスのopt-in初期値 |
| `FirstSetup.xaml` | `ModAPI\Windows\SubWindows\` | チェックボックス3個の初期値をオフに変更 |
| `ModsExcludedWarning.xaml` / `.cs` | `ModAPI\Windows\SubWindows\` | 新規 |
| 13x `Language.XX.xaml` | `ModAPI\resources\langs\` | 新規キー8個 |

---

</details>

<details>
<summary><b>v2.0.9620の変更点</b></summary>

## v2.0.9620の変更点

### MODAPI_LangToolの追加

ModAPIの言語ファイルを管理する独立WPFツールが追加されました (`LangTool\MODAPI_LangTool.csproj`) — 詳細は上記の**Lang Tool**セクションを参照してください。

---

### バグ修正

| # | ファイル | 問題 | 修正内容 |
|---|---|---|---|
| 1 | `App.xaml.cs` | 非英語のWindowsで.NET例外メッセージにフランス語が混入する | `App()`コンストラクタの先頭で`CultureInfo.InvariantCulture`を固定 |
| 2 | `Game.cs` | `UpdateVersions()`でSSL/TLSエラー — SSL/TLSセキュアチャネルを作成できない | `ServicePointManager.SecurityProtocol`を通じてTLS 1.2を明示的に設定 |
| 3 | `MainWindow.xaml.cs` | パスが設定されているにもかかわらずGreen Hellで`GamePathNotSet`ポップアップが表示される | `App.Game.GamePath`が空 → `Configuration`から保存済みパスを読み込み |
| 4 | `ModsViewModel.cs` | `mods\TheForest\`に手動で配置したモッドファイルがリストに表示されない | ファイル名パターン検証の診断ログを追加 |
| 5 | `MainWindow.xaml.cs` | `MixedGameMods`ポップアップが複数ゲームのモッド選択をブロックする | ブロックポップアップを削除 — `SelectGameDialog`に置き換え |

---

### 新機能

#### ゲーム起動 — ゲーム選択ポップアップ (`SelectGameDialog`)

異なるゲームのモッドが選択されている場合、または**All**フィルターが有効な場合、起動をブロックする代わりにゲーム選択ポップアップが表示されます。

**発動条件:**
- `All`フィルター選択 + Start Gameクリック
- 2つ以上の異なるゲームのモッドが同時に有効化されている

**動作:**
- パスが設定され、実行ファイルが存在するゲームのみ表示
- 選択したゲームのモッドのみが適用される — 他のゲームのモッドは完全に無視される
- ポップアップ終了後、選択したゲームにラジオボタンを同期 (`SyncModGameFilterRadioButton`)

**新規ファイル**: `ModAPI\Windows\SubWindows\SelectGameDialog.xaml / .cs`

#### ゲーム整合性検証 (Releaseビルド専用、`#if !DEBUG`)

ゲーム起動前に毎回3段階の整合性検査が実行されます:

| レイヤー | 方法 | 失敗時 |
|---|---|---|
| A — PEヘッダー | `FileValidator.IsValidGameExe()` | ブロック + `GameExeCorrupted`ポップアップ |
| B — アセンブリチェックサム | MD5 → `Versions.xml`比較 | ブロック + `GameAssemblyTampered`ポップアップ |
| C — デジタル署名 | `HasDigitalSignature()` | 警告 + ユーザー選択 (`GameIntegrityWarning`) |

**新規ファイル**: `ModAPI\Windows\SubWindows\GameIntegrityWarning.xaml / .cs`

**`FileValidator.cs`に追加された新規メソッド**:
- `ComputeAssemblyChecksum(managedFolder)` — Assembly-CSharp.dllのMD5ハッシュ (firstpassが存在する場合は含む)
- `HasDigitalSignature(path)` — Authenticode署名の確認

---

### 診断ログの追加

#### `ModAPI_Shared\Data\Game.cs` — `UpdateVersions()` (12項目、Release + Debug)

| # | 段階 | 種類 | 内容 |
|---|---|---|---|
| 1 | TLS設定 | Notice | 変更前後のプロトコル |
| 2 | ダウンロード開始 | Notice | サーバーリスト |
| 3 | URL試行 | Notice | 試行中の各URL |
| 4 | ダウンロード成功 | Notice | URL、レスポンス長、使用されたプロトコル |
| 5 | WebException | Error | URL、HTTPステータス、プロトコル、詳細内容 |
| 6 | その他の例外 | Error | URL、例外の種類、詳細内容 |
| 7 | ダウンロード完了 | Notice | 成功数 / 全サーバー数 |
| 8 | 解析成功 | Notice | 変更前後のファイル数およびバージョン数 |
| 9 | 解析失敗 | Error | 例外の種類および詳細内容 |
| 10 | 保存成功 | Notice | 保存パス、全体のバージョン数/ファイル数 |
| 11 | 保存失敗 | Error | パス、例外の種類、詳細内容 |
| 12 | レスポンスなし | Error | 試行したサーバー、プロトコル |

#### `ModAPI\Data\ViewModels\ModsViewModel.cs` — `FindMods()` (7項目、`#if DEBUG`のみ)

| # | 状況 | 種類 | 内容 |
|---|---|---|---|
| 1 | スキャン開始 | Notice | Modsフォルダパス、検出された総ファイル数 |
| 2 | 既に読み込み済み | Notice | ファイル名 |
| 3 | .modファイルではない | Notice | ファイル名 |
| 4 | パターンマッチング成功 | Notice | キューに追加されたファイル名 |
| 5 | パターンマッチング失敗 | Warning | ファイル名 + 理由 + 期待される形式 |
| 6 | スキャン完了 | Notice | キュー追加数 / 全ファイル数 |
| 7 | 例外 | Error | 例外の詳細内容 |

#### `ModAPI\Windows\MainWindow.xaml.cs` — `StartGame()` (10項目、Release + Debug)

| # | 状況 | 種類 | 内容 |
|---|---|---|---|
| 1 | ポップアップ条件 | Notice | 現在のフィルター、選択されたゲームID、needGameSelect |
| 2 | 候補ゲーム | Notice | ポップアップ候補IDリスト |
| 3 | パス未設定 | Notice | ゲームをスキップ — パス未設定 |
| 4 | Configurationに存在しない | Notice | ゲームをスキップ — Configuration.Gamesに存在しない |
| 5 | インストール確認済み | Notice | ゲーム + 実行ファイルパス |
| 6 | 実行ファイルなし | Warning | ゲームをスキップ — 実行ファイルなし |
| 7 | インストール済みゲームなし | Error | 候補0件 → GamePathNotSet |
| 8 | 自動選択 | Notice | 単一候補を自動選択 |
| 9 | ユーザーキャンセル | Notice | SelectGameDialogがキャンセルされた |
| 10 | ゲーム選択 + モッド | Notice | 選択されたゲーム、収集されたモッド数/リスト |

---

### 開発者 / ユーザーログの分離 (`#if DEBUG`)

| ファイル | ログ | 理由 |
|---|---|---|
| `ModsViewModel.cs` | `Scanning mods folder`, `Skip (already loaded)`, `Skip (not .mod)`, `Queued for load`, `Scan complete` | 1秒ごとに繰り返される — 全ログの81% |
| `Game.cs` | `Modified by: SiXxKilLuR`, `Checksum:`, `Type entry:`, `Backed up:`, `Added folder to resolver`, `TLS protocol set`, `Starting version file download`, `Trying URL` | 開発者専用の内部詳細情報 |

Releaseログとして維持: ダウンロード成功/失敗、解析/保存結果、パターンマッチング失敗、例外、整合性検査結果。

---

### バージョンテーブル更新 — アーキテクチャ

#### 設計意図

```
ゲームがSteamアップデートを受信
  → Assembly-CSharp.dllが変更される
  → ModAPIがVersions.xmlの既知チェックサムを確認
  → 見つからない場合 → サーバーから最新のVersions.xmlをダウンロード
  → ModAPIの再インストールなしで新バージョンを自動登録
```

#### 連携構造

```
Settingsタブ → KeepVersionsDataチェックボックス
  → Configuration.xml: "UpdateVersions" = true/false
    → Verify() → UpdateVersions()呼び出し
      → VersionUpdateDomains[]からVersions.xmlをダウンロード
      → ローカルのconfigs\games\{GameId}\Versions.xmlを上書き
```

#### GitHub Raw URLの統合

`modapi.survivetheforest.net`のみに依存する代わりに、直接管理のためGitHub Raw URLを主要ソースとして使用します:

```csharp
public static readonly string[] VersionUpdateDomains =
{
    // GitHub — 直接管理、優先度1
    "https://raw.githubusercontent.com/FluffyFishGames/ModAPI/master/ModAPI/configs/games/{0}/Versions.xml",
    // レガシーサーバー — フォールバック、優先度2
    "http://modapi.survivetheforest.net/app/configs/games/{0}/Versions.xml",
};
```

| 項目 | 詳細内容 |
|---|---|
| デフォルト | GitHub Raw URL — プッシュ後即時反映 |
| フォールバック | レガシーサーバー — GitHubが使用できない場合 |
| パス | リポジトリ内の`ModAPI/configs/games/{GameId}/Versions.xml` |
| 変更ファイル | `ModAPI_Shared\Data\Game.cs` — `VersionUpdateDomains` |

---

### Versions.xmlの更新

| ゲーム | ファイル | 変更内容 |
|---|---|---|
| Green Hell | `configs\games\GH\Versions.xml` | チェックサム修正 (誤った大文字のSHA-256) — `2.9.5b114117`に正しいMD5を設定 |
| The Forest | `configs\games\TheForest\Versions.xml` | `1.12` (BuildID: 20229486) を追加 — 128文字のMD5チェックサム |

---

### 新規言語キー (13言語)

| キー | 英語の値 |
|---|---|
| `Lang.Windows.SelectGame.Title` | Select Game |
| `Lang.Windows.SelectGame.Message` | Select the game to launch: |
| `Lang.Windows.GameExeCorrupted.Title` | Executable Corrupted |
| `Lang.Windows.GameExeCorrupted.Text` | The game executable failed validation... |
| `Lang.Windows.GameAssemblyTampered.Title` | Game Files Tampered |
| `Lang.Windows.GameAssemblyTampered.Text` | The game assembly checksum does not match... |
| `Lang.Windows.GameNoSignature.Title` | Integrity Warning |
| `Lang.Windows.GameNoSignature.Text` | The game executable has no digital signature... |
| `Lang.Windows.GameNoSignature.Continue` | Continue Anyway |
| `Lang.Windows.GameNoSignature.Cancel` | Cancel |
| `Lang.Savegames.*` (133キー) | 12言語に英語の値を追加 (DEは既に翻訳済み) |

---

### 変更ファイル

| ファイル | パス | 変更内容 |
|---|---|---|
| `App.xaml.cs` | `ModAPI\` | 起動時に`CultureInfo.InvariantCulture`を固定 |
| `MainWindow.xaml.cs` | `ModAPI\Windows\` | SelectGameDialog、整合性検査、MixedGameMods削除、ラジオ同期、10項目ログ |
| `SelectGameDialog.xaml/.cs` | `ModAPI\Windows\SubWindows\` | 新規 |
| `GameIntegrityWarning.xaml/.cs` | `ModAPI\Windows\SubWindows\` | 新規 |
| `ModsViewModel.cs` | `ModAPI\Data\ViewModels\` | ファイル名診断ログ、#if DEBUG分離 |
| `Game.cs` | `ModAPI_Shared\Data\` | TLS 1.2、UpdateVersions 12項目ログ、GitHub URL、#if DEBUG分離 |
| `FileValidator.cs` | `ModAPI_Shared\Utils\` | `ComputeAssemblyChecksum()`、`HasDigitalSignature()` |
| 13個の`Language.XX.xaml` | `ModAPI\resources\langs\` | 10個の新規キー + 133個のSavegamesキー (合計515個、全言語一致) |
| `GH\Versions.xml` | `ModAPI\configs\games\` | チェックサム修正 |
| `TheForest\Versions.xml` | `ModAPI\configs\games\` | `1.12`を追加 |
| `LangTool\` (13ファイル) | ソリューションルート | 新規 |
| `ModAPI.sln` | ソリューションルート | LangTool登録 |

---

### 追加修正およびロギングシステムの全面刷新 (2026-06-21)

#### StartGame検証 — 全面再設計

検証順序を厳密な3段階に是正し、ゲーム選択ポップアップがパス設定の有無にかかわらず、有効化されたモッドのゲームをすべて反映するように修正しました。

| 段階 | 検査項目 | 失敗時のポップアップ |
|---|---|---|
| 1 | Steamインストールの確認 | SteamNotFound |
| 2 | 選択したゲームのパス設定 + 実行ファイルの存在確認 | GamePathNotSet |
| 3 | 選択したゲームに有効化されたモッドが1つ以上存在 | NoModSelected |

- **Allフィルター / 複数ゲームのモッド選択時** → ポップアップは有効化されたモッドがあるゲームを**パス未設定のゲームも含めて**すべて表示 — パスがないゲームを選択した際に静かにリストから外れたり無関係なエラーが出たりする代わりに、正確に`GamePathNotSet`が表示される
- **特定のゲームフィルター選択時** → 該当ゲームに対して同じ1→2→3の順序でパス/モッド検査を直接実行

#### 主要バグ修正

| # | ファイル | 問題 | 修正内容 |
|---|---|---|---|
| 1 | `Game.cs` | `UpdateVersions()`が成功した**すべての**サーバー(GitHub + レガシー)のレスポンスをマージしてしまい、両方成功した場合にチェックサムが2倍(64文字→128文字)に壊れる — `GameAssemblyTampered`の誤検知をブロックしてしまう | 最初に成功したサーバーのレスポンスのみを解析し、1か所が成功したら他のサーバーへの試行を停止 |
| 2 | `MainWindow.xaml.cs` | `DeleteMod_Click`がモッド自身のゲームではなく`App.Game`(現在有効なフィルター)を使用 — TheForestが有効な状態でGreen Hellのモッドを削除すると、無関係なManagedフォルダを探索してしまい削除が静かに失敗する | `mod.Game`(モッドが実際に属するゲームインスタンス)から配布済みDLLパスを検索するよう変更し、`GamePath`が空の場合は`Configuration`から補完 |
| 3 | `Configuration.cs` / `MainWindow.xaml.cs` | 削除したモッドを再ダウンロードすると、有効化バッジがオンのまま復元される — 削除時に永続保存された`Selected`/`Version`キーやメモリ上のViewModelキャッシュがクリアされていなかった | `Configuration.cs`に`RemoveKey()` / `RemoveKeysWithPrefix()`を追加；`DeleteMod_Click`が削除時に`ModViewModel.Selected = false`を強制設定し、`Mods.{GameId}.{ModId}.*`キーをすべて削除 |
| 4 | `ModsViewModel.cs` | 特定のゲームフィルター("All"以外)が選択された状態でモッドを削除すると、Allに切り替えて戻るまでリストに残り続けているように見える | ファイル削除検出のポーリングループで`_Mods.RemoveAt()`直後の`FilteredMods`変更通知が漏れていた — モッドが実際に削除されるたびに通知が発生するよう修正 |
| 5 | `GameIntegrityWarning.xaml.cs` / `MainWindow.xaml.cs` | 署名なし警告ポップアップの生成/表示中に例外が発生すると、ログ1行も残さずModAPIが静かに強制終了することがあった | ポップアップの生成/表示とメッセージフォーマットをtry-catchで囲み、失敗時は原因をログに記録した上でユーザーが安全に続行できるようにした (署名なしはブロック理由ではなく推奨事項のため) |

#### デジタル署名警告 — メッセージの明確化

`GameNoSignature`の文言に具体的なゲーム名が明示されるようになり、署名なしが改ざんの可能性ではなく**インディーゲームでよくあるケースであり、ゲームの進行に影響がない**ことを明確に案内するようになりました。13言語ファイルすべてで、ゲーム表示名(例: "The Forest"、"Green Hell")が入る`{0}`プレースホルダーを使用するよう更新しました。

#### ロギングシステム — 2ファイル分離

`#if DEBUG`で囲まれていた診断ログを`detailedOnly`フラグへ切り替え、`ModAPI.log`(ユーザー向け)と`ModAPI.detailed.log`(常に全件記録)に分離しました — 詳細は上記の**Log**セクションを参照してください。

#### 変更ファイル (追加分)

| ファイル | パス | 変更内容 |
|---|---|---|
| `MainWindow.xaml.cs` | `ModAPI\Windows\` | StartGame検証の再設計、DeleteMod_Clickのゲームインスタンス修正、GameIntegrityWarningのtry-catch、ゲーム表示名マッピング |
| `Game.cs` | `ModAPI_Shared\Data\` | UpdateVersionsの単一レスポンス修正 |
| `Configuration.cs` | `ModAPI_Shared\Configurations\` | `RemoveKey()`、`RemoveKeysWithPrefix()` |
| `ModsViewModel.cs` | `ModAPI\Data\ViewModels\` | 削除時の`FilteredMods`変更通知、`#if DEBUG` → `detailedOnly` |
| `ModLib.cs` | `ModAPI_Shared\Data\` | `#if DEBUG` → `detailedOnly` (25か所の呼び出し) |
| `Mod.cs` | `ModAPI\Data\` | ヘッダーXMLダンプをdetailedOnlyへ移動、チェックサム不一致の要約化 |
| `Debug.cs` | `ModAPI_Shared\` | `detailedOnly`パラメータ、二重ファイル記録、4段階ロギングガイドコメント |
| `GameIntegrityWarning.xaml/.cs` | `ModAPI\Windows\SubWindows\` | `{0}`ゲーム名プレースホルダー、try-catchによる安全処理 |
| 13個の`Language.XX.xaml` | `ModAPI\resources\langs\` | `GameNoSignature.Text`をゲーム名プレースホルダー付きで再作成 |

---


</details>

<details>
<summary><b>v2.0.9619の変更点</b></summary>

### バグ修正

- **空のバックアップフォルダによるモッド適用の中断**: `gamefiles\original\`が空 → アセンブリ読み込み前にゲームインストールパスから自動的にバックアップを生成
- **ゲームDLLファイルロック (IOException)**: バックアップが存在する場合、アセンブリリゾルバーがゲームフォルダを条件付きで除外 — `DirectoryCopy`中にCecilがファイルロックを保持することを防止
- **破損したモッドの無限再試行ループ**: 破損したヘッダーの`.mod`ファイルが1秒ごとの再スキャンループを引き起こしていた — `LoadedFiles`に登録することで再スキャンを防止
- **LF改行のモッドファイルが拒否される**: ヘッダーパーサーの`EndsWith("</Mod>\r")`がUnixスタイルの`.mod`ファイルで失敗 — `TrimEnd`を使用してCRLFとLFの両方に対応
- **小型DLLの検証失敗**: `Assembly-UnityScript-firstpass.dll` (21 KB)が`FileValidator`で拒否される — 最小アセンブリサイズを64 KBから8 KBに引き下げ
- **不要なWARNINGログ**: 未設定のゲームパスおよび初回起動時の設定キーがノイズを生成 — `GetPath`/`GetString`/`GetInt`に`silent`パラメータを追加

### 改善事項

- **0バイトダウンロードの検出**: サーバーが空の`.mod`ファイルを返した際にポップアップ通知 + 一時ファイルの整理 (`Lang.Windows.DownloadEmpty`)
- **スライダー保存のデバウンス**: `ModListWidth` / `ProjectListWidth`をピクセル変更ごとではなく、ドラッグ終了後500msに一度だけ`ui.cfg`へ保存
- **条件付きゲームフォルダ生成**: `mods/`および`projects/`フォルダをパスが設定されているゲームのみに生成 — 5つすべてを無条件に生成しない
- **ヘッダー解析の診断ログ**: `.mod`ファイルの解析失敗時に行数と内容のプレビューを表示 (トラブルシューティング用)

### 新規言語キー (13言語)

| キー | 英語の値 |
|-----|---------------|
| `Lang.Windows.DownloadEmpty.Title` | Download Failed |
| `Lang.Windows.DownloadEmpty.Text` | The downloaded mod file is empty (0 bytes). The file may not exist on the server. |
| `Lang.Windows.DownloadEmpty.Buttons.OK` | OK |

### 変更ファイル

| ファイル | パス | 変更内容 |
|---|---|---|
| `Game.cs` | `ModAPI_Shared\Data\` | バックアップ自動生成、条件付きリゾルバー、ゲームフォルダフォールバック |
| `ModLib.cs` | `ModAPI_Shared\Data\` | IncludeAssemblies/CopyAssemblies用ゲームフォルダフォールバック |
| `FileValidator.cs` | `ModAPI_Shared\Utils\` | MinAssemblyBytes 64 KB → 8 KB |
| `Configuration.cs` | `ModAPI_Shared\Configurations\` | GetPath/GetString/GetIntに`silent`パラメータ |
| `MainWindow.xaml.cs` | `ModAPI\Windows\` | 0バイトダウンロード保護、スライダーデバウンス、サイレント設定読み取り、条件付きフォルダ生成 |
| `ModsViewModel.cs` | `ModAPI\Data\ViewModels\` | 破損したモッドの再試行防止 |
| `Mod.cs` | `ModAPI\Data\` | LF/CRLFヘッダー解析、診断ログ |
| 13個の`Language.XX.xaml` | `resources\langs\` | `DownloadEmpty`ポップアップキー |

---

</details>

<details>
<summary><b>v2.0.9618の変更点</b></summary>


### MODAPI_VersionToolの追加

ワンクリックでバージョン番号を更新できる独立WPFツールが追加されました (`VersionTool\MODAPI_VersionTool.csproj`) — 詳細は上記の**Version Tool**セクションを参照してください。

- `VersionLabel.Text`がハードコードされた`Version.Descriptor`ではなく`App.Version`を参照するようになったため、リビルド後にStatusBarへ即座に反映されます。

---

</details>

<details>
<summary><b>v2.0.9617の変更点</b></summary>


### Settingsタブ — パスリセットボタンの追加

Steamインストールパスおよび各ゲームインストールパスの行に**Reset**ボタンが追加されました。

**Steamパス行**
```
[TextBox] [Browse] [Save] [Reset]
```

**ゲームパス行 (ゲームごと)**
```
[TextBox] [Browse] [Save] [Reset]
```

**リセット動作**
- 即座にパステキストボックスを初期化
- `ui.cfg`にリセットフラグを保存 (`GamePathReset_{GameId}=1`、`SteamPathReset=1`)
- 再起動後もテキストボックスは空のまま維持
- Configuration XMLが空文字列を保存しない問題を回避

**Browseの自動保存**
- 従来: Browse後に別途Saveボタンのクリックが必要
- 変更後: ファイル選択時に自動保存 — Modsタブへ切り替えた後も反映される

**新規言語キー**

| キー | 値 |
|---|---|
| `Lang.Options.Labels.PathReset` | Reset |

---

</details>

<details>
<summary><b>v2.0.9616の変更点</b></summary>

### Versions.xml — 4ゲームの追加/更新

| ゲーム | ファイルパス | BuildID | 備考 |
|---|---|---|---|
| Subnautica | `configs/games/Subnautica/Versions.xml` | `20241558` | 新規作成 |
| Raft | `configs/games/Raft/Versions.xml` | `22312909` | チェックサム更新 |
| EscapeThePacific | `configs/games/EscapeThePacific/Versions.xml` | `19000490` | 新規作成 |
| GH | `configs/games/GH/Versions.xml` | `21698250` | チェックサム更新 |

### チェックサム構成ルール

チェックサム形式は、ゲームごとの`Assembly-CSharp-firstpass.dll`の有無によって異なります。

| ゲーム | firstpass.dll | チェックサム形式 |
|---|---|---|
| GH | ✅ あり | `firstpass MD5` + `Assembly-CSharp MD5`を連結 (64文字) |
| Subnautica | ✅ あり | `firstpass MD5` + `Assembly-CSharp MD5`を連結 (64文字) |
| EscapeThePacific | ✅ あり | `firstpass MD5` + `Assembly-CSharp MD5`を連結 (64文字) |
| Raft | ❌ なし | `Assembly-CSharp MD5`のみ (32文字) |

### ゲームアップデート時のVersions.xml更新手順

既存の項目を削除せずに新しい`<version>`項目を追加します。

**ステップ1 — 新しいBuildIDを探す**
```powershell
Get-Content "C:\Program Files (x86)\Steam\steamapps\appmanifest_{AppID}.acf" | Select-String "buildid"
```

| ゲーム | AppID |
|---|---|
| Subnautica | 264710 |
| Raft | 648800 |
| EscapeThePacific | 655290 |
| GH | 815370 |

**ステップ2 — 新しいチェックサムを抽出**
```powershell
# firstpass.dllがあるゲーム (GH, Subnautica, EscapeThePacific)
Get-FileHash "...\Assembly-CSharp-firstpass.dll" -Algorithm MD5
Get-FileHash "...\Assembly-CSharp.dll" -Algorithm MD5
# → 両方のHash値を順番に連結 (firstpassを先に)

# firstpass.dllがないゲーム (Raft)
Get-FileHash "...\Assembly-CSharp.dll" -Algorithm MD5
```

**ステップ3 — Versions.xmlに項目を追加**
```xml
<version id="{new BuildID}">
    <checksum>{new checksum}</checksum>
</version>
```

---

</details>

<details>
<summary><b>v2.0.9615の変更点</b></summary>

### Settingsタブ ゲームパス展開の修正

- **カード展開の高さ**: ゲームパスカードを展開した際、入力フィールドの高さ分だけウィンドウ下部が正確に伸びるように修正
- **`UpdateWindowHeight()`の改善**: `SizeToContent.Height`の測定前に`UpdateLayout()`を呼び出す；背景テクスチャが有効な場合、4K画像の元のサイズが高さ計算に影響しないよう`TextureLayer1`を一時的に`Collapsed`に設定
- **内部Grid行の修正**: ゲームパスパネル内部Gridの最後の行を`Height="*"`から`Height="Auto"`に変更 — 不要な下部の余白を削除

---

</details>

<details>
<summary><b>v2.0.9614の変更点</b></summary>

### 最大化ボタンの動作修正

- **最大化**: `WindowState.Maximized`の代わりに`SystemParameters.WorkArea`を使用した手動最大化 — タスクバーと重ならず、現在の画面解像度に正確にフィット
- **復元**: 最大化前に`Left`、`Top`、`Width`、`Height`、`MaxWidth`を保存し、復元ボタンのクリック時に元に戻す
- **`MaxWidth`の処理**: 最大化時は`∞`に設定、通常化時は保存された値に復元

---

</details>

<details>
<summary><b>v2.0.9613の変更点</b></summary>

### 新規Themesタブ

タブの順序が以下のように変更されました:

```
Welcome → Mods → Downloads → Development → Themes → Settings
```

テーマ選択UIがSettingsタブから専用の**Themesタブ**へ移動されました。
アイコン: Segoe MDL2 Assets `&#xE790;` (パレット)

### テーマレジストリ (データ駆動型構造)

新しいテーマの追加は`App.xaml.cs`辞書に**1行**追加するだけで完了するようになりました。
すべてのswitch文が削除されました — 他の箇所のコード変更は不要です。

```csharp
// App.xaml.cs
public static readonly Dictionary<string, string> ThemeRegistry = new Dictionary<string, string>
{
    { "classic", null },
    { "light",   "FluentStylesLight.xaml" },
    { "dark",    "FluentStyles.xaml" },
    { "diablo",  "FluentStylesDiablo.xaml" },
    { "nebula",  "FluentStylesNebula.xaml" },
    { "sunset",  "FluentStylesSunset.xaml" },
    { "ocean",   "FluentStylesOcean.xaml" },
    { "nordic",  "FluentStylesNordic.xaml" },
    { "citrus",  "FluentStylesCitrus.xaml" },
    { "bloom",   "FluentStylesBloom.xaml" },
};

public static readonly List<string> ThemeIds = new List<string>(new[]
{
    "classic", "light", "dark", "diablo",
    "nebula", "sunset", "ocean", "nordic", "citrus", "bloom"
});
```

`ThemeSelector`のComboBox項目は`ThemeIds`のループから自動生成されます。
言語キー規則: `Lang.Options.Theme.{PascalCase}` (例: `Lang.Options.Theme.Nebula`)

### サポートされているテーマ

| インデックス | ID | ファイル | パレット |
|---|---|---|---|
| 0 | `classic` | `Dictionary.xaml`のみ | オリジナルModAPIテクスチャ背景 |
| 1 | `light` | `FluentStylesLight.xaml` | 明るいトーン + 青のアクセントカラー |
| 2 | `dark` | `FluentStyles.xaml` | 暗いトーン + 青のアクセントカラー (デフォルト) |
| 3 | `diablo` | `FluentStylesDiablo.xaml` | 赤 + 黒 |
| 4 | `nebula` | `FluentStylesNebula.xaml` | 暗い宇宙 |
| 5 | `sunset` | `FluentStylesSunset.xaml` | 明るい夕焼け |
| 6 | `ocean` | `FluentStylesOcean.xaml` | 暗い海 |
| 7 | `nordic` | `FluentStylesNordic.xaml` | 明るいノルディック |
| 8 | `citrus` | `FluentStylesCitrus.xaml` | 明るいシトラス |
| 9 | `bloom` | `FluentStylesBloom.xaml` | 明るい花柄 |

テーマ変更時、アプリは自動的に再起動します。(`theme.cfg`に保存)

### 背景テクスチャ機能

Themesタブの**背景テクスチャ**カードで画像を選択すると、アプリ全体の背景として適用されます。選択中のテーマに関係なく動作します。

**サポートされる入力形式**: `.png` / `.jpg` / `.jpeg`、最大50MB、4K解像度以下

**画像処理パイプライン**

```
ユーザー選択画像 (.png / .jpg / .jpeg、最大50MB、4K以下)
  ↓
JPEG Q75圧縮 (メモリバッファ)
  ↓
16バイトのマジックヘッダーを挿入
  "MODAPI" + "BG" + バージョン + パディング (FF 00 FE 00)
  ↓
resources\textures\ui_bg\bg.datとして保存 (隠しファイル属性)
  ↓
SHA-256ハッシュ → ui.cfgにTextureHashとして保存
```

**セキュリティレイヤー**

| レイヤー | 方法 | 効果 |
|---|---|---|
| マジックヘッダー | JPEG署名(FF D8 FF)の前に16バイトを付加 | 外部ビューアーでファイルを認識できない |
| 隠しファイル属性 | `FileAttributes.Hidden` | エクスプローラーからデフォルトで非表示 |
| SHA-256整合性 | 読み込み時にハッシュ検証 | 改ざん検出時に自動リセット + 警告ポップアップ |

**改ざん検出時の動作**
1. `bg.dat`を削除
2. `ui.cfg`のキー`TexturePath`、`TextureHash`、`TextureActive`をリセット
3. テキストボックスおよびトグルをリセット
4. `Lang.Windows.TextureTampered`ポップアップを表示

**ui.cfgのキー**

| キー | 値 | 説明 |
|---|---|---|
| `TexturePath` | ファイル名 (表示用) | テキストボックスに表示される元のファイル名 |
| `TextureHash` | SHA-256 16進数 | 整合性検証ハッシュ |
| `TextureActive` | `true` / `false` | 有効化状態 |

**透明度処理**

背景画像が有効化されると、UI背景は2つのレイヤーで処理されます。

- **レイヤー1 — MergedDictionariesオーバーレイ**: `{DynamicResource FluentBgBrush}`などを参照するパネルが自動的に透明になります。無効化時は単一の`Remove()`呼び出しで復元されます。

  対象キー: `FluentBgBrush`、`FluentBgSecondaryBrush`、`FluentBgTertiaryBrush`、`FluentSurfaceBrush`、`FluentCardBrush`、`FluentTabBarBrush`、`FluentBorderBrush`

- **レイヤー2 — ビジュアルツリー走査 (`WalkStyleBackgrounds`)**: Fluentテーマの`{StaticResource}`要素はレイヤー1の影響を受けないため、元の色を基に半透明ブラシを適用するためビジュアルツリーを直接走査します。

  ```
  MakeSemiTransparent(originalBrush, alpha: 100)
  // alpha 0=完全に透明、255=不透明 → 100 ≈ 39%不透明
  ```

  処理対象: `Panel` (Grid以外)、`Border`、`ListBox` / `ListView`

  除外対象: `Grid` (背景は維持、子要素は走査)、`TabPanel` (タブヘッダー保護)、`ButtonBase` / `ComboBox`、`Collapsed`要素

  復元: スタイルSetterソース → `ClearValue()`、XAMLローカル値ソース → 元のブラシを直接復元

**タブ切り替え**

WPFのTabControlはタブの内容を遅延読み込みするため、タブ変更時に`ContextIdle`優先度で`WalkStyleBackgrounds(this)`を再実行します。既に処理済みの要素は`ContainsKey`チェックによりスキップされます。

**ThemeSelectorのロック**

背景テクスチャが有効化されると、テーマセレクターの上に`ThemeSelectorOverlay`のBorderが表示され、操作をブロックします。

- XAML: `ThemeSelectorOverlay`のBorderがThemeSelectorの上に追加される (`IsHitTestVisible=True`)
- 有効時: `ThemeSelectorOverlay.Visibility = Visible`
- 無効時: `ThemeSelectorOverlay.Visibility = Collapsed`
- `_textureActive`フラグにより`ThemeSelector_SelectionChanged`も保護される

**UI状態の流れ**

```
画像選択 (Browse)
  → bg.dat生成 → トグルのロック解除 → 自動有効化 → TextureLayer1表示
  → SaveAndClearBrushes() → ThemeSelectorOverlay表示

トグル無効化
  → RestoreThemeState() → RestoreBrushes() → ThemeSelectorOverlay非表示
  → TextureLayer1非表示

Clearボタン
  → bg.dat削除 → トグルロック → TextureLayer1非表示 → ブラシ復元
  → GC.Collect() (4K画像メモリ解放)
```

**新規言語キー**

| キー | 説明 |
|---|---|
| `Lang.Options.Theme.Diablo` ~ `Lang.Options.Theme.Bloom` | 7個の新規テーマ名 |
| `Lang.Options.Labels.TextureBackground` | 背景テクスチャラベル |
| `Lang.Options.Labels.TextureEnable` | 有効化ラベル |
| `Lang.Options.Labels.TextureClear` | Clearボタン |
| `Lang.Windows.TextureTooLarge` | ファイルサイズ超過警告 |
| `Lang.Windows.TextureTampered` | 改ざん検出警告 |

**ファイル構造**

```
ModAPI\
├── App.xaml.cs                    # ThemeRegistry, ThemeIds, ApplyTheme()
├── Windows\
│   ├── MainWindow.xaml            # Themesタブ、ThemeSelectorOverlay、TextureLayer1
│   └── MainWindow.xaml.cs         # テーマ & テクスチャロジック
├── Themes\
│   ├── Dictionary.xaml            # Classicテーマ
│   ├── FluentStyles.xaml          # Darkテーマ
│   ├── FluentStylesLight.xaml     # Lightテーマ
│   ├── FluentStylesDiablo.xaml    # Diabloテーマ
│   ├── FluentStylesNebula.xaml    # Nebulaテーマ
│   ├── FluentStylesSunset.xaml    # Sunsetテーマ
│   ├── FluentStylesOcean.xaml     # Oceanテーマ
│   ├── FluentStylesNordic.xaml    # Nordicテーマ
│   ├── FluentStylesCitrus.xaml    # Citrusテーマ
│   └── FluentStylesBloom.xaml     # Bloomテーマ
└── resources\
    └── textures\
        └── ui_bg\
            └── bg.dat             # 圧縮・セキュア処理された背景画像 (ランタイム生成)
```

**既知の設計上の制約**

| 項目 | 詳細内容 |
|---|---|
| ComboBoxの`IsEnabled=false` | `ElementNotEnabledException`によるクラッシュが発生 → `IsHitTestVisible`オーバーレイ方式を使用 |
| `MergedDictionaries`キーの直接置き換え | レイアウトパス中にクラッシュ → `Add`/`Remove`パターンのみ使用 |
| 隠しファイルの上書き | `Access Denied` → 書き込み前に`FileAttributes.Normal`の再設定が必要 |
| `{StaticResource}`背景 | レイヤー1の影響を受けない → WalkStyleBackgrounds (レイヤー2)が必要 |

---

</details>

<details>
<summary><b>v2.0.9612の変更点</b></summary>

### テーマモジュールの分離

- **新規`Themes/`フォルダ**: `Dictionary.xaml`、`FluentStyles.xaml`、`FluentStylesLight.xaml`、`FluentStylesClassic.xaml`を`ModAPI\Themes\`へ移動
- **`App.xaml.cs`**: `ApplyTheme()` — Classicテーマは`Dictionary.xaml`のみを使用；Light/Dark/その他のFluentテーマは対応するXAMLを読み込み
- **`ModAPI.csproj`**: テーマXAMLパスを`Themes\`サブディレクトリへ更新；`FluentStylesClassic.xaml`を登録

---

</details>

<details>
<summary><b>v2.0.9611の変更点</b></summary>

### バグ修正

- **テーマ切り替え後にMod List幅が適用されない**: Light/Darkテーマの切り替えと再起動後にMod List幅が適用されない問題を修正 — `InitModListWidth()`内に`ApplyModListWidth(width)`呼び出しを追加

---

</details>

<details>
<summary><b>v2.0.9610の変更点</b></summary>

### 追加事項

#### ゲームXML & Versions設定

| # | ファイル | 変更内容 |
|---|------|--------|
| 1 | `GH.xml` | 全面再作成 — 存在しない`DOTweenPro.dll`を削除；`AmplifyBloom/Color/Motion.dll`、`com.rlabrecque.steamworks.net.dll`、`Unity.ProBuilder.dll`、`Unity.Postprocessing.Runtime.dll`を追加 |
| 2 | `Subnautica.xml` | 全面再作成 — `extends="GenericUnityGame"`を削除；`XGamingRuntime.dll`、`XblPCSandbox.dll`、`FMODUnity.dll`、`Newtonsoft.Json.dll`、`Unity.InputSystem.dll`、`Unity.Collections.dll`、`Unity.Burst.dll`を追加 |
| 3 | `EscapeThePacific.xml` | 全面再作成 — `extends="GenericUnityGame"`を削除；`includeAssembly` → `Assembly-CSharp.dll`のみ |
| 4 | `Raft/Versions.xml` | 作成 — チェックサム付きバージョン`1.1.01` |
| 5 | `GH/Versions.xml` | 作成 — チェックサム付きバージョン`2.9.5` |
| 6 | `Subnautica/Versions.xml` | 作成 — チェックサムなし (更新頻度が高すぎるため) |

#### 重大なバグ修正

| # | 種類 | 問題 | 修正内容 |
|---|------|-------|-----|
| 1 | ハング | `extends="GenericUnityGame"`により`Assembly-CSharp-firstpass.dll`が継承される → `CreateModLibrary`がハング | 非TheForest XMLから`extends`をすべて削除 |
| 2 | クラッシュ | Subnautica適用中に`ResolutionException: XGamingRuntime.XUserGamertagComponent` | `XGamingRuntime.dll`、`XblPCSandbox.dll`を`copyAssembly`に追加 |
| 3 | クラッシュ | バックアップ生成後に`copyAssembly`へ追加されたDLLでリゾルバーが失敗 | `Game.cs`: 実際のインストールフォルダをリゾルバーフォールバックに追加 |
| 4 | クラッシュ | `CreateModLibrary`と`ApplyMods`の間で`BaseModLib.dll`のファイルロック`IOException` | 再試行ループ: 最大10回×500ms読み取り + 最大30回×500ms存在待機 |
| 5 | クラッシュ | `NullReferenceException` — `typesMap`エントリのValueがnull (ゲーム未インストール) | `if (entry.Value == null) continue`を追加 |
| 6 | クラッシュ | `NullReferenceException` — 軽量`Game`コンストラクタに`ModLibrary = new ModLib(this)`が欠落 → `CreateModLibrary()`がクラッシュ | 軽量コンストラクタに`ModLibrary = new ModLib(this)`を追加 |
| 7 | クラッシュ | `SwitchDevGame()` — 軽量コンストラクタ後に`App.Game.GamePath`が空 → `CreateModLibrary`がクラッシュ | 軽量コンストラクタ後に`App.Game.GamePath = savedPath`を設定 |
| 8 | 誤ったゲーム | `EscapeThePacific`のモッドがTheForestとして分類される | `ModsViewModel`: フォルダパスから`GameId`を抽出 |
| 9 | 誤ったパス | `GetGameFolder()` → `""` → ドライブルートとして解釈される (例: `E:\`) | 全6箇所の呼び出し地点にnull/空値ガードを追加 |

#### Debug / Release ビルド分離

- **`FileValidator.cs`** — 新規ファイル`ModAPI_Shared\Utils\FileValidator.cs`；`ModAPI_Shared.csproj`に登録
  - `IsValidSteamExe()` — PEヘッダー (MZ + PE\0\0) + 最小1 MB
  - `IsValidGameExe()` — PEヘッダー + 最小512 KB
  - `IsValidAssemblyDll()` — PEヘッダー + .NET CLRメタデータヘッダー + 最小8 KB
- **`CheckSteam()`** — `#if DEBUG`: `File.Exists()`のみ / `#else`: `FileValidator.IsValidSteamExe()`
- **`CheckGamePath()`** — `#if DEBUG`: `File.Exists()`のみ / `#else`: `FileValidator.IsValidAssemblyDll()`
- **`ModLib.Create()` IncludeAssemblies** — `#if DEBUG`: Cecilを省略した`File.Copy()` / `#else`: 完全なCecil解析 + IL修正
- **`ModLib.Create()` ファイル未検出** — `#if DEBUG`: 警告ログを出力してスキップ / `#else`: エラーログを出力して中断

#### Debugテスト

- **`create_dummy_Debug_games.ps1`** — `bin\Debug\`用PowerShellスクリプト；5つのゲームすべてに対して`dummy_games\`、`dummy_steam\`、`gamefiles\original\`配下に0バイトのダミーファイルを生成 — 実際のゲームをインストールせずに全UIワークフローのテストが可能

#### Settingsタブ

- **Steamパスカード** — Game Installation Pathsカードに統合；`InitSteamPath()`、`SteamBrowse_Click()`、`SteamSave_Click()`
- **ゲームパスパネル** — ゲームごとの展開可能なカードを持つ`BuildGamePathsPanel()`；テキストボックスは`HorizontalAlignment=Stretch`を使用
- **Expand All / Collapse All**ボタン
- **AlwaysOnTop**チェックボックス (`ui.cfg`に保存)
- **Mod/Project List幅**スライダー — 最小値`150`から開始；`ui.cfg`に保存
- **フォントサイズ**ComboBox — FHD 10~16、4K 10~22、8K 10~28
- **チェックボックス同期** — `SettingsCheckboxes.DataContext = SettingsVm`；AutoUpdate / UseSteam / UpdateVersionsが正しく同期されるように修正
- **`_uiInitialized`フラグ** — WPF起動中の`ui.cfg`への早期書き込みを防止

#### Modsタブ — ゲーム起動検証

Start Gameクリック時、モッドリストの状態に関係なく毎回5段階の検証が実行されます:

| 段階 | 検査 | ポップアップ |
|---|---|---|
| 1 | Settingsタブ Steamパスが有効 (`Steam.exe`が存在) | SteamNotFound |
| 2 | `mods/{GameId}/`フォルダのゲームがSettingsで構成されたゲームと一致 | GameModsMismatch |
| 3 | 最低1つのモッドが選択されている | NoModSelected |
| 4 | 複数ゲームのモッドが混在選択されていない | MixedGameMods |
| 5 | ゲームパスの設定 + 実行ファイルの存在確認 | GamePathNotSet / GameNotInstalled |

#### Developmentタブ — ModLib検証

Mod Library Regenerationクリック時に3段階の検証:

| 段階 | 検査 | ポップアップ |
|---|---|---|
| 1 | Settingsタブ Steamパスが有効 | SteamNotFound |
| 2 | 最低1つのプロジェクトが存在 | NoProjectWarning |
| 3 | `App.Game.GamePath`が設定されている | GamePathNotSet |

#### Downloadsタブ
- デバッグ文字列を`Lang.Downloads.Status.NoDownloads`に置き換え
- すべてのステータスメッセージに一貫した余白を適用
- サポートされている5つのゲーム用のオフライン手動テキストを更新；2つのTextBlockで改行

#### First Setup & ゲームパスシステム
- `FirstSetup.Check()` — `UseSteam`、`AutoUpdate`、`UpdateVersions`のデフォルト値を`true`
- `FirstSetupDone()` — 5つのゲームすべてに対して`mods/`および`projects/`フォルダを作成
- `SpecifyGamePath` — `GameNameLabel`にどのゲームかを表示；`NavigateToSettings()`がSettingsタブへ遷移

#### 新規/更新された言語キー

| キー | 英語の値 |
|-----|---------------|
| `Lang.Downloads.Status.NoDownloads` | No downloadable files for this mod. |
| `Lang.Options.Labels.ModListWidth` | Mod List Width |
| `Lang.Options.Labels.ProjectListWidth` | Project List Width |
| `Lang.Options.Labels.FontSize` | Font Size |
| `Lang.Options.Labels.MaxWidth` | Max Width |
| `Lang.Development.Labels.GameFilter` | Game Filter |
| `Lang.Options.Labels.SteamPath` | Steam Installation Path |
| `Lang.Windows.SteamNotFound.Title` | Steam Not Found |
| `Lang.Windows.SteamNotFound.Text` | Steam is not installed. Please configure Steam in the Settings tab. |
| `Lang.Windows.GameModsMismatch.Title` | Game Mismatch |
| `Lang.Windows.GameModsMismatch.Text` | The game in the mods folder does not match the game configured in the Settings tab. |
| `Lang.Downloads.Offline.Manual2` | (e.g. mods/TheForest, mods/Subnautica, …) |

### 未実装の項目

| 機能 | 理由 |
|---|---|
| 自動アップデート (最新バージョンの維持) | サーバー側インフラが未構築 |
| アップデート検索 | サーバー側インフラが未構築 |

### 削除された項目

| 項目 | 理由 |
|---|---|
| 起動時の`SpecifyGamePath`ポップアップ | すべてのパスがSettingsタブで設定されるため |
| 起動時の`SpecifySteamPath`ポップアップ | SteamパスがSettingsタブで設定されるため |
| ログインシステム | 元のサーバーの運用終了 (v2.0.9400で削除) |
| `Portable.System.ValueTuple.dll` | Mono 2.0で動作しない (v2.0.9586で削除) |
| Steam検査の`UseSteam`条件 | ゲーム起動およびMod Library Regeneration時にSteamが常に最初に検証されるため |

---

</details>

<details>
<summary><b>v2.0.9600の変更点</b></summary>

### 追加事項

- **Downloadsタブ**: 5つのゲームフィルター (TheForest, Subnautica, RAFT, EscapeThePacific, GH)
- **Welcomeタブ**: 最も左の位置に追加 (インデックス0)
- **Modsタブ**: 3列レイアウト (WrapPanel → 垂直リスト)；自動幅調整；モッド名の折り返し
- **`ModsViewModel`**: ゲームごとのフィルタリング、モッドごとの正しい`Game`インスタンス用の`ResolveGame()`
- **`Game.cs`**: 軽量コンストラクタ`new Game(config, true)` — 識別専用、`Verify()`なし
- **ビルド**: 4つのゲームXMLファイルが`CopyToOutputDirectory=Always`として`ModAPI.csproj`に登録
- **ビルド**: 警告のクリーンアップ — CS0168、CS0618、CS0252
- **ゲームXML**: TheForest、Raft、GHのDLLリストを修正
- **言語の国旗**: 13言語すべてのバッジで画像サイズを標準化

### 削除された項目

| 項目 | 理由 |
|---|---|
| ゲームXMLファイルの`extends="GenericUnityGame"` | `Assembly-CSharp-firstpass.dll`が誤って継承される問題 — Subnautica、Raft、EscapeThePacific、GHから削除 |
| Modsタブの`WrapPanel`レイアウト | 3列Gridレイアウトに置き換え (Game Filter / Mod List / Information) |

---

</details>

---

## バージョン履歴

<details>
<summary><b>Phase 6-3 — テーマシステム拡張、設定改善、安定性 & ツール追加</b></summary>

### v2.0.9621 — 2026-07-28

- Steam連携チェックボックスでゲーティングされた、5ゲーム全体のSteamライブラリ全体自動検出
- 別ゲーム用に作られたModの自動検出と除外（一覧段階＋Apply時）、Modsタブに⚠バッジ表示
- 除外Mod／未適用の案内をポップアップ1つに統合（積み重ね表示を廃止）、適用Modが0個ならゲーム未起動
- グローバルな未処理例外ロギング（UIスレッド＋バックグラウンドスレッド）
- `ModAPI.detailed.log` を `ModAPI.dev.log` に置き換え、設定タブに開発者ログ／起動時ログ初期化のトグルを追加
- `AutoUpdate`/`UseSteam`/`UpdateVersionsTable` の新規インストール時初期値をオフに変更
- 修正：`Configuration.GetPath()` の空パスバグ、Start Game検証順序の不一致、フィルターを無視していたMod収集、ゲーム間の `Mod.Mods` キー衝突とそれによる `UpdateMods()` クラッシュ、Green Hellのチェックサム重複（`_Data`/`_data`）、`BaseModLib.dll` のファイルロッククラッシュ、`mods\`/`projects\` の無条件作成、フォルダ未存在時の `Versions.xml` 保存失敗、フォントサイズ変更／タブ切替時のウィンドウ高さ未再計算、全展開時のウィンドウ高さ無制限拡大

### v2.0.9620 — 2026-06-21

**MODAPI_LangToolおよび主要な修正**
- MODAPI_LangToolを追加 (独立WPF言語管理ツール)
- SSL/TLS修正 (TLS 1.2)
- フランス語混入の修正 (`CultureInfo.InvariantCulture`)
- Green Hellの`GamePathNotSet`修正
- SelectGameDialog (Allフィルター + マルチゲームモッド起動)
- MixedGameModsのブロックを削除
- 3段階のゲーム整合性検証 (PEヘッダー / アセンブリチェックサム / デジタル署名)
- 開発者/ユーザーログの分離
- UpdateVersions 12項目 + FindMods 7項目 + StartGame 10項目のログ
- GitHub Raw URLを優先適用 (`VersionUpdateDomains`)
- GHの`Versions.xml`チェックサム修正
- TheForestの`Versions.xml`に`1.12`を追加
- 13言語ファイル515キーの完全一致

**追加修正 (2026-06-21)**
- StartGame検証順序の修正 (Steam → ゲームパス → モッド)
- ゲーム選択ポップアップがパス未設定のゲームも正確に表示
- UpdateVersionsの単一レスポンス処理でチェックサム重複問題を解決
- `DeleteMod`が現在有効なフィルターではなくモッド自身のゲームインスタンスを使用
- 削除したモッドの再ダウンロード時に有効化バッジが残存する問題を解決
- ゲームフィルターの状態にかかわらずモッド削除後即座にリストを更新
- `GameIntegrityWarning`ポップアップの強制終了を防止
- デジタル署名警告メッセージにゲーム名を明示し、インディーゲームに関する案内を改善
- 2ファイルロギングシステム(`ModAPI.log` / `ModAPI.detailed.log`)へ`#if DEBUG`ログを移行 — Releaseビルドでも全診断ログを確保しつつユーザー画面はクリーンに維持

### v2.0.9619 — 2026-05-25

- ゲームインストールパスからの自動バックアップ生成
- ファイルロック修正 (条件付きリゾルバー)
- 破損モッドの無限再試行を防止
- LF改行のモッドファイルに対応
- 0バイトダウンロード検出ポップアップ
- スライダー保存のデバウンス (500ms)
- 条件付きゲームフォルダ生成
- `FileValidator`の最小アセンブリサイズを64 KB → 8 KBに変更
- `GetPath`/`GetString`/`GetInt`の`silent`パラメータ
- ヘッダー解析の診断ログ
- `DownloadEmpty`言語キー (13言語)

### v2.0.9618 — 2026-04-25
MODAPI_VersionToolを追加 (独立WPFバージョン更新ツール)、StatusBarのバージョン表示をApp.Versionに連動

### v2.0.9617 — 2026-04-24
Settingsタブに Steam/ゲームパスのリセットボタンを追加、Browseの自動保存、ui.cfgフラグによるリセット状態の保持

### v2.0.9616 — 2026-04-18
4つのゲームのVersions.xmlを作成/更新 (Subnautica, Raft, EscapeThePacific, GH)、チェックサム構成ルールを確立、ゲームアップデート手順を文書化

### v2.0.9615 — 2026-04-18
Settingsタブのゲームパスカード展開高さの精度を修正、UpdateWindowHeightの背景テクスチャ干渉を防止

### v2.0.9614 — 2026-04-18
最大化ボタンのWorkAreaベース手動最大化、以前のサイズ/位置の保存と復元

### v2.0.9613 — 2026-04-18
Themesタブを追加、テーマレジストリのデータ駆動型構造、10種類のテーマ対応、背景テクスチャ機能 (圧縮、セキュリティ、2レイヤー透明度)、ThemeSelectorロックオーバーレイ、12個の新規言語キー

### v2.0.9612 — 2026-04-18
Themes/フォルダの分離、テーマXAMLのモジュール化

### v2.0.9611 — 2026-04-18
テーマ切り替え後にMod List幅が適用されない問題を修正

</details>

<details>
<summary><b>Phase 6-2 — 設定、パスの安全化、クラッシュ修正 & Debug/Release分岐</b></summary>

### v2.0.9610 — 2026-04-13

- マルチゲームXMLの修正 (GH, Subnautica, EscapeThePacific)
- `Versions.xml`を追加
- Settingsタブの再設計 (Steamパス、ゲームパスパネル、幅スライダー、フォントサイズ、チェックボックス同期)
- ゲームパスのnull安全処理 (6箇所)
- 起動時ポップアップをSettingsタブに置き換え
- Modsタブの5段階ゲーム起動検証 (Steamを常に最初に検証)
- Devタブの3段階ModLib検証
- `GameModsMismatch`ポップアップを追加
- 軽量コンストラクタの`ModLibrary` null修正
- `SwitchDevGame`の`GamePath`修正
- `FileValidator`のPEヘッダー検証 (Release)
- `#if DEBUG`ビルド分離 (`CheckSteam` / `CheckGamePath` / `ModLib.Create`)
- `create_dummy_Debug_games.ps1`
- 永続的な`ui.cfg`
- 5段階フォントシステム
- 多数のクラッシュ修正
- 言語キーの更新

</details>

<details>
<summary><b>Phase 6-1 — マルチゲーム & Mods再設計</b></summary>

### v2.0.9600 — 2026-04-09
> 5つのゲームフィルター、Modsタブの3列レイアウト、自動幅調整、軽量`Game`コンストラクタ、`ModsViewModel`のゲームフィルタリング、4つのXMLファイルの登録、ビルド警告のクリーンアップ、Welcomeタブ、言語国旗の標準化

</details>

<details>
<summary><b>Phase 5-6B — C# 7.3 & ポリフィル</b></summary>

### v2.0.9586 — 2026-03-31
> ブラックスクリーン修正、ポリフィル確定、ValueTupleの削除、C# 7.3検証

</details>

<details>
<summary><b>Phase 5-5 — アセンブリ解決</b></summary>

### v2.0.9561 — 2026-03-06
> C# 7.3サポート、PEヘッダーパッチング、ポリフィルパイプライン、アセンブリ解決の復元

</details>

<details>
<summary><b>Phase 5-1 — Downloadsタブ & 13言語</b></summary>

### v2.0.9552 — 2026-02-25
> Downloadsタブ、アイコンの近代化、テーマの統一、13言語対応

</details>

<details>
<summary><b>初期段階</b></summary>

### Phase 3 — UI再設計 & テーマシステム
v2.0.9500
> テーマシステム (Classic/Light/Dark)、Fluent Design UI、SubWindowシステム

### Phase 4 — コード整理
v2.0.9400
> コード整理、ログイン削除、レガシーの近代化

### Phase 2 — ビルド環境 & Fluent Design
v2.0.9300
> ビルド環境、UnityEngineスタブDLL、ModernWpf統合

### Phase 1 — .NET 4.8移行
v2.0.9200
> .NET Framework 4.8への移行

### v1.x
オリジナルFluffyFishリリース

</details>

---

## ビルド要件

| 要件 | バージョン | 備考 |
|---|---|---|
| Visual Studio | 2022 | |
| .NET Framework SDK | 4.8 | ModAPIプロジェクト用 |
| .NET Framework SDK | 3.5 | BaseModLibのみ |
| ModernWpf | 0.9.6 | NuGet |
| AsyncBridge | 0.3.1 | NuGet — `libs/polyfills/` |
| TaskParallelLibrary | 1.0.2856 | NuGet — `libs/polyfills/`の`System.Threading.dll` |

---

## ライセンス

GNU General Public License v3.0 — オリジナルのライセンスに準拠します。
